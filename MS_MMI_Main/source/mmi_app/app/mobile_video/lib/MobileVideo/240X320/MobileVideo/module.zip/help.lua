﻿--@module 	help 
--@note 	帮助
--@author 	shenyi
--@date 	2010/05/27

require "module.keyCode.keyCode"
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.common.commonScroll"

--记录这一次点击哪一行
CurItemIndex = 1
LastItemIndex = 1
prevSelSprite = nil
menuindex = 0
itemCount1 = 17
itemCount2 = 6
itemCount3 = 1
titleText = {}
titleText1 = {"浏览","直播与回放","点播","音量控制、全屏、暂停、快进/退","下载播放","订购、退订","热门推荐","搜索","收藏","直播预约","播放历史","好友推荐","互动","上传","客户端设置","公告","退出"}
titleText2 = {"收费方式","免费栏目","专题","排行榜","分类栏目","品牌专区"}
titleText3 = {"关于"}
helpIndex = {}

local DownMoveExtendFlag=0		--add by yaoxiangyin 判断局部显示界面，该列表项是否为最后一项且为展开状态 1：是  0：不是
local UpMoveExtendFlag=0		--add by yaoxiangyin 判断局部显示界面，该列表项是否为第一项且为展开状态 1：是  0：不是

helpIndex1 = {"HELP_OPERATION_VIEW","HELP_OPERATION_LIVE","HELP_OPERATION_VIDEO","HELP_OPERATION_CONTROL","HELP_OPERATION_PLAY","HELP_OPERATION_ORDER","HELP_OPERATION_HOT",
"HELP_OPERATION_SEARCH","HELP_OPERATION_FAVORITE","HELP_OPERATION_BOOK","HELP_OPERATION_HISTORY","HELP_OPERATION_COMMEND","HELP_OPERATION_HUDONG","HELP_OPERATION_UPLOAD",
"HELP_OPERATION_SET","HELP_OPERATION_BUllETIN","HELP_OPERATION_EXIT"}
helpIndex2 = {"HELP_INTRO_FEES","HELP_INTRO_FREE","HELP_INTRO_SPECIAL","HELP_INTRO_TOPTEN","HELP_INTRO_CATEGORY","HELP_INTRO_BRAND"}
helpIndex3={"HELP_ABOUT"}
--@tag-action	body:BuildChildrenFinished
--@brief	创建操作说明界面
function bodyBuildChildrenFinished(sprite)
	WriteLogs("bodyBuildChildrenFinished")
	local reg = registerCreate("help")   
	registerSetInteger(reg, "root", sprite)
	local kind = registerGetString(reg,"kind")
	local root = GetRootSprite(sprite)
	if kind == "help" then
		menuindex = 1
		itemCount = itemCount1	
		titleText = titleText1
		helpIndex = helpIndex1
		setTopItem(menuindex)
		local operButton = FindChildSprite(root, "operButton")
		SetSpriteFocus(operButton)
		saveTouchFocus(operButton)
		--WriteLogs("titleText1"..titleText[1])
	elseif kind == "intro" then
		menuindex = 2
		itemCount = itemCount2
		titleText = titleText2
		helpIndex = helpIndex2
		setTopItem(menuindex)
		local funcButton = FindChildSprite(root, "funcButton")
		SetSpriteFocus(funcButton)
		saveTouchFocus(funcButton)
	elseif kind == "about" then
	    WriteLogs("about");
		menuindex = 3
		itemCount = itemCount3
		titleText = titleText3
		helpIndex = helpIndex3
		setTopItem(menuindex)
	end	
	CreateHelpList()
	if kind == "about" then
		local concernBtn = FindChildSprite(root, "concern")
		topListButtonOnKeyUp(concernBtn,ApKeyCode_Down)
		local helpList=FindChildSprite(root,"help-list")
		local firstItem=SpriteList_GetListItem(helpList, 0)
		local firstItemBtn1=FindChildSprite(firstItem,"title1")
		helpNormalButtonOnKeyUp(firstItemBtn1,ApKeyCode_Enter)
		curIndex=2
	end
	return 1
end

function backtopButtonOnSelect(sprite)
    local scroll = FindChildSprite( GetRootSprite( sprite ), "scroll")
    --scrollbarSelect( scroll, 2, 2);
	local reg = registerCreate("help")   
	local spriteRoot = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(spriteRoot, "help-list")
	local helpSprite = SpriteList_GetListItem(spriteList, 0)
	local spriteButton = FindChildSprite(helpSprite,"title1")
	titleOnSelect1(spriteButton)
end

function setTopItem(index)
	local reg = registerCreate("help")   
	local spriteRoot = registerGetInteger(reg, "root")	
	local spriteImage1=FindChildSprite(spriteRoot,"operImg")
	local spriteImage2=FindChildSprite(spriteRoot,"funcImg")
	local spriteImage3=FindChildSprite(spriteRoot,"concImg")
	local spriteText1 = FindChildSprite(spriteRoot,"opertext")
	local spriteText2 = FindChildSprite(spriteRoot,"functext")
	local spriteText3 = FindChildSprite(spriteRoot,"conctext")
	if index == 1 then
		SetSpriteVisible(spriteImage1,1)
		SetSpriteVisible(spriteImage2,0)
		SetSpriteVisible(spriteImage3,0)
		SetSpriteProperty(spriteText1,"color","#0B5495")
		SetSpriteProperty(spriteText2,"color","#CCE6F4")
		SetSpriteProperty(spriteText3,"color","#CCE6F4")
	elseif index == 2 then
		SetSpriteVisible(spriteImage1,0)
		SetSpriteVisible(spriteImage2,1)
		SetSpriteVisible(spriteImage3,0)
		SetSpriteProperty(spriteText2,"color","#0B5495")
		SetSpriteProperty(spriteText1,"color","#CCE6F4")
		SetSpriteProperty(spriteText3,"color","#CCE6F4")
	elseif index == 3 then
		SetSpriteVisible(spriteImage1,0)
		SetSpriteVisible(spriteImage2,0)
		SetSpriteVisible(spriteImage3,1)
		SetSpriteProperty(spriteText2,"color","#CCE6F4")
		SetSpriteProperty(spriteText1,"color","#CCE6F4")
		SetSpriteProperty(spriteText3,"color","#0B5495")	
	end
end

function operButtonOnSelect(sprite)
	menuindex = 1
	itemCount = itemCount1	
	titleText = titleText1
	helpIndex = helpIndex1	
	setTopItem(menuindex)
	CreateHelpList()
	local scroll = FindChildSprite( GetRootSprite( sprite ), "scroll")
    local parent = GetParentSprite(sprite)
	local name = GetSpriteName(sprite)
	WriteLogs("~~~~~~~~~~~~~name :"..name)
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	SetScrollTotalHeight(25*(itemCount-1)+125,76)
	ResetScrollBar(sprite,itemCount1)
end

function funcButtonOnSelect(sprite)
	menuindex = 2
	itemCount = itemCount2	
	titleText = titleText2	
	helpIndex = helpIndex2
	setTopItem(menuindex)	
	CreateHelpList()
	local scroll = FindChildSprite( GetRootSprite( sprite ), "scroll")
    local name = GetSpriteName(sprite)
	WriteLogs("~~~~~~~~~~~~~name :"..name)
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	SetScrollTotalHeight(25*(itemCount-1)+125,76)
	ResetScrollBar(sprite,itemCount2)
end

function concButtonOnSelect(sprite)
	menuindex = 3
	itemCount = itemCount3	
	titleText = titleText3	
	helpIndex = helpIndex3
	setTopItem(menuindex)
	CreateHelpList()
	local scroll = FindChildSprite( GetRootSprite( sprite ), "scroll")
    local name = GetSpriteName(sprite)
	WriteLogs("~~~~~~~~~~~~~name :"..name)
	local root=GetRootSprite(sprite)
	local helpList=FindChildSprite(root,"help-list")
	local firstItem=SpriteList_GetListItem(helpList, 0)
	local firstItemBtn1=FindChildSprite(firstItem,"title1")
	local firstItemBtn=FindChildSprite(firstItem,"title")
	helpNormalButtonOnKeyUp(firstItemBtn1,3)
	SetSpriteFocus(firstItemBtn)
	saveTouchFocus(firstItemBtn)
	SetScrollTotalHeight(25*(itemCount-1)+125,76)
	ResetScrollBar(sprite,itemCount3)
	curIndex=2
end

function CreateHelpList()
	prevSelSprite = nil
	local reg = registerCreate("help")   
	local spriteRoot = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(spriteRoot, "help-list")
	SpriteList_ClearListItem(spriteList, 1, 1)
	SpriteList_LoadListItem(spriteList, "MODULE:\\helpItem.xml", itemCount)	
	for i=1,itemCount do
		WriteLogs("CreatehelpList name"..i.."---"..(titleText[i]))
		local helpSprite = SpriteList_GetListItem(spriteList, i-1)	

		local spriteSelect = FindChildSprite(helpSprite,"select")
		local spriteNormal = FindChildSprite(helpSprite,"normal")
		local spriteTitleText = FindChildSprite(helpSprite,"titleBtnText")
		local spriteTitleText1 = FindChildSprite(helpSprite,"titleBtnText1")
		local spriteTextArea = FindChildSprite(helpSprite,"helpText")
		SetSpriteProperty(spriteTitleText,"text",titleText[i])
		SetSpriteProperty(spriteTitleText1,"text",titleText[i])

		require "module.setting"
		WriteLogs("helpIndex==>"..helpIndex[i]);
		local textArea = Cfg.GetHelpText(helpIndex[i])
		SetSpriteProperty(spriteTextArea,"text",textArea)
		

		SetSpriteVisible(spriteSelect, 0)
		SetSpriteEnable(spriteSelect, 0)
		SetSpriteVisible(spriteNormal, 1)			
		SetSpriteEnable(spriteNormal, 1)
		SetSpriteRect(helpSprite, 0, 0, 218, 25)		
	end
	SpriteList_Adjust(spriteList)
	HelpList=spriteList
	
	--[[  创建滚动条  ]]--
	require "module.common.commonScroll"
	CreateScrollBar(spriteRoot,"help-list",25*(itemCount-1)+125,76)
	ScrollBarAdjust(0,4,0)
end


--@function	scrollbarSelect
--@tag-name	item-scroll
--@tag-action	scroll:OnMouseDown
--@brief	用于响应滚动条鼠标点击事件
function scrollbarSelect(sprite,x,y)
	local percent = y*100/199
	WriteLogs("percent"..percent.."  x="..x.." y="..y)
	local pos = percent-23
	SetSpriteProperty(sprite,"pos",pos)
	SpriteScrollBar_Adjust(sprite)
	local RootSprite = GetRootSprite(sprite)
	local spriteList = FindChildSprite(RootSprite,"help-list")
	local l,t,w,h = GetSpriteRect(spriteList)
	local totalheight = 25*itemCount+125-25
	SetSpriteRect(spriteList,l,10-percent*(totalheight-233)/100,w,h)
end


function titleOnSelect(sprite)
	prevSelSprite = nil
	local helpSprite = GetSpriteParent(GetSpriteParent(sprite))
	local spriteSelect = FindChildSprite(helpSprite,"select")
	local spriteNormal = FindChildSprite(helpSprite,"normal")
	SetSpriteVisible(spriteSelect, 0)
	SetSpriteEnable(spriteSelect, 0)
	SetSpriteVisible(spriteNormal, 1)			
	SetSpriteEnable(spriteNormal, 1)
	SetSpriteRect(helpSprite, 0, 0, 218, 25)		
	local reg = registerCreate("help")   
	local spriteRoot = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(spriteRoot, "help-list")
	SpriteList_Adjust(spriteList)
end

function titleOnSelect1(sprite)
	local helpSprite = GetSpriteParent(GetSpriteParent(sprite))
	local spriteSelect = FindChildSprite(helpSprite,"select")
	local spriteNormal = FindChildSprite(helpSprite,"normal")
	if prevSelSprite then
		local spriteSelect1 = FindChildSprite(prevSelSprite,"select")
		local spriteNormal1 = FindChildSprite(prevSelSprite,"normal")
		SetSpriteVisible(spriteSelect1, 0)
		SetSpriteEnable(spriteSelect1, 0)
		SetSpriteVisible(spriteNormal1, 1)			
		SetSpriteEnable(spriteNormal1, 1)
		SetSpriteRect(prevSelSprite, 0, 0, 218, 25)		
	end
	prevSelSprite = helpSprite
	SetSpriteVisible(spriteSelect, 1)
	SetSpriteEnable(spriteSelect, 1)
	SetSpriteVisible(spriteNormal, 0)			
	SetSpriteEnable(spriteNormal, 0)
	SetSpriteRect(helpSprite, 0, 0, 218, 125)	
	local reg = registerCreate("help")   
	local spriteRoot = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(spriteRoot, "help-list")	
	SpriteList_Adjust(spriteList)
end


function OnSpriteEvent2(message, params)
	require("module.common.commonMsg")
	require "module.videoexpress-common"
	WriteLogs("bodyOnSpriteEvent-----------------------start----message="..message)
	--WriteLogs("message-----------message-----message-------message----message="..MSG_SMS)
	if message == MSG_SMS then
		WriteLogs("bodyOnSpriteEvent-----------------------1")
		requestMsgContent()
	WriteLogs("bodyOnSpriteEvent-----------------------3")
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
	return 1
end

function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if MSG_SMS_ID == message then			
		DealMsgContent(sceneHelp, sceneHelp)
	end
	return 1
end
--@function topListButtonOnKeyUp
--@brief 响应顶部菜单列表键盘事件
function topListButtonOnKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	WriteLogs("~~~~~~~~topListButtonOnKeyUp "..keyCode)
	local root = GetRootSprite( sprite )
	topList = FindChildSprite( root, "top-list")
	local helpList = FindChildSprite(root, "help-list")
	parentItem = GetParentSprite(sprite)
	curIndex = SpriteListItem_GetIndex(parentItem)
	WriteLogs("~~~~~~~~~index:"..curIndex)
	 callBack_OnSelect = {operButtonOnSelect, funcButtonOnSelect, concButtonOnSelect}
	 button = {"operButton", "funcButton", "concButton",}
	if keyCode == ApKeyCode_Left then
		if curIndex == 0 then return end
		local preSpriteItem = SpriteList_GetListItem(topList, curIndex-1)
		local spriteItem = FindChildSprite(preSpriteItem, button[curIndex])
		callBack_OnSelect[curIndex](spriteItem)
	elseif keyCode == ApKeyCode_Right then
		if curIndex == 2 then return end
		local nextListItem = SpriteList_GetListItem(topList, curIndex+1)
		local spriteItem = FindChildSprite(nextListItem, button[curIndex+2])
		callBack_OnSelect[curIndex+2](spriteItem)
	elseif keyCode == ApKeyCode_Down then
		local selectButton = FindChildSprite(helpList, "title")
		local normalButton = FindChildSprite(helpList, "title1")
		SetSpriteFocus(normalButton)
		saveTouchFocus(normalButton)
	elseif keyCode == ApKeyCode_CharB then
		local backtopbutton = FindChildSprite(root, "backtopbutton")
		backtopButtonOnSelect(backtopbutton)
		local listItem = FindChildSprite( helpList, "title")
		SetSpriteFocus(listItem)
		saveTouchFocus(listItem)
		ScrollBarAdjust(0,4,0)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--@brief 响应列表项展开状态下键盘按键事件
function helpSelectButtonOnKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	WriteLogs("~~~~~~~~~~~helpSelectButtonOnKeyUp "..keyCode)
	local root = GetRootSprite( sprite )
	
	local topList = FindChildSprite( root, "top-list")
	local helpList = FindChildSprite(root, "help-list")
	local listCount = SpriteList_GetListItemCount(helpList)
	local index = SpriteList_GetCurItem(helpList)
	local _, y1 = GetSpriteRect(GetParentSprite(GetParentSprite(sprite)))
	local x, y2, w, h = GetSpriteRect(helpList)
	local y = y1 + y2
	
	WriteLogs("!~~~~~~~~~~~~~y:"..y.." y1:"..y1.." y2:"..y2)
	if keyCode == ApKeyCode_Down then
		if index == (listCount-1) then return end
		local curListItem = SpriteList_GetListItem(helpList, index+1)
		local selectButton = FindChildSprite(curListItem, "title")
		local normalButton = FindChildSprite(curListItem, "title1")
		titleOnSelect(sprite)
		SetSpriteFocus(normalButton)
		saveTouchFocus(normalButton)
		---------------add by yaoxiangyin------------------------------
		if DownMoveExtendFlag==1 and index<(listCount-1) then
			list_y=list_y-25
			ChangeScrollPositon(sprite,"down")
		end
		-----------------------------------------------------------------
	elseif keyCode == ApKeyCode_Left then
		WriteLogs("IIIIIIIIIIIIIIIIIIIIII")
		if curIndex == 0 then return end
		ScrollBarAdjust(0,4,0)
		local preSpriteItem = SpriteList_GetListItem(topList, curIndex-1)
		local spriteItem = FindChildSprite(preSpriteItem, button[curIndex])
		SetSpriteRect(helpList,0,4,230,700)  --add by yaoxiangyin
		callBack_OnSelect[curIndex](spriteItem)
		return 1  --add by yaoxiangyin
	elseif keyCode == ApKeyCode_Right then
		if curIndex == 2 then return end
		ScrollBarAdjust(0,4,0)
		local nextListItem = SpriteList_GetListItem(topList, curIndex+1)
		local spriteItem = FindChildSprite(nextListItem, button[curIndex+2])
		SetSpriteRect(helpList,0,4,230,700)  --add by yaoxiangyin
		callBack_OnSelect[curIndex+2](spriteItem)
		return 1  --add by yaoxiangyin
	elseif keyCode == ApKeyCode_Up then
		if index == 0 then 
			local i = SpriteList_GetCurItem(topList)
			local curListItem = SpriteList_GetListItem(topList, i)
			local button = {"operButton", "funcButton", "concButton"}
			local item = FindChildSprite(curListItem, button[i+1])
			SetSpriteFocus(item)
			saveTouchFocus(item)
		end
		local curListItem = SpriteList_GetListItem(helpList, index-1)
		local selectButton = FindChildSprite(curListItem, "title")
		local normalButton = FindChildSprite(curListItem, "title1")
		titleOnSelect(sprite)
		SetSpriteFocus(normalButton)
		saveTouchFocus(normalButton)
		---------------add by yaoxiangyin------------------------------
		if UpMoveExtendFlag==1 and index>0 then
			list_y=list_y+25
			ChangeScrollPositon(sprite,"up")
		end
		-----------------------------------------------------------------
	elseif keyCode == ApKeyCode_Enter then
		titleOnSelect(sprite)
		local parent = GetParentSprite(GetParentSprite(sprite))
		local normalButton = FindChildSprite(parent, "title1")
		SetSpriteFocus(normalButton)
		saveTouchFocus(normalButton)
	elseif keyCode == ApKeyCode_CharB then
		SpriteScrollBar_Adjust(helpList)
		--SetSpriteRect(helpList,x,y2+moveflag,w,h)
		local backtopbutton = FindChildSprite(root, "backtopbutton")
		backtopButtonOnSelect(backtopbutton)
		SetSpriteRect(helpList,0,4,230,700)  --add by yaoxiangyin
		list_x,list_y,list_w,list_h=0,4,230,700  --add by yaoxiangyin
		local listItem = FindChildSprite( helpList, "title")
		SetSpriteFocus(listItem)
		saveTouchFocus(listItem)
		ScrollBarAdjust(0,4,0)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	WriteLogs("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
	SetSpriteRect(HelpList,list_x,list_y,list_w,list_h)
end
--@brief 响应列表未展开时键盘按键事件
function helpNormalButtonOnKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	DownMoveExtendFlag=0
	UpMoveExtendFlag=0
	list_x,list_y,list_w,list_h=GetSpriteRect(HelpList)
	require("module.keyCode.keyCode")
	WriteLogs("~~~~~~~~~~~helpNormalButtonOnKeyUp "..keyCode)
	local root = GetRootSprite( sprite )
	
	local topList = FindChildSprite( root, "top-list")
	local helpList = FindChildSprite(root, "help-list")
	local listCount = SpriteList_GetListItemCount(helpList)
	local index = SpriteList_GetCurItem(helpList)
	local _, y1 = GetSpriteRect(GetParentSprite(GetParentSprite(sprite)))
	local x, y2, w, h = GetSpriteRect(helpList)
	local y = y1 + y2
	
	WriteLogs("!~~~~~~~~~~~~~y:"..y.." y1:"..y1.." y2:"..y2)
	if keyCode == ApKeyCode_Down then
		if index == (listCount-1) then return end
		if y >= 200 then
			SpriteScrollBar_Adjust(helpList)
			SetSpriteRect(helpList,x,y2-25,w,h)
			ChangeScrollPositon(sprite,"down")
		end
		local curListItem = SpriteList_GetListItem(helpList, index+1)
		local normalButton = FindChildSprite(curListItem, "title1")
		SetSpriteFocus(normalButton)
		saveTouchFocus(normalButton)
	elseif keyCode == ApKeyCode_Left then
		WriteLogs("IIIIIIIIIIIIIIIIIIIIII")
		if curIndex == 0 then return end
		ScrollBarAdjust(0,4,0)
		local preSpriteItem = SpriteList_GetListItem(topList, curIndex-1)
		local spriteItem = FindChildSprite(preSpriteItem, button[curIndex])
		SetSpriteRect(helpList,0,4,230,700)  --add by yaoxiangyin
		callBack_OnSelect[curIndex](spriteItem)
		return 1 --add by yaoxiangyin
	elseif keyCode == ApKeyCode_Right then
		if curIndex == 2 then return end
		ScrollBarAdjust(0,4,0)
		local nextListItem = SpriteList_GetListItem(topList, curIndex+1)
		local spriteItem = FindChildSprite(nextListItem, button[curIndex+2])
		SetSpriteRect(helpList,0,4,230,700)  --add by yaoxiangyin
		callBack_OnSelect[curIndex+2](spriteItem)
	elseif keyCode == ApKeyCode_Up then
		if index == 0 then 
			local i = SpriteList_GetCurItem(topList)
			local curListItem = SpriteList_GetListItem(topList, i)
			local button = {"operButton", "funcButton", "concButton"}
			local item = FindChildSprite(curListItem, button[i+1])
			SetSpriteFocus(item)
			saveTouchFocus(item)
			curIndex=i
			return
		end
		if y < 25 then
			SpriteScrollBar_Adjust(helpList)
			SetSpriteRect(helpList,x,y2+25,w,h)
			ChangeScrollPositon(sprite,"up")
		end
		local curListItem = SpriteList_GetListItem(helpList, index-1)
		local normalButton = FindChildSprite(curListItem, "title1")
		SetSpriteFocus(normalButton)
		saveTouchFocus(normalButton)
	elseif keyCode == ApKeyCode_Enter then
		if y > (200 - 125 + 25) then
			SpriteScrollBar_Adjust(helpList)
			SetSpriteRect(helpList,x,y2-(y+125-200-25),w,h)
			ChangeScrollPositon(sprite,"down")
		end
		titleOnSelect1(sprite)
		local parent = GetParentSprite(GetParentSprite(sprite))
		local selectButton = FindChildSprite(parent, "title")
		SetSpriteFocus(selectButton)
		saveTouchFocus(selectButton)
		--------------------------add by yaoxiangyin----------------------------
		if y>=200 then
			DownMoveExtendFlag=1   
		end
		if y < 25 then
			UpMoveExtendFlag=1 
		end
		----------------------------------------------------------------------------
	elseif keyCode == ApKeyCode_CharB then
		local backtopbutton = FindChildSprite(root, "backtopbutton")
		backtopButtonOnSelect(backtopbutton)
		SetSpriteRect(helpList,0,4,230,700)  --add by yaoxiangyin
		list_x,list_y,list_w,list_h=0,4,230,700  --add by yaoxiangyin
		local listItem = FindChildSprite( helpList, "title")
		SetSpriteFocus(listItem)
		saveTouchFocus(listItem)
		ScrollBarAdjust(0,4,0)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	SpriteList_Adjust(helpList)
end

--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	require "module.common.commonScroll"
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,4,0)
	else
		ScrollBarAdjust(CurIndex + 1,4,1)
	end
end

function ResetScrollBar(sprite,itemCount)
	local spriteList=FindChildSprite(GetRootSprite(sprite),"help-list")
	local listArea=GetSpriteParent(spriteList)
	local scrollBar=FindChildSprite(GetRootSprite(spriteList),"splider-bar")
	local area_x,area_y,area_w,area_h=GetSpriteRect(listArea)
	SetSpriteRect(spriteList,0,4,230,700)
	if itemCount*25>area_h then
		SetSpriteVisible(scrollBar,1)
		SetSpriteEnable(scrollBar,1)
	else
		SetSpriteVisible(scrollBar,0)
		SetSpriteEnable(scrollBar,0)
	end
end