--
--xuya
--
require "module.setting"
require "module.keyCode.keyCode"
require "module.common.SceneUtils"
require("module.loading.useLoading")
home_FirProgressRect = {0,28,120,6}
home_SecProgressRect = {0,28,200,6}
home_ThrProgressRect = {0,28,240,6}
home_SubjectRect = {0,84,240,35}
home_ChannelRect = {0,124,240,100}
home_PairRect = {0,228,240,63}
home_LoadareaRect = {0,0,240,320}

homeData = {}
function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("home")
	registerSetInteger(reg, "root", sprite)
	local regSystem = registerCreate("System")
	http = registerGetInteger(regSystem, "comHttpPipe")
	require("module.protocol.protocol_home")
	local homeData = HomeNetworkData()
	if homeData then
		SetTimer(1, 1, "onTimerBuildSearchUrl")
		SetTimer(1, 500, "onTimerRebuild")
	end
end

function onTimerRebuild(idevent)
	local reg = registerCreate("home")
	local root = registerGetInteger(reg, "root")
	local regreload = registerCreate("homeReload")
	local progress = registerGetString(regreload,"progress")
	if idevent == 1 then
		if progress ~= "" and not Cfg.IsChannelVersion() then
			SetTimer(2, 200, "onTimerRebuild")
			if progress ~= "100" then
				local progress_node = FindChildSprite(root,"progress_node")
				SetSpriteVisible(progress_node,1)
			end
		else
			--SetTimer(1, 10000, "onTimerRebuild")
		end
	elseif idevent == 2 then
		if progress == 0 then
			SetTimer(2, 200, "onTimerRebuild")
		elseif progress == "50" then
			SetTimer(2, 200, "onTimerRebuild")
			local progress_fc = FindChildSprite(root,"homereload_fc")
			SetSpriteRect(progress_fc,home_FirProgressRect[1],home_FirProgressRect[2],home_FirProgressRect[3],home_FirProgressRect[4])
		elseif progress == "75" then
			SetTimer(3, 1000, "onTimerRebuild")
			local progress_fc = FindChildSprite(root,"homereload_fc")
			SetSpriteRect(progress_fc,home_SecProgressRect[1],home_SecProgressRect[2],home_SecProgressRect[3],home_SecProgressRect[4])
		elseif progress == "100" then
			local progress_node = FindChildSprite(root,"progress_node")
			SetSpriteVisible(progress_node,0)
		end
	elseif idevent == 3 then
		SetTimer(1, 1000, "RebuildHome")
		local progress_fc = FindChildSprite(root,"homereload_fc")
		SetSpriteRect(progress_fc,home_ThrProgressRect[1],home_ThrProgressRect[2],home_ThrProgressRect[3],home_ThrProgressRect[4])
	end
end
function RebuildHome()
	local regreload = registerCreate("homeReload")
	registerSetString(regreload,"progress","100")
	require("module.common.SceneUtils")
	require("module.common.registerScene")
	require("module.protocol.protocol_home")
	HomeNetworkData()
	local regHandle = registerCreate("SCMngr_handle");
	local SceneName = registerGetString(regHandle, string.format("%d", GetCurScene()))
	if SceneName == sceneHome then
		FreeScene(GetCurScene())
		Go2Scene(sceneHome)
	end
end
function onTimerBuildSearchUrl()
	local reg = registerCreate("home")
	local sprite = registerGetInteger(reg, "root")
	local json = registerGetInteger(reg, "HomeNetwork")
	
	homeData.searchUrl = jsonToTable(json, "searchUrl")
	require("module.protocol.protocol_search_result")
	SetSearchUrl(homeData.searchUrl)
	SetTimer(1, 1, "onTimerBuildKeywordList");
end
function onTimerBuildKeywordList()
	require("module.homeCreate")
	local reg = registerCreate("home")
	local sprite = registerGetInteger(reg, "root")
	local json = registerGetInteger(reg, "HomeNetwork")
	homeData.keyword = jsonToTable(json, "keyword")
	homeData.moreKeyUrl = jsonToTable(json, "moreKeyUrl")
	createKeywordList(sprite)

	SetTimer(1, 1, "onTimerBuildSubjectList");
end
function onTimerBuildSubjectList()
	local reg = registerCreate("home")
	local sprite = registerGetInteger(reg, "root")
	local homeSpriteList = FindChildSprite(sprite, "home")
	
	local listItem = CreateSprite("listitem")
	LoadSprite(listItem, "MODULE:\\homeSubSubject.xml")
	SetSpriteProperty(listItem, "name", "subject")
	SetSpriteRect(listItem,home_SubjectRect[1],home_SubjectRect[2],home_SubjectRect[3],home_SubjectRect[4])
	SpriteList_AddListItem(homeSpriteList, listItem, 1)
	
	local json = registerGetInteger(reg, "HomeNetwork")
	homeData.subject = jsonToTable(json, "subject")
	createSubjectList(sprite)
	
	SetTimer(1, 1, "onTimerBuildChannelList");
end
function onTimerBuildChannelList()
	local reg = registerCreate("home")
	local sprite = registerGetInteger(reg, "root")
	
	local json = registerGetInteger(reg, "HomeNetwork")
	homeData.specialChannel = jsonToTable(json, "specialChannel")
	local homeSpriteList = FindChildSprite(sprite, "home")
	local listItem = CreateSprite("listitem")
	LoadSprite(listItem, "MODULE:\\homeSubChannel.xml")
	SetSpriteProperty(listItem, "name", "channel")
	SetSpriteRect(listItem,home_ChannelRect[1],home_ChannelRect[2],home_ChannelRect[3],home_ChannelRect[4])
	SpriteList_AddListItem(homeSpriteList, listItem, 1)
	
	createChannelList(sprite)	
	SetTimer(1, 1, "onTimerBuildPairList");
end
function onTimerBuildPairList()
	local reg = registerCreate("home")
	local sprite = registerGetInteger(reg, "root")
	local json = registerGetInteger(reg, "HomeNetwork")
	homeData.channel = jsonToTable(json, "channel")
	local homeSpriteList = FindChildSprite(sprite, "home")
	local listItem = CreateSprite("listitem")
	LoadSprite(listItem, "MODULE:\\homeSubPair.xml")
	SetSpriteProperty(listItem, "name", "pair")
	SetSpriteRect(listItem,home_PairRect[1],home_PairRect[2],home_PairRect[3],home_PairRect[4])
	SpriteList_AddListItem(homeSpriteList, listItem, 1)
	createPairList(sprite)
	
	require("module.protocol.protocol_home")
	--ReleaseHomeNetworkData()
	
	local nodeLoad = CreateSprite("node", sprite)
	SetSpriteProperty(nodeLoad, "name", "loadarea")
	SetSpriteRect(nodeLoad, home_LoadareaRect[1],home_LoadareaRect[2],home_LoadareaRect[3],home_LoadareaRect[4])
	
	require("module.common.SceneUtils")
	SetTimer(1, 1, "onTimerBuildAllFile");
	
end

function onTimerBuildAllFile()
	local reg = registerCreate("home")
	local sprite = registerGetInteger(reg, "root")
	SetTimer(1, 1, "onTimerBuildMenu");
end

function onTimerBuildMenu()
	require("module.homeOnButton")
	-- 不再使用预存图片
	--SetTimer(1, 1, "onTimerUnzipGuid");
end

----@ 解压guid页面数据图片
--function onTimerUnzipGuid()
--	local src = "MODULE:\\ComSkip.dll"
--	local target = "MODULE:\\"
--	local unzip = BeginUnzip(src, target)
--	if not unzip then
--		WriteLogs("bad ZPKG file")
--	else
--		while ProcessUnzip(unzip) ~= 0 do			
--		end
--		EndUnzip(unzip)
--		WriteLogs("ZPKG file end")		
--	end
--end

function GoAndFreeScene(pathName)
	local scene = FindScene(pathName)
	SetReturn( sceneHome, pathName )
	if scene and scene ~= 0 then
		FreeScene(scene)
	end
	Go2Scene(pathName, nil)
end

function OnPluginEvent(message, Param)
	require "module.videoexpress-common"
	if message == 101 then 	--主业务界面	
		exitLoading()
		local channelData = LoadChannelGroupData()
		if channelData then
			--GoAndFreeScene("MODULE:\\guide.xml")
			GoAndFreeScene( sceneGuide )
		end
	elseif message == 101 + MSG_CACHEDATA_RELOAD then
		require("module.guidReload")
		ReloadGuidData()		
	elseif message == 102 then --列表式导航
		exitLoading()
		local jason = ChannelNetworkData()
		if jason.imgListNavi and jason.programList then
			GoAndFreeScene( sceneProduct )
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneHome, sceneHome, GetCurScene())
			Go2Scene(sceneDialog)
		end
	elseif message == 103 then --标签式导航
		exitLoading()
		local navigationData = NavigationData()
		if navigationData then
			GoAndFreeScene( sceneNavigation )
		end
	elseif message == 104 then --排行榜
		exitLoading()
		local topTenData = LoadJsonTopTenNetworkData()
		if topTenData then
			GoAndFreeScene(scenePaihang)
		end
	elseif message == 105 then --search keyword 
		exitLoading()
		require "module.protocol.protocol_menusearch"
		
		local json = OnMenuSearchDecode()
		if json ~= nil and json ~= "" then
			GoAndFreeScene(sceneSearch)
		else
		    WriteLogs(" i request the menu search, but json no data!!")
		end
	elseif message == 106 then --search result
		exitLoading()
		local json = OnSearchResultDecode()
		if json ~= nil and json ~= "" then
			--GoAndFreeScene("MODULE:\\search_result.xml")
			GoAndFreeScene(sceneSearchResult)
		else
		    WriteLogs(" i request the search, but no json data!")		
		end		
	elseif message > 32768 and message ~= MSG_SMS_ID + 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneHome, sceneHome, nil)
		Go2Scene(sceneDialog)
	elseif MSG_SMS_ID == message then			
		DealMsgContent(sceneHome, sceneHome)
	elseif message == 32768 then
		require("module.dialog.useDialog")
		require "module.common.SceneUtils"
		require "module.common.registerScene"
		local regHandle = registerCreate("SCMngr_handle");
		local SceneName = registerGetString(regHandle, string.format("%d", GetCurScene()))
		setDialogParam("提示", "拨号失败", "BT_OK", SceneName, SceneName, GetCurScene())
		dailFail = 1
		Go2Scene(sceneDialog)
	end
end

function RequestObject(channelObject)
	local typeID = channelObject.nodeDisplayType
	if typeID == "0" then 			--列表式
		require("module.protocol.protocol_channel")
		RequestChannel(102, channelObject.urlPath)
	elseif typeID == "1" then		--业务式
		require("module.protocol.protocol_channelGroup")
		RequestChannelGroup(101, channelObject.urlPath)
	elseif typeID == "2" then		--标签式
		require("module.protocol.protocol_navigation")
		RequestNavigation(103, channelObject.urlPath)
	elseif typeID == "3" then		--排列榜
		require("module.protocol.protocol_topten")
		RequestTopTen(104, channelObject.urlPath)
	end
	loadAnimation()
end

function loadAnimation()
	local reg = registerCreate("home")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	require("module.loading.useLoading")
	enterLoading(loadarea)
end

function bodyOnSpriteEvent(message, params)
	if message == MSG_SMS then
		require "module.videoexpress-common"
		requestMsgContent()
	elseif message == MSG_ACTIVATE then
		local reg = registerCreate("home")
		local root = registerGetInteger(reg, "root")
		local progress_node = FindChildSprite(root,"progress_node")
		SetSpriteVisible(progress_node,0)
		local sprite1 = FindChildSprite(root,"subject-button-0")
		saveTouchFocus(sprite1)
	elseif message == 1001 then
		if dailFail and dailFail == 1  then
			Exit()
		end
	end
end

--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.9-----------------------------]]--
--search-region区域的键盘操作
function homeCreateButtonSearchRegionKeyUp(sprite, keyCode)
	pageIndexReg= registerCreate("pageIndex")
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	homeLastFoucsReg= registerCreate("homeLastFoucs")
	registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
	registerSetNumber(homeLastFoucsReg,"lastFocusFlag",1)
	registerSetInteger(homeLastFoucsReg,"homeBackSprite",sprite)
	-----------------------------------ksw-------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-----------------------------------------------------------------------------------
	require("module.homeOnButton")	
	local parentName=GetSpriteName(GetSpriteParent(sprite))
	if keyCode==ApKeyCode_Right and parentName=="searchButton1" then
		sprite1 =FindChildSprite(FindChildSprite(GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite))),"search-button"),"searchButton2")  
		SetSpriteFocus(sprite1)
		saveTouchFocus(sprite1)
	elseif keyCode==ApKeyCode_Left and parentName=="search-button" then
		sprite1 =FindChildSprite(FindChildSprite(FindChildSprite(GetSpriteParent(GetSpriteParent(sprite)),"search-box"),"searchButton1"),"edit-text") 
		SetSpriteFocus(sprite1)
		saveTouchFocus(sprite1)
	elseif keyCode==ApKeyCode_Down then
		--search-region下边界操作
		local lastDefaultFocus
		local homeSpriteList
		if parentName=="searchButton1" then
			homeSpriteList=GetSpriteParent(GetSpriteParent(GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite)))))
			lastDefaultFocus=0
		elseif parentName=="search-button" then
			homeSpriteList=GetSpriteParent(GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite))))
			lastDefaultFocus=1
		end
		registerSetNumber(pageIndexReg,"searchItemIndex",lastDefaultFocus)
		local keywordslistSprite=FindChildSprite(FindChildSprite(homeSpriteList,"hot-keywords"),"hot-keywordslist")  --hot-keywordslist节点
		local keywordslistCount=SpriteList_GetListItemCount(keywordslistSprite)
		local nextDefaultFocus=registerGetNumber(pageIndexReg,"keyWordItemIndex")
		local defaultKeywordButton
		if nextDefaultFocus==keywordslistCount-1 then
			defaultKeywordButton=FindChildSprite(SpriteList_GetListItem(keywordslistSprite,nextDefaultFocus),"moreButton")  --设置默认选中项
		else
			defaultKeywordButton=FindChildSprite(SpriteList_GetListItem(keywordslistSprite,nextDefaultFocus),"keyword-button-"..nextDefaultFocus)  --设置默认选中项
		end
		SetSpriteFocus(defaultKeywordButton)
		saveTouchFocus(defaultKeywordButton)
	--[[elseif keyCode==ApKeyCode_Enter and GetSpriteName(sprite)=="searchButton1" then
		editTextSprite=FindChildSprite(sprite,"edit-text")
		WriteLogs("@@@@@@@@@@@"..GetSpriteName(editTextSprite))
		SetSpriteFocus(editTextSprite)]]--
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	return 0
end
-------------------------------------------------------------------------------------------------------

