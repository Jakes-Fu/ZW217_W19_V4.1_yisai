﻿--@module 	LocalFile
--@note 		本地媒体
--@author 	chengzhongjie
--@date 		2010/05/27
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.protocol.protocol_video"
require "module.Loading.useLoading"
require "module.keyCode.keyCode"
require "module.common.commonScroll"


-- ↓↓↓↓↓↓↓↓↓↓↓↓ 坐标相关 ↓↓↓↓↓↓↓↓↓↓↓↓ 
scrWidth, scrHeight 	= GetScreenSize()		--屏幕宽度 这里是240x320
lineDistance        	= 25				--行间距
lineHight_F 	    	= 45				--焦点状态下的行高
lineWidth	    	= 210				--焦点状态下红色部分的宽度
lineX		    	= 10				--焦点状态下红色部分的横坐标
lineY		    	= 2					--焦点状态下红色部分的纵坐标
dotlineY	  	= 46						--焦点状态点线的纵坐标 
dotlineHeight		= 1			--点线的高度
scrollAdjust		= 35				--滚动条的调整高度
-- ↑↑↑↑↑↑↑↑↑↑↑↑ 坐标相关 ↑↑↑↑↑↑↑↑↑↑↑↑



--全局变量
nIsChange = 0
CurForcus = 0
nIndex2 = 1 --记录上一次点击的行数
nIndex = 1 --记录这一次点击的行数


function InitLocalFileData()
	local dir = {}
	local allMovie = {}
	local allMoviePath = {}
	local count = 1
	--找到程序运行目录	
	require "module.setting"
	folder = GetModuleFolder()
	local filter = Cfg.GetFileter()
	local FlashCard = GetFlashCardName()	--存储卡路径
    --得到运行目录下的所有文件
	for n = 1 ,table.maxn(filter) do
	  local folder = GetDefaultFolder(WDFIDL_DOWNLOAD)
		dir = OpenDirectory(folder..filter[n])	
		if dir~=nil then	
			for i = 0, table.maxn(dir) do
				local isTemp = string.find(dir[i].filename,"temp_")
				if isTemp == nil then
					allMovie[count] = dir[i].filename
					allMoviePath[count] = folder..dir[i].filename
					count = count + 1
				end			
			end
		end
	

		if FlashCard then
			dir = OpenDirectory(FlashCard.."\\"..filter[n])	
			if dir~=nil then	
				for i = 0, table.maxn(dir) do
					local isTemp = string.find(dir[i].filename,"temp_")
					if isTemp == nil then
						allMovie[count] = dir[i].filename
						allMoviePath[count] = FlashCard.."\\"..dir[i].filename
						count = count + 1	
					end		
				end
			end
		end	
		
		local folder = GetDefaultFolder(WDFIDL_MYVIDIO)
		local MyVideoFolder = GetDefaultFolder(WDFIDL_MYVIDIO)		--OpenDirectory("\\My Documents\\我的视频\\")
		if MyVideoFolder ~= nil then	
			dir = OpenDirectory(MyVideoFolder..filter[n])	
			if dir~=nil then
				for i = 0, table.maxn(dir) do
					local isTemp = string.find(dir[i].filename,"temp_")
					if isTemp == nil then
						allMovie[count] = dir[i].filename
						allMoviePath[count] = MyVideoFolder..dir[i].filename
						count = count + 1	
					end		
				end
			end
		end
	end	
	return allMovie,allMoviePath
end

function buttonDownloadingBrowseOnSelect(sprite)
	local Curscene = GetCurScene()
	FreeScene(Curscene)
	Go2Scene(sceneDownloadingInfo)
end

--@function 		bodyBuildChildrenFinished
--@tag-name 		body
--@tag-action 	BuildChildrenFinished
--@brief 				xml创建完成后默认选择第一条数据
function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("localfile")
	registerSetInteger(reg,"root",sprite)
	local regVideo = registerCreate("video")
	registerSetString(regVideo, "isDownloading","")
	WriteLogs("dw")
	SetTimer( 1, 10, "StatusOnTimer")
	return 1
end

function StatusOnTimer()
	local reg = registerCreate("localfile")
	local sprite = registerGetInteger(reg,"root")
	createVideoList(sprite)
	--local RootSprite = GetRootSprite(sprite)
	--SetSpriteFocus(FindChildSprite(RootSprite,"button1"))
	--SetSpriteFocus(FindChildSprite(RootSprite,"init-item"))
	--WriteLogs("初始化项目栏"..GetSpriteName(FindChildSprite(RootSprite,"init-item")))
	
end

--@function 		createVideoList
--@tag-name 		LocalFile中，FileList
--@tag-action 	无
--@brief 				在FileList中，用于创建文件列表
function createVideoList(sprite)
	--找到列表的list段
	local ParentSprite = FindChildSprite(GetRootSprite(sprite),"FileList")	
	--local nMax = math.min(#arrData, 8)
	Movie,MoviePath = InitLocalFileData()
	if Movie == nil then 
		return 1
	end
	local filename = "MODULE:\\LocalFile_ListItem.xml"
	local count = table.maxn(Movie)
	if count==0 then
		local root = GetRootSprite(sprite)
		local empty = FindChildSprite(root, "emptybutton")
		SetSpriteFocus(empty)
		saveTouchFocus(empty)
		WriteLogs("焦点设置成功:"..HasSpriteFocus(empty))
		WriteLogs("----------------------------------------------------------------------------------")
	end
	SpriteList_LoadListItem(ParentSprite, filename, count)
	for i=1, table.maxn(Movie)  do
		--载入列表资源
		local FileListItem = SpriteList_GetListItem(ParentSprite, i-1)
		SetSpriteRect(FileListItem,0,60,scrWidth,lineDistance)--0，60，240，25
		SetSpriteProperty(FileListItem,"name","ListItem"..i)

		--找文件列表中button标签 对其重命名
		local SpriteLabel = FindChildSprite(FileListItem,"button")
		SetSpriteProperty(SpriteLabel,"name","button"..i)
		--找label1标签 并重命名、加入文件名
		local SpriteLabel = FindChildSprite(FileListItem,"label1")
		SetSpriteProperty(SpriteLabel,"name","Label1_"..i)
		SetSpriteProperty(SpriteLabel,"text",Movie[i])		
		--找label2标签 并重命名、加入文件名
		local SpriteLabel = FindChildSprite(FileListItem,"label2")
		SetSpriteProperty(SpriteLabel,"name","Label2_"..i)
		SetSpriteProperty(SpriteLabel,"text",Movie[i])
		if i==1 then
			SetSpriteFocus(FindChildSprite(FileListItem,"init-item"))
			saveTouchFocus(FindChildSprite(FileListItem,"init-item"))
		end
	end	
	
	--找第一行高度设为40
	local item1 = FindChildSprite(GetRootSprite(sprite),"ListItem1")
	SetSpriteRect(item1,0,0,scrWidth,lineDistance)--dw
	--将删除按钮显示
	local deleteSprite = FindChildSprite(item1,"delete")
	SetSpriteProperty(deleteSprite,"visible","true")
	--红色背景图高度变为40
	local BGSprite = FindChildSprite(GetRootSprite(sprite),"imageFocus")
	SetSpriteRect(BGSprite,lineX,lineY,lineWidth,lineHight_F )--dw
	--点线位置变化
	local BGSprite = FindChildSprite(GetRootSprite(sprite),"dotline")
	SetSpriteRect(BGSprite,lineX,dotlineY,lineWidth,dotlineHeight)
	--调整页面布局
	SpriteList_Adjust(ParentSprite)
	lcoalFileList=ParentSprite
	CreateScrollBar(sprite,"FileList",(count-1)*lineDistance+lineHight_F,76)
	ScrollBarAdjust(0,3,0)
end


--@function 		listitemOnSelect
--@tag-name 		LocalFile_ListItem中，文件列表按钮button[i]按下时的事件
--@tag-action 	botton:OnSelect
--@brief 				用于控制菜单的显示逻辑
function listitemOnSelect(sprite)	
	local listitem = GetParentSprite(GetParentSprite(sprite))
	if lastItem and lastItem ~= listitem then
		selectedToUnselected(lastItem)
	end
	local spriteSel=FindChildSprite(listitem,"buttonFocus")
	local spriteUnSel = FindChildSprite(listitem,"unselect")
	local playSprite = FindChildSprite(listitem,"play")
	local reg_index=registerCreate("lcoal_F_Index")
	local index = SpriteListItem_GetIndex(listitem)
	registerSetInteger(reg_index,"INDEX",index+1)
	SetSpriteVisible(spriteSel, 1)
	SetSpriteEnable(spriteSel, 1)
	SetSpriteVisible(spriteUnSel, 0)			
	SetSpriteEnable(spriteUnSel, 0)
	local x, y, w, h = GetSpriteRect(listitem)
	SetSpriteRect(listitem, x, y, 222,45)
	SetSpriteFocus(playSprite)
	saveTouchFocus(playSprite)
	SpriteList_Adjust(lcoalFileList)
	lastItem = listitem
end


function selectedToUnselected(listitem)
	local spriteSel = FindChildSprite(listitem,"buttonFocus")
	local spriteUnSel = FindChildSprite(listitem,"unselect")
	local spriteList = GetParentSprite(listitem)
	SetSpriteVisible(spriteSel, 0)
	SetSpriteEnable(spriteSel, 0)
	SetSpriteVisible(spriteUnSel, 1)
	SetSpriteEnable(spriteUnSel, 1)
	local x, y, w, h = GetSpriteRect(listitem)
	SetSpriteRect(listitem, x, y, 222,25)
	SpriteList_Adjust(lcoalFileList)
end

--@function playOnSelect
--@tag-name play
--@tag-action button:OnSelect
--@brief 播放按钮，用户发起播放请求，成功则播放
function playOnSelect(sprite)
	--local reg_index=registerCreate("lcoal_F_Index")
	--local index=registerGetInteger(reg_index,"INDEX")
	local item=GetSpriteParent(GetSpriteParent(sprite))
	index=SpriteListItem_GetIndex(item)
	SetReturn(sceneLocalFile,sceneVideolocal)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_volume")
	local root = GetRootSprite(sprite)
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	--[[  这里应该动态获取点击按钮的具体url  ]]--
	local spriteButton = GetSpriteParent(GetSpriteParent(sprite))
	local num = SpriteListItem_GetIndex(spriteButton)
	local PlayTable = {url = MoviePath, urlItem = index+1}	--dw
	RequestVideo(109, PlayTable,"","","local")
	exitLoading()
	local listSprite = GetCurScene()
	FreeScene(listSprite)
	GoAndFreeScene(sceneVideolocal)
	return 1
end


--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if message == 109 then
		local videoData = OnVideoDecode()
		WriteLogs("hit here")
		if videoData then
			exitLoading()
			local listSprite = GetCurScene()
			FreeSprite(listSprite)
			Go2Scene(sceneVideolocal)
		else
		--[[  出错提示  ]]--
		end
	elseif MSG_SMS_ID == message then			
		DealMsgContent(sceneLocalFile, sceneLocalFile)
	end
	return 1
end

function deleteOnSelect(sprite)
	require "module.dialog.useDialog"
	require "module.common.SceneUtils"
	local RootSprite = GetRootSprite(sprite)
	local spriteEvent = FindChildSprite(RootSprite,"event")
	setDialogParam("本地媒体库", "您确认要删除吗？", "BT_OK_CANCEL",sceneLocalFile ,sceneLocalFile,spriteEvent)
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	local curScene=registerSetString(SceneReg,"SceneName","LocalFile")
	Go2Scene(sceneDialog)	
end

function listitemOnLostFocus(sprite)
	local RootSprite = GetRootSprite(sprite)
	local list = FindChildSprite(RootSprite,"FileList")
	--获取当前点击行的name
	local CurButtonName = GetSpriteName(sprite)
	local strIndex = string.sub(CurButtonName,7,8)
--	--获取当前行的下标nIndex2
	 nIndex2 = tonumber(strIndex)
	--找到文件列表List
	local list = FindChildSprite(RootSprite,"FileList")
	--调整行高前先将所有行复原
--	for n = 1, #arrData+1 do
	local listitem = FindChildSprite(RootSprite,string.format("ListItem%d",nIndex2))
	SetSpriteRect(listitem,0,(nIndex2-1)*lineDistance,lineWidth,lineDistance)				--string.format("0,%d,205,25",(nIndex2-1)*25)
	--将所有的按钮高度变为25	
	local buttonSprite = FindChildSprite(RootSprite,string.format("button%d",nIndex2))
	SetSpriteRect(buttonSprite,0, 0, lineWidth, lineDistance)						--string.format("0,0,210,25",(nIndex2-1)*25)
	SpriteList_Adjust(list)
end

function OnSpriteEvent_LocalFile(message, params)
	local reg_index=registerCreate("lcoal_F_Index")
	local index=registerGetInteger(reg_index,"INDEX")
	if message == 1001 then	
		filename = MoviePath[index] --dw
		os.remove (filename)
		local Curscene = GetCurScene()
		FreeScene(Curscene)
		Go2Scene(sceneLocalFile)
		
	elseif message == 1002 then
		--local Curscene = GetCurScene()
		--FreeScene(Curscene)
		--Go2Scene(sceneLocalFile)
	end
end

function OnSpriteEvent2(message, params)
	require("module.common.commonMsg")
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	elseif message == MSG_ACTIVATE then
		local reg = registerCreate("localfile")
		local root=registerGetInteger(reg,"root")
		local defaultSprite=FindChildSprite(root,"init-item")
		if defaultSprite~=0 then
			saveTouchFocus(defaultSprite)
		else
			saveTouchFocus(FindChildSprite(root,"emptybutton"))
		end
	end
	return 1
end

function emptyBtKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	WriteLogs("keyCode:"..keyCode)
	if keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode== ApKeyCode_Left then
		buttonDownloadingBrowseOnSelect(sprite)
	end
	return 0
end

function LocalFileKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	local itemCount=SpriteList_GetListItemCount(lcoalFileList)
	WriteLogs("itemCount="..itemCount)
	local item=GetSpriteParent(GetSpriteParent(sprite))
	index=SpriteListItem_GetIndex(item)
	local reg_index=registerCreate("lcoal_F_Index")
	registerSetInteger(reg_index,"INDEX",index+1)
	local spriteSel=FindChildSprite(item,"buttonFocus")
	local spriteUnSel = FindChildSprite(item,"unselect")
	local focusSprite = FindChildSprite(spriteSel,"play")
	local deleteSprite=FindChildSprite(spriteSel,"delete")
	local name = GetSpriteName(sprite)
	local initItem=FindChildSprite(FindChildSprite(item,"unselect"),"init-item")
	local list_x, list_y2, list_w, list_h = GetSpriteRect(lcoalFileList)
	local _, list_y1 = GetSpriteRect(item)
	local list_y = list_y1+list_y2
	WriteLogs("当前结点："..GetSpriteName(focusSprite))
	WriteLogs("当前index:"..index)
	WriteLogs("@@@@@@@@@@@@@@@@@@@@@@::"..keyCode)
	local i=1
	if	keyCode==ApKeyCode_Enter then
		if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
			WriteLogs("Enter 当前index"..index)
			SetSpriteVisible(spriteSel, 1)
			SetSpriteEnable(spriteSel, 1)
			SetSpriteVisible(spriteUnSel, 0)			
			SetSpriteEnable(spriteUnSel, 0)
			SetSpriteFocus(focusSprite)
			saveTouchFocus(focusSprite)
			WriteLogs("焦点Sucess："..HasSpriteFocus(focusSprite))
			local x, y, w, h = GetSpriteRect(item)
			SetSpriteRect(item, x, y, 222,45)
			SpriteList_Adjust(lcoalFileList)
			lastItem = item
		elseif GetSpriteName(GetSpriteParent(sprite))=="buttonFocus" then
			if GetSpriteName(sprite)=="play" then playOnSelect(sprite)
			elseif GetSpriteName(sprite)=="delete" then deleteOnSelect(sprite)
			-----------------------------------ksw-------------------------------------------
			local ToDigReg = registerCreate("ToDigReg")
			registerSetInteger(ToDigReg,"ToDigFocus",sprite)
			----------------------------------------------------------------------------------
			end
		end
				if list_y >=195 then
				SpriteScrollBar_Adjust(lcoalFileList)
				SetSpriteRect(lcoalFileList,list_x, list_y2-lineDistance,list_w, list_h)
				---------------------------modified 10.27-----------------
				ChangeScrollPositon(sprite,"down")
				----------------------------------------------------------
		end
	elseif keyCode == ApKeyCode_Left then
		if name=="play" or name=="init-item" or name=="delete"  then
			--[[
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)	
			SetSpriteFocus(initItem)
			saveTouchFocus(initItem)
			WriteLogs("焦点Sucess："..HasSpriteFocus(initItem))
			local x, y, w, h = GetSpriteRect(item)
			SetSpriteRect(item, x, y, 222,25)
			SpriteList_Adjust(lcoalFileList)
			]]--
			buttonDownloadingBrowseOnSelect(sprite)
		end
	elseif keyCode == ApKeyCode_Right then
			if name=="delete" then
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)	
			initItem=FindChildSprite(FindChildSprite(item,"unselect"),"init-item")
			WriteLogs("初始焦点："..GetSpriteName(initItem))
			SetSpriteFocus(initItem)
			saveTouchFocus(initItem)
			WriteLogs("焦点Sucess："..HasSpriteFocus(initItem))
			local x, y, w, h = GetSpriteRect(item)
			SetSpriteRect(item, x, y, 222,25)
			SpriteList_Adjust(lcoalFileList)
		end
	elseif keyCode==ApKeyCode_Down  and index<=itemCount-1 then
			
		if name=="play" then
			SetSpriteFocus(FindChildSprite(GetParentSprite(sprite),"delete"))
			saveTouchFocus(FindChildSprite(GetParentSprite(sprite),"delete"))
		elseif name=="init-item" then
				if index==itemCount-1 then return 0 end
				local nextListItem = SpriteList_GetListItem(lcoalFileList, index+1)	
				SetSpriteFocus(FindChildSprite(nextListItem,"init-item"))
				saveTouchFocus(FindChildSprite(nextListItem,"init-item"))
		elseif name=="delete" then
				if index==itemCount-1 then return 0 end
					local nextListItem = SpriteList_GetListItem(lcoalFileList, index+1)
					
					WriteLogs("下焦点："..SpriteListItem_GetIndex(nextListItem))
					SetSpriteVisible(spriteSel, 0)
					SetSpriteEnable(spriteSel, 0)
					SetSpriteVisible(spriteUnSel, 1)			
					SetSpriteEnable(spriteUnSel, 1)		
					local x, y, w, h = GetSpriteRect(item)							
					SetSpriteRect(item, x, y, 222,25)
					local spriteSelNext = FindChildSprite(nextListItem,"buttonFocus")
					local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
					SetSpriteVisible(spriteSelNext, 0)
					SetSpriteEnable(spriteSelNext, 0)
					SetSpriteVisible(spriteUnSelNext, 1)			
					SetSpriteEnable(spriteUnSelNext, 1)		
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"init-item" ))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"init-item" ))
					lastItem = nextListItem
					SpriteList_Adjust(lcoalFileList)
		end		
			if list_y >= 195 then
				SpriteScrollBar_Adjust(lcoalFileList)
				SetSpriteRect(lcoalFileList,list_x, list_y2-lineDistance,list_w, list_h)
				---------------------------modified 10.27-----------------
				ChangeScrollPositon(sprite,"down")
				----------------------------------------------------------
			end
		
		elseif 	keyCode==ApKeyCode_Up  then
				if index==0 and name=="play"then return 0 
				elseif index==0 and name=="delete" then 
				SetSpriteFocus(FindChildSprite(GetParentSprite(sprite),"play")) 
				saveTouchFocus(FindChildSprite(GetParentSprite(sprite),"play"))
				return 0
				elseif index==0 then return 0
				end
				if name=="delete" then
					SetSpriteFocus(FindChildSprite(GetParentSprite(sprite),"play"))
					saveTouchFocus(FindChildSprite(GetParentSprite(sprite),"play"))
				elseif name=="init-item" then
					if index==0 then return 0 end
					local nextListItem = SpriteList_GetListItem(lcoalFileList, index-1)	
					SetSpriteFocus(FindChildSprite(nextListItem,"init-item"))
					saveTouchFocus(FindChildSprite(nextListItem,"init-item"))
				elseif name=="play" then
					if index==0 then return 0 end
						local nextListItem = SpriteList_GetListItem(lcoalFileList, index-1)
						
						WriteLogs("上焦点："..SpriteListItem_GetIndex(nextListItem))
						SetSpriteVisible(spriteSel, 0)
						SetSpriteEnable(spriteSel, 0)
						SetSpriteVisible(spriteUnSel, 1)			
						SetSpriteEnable(spriteUnSel, 1)		
						local x, y, w, h = GetSpriteRect(item)							
						SetSpriteRect(item, x, y, 222,25)
						local spriteSelNext = FindChildSprite(nextListItem,"buttonFocus")
						local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
						SetSpriteVisible(spriteSelNext, 0)
						SetSpriteEnable(spriteSelNext, 0)
						SetSpriteVisible(spriteUnSelNext, 1)			
						SetSpriteEnable(spriteUnSelNext, 1)		
						SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"init-item" ))
						saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"init-item" ))
						lastItem = nextListItem
						SpriteList_Adjust(lcoalFileList)
				end		
				if list_y <= 10 then
					SpriteScrollBar_Adjust(lcoalFileList)
					SetSpriteRect(lcoalFileList,list_x, list_y2+lineDistance,list_w, list_h)
					---------------------------modified 10.27-----------------
					ChangeScrollPositon(sprite,"up")
					----------------------------------------------------------
				end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)	
	end
end

--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	WriteLogs("liuchaobing test spriteitem name is "..GetSpriteName(spriteitem))
	WriteLogs("liuchaobing test spriteitem index is "..CurIndex)
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,4,0)
	else
		ScrollBarAdjust(CurIndex + 1,4,1)
	end
end
