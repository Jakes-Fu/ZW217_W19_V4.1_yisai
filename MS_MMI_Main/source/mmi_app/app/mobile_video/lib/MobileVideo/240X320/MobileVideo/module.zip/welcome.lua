--
require "module.protocol.clientInit"
require "module.common.registerScene"
require "module.protocol.protocol_login"
require "module.protocol.protocol_home"
require "module.debug.printDbg"
require "module.videoexpress-common"
require "module.common.SceneUtils"

local MSG_CONTENT_REQUEST = "http://c2.cmvideo.cn/sup/msp/qryMsg.msp?msgId="
function progressOnTick(sprite)
	local reg = registerCreate("welcome")
	local n = registerGetInteger(reg, "status2")
	if n == 1 then
		SetSpriteVisible(sprite, 1)
		local l,t,w,h = GetSpriteRect(sprite)
		l = l + 2
		if l >= 0 then
			l = -112
		end
		SetSpriteRect(sprite, l, t, w, h)
		return 1
	elseif n == 2 then
		SetSpriteVisible(sprite, 0)
	end
end

--设置状态信息
function SetStatusText(text)
	local reg = registerCreate("welcome")
	local labelStatus1 = registerGetInteger(reg, "status1")
	SetSpriteProperty(labelStatus1, "text", text)
end

--设置状态信息
function SetBottomStatusText(text)
	local reg = registerCreate("welcome")
	local labelStatus2 = registerGetInteger(reg, "statusB")
	SetSpriteProperty(labelStatus2, "text", text)
end

function bodyBuildChildrenFinished(sprite)
	require "module.protocol.protocol_downloadinfor"
	local spaceh, spacel = GetLocalSpace()
	local space = spaceh*4294967296 + spacel
	if space < 5120 then
		SetTimer(1,500,"NotEnoughMemory")
		return
	end
	--滚动对象
	WelcomeReg = registerCreate("WelcomeReg")
	registerSetInteger(WelcomeReg,"WelcomeFlag",1)
	local labelStatus1 = FindChildSprite(sprite, "status-forground")
	local labelStatus2 = FindChildSprite(sprite, "status-bottom")
	local welcomeExit  = FindChildSprite(sprite, "back")
	local reg = registerCreate("welcome")
	registerSetInteger(reg, "status1", labelStatus1)
	registerSetInteger(reg, "statusB", labelStatus2)
	registerSetInteger(reg, "welcomeExit", welcomeExit)
	--进度对象
	local spriteProgress = FindChildSprite(sprite, "status-progress")
	registerSetInteger(reg, "spriteProgress", spriteProgress)
	--通信组件
	local regSystem = registerCreate("System")
	http = pluginCreate("HttpPipe")
	registerSetInteger(regSystem, "comHttpPipe", http)

	registerSetInteger(reg, "status2", 1)
	--连接网络中
	--网络请求Login or Client
	local uuid = Cfg.GetUUID()
	if uuid ~= nil and uuid ~= "" then
		SetStatusText("登录中...")
		RequestLogin(102, uuid)
	else
		SetStatusText("初始化中...")
		RequestClientInit(101)
	end
	return 1
end

function NotEnoughMemory()
	require("module.dialog.useDialog")
	local curScene = GetCurScene()
	local reg = registerCreate("welcome")
	registerSetInteger(reg, "network-status", 1)
	local pathName = "MODULE:\\welcome.xml"
	setDialogParam("提示", "手机剩余空间不足，请保留大于5M空间后，再次尝试启动。", "BT_OK", pathName,pathName,curScene, 1)
	Go2Scene("MODULE:\\dialog.xml", 1)
end

function OnTimer(idEvent)
	if idEvent == 999 then
		SetWelcomeText("")
	end
	if idEvent == 1000 then
		local curScene	= FindScene("MODULE:\\welcome.xml")
		if curScene == GetCurScene() then 
			require "module.common.SceneUtils"
			Go2Scene("MODULE:\\welcomeNew_1.xml",1)
		end
	end
	if idEvent == 2000 then
		if isRecommendMsg() then
			requestMsgContent()
		end
		Go2Scene(sceneGuide, nil)
	end
end

function SetWelcomeText(text)
	local reg_w = registerCreate("welcomeNew")
	registerSetString(reg_w, "text", text)
	local root = registerGetInteger(reg_w, "root")
	if root then
		local textlabel = FindChildSprite(root,"status-forground")
		SetSpriteProperty(textlabel,"text",text)
	end
end

function SavePhoneNumAfterLogin(loginInfo)
	if ( loginInfo and loginInfo.Phone ) then
		Cfg.SavePhoneNum( loginInfo.Phone )
	else
		WriteLogs("SavePhoneNumAfterLogin failed!")
	end
end

function OnPluginEvent(message, param)
	if message - MSG_NETWORK_ERROR > 100 and message - MSG_NETWORK_ERROR ~= 113 and message - MSG_NETWORK_ERROR ~= 109 then
		OnNetworkError()
	elseif message == MSG_SMS_ID then --获得短信内容
		--弹出提示对话框
		if Cfg.IsChannelVersion() and loginInfo.channelDataUrl ~= "" and Cfg.GetEntryPage() == "home" then
			WriteLogs("recommend msg MSG_SMS_ID")
			require "module.protocol.protocol_videoexpress"
			local json = OnMessageContentDecode()
			if nil == json then
				return
			else
				--CancelTimer(1000)
				local reg_System = registerCreate("System")
				registerSetString(reg_System, "isToExit", "true")
				DealMsgContent(sceneGuide, sceneGuide)
			end
		else
			WriteLogs("recommend msg MSG_SMS_ID")
			require "module.protocol.protocol_videoexpress"
			local json = OnMessageContentDecode()
			if nil == json then
				return
			else
				--CancelTimer(1000)
				local reg_System = registerCreate("System")
				registerSetString(reg_System, "isToExit", "true")
				local regHandle = registerCreate("SCMngr_handle");
				local SceneName = registerGetString(regHandle, string.format("%d", GetCurScene()))
				if SceneName then
					DealMsgContent(SceneName, SceneName)
				else
					DealMsgContent(sceneWelcome, sceneWelcome)
				end
			end
		end
	elseif message == 101 then
		local uuid = OnPipeClientInitDecode()
		if uuid then
			require "module.setting"
			Cfg.SetUUID( uuid , true )
			RequestLogin(102, uuid)
		else
			OnNetworkError()
		end
	elseif message == 102 then
		SetWelcomeText("登录中...")
		SetStatusText("登录中...")
		loginInfo, updateInfo = OnPipeLoginDecode()
		RequestWelcomeNew(104,loginInfo.welcomeUrl)
		SavePhoneNumAfterLogin( loginInfo )
		if updateInfo and checkUpdate() then
			return
		else
			if isRecommendMsg() then
				hideExitAndStatus()
				local returnValue = requestMsgContent()
				if returnValue == 0 then
					if not (Cfg.IsChannelVersion()) then
						SetTimer(1000,3000,"OnTimer")
					end
					if Cfg.IsChannelVersion() and Cfg.GetEntryPage() == "welcomeNew" then
						SetTimer(1000,3000,"OnTimer")
					end
				end
			else
				if not (Cfg.IsChannelVersion()) then
					SetTimer(1000,1700,"OnTimer")
				end
				if Cfg.IsChannelVersion() and Cfg.GetEntryPage() == "welcomeNew" then
					SetTimer(1000,1700,"OnTimer")
				end
			end
			checkLogin()
		end
	elseif message == 103 then
		SetWelcomeText("数据获取完成...")
		SetBottomStatusText("数据获取完成...")
		local homeData = HomeNetworkData()
		SetTimer(999,1000,"OnTimer")
		local reg_w = registerCreate("welcomeNew")
		registerSetInteger(reg_w, "load",1)
		local root = registerGetInteger(reg_w, "root")
		local gotoHomePage = FindChildSprite(root,"gotoHomePage")
		local textlabel = FindChildSprite(root , "status-forground")
		ReleaseSpriteCapture(textlabel)
		SetSpriteVisible(gotoHomePage,1)
		SetSpriteEnable(gotoHomePage,1)
		if not homeData then
		  OnNetworkError()
		end
	elseif message == 103 + MSG_CACHEDATA_RELOAD then
		local regreload = registerCreate("homeReload")
		registerSetString(regreload,"progress","75")
		HomeNetworkData()
	elseif message == 104 + MSG_CACHEDATA_RELOAD then
		local reg = registerCreate("welcomeNew")
		local root = registerGetInteger(reg, "root")
		if root and root ~= 0 then
			SendSpriteEvent(root, 999)
		end
	elseif message == 104 then
		local reg = registerCreate("welcomeNew")
		local root = registerGetInteger(reg, "root")
		if root and root ~= 0 then
			SendSpriteEvent(root, 999)
		end
	---------------------add by zr 0617-------------start-------------
	elseif message == 112 then
		require "module.protocol.channelGroup"
		local guideData = OnChannelGroupDecode()
		if guideData then 
			local scene = FindScene(sceneGuide)
			SetReturn( sceneHome, sceneGuide )
			if scene and scene ~= 0 then
				FreeScene(scene)
			end
			SetTimer(2000,500,"OnTimer")
		end
	elseif message == 113 then
		local homeData = HomeNetworkData()
		if isRecommendMsg() then
			requestMsgContent()
		end
	elseif message == 2010 then
		HomeNetworkData()
		local homeData = LoadJsonHomeNetworkData()
		if homeData and homeData.searchUrl then
			require "module.protocol.protocol_search_result"
			SetSearchUrl(homeData.searchUrl)
		end
	elseif message == MSG_SMS_ID + 32768 then
		Exit()
	elseif message == 32768 then
		OnNetworkError()
	end
	local regSystem = registerCreate("System")
	local srvURL  = CreateRequestURL( "/sup/msp/imagesPacking.msp" )
	WriteLogs("welcome srvURL: "..srvURL)
	http = registerGetInteger(regSystem, "comHttpPipe")
	pluginInvoke(http, "SetPackingUrl", srvURL)
	return 1
end

function ProgressChange()
	local regreload = registerCreate("homeReload")
	registerSetString(regreload,"progress","75")
end

function checkUpdate()
	SceneMngrAdd("MODULE:\\welcome.xml", GetCurScene())
	local system = registerCreate("System")
	local updateComponentCount = registerGetInteger(system,"updateComponentCount")
	if updateInfo then
		WriteLogs("===================================")
		printData(updateInfo)
		WriteLogs("===================================")
		if table.maxn(updateInfo) >= 0 then
			for i=0,updateComponentCount do
				if updateInfo[i].url and updateInfo[i].url~="" then
					registerSetInteger(system,"updateUrl",i)
					require("module.dialog.useDialog")
					local curScene = GetCurScene()
					local reg = registerCreate("welcome")
					registerSetInteger(reg, "welcomeScene", curScene)
					local pathName = "MODULE:\\welcome.xml"
					if updateInfo[i].flags == "3" or string.match(updateInfo[i].id, "Module") then
						-- 3 无提示，直接下载
						OnSpriteEvent(1001, nil)
						return 2
					elseif updateInfo[i].flags == "1" then
						setDialogParam("版本升级", "有新版本，是否需要升级!", "BT_OK_CANCEL", pathName,pathName,curScene, 1)
						Go2Scene("MODULE:\\dialog.xml", 1)
						return 1
					elseif updateInfo[i].flags == "2" then
						setDialogParam("版本升级", "有新版本，必须升级!", "BT_OK_CANCEL", pathName,pathName,curScene, 1)
						Go2Scene("MODULE:\\dialog.xml", 1)
						return 2
					end
				end
			end
		end
	end
	return false
end

function checkLogin()
	require ("module.protocol.protocol_systime")
	RequestSysTime(120)
	if loginInfo and loginInfo.code == "0" then
		WriteLogs("===================================")
		printData(loginInfo)
		WriteLogs("===================================")
		require "module.setting"
		if Cfg.IsChannelVersion() and loginInfo.channelDataUrl ~= "" and Cfg.GetEntryPage() == "home" then
			require "module.protocol.channelGroup"
			RequestHome(2010,loginInfo.defaultDataUrl) -- 不需要响应此事件
			RequestChannelGroup(112,loginInfo.channelDataUrl)
		else
			RequestHome(103,loginInfo.defaultDataUrl)
		end
		SetWelcomeText("获取首页数据...")
		SetBottomStatusText("获取首页数据...")
		Cfg.AddLoginTimes(true)
		require("module.protocol.protocol_usercheck")
		RequestUserCheck(109,"001") --不需要响应此事件
	else
		OnNetworkError()
	end
end

--开始升级
function OnSpriteEvent(message, params)
	local reg = registerCreate("welcome")
	local curScene = registerGetInteger(reg, "welcomeScene")
	SetCurScene(curScene)
	local system = registerCreate("System")
	local updateUrl = registerGetInteger(system,"updateUrl")
	if message == 1001 then
		if dailFail and dailFail == 1 then
			Exit()
		else
			local reg = registerCreate("welcome")
			local networkStatus = registerGetInteger(reg, "network-status")
			deleteLoginCacheFile()
			if networkStatus == 1 then
				Exit()
			else
				DownLoadVersion()
			end
		end
	elseif message == 1002 then
		deleteLoginCacheFile()	
		if updateInfo[updateUrl].flags == "2" then
			Exit()
		else
			if not (Cfg.IsChannelVersion()) then
				SetTimer(1000,3000,"OnTimer")
			end
			if Cfg.IsChannelVersion() and Cfg.GetEntryPage() == "welcomeNew" then	
				SetTimer(1000,3000,"OnTimer")
			end
			checkLogin()
		end
	end
end

function DownLoadVersion()
	local regSystem = registerCreate("System")
	systemDownload = registerGetInteger(regSystem, "SystemDownload")
	if systemDownload == 0 then
		systemDownload = pluginCreate("Download")
		registerSetInteger(regSystem, "SystemDownload", systemDownload)
	end
	local system = registerCreate("System")
	local updateUrl = registerGetInteger(system,"updateUrl")
	if table.maxn(updateInfo) >= 0 then
		if updateInfo[updateUrl].url and updateInfo[updateUrl].url ~= ""  then
			local downloadIndex = pluginInvoke(systemDownload, "SystemAppend", updateInfo[updateUrl].url, "MODULE:\\cache\\"..updateInfo[updateUrl].id..".cab", updateInfo[updateUrl].id)
			local reg = registerCreate("welcome")
			registerSetInteger(reg, "downloadIndex", downloadIndex)
			registerSetInteger(reg, "status2", 2)
			SetStatusText("下载中...")
			SetTimer(1, 100, "OnTimerChangeSprite")
		end
	end
end

function OnTimerChangeSprite(IDParam)
	local reg = registerCreate("welcome")
	local spriteProgress = registerGetInteger(reg, "spriteProgress")
	local spriteRootStatus = registerGetInteger(reg, "status2")
	local downloadIndex = registerGetInteger(reg, "downloadIndex")

	if spriteRootStatus == 2 then

--		local result			结果
--		local id				任务ID
--		local remoteUrl			远程下载地址
--		local localPathName		本地文件路径名
--		local title				任务名
--		local maxSize			文件最大值
--		local curSize			当前下载值
--		local status			当前状态 0是空闭 4是完成 2是暂停
		local result, id, remoteUrl, localPathName, title, maxSize, curSize, status = pluginInvoke(systemDownload, "SystemGetItem", downloadIndex)
		if status == 4 then
			WriteLogs("download finished")
			registerSetInteger(reg, "status2", 1)
			ExecuteDowload(title, localPathName)
			SetSpriteVisible(spriteProgress, 0)
		elseif status == 2 or status == 0 then
			SetSpriteVisible(spriteProgress, 1)
			local l,t,w,h = GetSpriteRect(spriteProgress)
			if maxSize == 0 then
				SetSpriteRect(spriteProgress, l, t, 0, h)
			else
				local width = math.floor(curSize * 112 / maxSize)
				SetSpriteRect(spriteProgress, l, t, width, h)
				WriteLogs("width "..width)
			end
			SetTimer(1, 50, "OnTimerChangeSprite")
		end
	end
end

function ExecuteDowload(title, localPathName)
	--[[  删除上一版本缓存  ]]--
	require "module.common.io"
	local dir=OpenDirectory("CACHE:\\*.txt")
	if dir then
		for n=0 ,table.maxn(dir) do
			WriteLogs(dir[n].attr..":"..dir[n].filename)
			fileRemove("CACHE:\\"..dir[n].filename)
		end
	else
		WriteLogs("open failed")
	end
	if string.match(title, "MobileVideo") then
		--进行安装
		InstallApp(localPathName)
		Exit()
	elseif string.match(title, "Skin") then
		--进行安装
		local unzip = BeginUnzip(localPathName, "WONDER:\\")
		if unzip then
			local reg = registerCreate("welcome")
			registerSetInteger(reg, "unzipHandle", unzip)
			SetTimer(1, 10, "OnTimerUnzip")
		else
			WriteLogs("Upzip is Error.")
		end
	elseif string.match(title, "Module") then
		--进行安装
		local system = registerCreate("System")
		local indexUpdate = registerGetInteger(system,"updateUrl")
		local moduleversion = updateInfo[indexUpdate].version

		--解压覆盖module.zip和image.zip
		local unzip = BeginUnzip(localPathName, "WONDER:\\")
		if not unzip then
			WriteLogs("bad zip file");
		else
			while GoToUnzipNextFile(unzip) do
				ProcessUnzip(unzip)
			end
			EndUnzip(unzip)
		end
		fileRemove(localPathName)
		local insmod = InstallMirrorImage("WONDER:\\module.zip", "MODULE:\\")
		local insimg = InstallMirrorImage("WONDER:\\image.zip", "MODULE:\\image\\")
		WriteLogs("welcome.lua: ExecuteDowload: unzip "..tostring(unzip).." mirror module "..tostring(insmod).." mirror image "..tostring(insimg))

		--更新ver.lua版本号
		local verfile = "WONDER:\\ver.lua"
		local verstr = fileRead(verfile)

		local supdate = "G_MODULE_VER = \""..moduleversion.."\""
		if G_MODULE_VER == nil then
			verstr = verstr.."\r\n"..supdate.."\r\n"
		else
			local scurrent = "G_MODULE_VER(%s-)=(%s-)\""..tostring(G_MODULE_VER).."\""
			local spos, epos = string.find(verstr, scurrent)
			if spos == nil then
				verstr = verstr.."\r\n"..supdate.."\r\n"
			else
				verstr = string.gsub(verstr, scurrent, supdate)
			end
		end
		local ret = fileWrite(verfile, verstr)
		WriteLogs("welcome.lua: ExecuteDowload: write "..tostring(ret).."\r\n"..verstr)
		G_MODULE_VER = moduleversion

		--继续登录
		if not (Cfg.IsChannelVersion()) then
			SetTimer(1000,3000,"OnTimer")
		end
		if Cfg.IsChannelVersion() and Cfg.GetEntryPage() == "welcomeNew" then
			SetTimer(1000,3000,"OnTimer")
		end
		SetStatusText("登录中...")
		checkLogin()
	elseif string.match(title, "MediaPlayer") then
		--进行安装
		InstallApp(localPathName)
		CheckLogin()
	end
end

function OnTimerUnzip(IDEvent)
	local reg = registerCreate("welcome")
	local unzip = registerGetInteger(reg, "unzipHandle")
	if unzip then
		for i=1, 20 do
			if ProcessUnzip(unzip) == 0 then
				EndUnzip(unzip)
				checkLogin()
				return
			end
		end
		WriteLogs("OnTimerUnzip")
		SetTimer(1, 10, "OnTimerUnzip")
	else
		WriteLogs("Upzip is Error2.")
	end
end

function SaveUUIDFromSettingXML()
	
end

function ChangeScene()
	---------------------add by xf_pan  start------------------------
	-- local src = "MODULE:\\ComAction.dll"
	-- local target = "MODULE:\\"
	-- local unzip = BeginUnzip(src, target)
	-- if not unzip then
		-- WriteLogs("bad ZPKG file")
	-- else
		-- while ProcessUnzip(unzip) ~= 0 do
		-- end
		-- EndUnzip(unzip)
		-- WriteLogs("ZPKG file end")
	-- end
	----------------------add by xf_pan  end--------------------------
end

function OnNetworkError()
	local SCWelcome = FindScene("MODULE:\\welcome.xml")
	if GetCurScene() == SCWelcome then
		require("module.dialog.useDialog")
		local curScene = GetCurScene()
		local reg = registerCreate("welcome")
		registerSetInteger(reg, "network-status", 1)
		local pathName = "MODULE:\\welcome.xml"
		setDialogParam("提示", "登录失败，请稍后重试", "BT_OK", pathName,pathName,curScene, 1)
		Go2Scene("MODULE:\\dialog.xml", 1)
	end
	deleteHomeCacheFile()
	deleteLoginCacheFile()
end

function hideExitAndStatus()
	local reg = registerCreate("welcome")
	local labelStatus2 = registerGetInteger(reg, "statusB")
	local welcomeExit  = registerGetInteger(reg, "welcomeExit")
	SetSpriteVisible(labelStatus2,0)
	SetSpriteVisible(welcomeExit,0)
end


	
function welcomeButtonBackKeyUp(sprite, keyCode)
  require "module.keyCode.keyCode"
	WriteLogs("KeyUp")
	
	if keyCode == ApKeyCode_F2 then
		Exit()
		
	end
	return 0
end

function OnSelectBackButton(sprite)
	Exit()
end

