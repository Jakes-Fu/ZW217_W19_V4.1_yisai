--@author xf_pan
--@date 2010/06/15
require ("module.setting")

function RequestUserCheck(protocolNumber, userType)

	local requestUrl = string.format("%s/ugcapp/uploadFile/UGC_CheckUser.html?T_TYPE=%s", Cfg.GetServer(), userType)
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")

	local userCheckUrlFileName = GetLocalFilename(requestUrl)
	local reg = registerCreate("welcome-usercheck")
	local fileName = registerSetString(reg, "welcome-usercheck-filename", userCheckUrlFileName)

	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, requestUrl, 0, userCheckUrlFileName, observer, protocolNumber, 0, 1)
	WriteLogs("usercheck")
end

function OnPipeUserCheckDecode()

	local reg = registerCreate("welcome-usercheck")
	local fileName = registerGetString(reg, "welcome-usercheck-filename")

	local userStauts = -1
	local reg = registerCreate("system")
	registerSetInteger(reg, "usercheck-status-hasDecode", 1)

	local nodeTree = xmlLoadFile(fileName)
	if nodeTree ~= 0 then
		local nodeRoot = xmlFindElement(nodeTree, nodeTree, "RESULT")
		WriteLogs("nodeRoot: " ..nodeRoot)
		if nodeRoot ~= 0  then
			local nodeStatus = xmlFindElement(nodeTree, nodeRoot, "STATUS")
			WriteLogs("nodeStatus: " ..nodeStatus)
			if nodeStatus ~= 0  then
				local userStatus = xmlGetText(nodeStatus)
				WriteLogs("userStatus: " ..userStatus)
				if userStatus == "01" then
					local nodeValidUser = xmlFindElement(nodeTree, nodeRoot, "VALID_USER")
					local userValidStatus = xmlGetText(nodeValidUser)
					userStauts = tonumber(userValidStatus)
					WriteLogs("userStatus2: " ..userStatus)
					registerSetInteger(reg, "usercheck-status", userStauts)
					WriteLogs("userValidStatus: " ..userValidStatus)
				end
			end
		end
	end
	xmlRelease(nodeTree)
	return userStauts
end

function GetUserStatus()
	local reg = registerCreate("system")
	local userStatus = registerGetInteger(reg, "usercheck-status-hasDecode")
	WriteLogs("userStatus: " .. userStatus)
	if userStatus == 1 then
		return registerGetInteger(reg, "usercheck-status")
	else
		return OnPipeUserCheckDecode()
	end
end

function SetUserAuthority(ntype)
	local reg = registerCreate("system")
	local userStatus = registerSetInteger(reg, "usercheck-status-hasDecode", ntype)
end

function GetUserAuthority(protocolNumber,userType)
	local reg = registerCreate("system")
	local userStatus = registerGetInteger(reg, "usercheck-status-hasDecode")
	if userStatus == 3 then
		--3��ʾ�Ѿ�ע�ᣬ����ע��ɹ�����ж�
		return 3
	end
	local reg = registerCreate("welcome-usercheck")
	local fileName = registerGetString(reg, "welcome-usercheck-filename")
	if fileName == "" then
		--RequestUserCheck(protocolNumber, userType)
		return GetUserStatus()
	else
		local dir = {}
		dir = OpenDirectory(fileName)
		WriteLogs("requestUserCheck")
		RequestUserCheck(protocolNumber, userType)
		return GetUserStatus()
	end
end