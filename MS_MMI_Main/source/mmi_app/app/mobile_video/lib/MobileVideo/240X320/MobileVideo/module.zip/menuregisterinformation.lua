﻿--@module menuregisterinformation
--@note 注册界面

require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.dialog"
require "module.dialog.useDialog"
require "module.protocol.protocol_menuregisterinformation"
require "module.Loading.useLoading"

isReg = false --1代表注册成功,2代表未注册,0代表重新开始
--isRequest = false

function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	regCreate = registerCreate("menuregisterinformation")
	registerSetInteger(regCreate, "root", sprite)
	
	--获取白名单用户验证协议解析
	--createUserVerifyData()
	--获取UGC用户注册协议解析
	--createUserRegData()
	
	backSceneSprite	= FindChildSprite(sprite, "back-scene")
	local dialogRootSprite	= FindChildSprite(sprite, "menuregisterinformation")
	--获得需要返回的界面,这里保存的前一个界面的场景为空有问题
	--regBackScene = registerCreate("messagepannel")
	--backgroundScene = registerGetString(regBackScene,"returnpath")
	
	
	local dearUser1 = FindChildSprite(sprite, "dearUser1")
	require "module.setting"
	local PhoneNum = Cfg.GetPhoneNum()
	local PhoneNum_Front = string.sub(PhoneNum, 1, 3)
	WriteLogs("PhoneNum_Front======>"..PhoneNum_Front)
	local PhoneNum_Back = string.sub(PhoneNum, 8, 11)
	WriteLogs("PhoneNum_Back======>"..PhoneNum_Back)
	SetSpriteProperty(dearUser1,"text", "亲爱的"..PhoneNum_Front.."****"..PhoneNum_Back.."用户:")
	local dearUser2 = FindChildSprite(sprite, "dearUser2")
	require "module.setting"
	local PhoneNum = Cfg.GetPhoneNum()
	SetSpriteProperty(dearUser2,"text", "亲爱的"..PhoneNum_Front.."****"..PhoneNum_Back.."用户:")
	
	--找数据ReturnTable仓库
 	local reg = registerCreate("QuickLauncherBar");
 	--得到ReturnTable中"PageName"的总数,就是找到最近的页面
 	local count = registerGetInteger(reg, "Count");
 	--得到ReturnTable中最近的页面的名字
	backgroundScene = registerGetString(reg, "PageName"..count)
	WriteLogs("backgroundScene-start="..backgroundScene)
	if backgroundScene == "" then
		backgroundScene = sceneHome
	end
	WriteLogs("backgroundScene-end="..backgroundScene)
	background	= FindScene(backgroundScene)
	AddChildSprite(backSceneSprite, background)
	SetSpriteCapture(dialogRootSprite)
	return 1
end

function btnOKOnSelect(sprite)
	--if true == isRequest then 
	--	return
	--end
	local spriteRoot = registerGetInteger(regCreate, "root")	
	local spriteEditLabel = FindChildSprite(spriteRoot, "nickname-edit")
	local nickName = GetSpriteText(spriteEditLabel)
	local name = GetSpriteName(sprite)
	WriteLogs("nickName lenth==>"..string.len(nickName))
	width, height = GetTextSize(nickName)
	WriteLogs("width==>"..width)
	WriteLogs("height==>"..height)
	if width <= 120 then
		if name == "ok-button" and "" ~= nickName then
			local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadareaReg")
			enterLoading(nodeLoading)
		    
			local regUser = "http://c2.cmvideo.cn/ugcapp/uploadFile/UGC_RegUser.html"
			-- regUser = regUser.."?A_NAME="
			-- regUser = regUser..nickName
			-- regUser = regUser.."&T_TYPE=001"
			--isRequest = ture
			RequestUGCCheckReg(101, regUser, nickName)
		end
	else
		local spriteRegTitleLabel = FindChildSprite(spriteRoot, "RegistInf-3")
		local titleTxt = GetSpriteText(spriteRegTitleLabel)
		local spriteRegFalseLabel = FindChildSprite(spriteRoot, "RegistInf-2")
		local regFalse = GetSpriteText(spriteRegFalseLabel)
		local   spriteRoot = registerGetInteger(regCreate, "root")
		local dialogsprite = FindChildSprite(spriteRoot, "dialogInterface")
		setDialogParam(titleTxt, "昵称长度不能超过10个汉字/20个英文字符", "BT_OK", backgroundScene, nil,dialogsprite)
		Go2Scene(sceneDialog)
	end

end

function btnCancelOnSelect(sprite)
	WriteLogs("btnCancelOnSelect-start")
	local name = GetSpriteName(sprite)
	if name == "cancel-button" then
		FreeCurScene(GetCurScene())
		--TraceSpritesTree(backSceneSprite)
		--FreeScene(GetCurScene()) --会退出程序
		isReg = false
		ReturnProc()
		---------------------------------------------
		local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
		local curScene=registerGetString(SceneReg,"SceneName")
		-------------------------------------------
		if curScene~=nil and curScene=="history" then
			WriteLogs("取消：")
			registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
			return
		elseif curScene~=nil and curScene=="search-result" then
			registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
			return
		elseif curScene~=nil and curScene=="favorite" then
			registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
			return
		elseif curScene~=nil and curScene=="LocalFile" then
			WriteLogs("*****************yao go to LocalFile..................")
			registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
			return
		elseif curScene~=nil and curScene=="uploadingFile" then
			WriteLogs("取消按钮")
			registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
			return
		elseif curScene~=nil and curScene=="uploadHistoryFile" then
			registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
			return
		elseif curScene~=nil and curScene=="menuSetingScene" then
			WriteLogs("menuSetting")
			registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
			return
		end
		-------------------------------------------
	
		local ToDigReg = registerCreate("ToDigReg")
		local ToDigFocus = registerGetInteger(ToDigReg,"ToDigFocus")
		if ToDigFocus then
			SetSpriteFocus(ToDigFocus)
		end
		--Go2Scene(backgroundScene)
	end
	WriteLogs("btnCancelOnSelect-end")
end

--UGC用户注册
function LoadUserRegXMLData(filename)
	local nodeTree = xmlLoadFile(filename)
	if nodeTree ~= 0 then
		local nodeRoot = xmlFindElement(nodeTree, nodeTree, "RESULT")	
		if nodeRoot ~= 0 then
			--STATUS
			local   spriteRoot = registerGetInteger(regCreate, "root")
			local dialogsprite = FindChildSprite(spriteRoot, "dialogInterface")
			--获得需要返回的界面
			local nodeStatus = xmlFindElement(nodeTree, nodeRoot, "STATUS")			
			if nodeStatus ~= 0 then
				statusUserRegValue = xmlGetText(nodeStatus)
				--local spriteRoot = registerGetInteger(regCreate, "root")
				local spriteRegTitleLabel = FindChildSprite(spriteRoot, "RegistInf-3")
				local titleTxt = GetSpriteText(spriteRegTitleLabel)
				
				if "01" == statusUserRegValue then
					require "module.protocol.protocol_usercheck"
					SetUserAuthority(3)
					--USER_ID
					local nodeValidUser = xmlFindElement(nodeTree, nodeRoot, "USER_ID")			
					if nodeValidUser ~= 0 then
						userIDUserRegValue = xmlGetText(nodeValidUser) --要做保存
					end
					
					--跳转
					local spriteRegSucLabel = FindChildSprite(spriteRoot, "RegistInf-1")
					local regSuc = GetSpriteText(spriteRegSucLabel)
					setDialogParam(titleTxt, regSuc, "BT_OK", backgroundScene, nil,dialogsprite)
					Go2Scene(sceneDialog)
				else
					local spriteRegFalseLabel = FindChildSprite(spriteRoot, "RegistInf-2")
					local regFalse = GetSpriteText(spriteRegFalseLabel)
					setDialogParam(titleTxt, regFalse, "BT_OK", backgroundScene, nil,dialogsprite)
					Go2Scene(sceneDialog)
				end
			end

		end
	end
	return nil
end

function bodyOnPluginEvent(message, param)
	require "module.videoexpress-common"
	if message == 101 then
		exitLoading()
		local filename = GetUGCCheckRegFileName()
		WriteLogs("filename="..filename)

		if filename ~= "" then
			LoadUserRegXMLData(filename)
		else
			--提示失败
		end
		--isRequest = false
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneRegisterInformation, sceneRegisterInformation)
	end
	
end

--对话框按钮的事件返回
function DialogSpriteEvent(message, params)
	if 1001 == message then --0k
		--FreeScene(GetCurScene())
		if "01" == statusUserRegValue then
			isReg = true
			local sceneReg	= FindScene(sceneRegisterInformation)
			FreeCurScene(sceneReg)
			ReturnProc()
		else
			Go2Scene(sceneRegisterInformation)
		end

	end
	
end

--返回是一个界面
function ReturnProc()
 	local reg = registerCreate("QuickLauncherBar");
 	--得到ReturnTable中"PageName"的总数,就是找到最近的页面
 	local count = registerGetInteger(reg, "Count");
 	--得到ReturnTable中最近的页面的名字
	local LastPageName = registerGetString(reg, "PageName"..count)
	--如果存在，返回那个页面
	--by ljc,home不要再创建菜单
	if LastPageName ~= "" and LastPageName ~= nil then
		if true == isReg then
			Go2Scene(LastPageName)	
		else
			Go2Scene(LastPageName, 1)	
		end
		registerSetString(reg, "CurPage", LastPageName)
	else
		if true == isReg then
			GoAndFreeScene(sceneHome)
		else
			Go2Scene(sceneHome, 1)	
		end
		registerSetString(reg, "CurPage", sceneHome)
	end
	if count >= 1 then
		registerRemove(reg, "PageName"..count)
		count = count - 1		
	end
	registerSetInteger(reg, "Count", count)	
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	end
end

function FreeCurScene(curScene)
	local backSceneNode = FindChildSprite(curScene, "back-scene")
	RemoveChildSprite(curScene, backSceneNode)
	FreeScene(curScene)
	--TraceSpritesTree(curScene)
end


function editOnTextChanged(sprite)     
	local rootSprite = GetRootSprite(sprite, "root")
	local sendSprite = FindChildSprite(rootSprite,"scapegoat")
	SetSpriteFocus(sendSprite)
	ReleaseSpriteCapture(sprite)
	SetSpriteFocus(sprite)
end

function TextOnSelected(sprite)
	local rootSprite = GetRootSprite(sprite, "root")
	SetSpriteCapture(rootSprite)
end

function textButtonOnKeyUp(sprite, keyCode)
	require("module.keyCode.keyCode")
	if ApKeyCode_Down == keyCode then
		local parent = GetParentSprite(sprite)
		local okButton = FindChildSprite(parent, "ok-button")
		SetSpriteFocus(okButton)
	end
end

function okButtonOnKeyUp(sprite, keyCode)
	require("module.keyCode.keyCode")
	local parent = GetParentSprite(sprite)
	if ApKeyCode_Enter == keyCode then
		btnOKOnSelect(sprite)
	elseif ApKeyCode_Up == keyCode then
		local nicknamebutton = FindChildSprite(parent, "nickname-button")
		local edit = FindChildSprite(nicknamebutton, "nickname-edit")
		SetSpriteFocus(edit)
	elseif ApKeyCode_Right == keyCode then
		local cancelButton = FindChildSprite(parent, "cancel-button")
		SetSpriteFocus(cancelButton)
	end
end

function cancelButtonOnKeyUp(sprite, keyCode)
	require("module.keyCode.keyCode")
	local parent = GetParentSprite(sprite)
	if ApKeyCode_Enter == keyCode then
		btnCancelOnSelect(sprite)
	elseif ApKeyCode_Up == keyCode then
		local nicknamebutton = FindChildSprite(parent, "nickname-button")
		local edit = FindChildSprite(nicknamebutton, "nickname-edit")
		SetSpriteFocus(edit)
	elseif ApKeyCode_Left == keyCode then
		local okButton = FindChildSprite(parent, "ok-button")
		SetSpriteFocus(okButton)
	end
end