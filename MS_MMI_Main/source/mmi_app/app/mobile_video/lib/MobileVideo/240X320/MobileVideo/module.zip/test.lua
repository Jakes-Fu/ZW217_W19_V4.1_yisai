﻿
--中间滚动条滚动
function progressOnTick(sprite)
	local l,t,w,h = GetSpriteRect(sprite)
	l = l + 2
	if l >= 0 then
		l = -112
	end
	SetSpriteRect(sprite, l, t, w, h)
	return	1
end

--设置状态信息
function SetStatusText(text)
	reg = registerCreate("welcome")
	labelStatus = registerGetInteger(reg, "status-label")
	SetSpriteProperty(labelStatus, "text", text)
end

function bodyBuildChildrenFinished(sprite)
	labelStatus = FindChildSprite(sprite, "status-label")
	reg = registerCreate("welcome")
	registerSetInteger(reg, "status-label", labelStatus)

	SetStatusText("正在连接网络中")
	
	http = pluginCreate("HttpPipe")
	observer = pluginGetObserver()
	postData = ""
	pluginInvoke(http, "AppendCommand", 0, "http://172.16.13.50/PtrArray.cpp", postData, "MODULE:\\test1.txt", observer, 100, 0)

	return 1
end

function OnPluginEvent(message, param)
	
	if message == 100 then
		SetStatusText("test1.txt下载好了，等待3秒")
		SetTimer(1, 3000, "OnTimer1")
	end

	if message == 101 then
		SetStatusText("test1.txt下载好了，等待3秒,切换界面了")
		SetTimer(2, 3000, "OnTimer2")
	end
end

function OnTimer1(idEvent)
	SetStatusText("test1.txt下载好了，开始下载test2.txt")
	pluginInvoke(http, "AppendCommand", 0, "http://172.16.13.50/xxxx.lua", postData, "MODULE:\\test2.txt", observer, 101, 0)
--	pluginInvoke(http, "AppendResource", "http://172.16.13.50/xxxx.lua", "MODULE:\\test2.txt", 99, observer, 101, 0)
end

function OnTimer2(idEvent)
--		welcomeSprite = GetCurScene()
--		homeSprite = CreateSprite()
--		LoadSprite(homeSprite, "MODULE:\\home.xml")
--		SetCurScene(homeSprite)
--		FreeSprite(welcomeSprite)
end

function testButtonOnSelect(sprite)
	local url="http://www.google.cn"
	local text=GetLocalFilename(url)
	SetStatusText(text)
	Test1();
end

function testEditOnTextChanged(sprite)
	text = GetSpriteText(sprite)
	SetStatusText(text)
end

function list1_leftButtonOnSelect(sprite)
	local list = FindChildSprite(GetRootSprite(sprite), "list1")
	local itemPerPage = SpriteList_GetItemPerPage(list)
	local start = SpriteList_GetStartItem(list)
	local itemCount = SpriteList_GetListItemCount(list)
	start = start - itemPerPage
	if start >=0 then
		SpriteList_SetStartItem(list, start)
	end
	return	1
end

function list1_rightButtonOnSelect(sprite)
	local list = FindChildSprite(GetRootSprite(sprite), "list1")
	local itemPerPage = SpriteList_GetItemPerPage(list)
	local start = SpriteList_GetStartItem(list)
	local itemCount = SpriteList_GetListItemCount(list)
	start = start + itemPerPage
	if start < itemCount then
		SpriteList_SetStartItem(list, start)
	end
	return	1
end

function resizeOnTextChanged(sprite)
	local text = GetSpriteText(sprite)
	local textWidth, textHeight = GetTextSize(text)
	l, t, w, h = GetSpriteRect(sprite)
	w = textWidth + 10
	h = textHeight + 10
	SetSpriteRect(sprite, l, t, w, h)
end

function pageButtonOnSelect(sprite)
	local name=GetSpriteName(sprite)
	textarea = FindChildSprite(GetRootSprite(sprite), "textarea");
	if name == "page1" then
		SetSpriteProperty(textarea, "text", "只说武松自与宋江公别之后，当晚投客店歇了。次日早起来，打火吃了饭，还了房钱，拴束包裹，提了梢棒，便走上路。寻思道：江湖上只闻说及时雨宋公明，果然不虚！结识得这般弟兄，也不枉了！\n武松在路上行了几日，来到阳谷县地面。此去离那县还远。当日晌午时分，走得肚中饥渴。望见前面有一个酒店，挑着一面招旗在门前，上头写着五个字道：三碗不过冈。")
	else
		if name == "page2" then
			SetSpriteProperty(textarea, "text", "武松入到里面坐下，把梢棒倚了，叫道：主人家，快把酒来吃。只见店主人把三只碗、一双箸、一碟热菜，放在武松面前。满满筛一碗酒来。\n武松拿起碗。一饮而尽。叫道：这酒好生有气力,主人家，有饱肚的买些吃酒？\n酒家道：只有熟牛肉。\n武松道：好的切二三斤来吃。\n酒店家去里面切出二斤熟牛肉，做一大盘子将来，放在武松面前。随即再筛一碗酒。\n武松吃了道：好酒！又筛下一碗。恰好吃了三碗酒，再也不来筛。")
		else
			if name == "page3" then
				SetSpriteProperty(textarea, "text", "武松敲着桌子叫道：主人家，怎的不来筛酒？\n酒家道：客官要肉便添来。\n武松道：我也要酒，也再切些肉来。\n酒家道：肉便切来，添与客官吃，酒却不添了。\n武松道：却又作怪！便问主人家道：你如何不肯卖酒与我吃？\n酒家道：客官，你须见我门前招旗上面，明明写道：三碗不过冈。\n武松道：怎地唤做三碗不过冈？\n酒家道：俺家的酒，虽是村酒，却比老酒的滋味。但凡客人来我店中吃了三碗的，便醉了，过不得前面的山冈去。因此唤做‘三碗不过冈’。若是过往客人到此，只吃三碗，更不再问。\n武松笑道：原来恁地！我却吃了三碗，如何不醉？\n酒家道：我这酒叫做‘透瓶香’，又唤做‘出门倒’。初入口时，醇厚好吃，少刻时便倒。\n武松道：休要胡说。没地不还你钱。再筛三碗来我吃。\n酒家见武松全然不动，又筛三碗。武松吃道：端的好酒！主人家，我吃一碗，还你一碗钱，只顾筛来。\n酒家道：客官休只管要饮。这酒端的要醉倒人，没药医。")
			end
		end
	end
	SetSpriteProperty(textarea, "top", "0")
end

function jsonParserButtonOnSelect(sprite)
	local json = jsonLoadFile("MODULE:\\test.json");
	if json then
		WriteLogs("1. max keyword index is " .. table.maxn(json.keyword));
		WriteLogs("2. " .. json.keyword[0].value);
		WriteLogs("3. " .. json.keyword[0].searchUrl);
		WriteLogs("4. " .. json.keyword[1].value);
		WriteLogs("5. " .. json.keyword[1].searchUrl);
		WriteLogs("6. " .. json.moreKeyUrl);
		WriteLogs("7. " .. json.searchUrl);
		WriteLogs("8. max subject index is " .. table.maxn(json.subject));
		WriteLogs("9. " .. json.subject[0].channelId);
		WriteLogs("A. " .. json.subject[0].channelName);
		WriteLogs("B. " .. json.subject[0].bigImg);
		WriteLogs("C. " .. json.subject[1].channelId);
		WriteLogs("D. " .. json.subject[1].channelName);
		WriteLogs("E. " .. json.subject[1].bigImg);
	end
end

function scene1ButtonOnSelect(sprite)
	newScene = CreateSprite("node");
	LoadSprite(newScene, "MODULE:\\test1.xml");
	SetCurScene(newScene);
	FreeSprite(GetRootSprite(sprite));
end

function OnSpriteEvent(message, params)
	if message == MSG_ACTIVATE then
		WriteLogs("test activate");
	elseif message == MSG_DEACTIVATE then
		WriteLogs("test deactivate");
	end
end

function saveNodeButtonOnSelect(sprite)
--	local varTable={
--							"scene1", "scene1.xml",
--							"scene2", "scene2.xml",
--						};
--	reg = registerCreate("table");
--	registerSetInteger(reg, "Count", table.maxn(varTable) + 1);
--	for n = 1, table.maxn(varTable) do
--		WriteLogs(varTable[n]);
--		registerSetString(reg, "Value" .. n, varTable[n]);
--	end
--	registerSave(reg, "WONDER:\\table.xml");
	local	varTable = {};
	reg = registerCreate("table");
	registerLoad(reg, "WONDER:\\table.xml");
	local count = registerGetInteger(reg, "Count");
	for n = 1, count do
		varTable[n] = registerGetString(reg, "Value" .. n);
		WriteLogs(varTable[n]);
	end
	
end

function unzipButtonOnSelect(sprite)
--	local	zipfile = "MODULE:\\package.bin"
--	local	target = "MODULE:\\test\\"
--	local unzip = BeginUnzip(zipfile, target)
--	if not unzip then
--		WriteLogs("bad ZPKG file");
--	else
--		while ProcessUnzip(unzip) ~= 0 do
--		end
--		EndUnzip(unzip)
--		WriteLogs("unzip success");
--	end
--	json = jsonLoadFile("CACHE:\\976b10271ba58b31a803817409a2bdb9.txt");
	WriteLogs("***unzipButtonOnSelect****");
	require("module.test1");
	FreeFunctions();
end

function Test2()
	WriteLogs("***test2***");
end

function testListKeyUp(sprite, keyCode)
	WriteLogs("testListKeyUp")
	local i = SpriteList_GetCurItem(sprite)
	WriteLogs(string.format("i"..i))
end

function testListItem0KeyUp(sprite, keyCode)
	WriteLogs("testListItem0KeyUp")
	return 0
end
