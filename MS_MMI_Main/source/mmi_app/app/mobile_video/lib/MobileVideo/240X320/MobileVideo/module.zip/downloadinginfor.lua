﻿--@module	downloadingInfor
--@note	用于正在下载界面的UI显示
--@author	shenyi
--@date	2010/06/04

require("module.common.SceneUtils")
require("module.keyCode.keyCode")
require "module.common.commonScroll"

downloadingInfor_SelectHeight = 72
downloadingInfor_NormalHeight = 25
downloadingInfor_ItemWidth = 222
downloadingInfor_FirButtonPosX = 168
downloadingInfor_FirButtonPosY = 3
downloadingInfor_FirButtonWidth = 33
downloadingInfor_FirButtonHeight = 19
downloadingInfor_SecButtonPosX = 168
downloadingInfor_SecButtonPosY = 24
downloadingInfor_SecButtonWidth = 33
downloadingInfor_SecButtonHeight = 19
downloadingInfor_ProgressWidth = 109

failflag = 0
fullflag = 0
dialogflag = 0
status={1,2,0,1,0,1,2,1,0,1}
textlist={"记录新中国的48个瞬间","喜洋洋与灰太郎之牛气冲天","全球高科技武器大集合","自然界最凶残动物排行榜","喜洋洋与灰太郎之牛气冲天","世界奇人怪人大聚会","全球高科技武器大集合","自然界最凶残动物排行榜","记录新中国的48个瞬间","自然界最凶残动物排行榜" }
-- itemCount = 10
-- totalheight = itemCount*25+47
--curIndex = nil
prevSelectSprite = nil
failBtnEnableFlag=true
deleteButtonEnable=true
task={}
filter={"*.3gp","*.dat"}	--需要过滤的文件类型，可以直接添加
--uploadTime = {}

DOWNLOADING_SHOW_STATUS_INTERVAL = 1000

--上个时间片的上传大小
preTimerSize = {}
--初次进入上传大小
initTimerSize = {}
totalTime = {}
initFinish = {}


--@tag-action	body:BuildChildrenFinished
--@brief	创建收藏列表
function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("downloading")
	registerSetInteger(reg, "root", sprite)
	local reg = registerCreate("System")
	download = registerGetInteger(reg,"Download")	
	if download == 0 then
		download = pluginCreate("Download")
	end
	initPage(sprite)
	return 1
	
end

function initPage(sprite)
	itemCount = updateTaskTable()		
	if itemCount > 0 then
		-- for i=1,itemCount do
			-- local uptime = registerGetInteger(reg,"uploadtime"..i)
			-- if uptime ~= nil then
				-- uploadTime[i] = uptime
			-- else
				-- uploadTime[i] = 0
			-- end
			
		-- end		
		for i=1,itemCount do
			preTimerSize[i] = task[i-1].size/(1024*1024)
			initTimerSize[i] = task[i-1].size/(1024*1024)
			if task[i-1].size < task[i-1].maxsize then
				initFinish[i] = 1
			end
		end
		WriteLogs("bodyBuildChildrenFinished")
		WriteLogs("initTimerSize---"..initTimerSize[1])
		WriteLogs("preTimerSize---"..preTimerSize[1])
		
		totalheight = itemCount*25+47
		local reg = registerCreate("downloading")
		registerSetInteger(reg,"curIndex",0)
		local curIndex = registerGetInteger(reg,"curIndex")		
		if curIndex then
			WriteLogs("0000000curIndex---"..curIndex)
		else
			WriteLogs("0000000curIndex---nil")
		end		
		CreatedownloadingInforList(sprite)
		--setdownloadingInforData()
		if curIndex then
			WriteLogs("77777777curIndex---"..curIndex)
		else
			WriteLogs("77777777curIndex---nil")
		end
		SetTimer(1,100,"onTimer")
		--SetTimer(1,1000,"CheckSpace")			
	else
		---------------------------在没有下载列表时设置焦点--------------------------
		SetSpriteFocus(FindChildSprite(sprite,"history"))
		saveTouchFocus(FindChildSprite(sprite,"history"))
		----------------------------------------------------------------------------
		local spriteImage = FindChildSprite(sprite,"scrollbar-image")
		local spriteScroll = FindChildSprite(sprite,"scroll")
		local spriteSplider = FindChildSprite(sprite,"splider-bar")	
		SetSpriteVisible(spriteImage,1)
		SetSpriteVisible(spriteSplider,0)
		SetSpriteEnable(spriteScroll,0)
		SetSpriteEnable(spriteSplider,0)		
	end	
end

--@function	CreatedownloadList
--@brief	创建下载列表
function CreatedownloadingInforList(sprite)
	local reg = registerCreate("downloading")
	local curIndex = registerGetInteger(reg,"curIndex")
	if curIndex then
		WriteLogs("11111111curIndex---"..curIndex)
	else
		WriteLogs("11111111curIndex---nil")
	end
	local spriteList = FindChildSprite(sprite, "downloading-list")
	for i=1,itemCount do 
		if task[i-1].status == "Downloading" then
			if totalTime[i] ~= nil then
				totalTime[i] = totalTime[i] + 1
			else
				totalTime[i] = 1
			end
			curIndex = i-1
		end	
	end		
	if curIndex then
		WriteLogs("22222222curIndex---"..curIndex)
	else
		WriteLogs("22222222curIndex---nil")
	end
	if curIndex == nil then
		curIndex = 0
	end
	if curIndex then
		WriteLogs("33333333curIndex---"..curIndex)
	else
		WriteLogs("33333333curIndex---nil")
	end
	registerSetInteger(reg,"curIndex",curIndex)
	local childPlayButtonFocus = nil
	local xmlNode=xmlLoadFile("MODULE:\\downloadingInforList.xml")
	for i=1,itemCount do
		local downloadSprite = CreateSprite("listitem")
		ret = LoadSpriteFromNode(downloadSprite,xmlNode)
		local spriteSel1 = FindChildSprite(downloadSprite,"select1")
		local spriteSel2 = FindChildSprite(downloadSprite,"select2")
		local spriteUnSel = FindChildSprite(downloadSprite,"unselect")
		--[[--------------------------修改人：yaoxiangyin 修改时间：2010.08.25---------------------------------------]]--
		local spriteSmallButton=FindChildSprite(downloadSprite,"item-smallbutton")
		SetSpriteProperty(spriteSmallButton, "name",string.format("item-smallbutton-%d",i))
		WriteLogs("@@@@@@@"..GetSpriteName(spriteSmallButton))
		----------------------------------------------------------------------------------------------------------------
		local downloadingItemName = string.format("downloading-button-%d", i)
		SetSpriteProperty(downloadSprite, "name", downloadingItemName)
		if i == curIndex + 1 then
			if task[curIndex].status == "Idle" or task[curIndex].status == "Paused" or task[curIndex].status == "Failed" then
				
				SetSpriteVisible(spriteSel1, 1)
				SetSpriteEnable(spriteSel1, 1)
				SetSpriteVisible(spriteSel2, 0)
				SetSpriteEnable(spriteSel2, 0)
				SetSpriteVisible(spriteUnSel, 0)			
				SetSpriteEnable(spriteUnSel, 0)		
				SetSpriteRect(downloadSprite, 0, 0, downloadingInfor_ItemWidth, downloadingInfor_SelectHeight)
				prevSelectSprite = downloadSprite
				childPlayButtonFocus = FindChildSprite(downloadSprite,"playbutton")
			elseif task[curIndex].status == "Downloading" then
				SetSpriteVisible(spriteSel2, 1)
				SetSpriteEnable(spriteSel2, 1)
				SetSpriteVisible(spriteSel1, 0)
				SetSpriteEnable(spriteSel1, 0)
				SetSpriteVisible(spriteUnSel, 0)			
				SetSpriteEnable(spriteUnSel, 0)			
				SetSpriteRect(downloadSprite, 0, 0, downloadingInfor_ItemWidth, downloadingInfor_SelectHeight)
				childPlayButtonFocus = FindChildSprite(downloadSprite,"playbutton1")
			end
			prevSelectSprite = downloadSprite
		else
			SetSpriteVisible(spriteSel1, 0)
			SetSpriteEnable(spriteSel1, 0)
			SetSpriteVisible(spriteSel2, 0)
			SetSpriteEnable(spriteSel2, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)
			SetSpriteRect(downloadSprite, 0, 0, downloadingInfor_ItemWidth, downloadingInfor_NormalHeight)
		end
		local spriteText = FindChildSprite(downloadSprite,"item-text")
		local spriteText1 = FindChildSprite(downloadSprite,"item-text1")
		local spriteText2 = FindChildSprite(downloadSprite,"item-text2")
		
		local title = string.gsub(task[i-1].title, "temp_", "")
		SetSpriteProperty(spriteText,"text",title)
		SetSpriteProperty(spriteText1,"text",title)
		SetSpriteProperty(spriteText2,"text",title)
		
		local spriteImage = FindChildSprite(downloadSprite,"image-select")
		if task[i-1].status == "Idle" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])				
		elseif task[i-1].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
		elseif task[i-1].status == "Downloading" then
			SetSpriteProperty(spriteImage,"src",imagelist[3])
		elseif task[i-1].status == "Failed" then
			SetSpriteProperty(spriteImage,"src",imagelist[5])			
		end				
		---------------设置listItem的键盘点击事件----------------
		SetSpriteProperty(downloadSprite, "OnKeyUp", "downloadingInforButtonSubjectKeyUp")
		---------------------------------------------------------
		
		AddChildSprite(spriteList, downloadSprite)
		SpriteList_AddListItem(spriteList, downloadSprite)
	end
	xmlRelease(xmlNode)
	if curIndex then
		WriteLogs("444444444curIndex---"..curIndex)
	else
		WriteLogs("444444444curIndex---nil")
	end
	-------------------------设置初始选中Item的焦点----------------------------
	if childPlayButtonFocus or spriteList==nil then
		SetSpriteFocus(childPlayButtonFocus)
		saveTouchFocus(childPlayButtonFocus)
	end
	----------------------------------------------------------------------------
	if itemCount > 0 then
		UpdateSelectItemData()
	end
	SpriteList_Adjust(spriteList)
	--[[  统一滚动条创建  ]]--
	CreateScrollBar(sprite,"downloading-list",itemCount*25+72-25,76)
	local xx,yy,widthW,heightH = GetSpriteRect(spriteList)
	if curIndex > 3 then
		SetSpriteRect(spriteList,xx,yy-(curIndex-3)*downloadingInfor_NormalHeight,widthW,heightH)
	end
	--ScrollBarAdjust(curIndex,3,1)
	ScrollBarAdjust(curIndex,math.floor(76/25)+2,1)
end

--@function	setdownloadSelectData
--@brief	设置正在下载数据
imagelist = {"file:///image/uploading/ico_3.png","file:///image/uploading/ico_2.png","file:///image/uploading/xiazai_icon.png","file:///image/uploading/ico_4.png","file:///image/uploading/ico_5.png"}

function setdownloadingInforData()
	local reg = registerCreate("downloading")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite,"downloading-list")
	for i = 1,itemCount do
		spriteItem = SpriteList_GetListItem(spriteList, i-1)
		local spriteSel1 = FindChildSprite(spriteItem,"select1")
		local spriteSel2 = FindChildSprite(spriteItem,"select2")
		local spriteUnSel = FindChildSprite(spriteItem,"unselect")
		
		local spriteText = FindChildSprite(spriteItem,"item-text")
		local spriteText1 = FindChildSprite(spriteItem,"item-text1")
		local spriteText2 = FindChildSprite(spriteItem,"item-text2")
		
		local title = string.gsub(task[i-1].title, "temp_", "")
		SetSpriteProperty(spriteText,"text",title)
		SetSpriteProperty(spriteText1,"text",title)
		SetSpriteProperty(spriteText2,"text",title)
		
		local spriteImage = FindChildSprite(spriteItem,"image-select")
		if task[i-1].status == "Idle" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])				
		elseif task[i-1].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
		elseif task[i-1].status == "Downloading" then
			SetSpriteProperty(spriteImage,"src",imagelist[3])
		elseif task[i-1].status == "Failed" then
			SetSpriteProperty(spriteImage,"src",imagelist[5])			
		end		
		
		if i==1 then
			--UpdateSelectItemData(i-1)
			curIndex = i-1
			prevSelectSprite = spriteItem
		else 
			SetSpriteVisible(spriteSel1, 0)
			SetSpriteEnable(spriteSel1, 0)
			SetSpriteVisible(spriteSel2, 0)
			SetSpriteEnable(spriteSel2, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)
			SetSpriteRect(spriteItem, 0, 0, downloadingInfor_ItemWidth, downloadingInfor_NormalHeight)			
		end		
	end
	SpriteList_Adjust(spriteList)
end

function toLocalFiel(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	if keyCode == ApKeyCode_Right then
		buttonLocalFileSelect()
	elseif keyCode == ApKeyCode_F1 then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		--WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)

	end
end
----------------------------listItem的键盘点击事件----------------------
function downloadingInforButtonSubjectKeyUp(sprite,keyCode)
	--WriteLogs("_=_=-=-=-0=-=-=-=-=-=-=			downloadingInforButtonSubjectKeyUp")
	WriteLogs("jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj")
	--WriteLogs("SpriteListItem_GetIndex(sprite)="..SpriteListItem_GetIndex(sprite))
	local downloadListItemSprite = GetSpriteName(sprite)
	WriteLogs("#################@@@@@@@@@@@@@@@@@@the name of downloadListItemSprite=="..downloadListItemSprite)
	local downloadReg = registerCreate("downloading")
	registerSetInteger(downloadReg,"lastFocusSprite",sprite)
	registerSetNumber(downloadReg,"lastFocusFlag",1)
	----------------------------------ksw---------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	
	local spriteList=FindChildSprite(GetRootSprite(sprite),"downloading-list")
	local listCount=SpriteList_GetListItemCount(spriteList)
	---------------------第一种选中情况-----------------------
	local downloadPlayButton= FindChildSprite(sprite, "playbutton")
	local downloadOperbutton= FindChildSprite(sprite, "operbutton")
	local downloadDeletebutton= FindChildSprite(sprite, "deletebutton")
	---------------------第二种选中情况-----------------------
	local downloadPlayButton1= FindChildSprite(sprite, "playbutton1")
	local downloadPausebutton= FindChildSprite(sprite, "pausebutton")
	local downloadDeletebutton1= FindChildSprite(sprite, "deletebutton1")
	local arrayButton={downloadPlayButton, downloadOperbutton, downloadDeletebutton, downloadPlayButton1, downloadPausebutton, downloadDeletebutton1}
	--WriteLogs("downloadPlayButton---"..downloadPlayButton)
	--WriteLogs("downloadPlayButton1---"..downloadPlayButton1)
	
	local downloadingItemIndex = SpriteListItem_GetIndex(sprite)
	
	--WriteLogs("all itemsb="..SpriteList_GetListItemCount(GetSpriteParent(sprite)))
	
	local preItem
	local nextItem
	
	local list_x, list_y2, list_w, list_h = GetSpriteRect(spriteList)
	local _, list_y1 = GetSpriteRect(sprite)
	local list_y = list_y1+list_y2
	
	if(keyCode == ApKeyCode_Right) then
		buttonLocalFileSelect()
	else
		for k=1,table.getn(arrayButton) do
			if HasSpriteFocus(arrayButton[k]) == 1 then
				local downloadReg = registerCreate("downloading")
				registerSetInteger(downloadReg,"lastFocusSprite",arrayButton[k])
				registerSetNumber(downloadReg,"lastFocusFlag",1)
				----------------------------------ksw------------------------------------------------------
				local ToDigReg = registerCreate("ToDigReg")
				registerSetInteger(ToDigReg,"ToDigFocus",sprite)
				-------------------------------------------------------------------------------------------
				if(keyCode == ApKeyCode_Enter) then
					if(k == 2) then
						operButtonOnSelect(downloadOperbutton)
						return 1
					elseif(k == 5) then
						pauseButtonOnSelect(downloadPausebutton)
						return 1
					end
				elseif(keyCode == ApKeyCode_Up) and failBtnEnableFlag then
					if(k == 1 or k==4) then
						if downloadingItemIndex ~= 0 then
--[[----------------------------------修改人：yaoxiangyin 修改时间：2010.08.25-----------------------------------]]--
							SetSpriteVisible(FindChildSprite(sprite,"select2"),0)
							SetSpriteEnable(FindChildSprite(sprite,"select2"),0)
							SetSpriteVisible(FindChildSprite(sprite,"select1"), 0)
							SetSpriteEnable(FindChildSprite(sprite,"select1"), 0)
							SetSpriteVisible(FindChildSprite(sprite,"unselect"),1)			
							SetSpriteEnable(FindChildSprite(sprite,"unselect"),1)
							x,y,width,height=GetSpriteRect(sprite)
							SetSpriteRect(sprite,x,y,width,25)
							
							local preItem=SpriteList_GetListItem(GetSpriteParent(sprite),downloadingItemIndex-1)
							SetSpriteVisible(FindChildSprite(preItem,"select2"),0)
							SetSpriteEnable(FindChildSprite(preItem,"select2"),0)
							SetSpriteVisible(FindChildSprite(preItem,"select1"), 0)
							SetSpriteEnable(FindChildSprite(preItem,"select1"), 0)
							SetSpriteVisible(FindChildSprite(preItem,"unselect"),1)			
							SetSpriteEnable(FindChildSprite(preItem,"unselect"),1)
							SetSpriteFocus(FindChildSprite(spriteList,"item-smallbutton-"..downloadingItemIndex))
							saveTouchFocus(FindChildSprite(spriteList,"item-smallbutton-"..downloadingItemIndex))
							SpriteList_Adjust(spriteList)
						end
					else
						if IsSpriteEnable(arrayButton[k-1]) == 0 then
							if k-1 == 1 or k-1== 4 then
								if downloadingItemIndex == 0 then
									SetSpriteFocus(arrayButton[k])
									saveTouchFocus(arrayButton[k])
									return 1
								else
--[[----------------------------------修改人：yaoxiangyin 修改时间：2010.08.25-----------------------------------]]--
									SetSpriteVisible(FindChildSprite(sprite,"select2"),0)
									SetSpriteEnable(FindChildSprite(sprite,"select2"),0)
									SetSpriteVisible(FindChildSprite(sprite,"select1"), 0)
									SetSpriteEnable(FindChildSprite(sprite,"select1"), 0)
									SetSpriteVisible(FindChildSprite(sprite,"unselect"),1)			
									SetSpriteEnable(FindChildSprite(sprite,"unselect"),1)
									x,y,width,height=GetSpriteRect(sprite)
									SetSpriteRect(sprite,x,y,width,25)
									
									local preItem=SpriteList_GetListItem(GetSpriteParent(sprite),downloadingItemIndex-1)
									SetSpriteVisible(FindChildSprite(preItem,"select2"),0)
									SetSpriteEnable(FindChildSprite(preItem,"select2"),0)
									SetSpriteVisible(FindChildSprite(preItem,"select1"), 0)
									SetSpriteEnable(FindChildSprite(preItem,"select1"), 0)
									SetSpriteVisible(FindChildSprite(preItem,"unselect"),1)			
									SetSpriteEnable(FindChildSprite(preItem,"unselect"),1)
									SetSpriteFocus(FindChildSprite(spriteList,"item-smallbutton-"..downloadingItemIndex))
									saveTouchFocus(FindChildSprite(spriteList,"item-smallbutton-"..downloadingItemIndex))
									SpriteList_Adjust(spriteList)
-----------------------------------------------------------------------------------------------------------------									
								end
							elseif(k-2 == 1 or k-2 == 4) then
								--WriteLogs("====================IsSpriteEnable(arrayButton[k-2])=============="..IsSpriteEnable(arrayButton[k-2]))
								if IsSpriteEnable(arrayButton[k-2]) == 0 then
									if downloadingItemIndex == 0 then
										SetSpriteFocus(arrayButton[k])
										saveTouchFocus(arrayButton[k])
										return 1
									else
										preItem = FindChildSprite(SpriteList_GetListItem(GetSpriteParent(sprite),downloadingItemIndex-1),"item-button")
										itemButtonOnSelect(preItem)
									end
								else
									SetSpriteFocus(arrayButton[k-2])
									saveTouchFocus(arrayButton[k-2])
									return 1
								end
							end
						else
							SetSpriteFocus(arrayButton[k-1])
							saveTouchFocus(arrayButton[k-1])
							return 1
						end
					end
					if list_y <= 10 and downloadingItemIndex ~= 0 then
						SetSpriteRect(spriteList,list_x, list_y2+25,list_w, list_h)
						---------------------------modified 10.27-----------------
						ChangeScrollPositon(sprite,"up")
						----------------------------------------------------------
					end
				elseif(keyCode == ApKeyCode_Down) and failBtnEnableFlag then
					if(k == 3 or k == 6) then
						if downloadingItemIndex ~= SpriteList_GetListItemCount(GetSpriteParent(sprite))-1 then
--[[----------------------------------修改人：yaoxiangyin 修改时间：2010.08.25-----------------------------------]]--
							SetSpriteVisible(FindChildSprite(sprite,"select2"),0)
							SetSpriteEnable(FindChildSprite(sprite,"select2"),0)
							SetSpriteVisible(FindChildSprite(sprite,"select1"), 0)
							SetSpriteEnable(FindChildSprite(sprite,"select1"), 0)
							SetSpriteVisible(FindChildSprite(sprite,"unselect"),1)			
							SetSpriteEnable(FindChildSprite(sprite,"unselect"),1)
							x,y,width,height=GetSpriteRect(sprite)
							SetSpriteRect(sprite,x,y,width,25)							
							
							local nextItem=SpriteList_GetListItem(GetSpriteParent(sprite),downloadingItemIndex+1)
							SetSpriteVisible(FindChildSprite(nextItem,"select2"),0)
							SetSpriteEnable(FindChildSprite(nextItem,"select2"),0)
							SetSpriteVisible(FindChildSprite(nextItem,"select1"), 0)
							SetSpriteEnable(FindChildSprite(nextItem,"select1"), 0)
							SetSpriteVisible(FindChildSprite(nextItem,"unselect"),1)			
							SetSpriteEnable(FindChildSprite(nextItem,"unselect"),1)

							SetSpriteFocus(FindChildSprite(spriteList,"item-smallbutton-"..(downloadingItemIndex+2)))
							saveTouchFocus(FindChildSprite(spriteList,"item-smallbutton-"..(downloadingItemIndex+2)))
							SpriteList_Adjust(spriteList)
----------------------------------------------------------------------------------------------------------------------							
						end
					else
						
						if IsSpriteEnable(arrayButton[k+1]) == 0 then
							if k+1 == 3 or k+1 == 6 then
								if downloadingItemIndex == SpriteList_GetListItemCount(GetSpriteParent(sprite))-1 then
									SetSpriteFocus(arrayButton[k])
									saveTouchFocus(arrayButton[k])
									return 1
								else
									nextItem = FindChildSprite(SpriteList_GetListItem(GetSpriteParent(sprite),downloadingItemIndex+1),"item-button")
									itemButtonOnSelect(nextItem)
								end
							elseif(k+2 == 3 or k+2 == 6) then
								if IsSpriteEnable(arrayButton[k+2]) == 0 then
									if downloadingItemIndex == SpriteList_GetListItemCount(GetSpriteParent(sprite))-1 then
										SetSpriteFocus(arrayButton[k])
										saveTouchFocus(arrayButton[k])
										return 1
									else
										nextItem = FindChildSprite(SpriteList_GetListItem(GetSpriteParent(sprite),downloadingItemIndex+1),"item-button")
										itemButtonOnSelect(nextItem)
									end
								else
									SetSpriteFocus(arrayButton[k+2])
									saveTouchFocus(arrayButton[k+2])
									return 1
								end
							end
						else
							SetSpriteFocus(arrayButton[k+1])
							saveTouchFocus(arrayButton[k+1])
							return 1
						end
					end
				elseif keyCode == ApKeyCode_F1 and failBtnEnableFlag then
					local homeLastFoucsReg= registerCreate("homeLastFoucs")
					registerSetInteger(homeLastFoucsReg,"lastFocusSprite",arrayButton[k])
					require("module.sysmenu")
					require("module.menuopen")
					SysGetSeceSprite(arrayButton[k])
					menuButtonOnSelect(arrayButton[k])
				
				elseif keyCode == ApKeyCode_F2  then
					require("module.menuopen")
					returnButtonOnSelect(sprite)
				end
				break
			end
		end
	end
end
----------------------------------------------------------------------------------

--@function	itemButtonOnSelect
--@tag-name	item-button
--@tag-action	button:OnSelect
--@brief	用于响应各列表项按钮
function itemButtonOnSelect(sprite)	
	--WriteLogs("11111111"..GetSpriteName(sprite))
	--WriteLogs("prevSelectSprite  44444444444444444444444"..GetSpriteName(prevSelectSprite))
	------------------------获得前一个所选的listItem的名字并截取字符串-------------------
	local preSelectSubString = string.sub(GetSpriteName(prevSelectSprite),20,20)
	------------------------------------------------------------------------------------
	
	if prevSelectSprite ~= nil then
		local spriteSel11 = FindChildSprite(prevSelectSprite,"select1")
		local spriteSel12 = FindChildSprite(prevSelectSprite,"select2")
		local spriteUnSel1 = FindChildSprite(prevSelectSprite,"unselect")
		SetSpriteVisible(spriteSel11, 0)
		SetSpriteEnable(spriteSel11, 0)
		SetSpriteVisible(spriteSel12, 0)
		SetSpriteEnable(spriteSel12, 0)		
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(prevSelectSprite, 0, 0, downloadingInfor_ItemWidth, downloadingInfor_NormalHeight)
	end
	local spriteParent = GetSpriteParent(sprite)
	local spritedownload = GetSpriteParent(spriteParent)
	local spriteSel21 = FindChildSprite(spritedownload,"select1")
	local spriteSel22 = FindChildSprite(spritedownload,"select2")
	local spriteUnSel2 = FindChildSprite(spritedownload,"unselect")
	------------------------获得当前所选的listItem的名字并截取字符串-------------------
	local selectSpriteSubString = string.sub(GetSpriteName(spritedownload),20,20)
	WriteLogs("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@the name of selectSpriteSubString=="..selectSpriteSubString)
	------------------------------------------------------------------------------------
	local index = SpriteListItem_GetIndex(spritedownload)
	if task[index].status == "Idle" or task[index].status == "Paused" or task[index].status == "Failed"then
		local spriteImage = FindChildSprite(spritedownload,"image-select1")
		local spritePercent = FindChildSprite(spritedownload,"percent-text")
		if task[index].status == "Idle" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])
			SetSpriteProperty(spritePercent, "text","")					
		elseif task[index].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
		elseif task[index].status == "Failed" then
			SetSpriteProperty(spriteImage,"src",imagelist[4])
			failBtnEnableFlag=false
		end		
		
		----------------------判断前一个listItem和当前listItem的位置关系---------
		if(tonumber(preSelectSubString) > tonumber(selectSpriteSubString)) then
			WriteLogs("#########################@@@@@@@@@@@@@@go to here 1")
			local deletebuttonSelect=FindChildSprite(spritedownload,"deletebutton")
			SetSpriteFocus(deletebuttonSelect)
			saveTouchFocus(deletebuttonSelect)
		else
			local playButtonSelect=FindChildSprite(spritedownload,"playbutton")
			SetSpriteFocus(playButtonSelect)
			saveTouchFocus(playButtonSelect)
		end
		
		-----------------------------------------------------------------------------
		SetSpriteVisible(spriteSel21, 1)
		SetSpriteEnable(spriteSel21, 1)
		SetSpriteVisible(spriteSel22, 0)
		SetSpriteEnable(spriteSel22, 0)
		SetSpriteVisible(spriteUnSel2, 0)			
		SetSpriteEnable(spriteUnSel2, 0)			
		SetSpriteRect(spritedownload, 0, 0, downloadingInfor_ItemWidth, downloadingInfor_SelectHeight)
		
	elseif task[index].status == "Downloading" then
		----------------------判断前一个listItem和当前listItem的位置关系---------
		
		if(tonumber(preSelectSubString) > tonumber(selectSpriteSubString)) then
			WriteLogs("#########################@@@@@@@@@@@@@@go to here 2")
			local deletebuttonSelect1=FindChildSprite(spritedownload,"deletebutton1")
			SetSpriteFocus(deletebuttonSelect1)
			saveTouchFocus(deletebuttonSelect1)
		else
			local playButtonSelect1=FindChildSprite(spritedownload,"playbutton1")
			SetSpriteFocus(playButtonSelect1)
			saveTouchFocus(playButtonSelect1)
		end
		
		-----------------------------------------------------------------------------
		SetSpriteVisible(spriteSel21, 0)
		SetSpriteEnable(spriteSel21, 0)
		SetSpriteVisible(spriteSel22, 1)
		SetSpriteEnable(spriteSel22, 1)
		SetSpriteVisible(spriteUnSel2, 0)			
		SetSpriteEnable(spriteUnSel2, 0)
		SetSpriteRect(spritedownload, 0, 0, downloadingInfor_ItemWidth, downloadingInfor_SelectHeight)
	end	
	
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "downloading-list")
	SpriteList_Adjust(spriteList)
	prevSelectSprite = spritedownload
	local reg = registerCreate("downloading")
	registerSetInteger(reg,"curIndex",index)
	failflag = 0
	fullflag = 0
end

function playButtonOnSelect(sprite)
	PlayProc(sprite)
end

function operButtonOnSelect(sprite)
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local index = SpriteListItem_GetIndex(spriteItem)
	--local spriteLabel = FindChildSprite(sprite, "oper-label")
	--local text = GetSpriteText(spriteLabel)
	--if text == "下载" then
	if task[index].status == "Paused" then
		local itemCount = updateTaskTable()
		local isExistDownloadingItem = 0
		if itemCount > 0 then
			for i=1,itemCount do
				if task[i-1].status == "Downloading" then
					isExistDownloadingItem = 1
				end
			end
			if fullflag == 0 then
				pluginInvoke(download, "Resume", task[index].id)
			else
				local reg = registerCreate("downloading")
				local spriteRoot = registerGetInteger(reg, "root")
				local fulltip = FindChildSprite(spriteRoot,"full-tip")
				SetSpriteVisible(fulltip,1)
				SetSpriteEnable(fulltip,1)
				SetTimer(1,2000,"okFullButtonOnSelect")
			end
			--pluginInvoke(download, "Resume", task[index].id)
			--SetTimer(1,1000,"CheckSpace")		
		end
		if isExistDownloadingItem == 1 then
			SetSpriteVisible(FindChildSprite(spriteItem,"select2"),0)
			SetSpriteEnable(FindChildSprite(spriteItem,"select2"),0)
			SetSpriteVisible(FindChildSprite(spriteItem,"select1"), 1)
			SetSpriteEnable(FindChildSprite(spriteItem,"select1"), 1)
			SetSpriteFocus(FindChildSprite(spriteItem,"operbutton"))
			saveTouchFocus(FindChildSprite(spriteItem,"operbutton"))
		else
			SetSpriteVisible(FindChildSprite(spriteItem,"select2"),1)
			SetSpriteEnable(FindChildSprite(spriteItem,"select2"),1)
			SetSpriteVisible(FindChildSprite(spriteItem,"select1"), 0)
			SetSpriteEnable(FindChildSprite(spriteItem,"select1"), 0)
			SetSpriteFocus(FindChildSprite(spriteItem,"pausebutton"))
			saveTouchFocus(FindChildSprite(spriteItem,"pausebutton"))
		end
		SetSpriteVisible(FindChildSprite(spriteItem,"unselect"),0)			
		SetSpriteEnable(FindChildSprite(spriteItem,"unselect"),0)
	--elseif text == "暂停" then
	elseif task[index].status == "Idle" then
		local itemCount = updateTaskTable()
		if itemCount > 0 then
			pluginInvoke(download, "Pause", task[index].id)
		end
		SetSpriteVisible(FindChildSprite(spriteItem,"select2"),0)
		SetSpriteEnable(FindChildSprite(spriteItem,"select2"),0)
		SetSpriteVisible(FindChildSprite(spriteItem,"select1"), 1)
		SetSpriteEnable(FindChildSprite(spriteItem,"select1"), 1)
		SetSpriteVisible(FindChildSprite(spriteItem,"unselect"),0)			
		SetSpriteEnable(FindChildSprite(spriteItem,"unselect"),0)
		SetSpriteFocus(FindChildSprite(spriteItem,"operbutton"))
		saveTouchFocus(FindChildSprite(spriteItem,"operbutton"))
	end
	x,y,width,height=GetSpriteRect(spriteItem)
	SetSpriteRect(spriteItem,x,y,width,downloadingInfor_SelectHeight)
end

function deleteButtonOnSelect(sprite)
	if deleteButtonEnable then
		dialogflag = 1
		local downloadReg = registerCreate("downloading")
		registerSetInteger(downloadReg,"lastFocusSprite",sprite)
		registerSetNumber(downloadReg,"lastFocusFlag",1)
		----------------------------------ksw---------------------------------------------------------
		local ToDigReg = registerCreate("ToDigReg")
		registerSetInteger(ToDigReg,"ToDigFocus",sprite)
		----------------------------------------------------------------------------------------------
		KillSpriteFocus(sprite)
		isDelete = 1
		local root = GetRootSprite(sprite)
		local spriteEvent = FindChildSprite(root, "event")
		local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
		indexDel = SpriteListItem_GetIndex(spriteItem)
		require "module.protocol.protocol_usercheck"	
		require "module.dialog.useDialog"	
		require "module.common.registerScene"
		require "module.common.SceneUtils"
		deleteButtonSprite = sprite
		setDialogParam("下载管理", "是否要删除下载任务", "BT_OK_CANCEL",sceneDownloadingInfo, nil,spriteEvent)	
		Go2Scene(sceneDialog)
	end
end

function changeDeleteBtnEnable()
	CancelTimer(3)
	deleteButtonEnable = true
end

function playButtonOnSelect1(sprite)
	PlayProc(sprite)
end

function pauseButtonOnSelect(sprite)
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local index = SpriteListItem_GetIndex(spriteItem)
	
	local itemCount = updateTaskTable()
	if itemCount > 0 then
		pluginInvoke(download, "Pause", task[index].id)
		SetSpriteVisible(FindChildSprite(spriteItem,"select2"),0)
		SetSpriteEnable(FindChildSprite(spriteItem,"select2"),0)
		SetSpriteVisible(FindChildSprite(spriteItem,"select1"), 1)
		SetSpriteEnable(FindChildSprite(spriteItem,"select1"), 1)
		SetSpriteVisible(FindChildSprite(spriteItem,"unselect"),0)			
		SetSpriteEnable(FindChildSprite(spriteItem,"unselect"),0)
		x,y,width,height=GetSpriteRect(spriteItem)
		SetSpriteRect(spriteItem,x,y,width,downloadingInfor_SelectHeight)
		SetSpriteFocus(FindChildSprite(spriteItem,"operbutton"))
		saveTouchFocus(FindChildSprite(spriteItem,"operbutton"))
	end
end

function deleteButtonOnSelect1(sprite)
	if deleteButtonEnable then 
		dialogflag = 1
		local downloadReg = registerCreate("downloading")
		registerSetInteger(downloadReg,"lastFocusSprite",sprite)
		registerSetNumber(downloadReg,"lastFocusFlag",1)
		----------------------------------ksw---------------------------------------------------------
		local ToDigReg = registerCreate("ToDigReg")
		registerSetInteger(ToDigReg,"ToDigFocus",sprite)
		-------------------------------------------------------------------------------------------
		isDelete = 1
		local root = GetRootSprite(sprite)
		local spriteEvent = FindChildSprite(root, "event")
		local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
		indexDel = SpriteListItem_GetIndex(spriteItem)
		require "module.protocol.protocol_usercheck"	
		require "module.dialog.useDialog"	
		require "module.common.registerScene"
		require "module.common.SceneUtils"
		deleteButtonSprite = sprite
		setDialogParam("下载管理", "是否要删除下载任务", "BT_OK_CANCEL",sceneDownloadingInfo, nil,spriteEvent)	
		Go2Scene(sceneDialog)
	end
end

function UpdateSelectItemData()
	local reg = registerCreate("downloading")
	local index = registerGetInteger(reg,"curIndex")
	if index then	
		WriteLogs("UpdateSelectItemData index---"..index)
	end
	--local reg = registerCreate("downloading")
	local spriteRoot = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(spriteRoot,"downloading-list")
	for i=1,itemCount do
		local spriteItem = SpriteList_GetListItem(spriteList, i-1)
		local spriteImage = FindChildSprite(spriteItem,"image-select")
		if task[i-1].status == "Idle" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])
		elseif task[i-1].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
		elseif task[i-1].status == "Downloading" then
			SetSpriteProperty(spriteImage,"src",imagelist[3])
		elseif task[i-1].status == "Failed" then	
			SetSpriteProperty(spriteImage,"src",imagelist[5])		
		end
	end		
	
	local spriteItem = SpriteList_GetListItem(spriteList, index)
	local spriteSel1 = FindChildSprite(spriteItem,"select1")
	local spriteSel2 = FindChildSprite(spriteItem,"select2")
	local spriteUnSel = FindChildSprite(spriteItem,"unselect")
	
	if task and task[index] and task[index].size == 0 then 
		local playbutton = FindChildSprite(spriteItem, "playbutton1")
        if IsSpriteEnable(playbutton) == 1 then
            SetSpriteEnable(playbutton, 0)
            local playBG =  FindChildSprite(playbutton,"playbg")
            SetSpriteProperty(playBG, "src", "file:///image/download/bf3.png")
            if IsSpriteVisible(spriteSel2) == 1 and dialogflag==0 then
                SetSpriteFocus(FindChildSprite(spriteSel2, "pausebutton"))
            end
        end
        
        local playbutton = FindChildSprite(spriteItem,"playbutton")
        if IsSpriteEnable(playbutton) == 1 then
            SetSpriteEnable(playbutton, 0)
            local playBG =  FindChildSprite(playbutton,"playbg")
            SetSpriteProperty(playBG, "src", "file:///image/download/bf3.png")
            if IsSpriteVisible(spriteSel1) == 1  and dialogflag==0 then
                SetSpriteFocus(FindChildSprite(spriteSel1, "operbutton"))
            end
        end
	else 
		local playbutton = FindChildSprite(spriteItem, "playbutton1")
		SetSpriteEnable(playbutton, 1)
		local playBG =  FindChildSprite(playbutton,"playbg")
		SetSpriteProperty(playBG, "src", "file:///image/download/bf2.png")
		
		local playbutton = FindChildSprite(spriteItem, "playbutton")
		SetSpriteEnable(playbutton, 1)
		local playBG =  FindChildSprite(playbutton,"playbg")
		SetSpriteProperty(playBG, "src", "file:///image/download/bf2.png")
	end

	require "module.debug.printDbg"
	printData( task[index] )	
	
	if task[index].status == "Idle" or task[index].status == "Paused" or task[index].status == "Failed" then
		local spriteImage = FindChildSprite(spriteItem,"image-select1")
		local spritePercent = FindChildSprite(spriteItem,"percent-text")
		--local spriteLabel = FindChildSprite(spriteItem, "oper-label")
		local spriteImg = FindChildSprite(spriteItem, "oper-img")
		local spriteButton = FindChildSprite(spriteItem,"operbutton")
		local spritePlay = FindChildSprite(spriteItem,"playbutton")
								
		if task[index].status == "Idle" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])
			SetSpriteProperty(spritePercent, "text","")		
			--SetSpriteProperty(spriteLabel,"text","暂停")		
			SetSpriteProperty(spriteImg, "src", "file:///image/download/zt2.png")
			local focusSprite = FindChildSprite(spriteItem,"focus")	
			--local focusTextLabel = FindChildSprite(spriteItem,"oper-label1")
			local focusOperImg = FindChildSprite(spriteItem, "oper-img1")
			--SetSpriteProperty(focusTextLabel,"text","暂停")	
			SetSpriteProperty(focusOperImg, "src", "file:///image/download/zt1.png")
			SetSpriteVisible(spriteButton, 1)
			SetSpriteEnable(spriteButton, 1)		
			SetSpriteRect(spritePlay,downloadingInfor_FirButtonPosX,downloadingInfor_FirButtonPosY,downloadingInfor_FirButtonWidth,downloadingInfor_FirButtonHeight)	
		elseif task[index].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
			local maxsize = string.format("%.2f",task[index].maxsize/(1024*1024))
			local size = string.format("%.2f",task[index].size/(1024*1024))		
			local focusSprite = FindChildSprite(spriteItem,"focus")	
			--local focusTextLabel = FindChildSprite(spriteItem,"oper-label1")
			--SetSpriteProperty(focusTextLabel,"text","下载")	
			local focusOperImg = FindChildSprite(spriteItem, "oper-img1")
			SetSpriteProperty(focusOperImg, "src", "file:///image/download/xz1.png")
			if ( task[index].maxsize >0 ) then
				percent = string.format("%.2f",size*100/maxsize)
			else  -- 0/0 ==> -1.#J
			  percent = "0.00"
			end
			
			SetSpriteProperty(spritePercent, "text","已下载: "..percent.."%")
			--SetSpriteProperty(spriteLabel,"text","下载")
			SetSpriteProperty(spriteImg,"src","file:///image/download/xz2.png")
			SetSpriteVisible(spriteButton, 1)
			SetSpriteEnable(spriteButton, 1)		
			SetSpriteRect(spritePlay,downloadingInfor_FirButtonPosX,downloadingInfor_FirButtonPosY,downloadingInfor_FirButtonWidth,downloadingInfor_FirButtonHeight)	
		elseif task[index].status == "Failed" then	
			---------------------------------------------------------------------------------
			findAgainItem = spriteItem
			---------------------------------------------------------------------------------
			SetSpriteProperty(spriteImage,"src",imagelist[4])
			SetSpriteProperty(spritePercent, "text","")
			SetSpriteVisible(spriteButton, 0)
			SetSpriteEnable(spriteButton, 0)		
			SetSpriteRect(spritePlay,downloadingInfor_SecButtonPosX,downloadingInfor_SecButtonPosY,downloadingInfor_SecButtonWidth,downloadingInfor_SecButtonHeight)	
			--[[  弹框提示下载失败  ]]--
			if failflag == 0 and dialogflag == 0 then
				deleteButtonEnable = false
				local failedtip = FindChildSprite(spriteRoot,"failed-tip")
				SetSpriteVisible(failedtip,1)
				SetSpriteEnable(failedtip,1)
				SetTimer(123,3000,"okButtonOnSelect")
				SetTimer(3,3000,"changeDeleteBtnEnable")
				SetSpriteFocus(FindChildSprite(failedtip,"ok-button"))
				saveTouchFocus(FindChildSprite(failedtip,"ok-button"))
				failflag = 1
				failBtnEnableFlag=true
			end
		end
		--[[
		SetSpriteVisible(spriteSel1, 1)
		SetSpriteEnable(spriteSel1, 1)
		SetSpriteVisible(spriteSel2, 0)
		SetSpriteEnable(spriteSel2, 0)
		SetSpriteVisible(spriteUnSel, 0)			
		SetSpriteEnable(spriteUnSel, 0)			
		--SetSpriteRect(spriteItem, 0, 0, 222, 72)
		]]--
	elseif task[index].status == "Downloading" then
		if fullflag == 0 then
			CheckSpace(index)
		end
		local spriteSize = FindChildSprite(spriteItem,"download-size")
		local spriteCurPercent = FindChildSprite(spriteItem,"curpercent")
		local spriteForeground = FindChildSprite(spriteItem,"foreground")
		local spriteSpeed = FindChildSprite(spriteItem, "speed")
		local maxsize = string.format("%.2f",task[index].maxsize/(1024*1024))
		local size = string.format("%.2f",task[index].size/(1024*1024))		
		local percent, width

		if ( task[index].maxsize > 0 ) then 
			percent = string.format("%.2f",task[index].size*100/task[index].maxsize)
			if percent then
				width = task[index].size*downloadingInfor_ProgressWidth/task[index].maxsize
			end
		else   -- 0/0 ==> -1.#J
			percent = "0.00"
			width = 0		   
		end
				
		SetSpriteProperty(spriteCurPercent, "text",""..percent.."%")
		SetSpriteProperty(spriteSize,"text",""..size.."MB / "..maxsize.."MB")
		x,y,w,h =  GetSpriteRect(spriteForeground)
		if width then
			SetSpriteRect(spriteForeground,x,y,width,h)
		else
			SetSpriteRect(spriteForeground,x,y,0,h)
		end
		
		
		local speed = 0
		local speed1 = 0
		local speed2 = 0
		--if uploadTime[index+1] > 0 then
			WriteLogs("preTimerSize  "..preTimerSize[index+1])
			WriteLogs("task[index].size  "..task[index].size/(1024*1024))				
			speed1 = (task[index].size/(1024*1024) - preTimerSize[index+1])/(DOWNLOADING_SHOW_STATUS_INTERVAL/1000)
			WriteLogs("totalTime---"..totalTime[index+1])
			WriteLogs("speed1---"..speed1)
			if totalTime[index+1] == 0 then
				speed2 = 0
			else
				speed2 = (task[index].size/(1024*1024) - initTimerSize[index+1])/(totalTime[index+1]*DOWNLOADING_SHOW_STATUS_INTERVAL/1000)
			end
			WriteLogs("speed2---"..speed2)
			--preTimerSize[index+1] = task[index].size/(1024*1024)
			speed = 0.2*speed1 + 0.8*speed2
			WriteLogs("speed---"..speed)
		--end
		if speed < 0 then
			speed = 0
		end
		
		
		local showspeed = string.format("%d",speed*1024)
		SetSpriteProperty(spriteSpeed, "text",""..showspeed.."KB/S")
		--[[	
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteSel2, 1)
		SetSpriteEnable(spriteSel2, 1)
		SetSpriteVisible(spriteUnSel, 0)			
		SetSpriteEnable(spriteUnSel, 0)
		]]--
	end
	for i=1,itemCount do
		preTimerSize[i] = task[i-1].size/(1024*1024)
		if initFinish[i] ~= 1 then
			initTimerSize[i] = task[i-1].size/(1024*1024)
			if task[i-1].size < task[i-1].maxsize then
				initFinish[i] = 1
			end
		end
	end

	
end

function onTimer()
	WriteLogs("3243534onTimer")
	local reg = registerCreate("downloading")
	local curIndex = registerGetInteger(reg,"curIndex")	
	if curIndex then
		WriteLogs("5555555555curIndex---"..curIndex)
	else
		WriteLogs("5555555555curIndex---nil")
	end
	local itemCount = updateTaskTable()
	for i=1,itemCount do 
		if task[i-1].status == "Downloading" then
			if totalTime[i] ~= nil then
				totalTime[i] = totalTime[i] + 1
			else
				totalTime[i] = 1
			end
		end	
	end	
	local curCount = itemCount
	if itemCount >0 then
		if curIndex then
			WriteLogs("666666666curIndex---"..curIndex)
		else
			WriteLogs("666666666curIndex---nil")
		end	
		UpdateSelectItemData()
		-- for idx = 0, itemCount - 1 do
			-- WriteLogs("idx "..idx)
			-- WriteLogs("uploadTime "..uploadTime[idx+1])
			-- if task[idx].status == "Downloading" then
				-- uploadTime[idx+1] = uploadTime[idx+1] + 1
			-- end
		-- end
		local finish = 0
		for idx = 0, itemCount - 1 do
			if task[idx].status == "Finished" then
				WriteLogs("idx"..idx.."  finished")
				-- for i = idx+1, curCount-1 do
					-- uploadTime[i] = uploadTime[i+1]
				-- end
				curCount = curCount - 1			
				finish = 1				
				
				--重命名文件，其他文件格式会有问题
				local localfile = task[idx].localfile	
				local NewFileName = string.gsub(localfile, "temp_", "")
				local renameReturn = os.rename(localfile, NewFileName)
				for renameTimes =1, 5 do
					if renameReturn ~= 1 then
						reg_v = registerCreate("video")
						local MediapalyPlugin = registerGetInteger(reg_v, "MediapalyPlugin")
						if MediapalyPlugin ~= 0 then
							local status = pluginInvoke(MediapalyPlugin, "GetStatus")
							if status ~= 6 then
								pluginInvoke(MediapalyPlugin, "Stop")
							end
							renameReturn = os.rename(localfile, NewFileName)						
						end
					else	
						--pluginInvoke(download, "Remove", task[idx].id)
					end	
				end	
				pluginInvoke(download, "Remove", task[idx].id)
				break
			end
		end
		if finish == 1 then
			local curScene = GetCurScene()
			local regHandle = registerCreate("SCMngr_handle")
			local SceneName = registerGetString(regHandle, string.format("%d", curScene))
			if SceneName == sceneDownloadingInfo then
				FreeScene(curScene)	
				Go2Scene(sceneDownloadingInfo)
			else
				returnFromDialog()
			end
		end
		SetTimer(1,DOWNLOADING_SHOW_STATUS_INTERVAL,"onTimer")
	end
end

function returnFromDialog()
	local dialog = GetCurScene()
	FreeDialog(dialog)
	FreeScene(FindScene(sceneDownloadingInfo))
	Go2Scene(sceneDownloadingInfo)
end

function FreeDialog(dialog)
	local backSceneNode  = FindChildSprite(dialog, "back-scene")
	local backgroundScene= FindScene(sceneDownloadingInfo)
	if backSceneNode and backSceneNode ~= 0 and backgroundScene and backgroundScene ~= 0 then
		RemoveChildSprite(backSceneNode, backgroundScene)
	end
	FreeScene(dialog)
end

function updateTaskTable()
	local itemCount = pluginInvoke(download, "Count")
	for idx = 0, itemCount - 1 do
		task[idx] = {}
		local result, id, remote, localfile, title, maxsize, size, status = pluginInvoke(download, "GetItem", idx)
		task[idx].id = id
		task[idx].remote = remote
		task[idx].localfile = localfile
		task[idx].title = title
		task[idx].maxsize = maxsize
		task[idx].size = size
		if status == 0 then		task[idx].status = "Idle"
		elseif status == 1 then	task[idx].status = "NotEnoughSpace"
		elseif status == 2 then	task[idx].status = "Downloading"
		elseif status == 3 then	task[idx].status = "Paused"
		elseif status == 4 then	task[idx].status = "Finished"
		elseif status == 5 then
			task[idx].status = "Failed"
			if  maxsize == size and size~=0 then
				task[idx].status = "Finished"
			end
		else   task[idx].status = "Unknown"
		end		
	end
	return	itemCount
end

function buttonLocalFileSelect()
	-- if itemCount > 0 then
		-- local reg = registerCreate("downloading")
		-- for i=1,itemCount do
			-- registerSetInteger(reg,"uploadtime"..i,uploadTime[i])
		-- end
	-- end
	local Curscene = GetCurScene()
	FreeScene(Curscene)
	Go2Scene(sceneLocalFile)
end


function GetMovie()
	local dir = {}
	local allMovie = {}
	local count = 1

	--找到程序运行目录	
	--folder = GetModuleFolder()
	--local reg = registerCreate("setting")
	--registerLoad(reg, "MODULE:\\config.xml")
	--local downloadPath = registerGetString(reg, "path")
	require "module.setting"
	local downloadPath = Cfg.GetDownloadPath();
	--得到运行目录下的所有文件
	for n = 1 ,table.maxn(filter) do
		dir = OpenDirectory(downloadPath..filter[n])	
		if dir~=nil then	
			for i = 0, table.maxn(dir) do
				allMovie[count] = dir[i].filename
				count = count + 1			
			end
		end		
	end	
	return allMovie
end


--对话框响应
function OnSpriteEvent(message, params)
	if message == 1001 and isDelete == 1 then
		--curIndex = 0
		local itemCount = updateTaskTable()
		if itemCount > 0 then
			-- for i = indexDel+1,itemCount-1 do
				-- uploadTime[i] = uploadTime[i+1]
			-- end
			-- local reg = registerCreate("downloading")
			-- for i=1,itemCount-1 do
				-- registerSetInteger(reg,"uploadtime"..i,uploadTime[i])
			-- end		
			pluginInvoke(download, "Remove", task[indexDel].id)
			
			--删除临时文件
			local fullFileName = task[indexDel].localfile
			os.remove (fullFileName)
		end
		local reg = registerCreate("downloading")
		local spriteRoot = registerGetInteger(reg, "root")
		local spriteList = FindChildSprite(spriteRoot, "downloading-list")
		SpriteList_ClearListItem(spriteList, 1, 1)
		initPage(spriteRoot)
		--local labelSprite = GetCurScene()
		--FreeScene(labelSprite)
		--Go2Scene(sceneDownloadingInfo)
	elseif message == 1002 then
		SetSpriteFocus(deleteButtonSprite)
		saveTouchFocus(deleteButtonSprite)
	end
	dialogflag = 0
end


function DeleteProc()
	Go2Scene(sceneDownloadingInfo)
end

--返回事件
function bodyOnSpriteEvent(message, params)
	-- local itemCount = updateTaskTable()
	-- if itemCount then
		-- local reg = registerCreate("downloading")
		-- for i=1,itemCount do
			-- registerSetInteger(reg,"uploadtime"..i,uploadTime[i])
		-- end
	-- end
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_USER + 99 then
		FreeScene(GetCurScene())
	elseif message == MSG_ACTIVATE then		
		failflag = 0
		fullflag = 0
--	require "module.common.DownloadUpload"
--	StartDownloadTask()
	end	
end

function CheckSpace(curIndex)
	require "module.protocol.protocol_downloadinfor"
	local spaceh, spacel = GetLocalSpace()	
	WriteLogs("spaceh----->"..spaceh)
	WriteLogs("spacel----->"..spacel)
	WriteLogs("GetTotalSize()----->"..GetSize(curIndex))
	space = spaceh*4294967296 + spacel
	if space < GetSize(curIndex) + 1024 then
		fullflag = 1
		local reg = registerCreate("downloading")
		local spriteRoot = registerGetInteger(reg, "root")
		local fulltip = FindChildSprite(spriteRoot,"full-tip")
		SetSpriteVisible(fulltip,1)
		SetSpriteEnable(fulltip,1)
		SetTimer(1,2000,"okFullButtonOnSelect")
--		isDelete = 0	
--		require "module.dialog.useDialog"
--		require "module.common.SceneUtils"
--		require "module.common.registerScene"
--		local reg = registerCreate("downloading")
--		local RootSprite = registerGetInteger(reg, "root")
--		local spriteEvent = FindChildSprite(RootSprite,"event")
--		setDialogParam("下载管理", "磁盘剩余空间容量不足", "BT_OK",sceneDownloadingInfo ,nil,spriteEvent)
--		Go2Scene(sceneDialog)	
		require "module.common.DownloadUpload"
		PauseDownloadTask()
	end
	return 1
end

function GetSize(curIndex)
	local itemCount = pluginInvoke(download, "Count")
	local sumSize = 0
	sumSize = task[curIndex].maxsize		
	local TotalSize = string.format("%.2f",sumSize/(1024))
	return tonumber(TotalSize)
end

function PlayProc(sprite)
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local index = SpriteListItem_GetIndex(spriteItem)
	--if task[index].status == "Failed" then
--		require "module.dialog.useDialog"	
--		require "module.common.registerScene"
--		require "module.common.SceneUtils"
--		setDialogParam("下载管理", "当前下载任务失败，请删除任务重试", "BT_OK",sceneDownloadingInfo, nil,spriteEvent)	
--		Go2Scene(sceneDialog)
	--else
		local Movie = {}--= GetMovie()
		require "module.protocol.protocol_video"
		require "module.common.SceneUtils"
		require "module.common.registerScene"
		require "module.Loading.useLoading"
		require "module.dialog.useDialog"
		SetReturn(sceneDownloadingInfo,sceneVideolocal)
--		--[[  获得根节点  ]]--  
--		local reg = registerCreate("menuprograminfo_volume")
--		local root = GetRootSprite(sprite)
--		local loadarea = FindChildSprite(root, "loadarea")
--		--[[  显示loading场景  ]]--
--		enterLoading(loadarea)
--		--[[  这里应该动态获取点击按钮的具体url  ]]--
--		local spriteButton = GetSpriteParent(GetSpriteParent(sprite))
--		local num = SpriteListItem_GetIndex(spriteButton)
		require "module.setting"
		
--		local downloadPath = Cfg.GetDownloadPath() 
--		local fullFileName = downloadPath..task[index].title..".3gp"
		local fullFileName = task[index].localfile
		local DownloadingName = string.gsub(fullFileName, "\\", "/")
		--边下载边播放格式 vfile://321222@/Storage card/bin/MobileVideo/download/建国大业.3gp
		local path = "vfile://"..task[index].maxsize.."@"..DownloadingName
		WriteLogs("边下载边播放格式===>>>>>"..path)
		--local dir = OpenDirectory(fullFileName)
		--if dir then
			--table.insert(Movie, 0, path)
			Movie[1]=path
			local PlayTable = {url = Movie, urlItem = 1}
			regVideo = registerCreate("video")
			registerSetString(regVideo, "isDownloading", "Downloading")
			RequestVideo(109, PlayTable,"","","local")
			exitLoading()
			local listSprite = GetCurScene()
			FreeScene(listSprite)
			Go2Scene(sceneVideolocal)
		--else
			--setDialogParam("下载管理", "下载任务尚未开始", "BT_OK",sceneDownloadingInfo, nil,spriteEvent)	
			--Go2Scene(sceneDialog)
		--end
	--end
end

function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if MSG_SMS_ID == message then			
		DealMsgContent(sceneDownloadingInfo, sceneDownloadingInfo)
	end
	return 1
end

function okButtonOnSelect()
	CancelTimer(123)
	local reg = registerCreate("downloading")
	local spriteRoot = registerGetInteger(reg, "root")
	local failedtip = FindChildSprite(spriteRoot,"failed-tip")
	SetSpriteVisible(failedtip,0)
	SetSpriteEnable(failedtip,0)
	if findAgainItem then
		if IsSpriteVisible(FindChildSprite(findAgainItem,"select1")) == 1 then
			SetSpriteFocus(FindChildSprite(FindChildSprite(findAgainItem,"select1"),"deletebutton"))
			saveTouchFocus(FindChildSprite(FindChildSprite(findAgainItem,"select1"),"deletebutton"))
		elseif IsSpriteVisible(FindChildSprite(findAgainItem,"select2")) == 1 then
			SetSpriteFocus(FindChildSprite(FindChildSprite(findAgainItem,"select2"),"deletebutton1"))
			saveTouchFocus(FindChildSprite(FindChildSprite(findAgainItem,"select2"),"deletebutton1"))
		else
			local listLocal = GetParentSprite(findAgainItem)
			local item = SpriteList_GetListItem(listLocal, 0)
			SetSpriteFocus(FindChildSprite(item,"item-smallbutton-1"))
			saveTouchFocus(FindChildSprite(item,"item-smallbutton-1"))
		end
	end
end

--[[------------------------------修改人：yaoxiangyin 修改时间：2010.08.25------------------------------------]]--
function downloadButtonOnKeyUp(sprite,keyCode)
	require("module.keyCode.keyCode")
	local downloadReg = registerCreate("downloading")
	registerSetInteger(downloadReg,"lastFocusSprite",sprite)
	registerSetNumber(downloadReg,"lastFocusFlag",1)
	----------------------------------ksw---------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	smallList={}
	WriteLogs("@@@@ the name of sprite=="..GetSpriteName(sprite))
	WriteLogs("@@@@ keyCode=="..keyCode)
	
	local spriteList =FindChildSprite(GetRootSprite(sprite),"downloading-list")  --downloading-list节点
	local smallName = GetSpriteName(sprite)
	local smallFocusNum
	local smallCount=SpriteList_GetListItemCount(spriteList)
	for j=1,smallCount do
		smallList[j]="item-smallbutton-"..j
	end
	
	for i=1,smallCount do  --寻找当前Button节点名
	  if smallList[i]==smallName then
	    smallFocusNum=i
	  end
	end
	
	local downloadSprite=SpriteList_GetListItem(spriteList,smallFocusNum-1)
	local spriteSel1 = FindChildSprite(downloadSprite,"select1")
	local spriteSel2 = FindChildSprite(downloadSprite,"select2")
	local spriteUnSel =FindChildSprite(downloadSprite,"unselect")

	local list_x, list_y2, list_w, list_h = GetSpriteRect(spriteList)
	local _, list_y1 = GetSpriteRect(downloadSprite)
	local list_y = list_y1+list_y2

	if keyCode==ApKeyCode_Down then
		if smallList[smallFocusNum+1]~=nil then
			SetSpriteFocus(FindChildSprite(spriteList,smallList[smallFocusNum+1]))
			saveTouchFocus(FindChildSprite(spriteList,smallList[smallFocusNum+1]))
			if list_y >= 159 then
				SetSpriteRect(spriteList,list_x, list_y2-25,list_w, list_h)
				---------------------------modified 10.27-----------------
				ChangeScrollPositon(sprite,"down")
				----------------------------------------------------------
			end
			SpriteList_Adjust(spriteList)
		end
	elseif keyCode==ApKeyCode_Up then
		if smallList[smallFocusNum-1]~=nil then
			SetSpriteFocus(FindChildSprite(spriteList,smallList[smallFocusNum-1]))
			saveTouchFocus(FindChildSprite(spriteList,smallList[smallFocusNum-1]))
			if list_y <= 10 then
				SetSpriteRect(spriteList,list_x, list_y2+25,list_w, list_h)
				---------------------------modified 10.27-----------------
				ChangeScrollPositon(sprite,"up")
				----------------------------------------------------------
			end
			SpriteList_Adjust(spriteList)
		end
	elseif keyCode==ApKeyCode_Right then
		buttonLocalFileSelect()
	elseif keyCode==ApKeyCode_Enter then
		--itemButtonOnSelect(GetParentSprite(sprite))
		itemButtonOnSelect(sprite)
		if list_y >= 134 then
			SetSpriteRect(spriteList,list_x, list_y2-25-25,list_w, list_h)
			---------------------------modified 10.27-----------------
			ChangeScrollPositon(sprite,"down")
			----------------------------------------------------------
		end
		SpriteList_Adjust(spriteList)
	elseif keyCode == ApKeyCode_F1 then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
-----------------------------------------------------------------------------------------------------------------

--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	WriteLogs("liuchaobing test spriteitem name is "..GetSpriteName(spriteitem))
	WriteLogs("liuchaobing test spriteitem index is "..CurIndex)
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,3,0)
	else
		ScrollBarAdjust(CurIndex + 1,3,1)
	end
end

function okFullButtonOnSelect()
	local reg = registerCreate("downloading")
	local spriteRoot = registerGetInteger(reg, "root")
	local fulltip = FindChildSprite(spriteRoot,"full-tip")
	SetSpriteVisible(fulltip,0)
	SetSpriteEnable(fulltip,0)
end
