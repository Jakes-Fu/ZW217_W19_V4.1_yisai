﻿--@module 	SystemMenu
--@note 		底部菜单
--@author 	chengzhongjie
--@date 		2010/05/25
--@brief 		用于显示弹出菜单
require "module.sysmenu"
require "module.setting"

function hidePopupSprites()
	local ToDigReg = registerCreate("ToDigReg")
	local TuchReg=registerCreate("PopMenuHide")
	local ToDigFocus 
	if registerGetInteger(ToDigReg,"KeyFlag")==1 then
		ToDigFocus = registerGetInteger(ToDigReg,"ToDigFocus")
		registerSetInteger(ToDigReg,"KeyFlag",0)
	else
		ToDigFocus = registerGetInteger(TuchReg,"sencePreFocus")
	end
	if ToDigFocus then
		SetSpriteFocus(ToDigFocus)
	end
	
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	
	if hideMenuSprite(rootSprite) == 1 then	
		return	1
	end
	return	0;
end
function blackThemeButtonOnSelect(sprite)
	hidePopupSprites()
	ChangeSkin(255, 255, 255);
	Cfg.SaveTheme("black")
end

function pinkThemeButtonOnSelect(sprite)
	hidePopupSprites()
	ChangeSkin(107, 0, 0)
	Cfg.SaveTheme("pink")
end

function purpleThemeButtonOnSelect(sprite)
	hidePopupSprites()
	ChangeSkin(70, 0, 0)
	Cfg.SaveTheme("purple")
end

function blueThemeButtonOnSelect(sprite)
	hidePopupSprites()
	ChangeSkin(0, 0, 0)
	Cfg.SaveTheme("blue")
end

function themeKeyUp(sprite,keyCode)
	require "module.keyCode.keyCode"
	WriteLogs("-------------------++++++++++++++++++++++++++++:"..keyCode)
	item=GetParentSprite(sprite)
	local menuList=GetParentSprite(GetParentSprite(sprite))
	itemCount = SpriteList_GetListItemCount(menuList)
	WriteLogs("______name:"..GetSpriteName(menuList))
	index = SpriteListItem_GetIndex(item)
	WriteLogs(".....index:"..index)
	local list={"black","pink","purple","blue"}
	if keyCode==10 and index <=itemCount-1 then
		if index==(itemCount-1) then 
		
		return 0
		else
		listitem=SpriteList_GetListItem(menuList, index+1)
		WriteLogs("---------"..SpriteListItem_GetIndex(listitem))
		cursprite=FindChildSprite(listitem,list[index+2])
		SetSpriteFocus(cursprite)
		result=HasSpriteFocus(cursprite)
		WriteLogs("result:"..result)
		
		end

	elseif keyCode==3 then
		WriteLogs("index...."..index)
		if index==0 then 
		blackThemeButtonOnSelect(sprite)	
		elseif index==1 then 
		pinkThemeButtonOnSelect(sprite)	
		elseif index==2 then 
		purpleThemeButtonOnSelect(sprite)	
		elseif index==3 then 
		blueThemeButtonOnSelect(sprite)	
	end
	
	elseif keyCode==7 then
		local  reg = registerCreate("passSprite")
		local tool=registerGetInteger(reg, "SettingSprite")--记录当前结点
		SetSpriteFocus(tool)
		SetSpriteVisible(GetParentSprite(GetParentSprite(sprite)),0)
		SetSpriteEnable(GetParentSprite(GetParentSprite(sprite)),0)
		local  reg1 = registerCreate("passSprite1")
		registerSetInteger(reg1, "SettingSprite1", FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"black"))
		flag=1
		local flags=registerCreate("flags")
		registerSetInteger(flags, "flagtool",flag)
		
	
		elseif keyCode == ApKeyCode_F1 then
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			require("module.menuopen")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
			
		elseif keyCode == ApKeyCode_F2  then
			require("module.menuopen")
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
	
	elseif keyCode==9 and index>=1 then
		if index==0 then return 0
		else 
		listitem=SpriteList_GetListItem(menuList, index-1)
		WriteLogs("---------"..SpriteListItem_GetIndex(listitem))
		cursprite=FindChildSprite(listitem,list[index])
		SetSpriteFocus(cursprite)
		
		end
	end
		return 0
end