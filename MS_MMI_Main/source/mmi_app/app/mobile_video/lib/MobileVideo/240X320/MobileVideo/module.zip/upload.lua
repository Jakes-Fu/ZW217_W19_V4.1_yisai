﻿--调试开关
--设置状态信息
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.Loading.useLoading"
require "module.keyCode.keyCode"
---保存输入的描述内容
editText = nil

--上传文件类型
UPLOAD_FILE_TYPE = "3gp"

function SetStatusText(text)
	local reg = registerCreate("welcome")
	local labelStatus1 = registerGetInteger(reg, "status1")
	SetSpriteProperty(labelStatus1, "text", text)
end

function SetText(sprite, text)
	SetSpriteProperty(sprite, "text", text)
end

function bodyBuildChildrenFinished(sprite)
	local reg_u = registerCreate("upload")
	registerSetInteger(reg_u,"root",sprite)
	local reg1 = registerCreate("upload-select")
	filedir  = registerGetString(reg1, "upload-filedir")
	selectFileName = registerGetString(reg1, "upload_fileName")
	
	WriteLogs("fileDir="..filedir)
	WriteLogs("selectFileName="..selectFileName)
	
	local reg2 = registerCreate("System")
	upload = registerGetInteger(reg2,"Upload")
	if upload == 0 then
		upload = pluginCreate("Upload")
	end
	
	local reg = registerCreate("uploadinfor")
	local spriteScroll = FindChildSprite(sprite,"labelUploadVideoName")
	local spriteLabelUploadVideoName1 = FindChildSprite(sprite,"labelUploadVideoName1")
	
	if filedir and filedir ~= "" then
		SetSpriteProperty(spriteScroll,"text",filedir)
		registerSetString(reg, "upload-filedir",filedir)
		SetSpriteVisible(spriteLabelUploadVideoName1,0)
	else
		SetSpriteVisible(spriteLabelUploadVideoName1,1)
	end
	local inputUploadVideoName = FindChildSprite(sprite,"inputUploadVideoName")
	require "module.common.io"
	local ext = fileExt(selectFileName)
	local pos = string.find(selectFileName,ext,0)
	if pos then
		selectFileName = string.sub(selectFileName,0,pos-2)
	end

	if selectFileName then
		SetSpriteProperty(inputUploadVideoName,"text",selectFileName)
		if selectFileName ~= "" then
			local inputUploadVideoName1 = FindChildSprite(sprite,"inputUploadVideoName1")
			SetSpriteVisible(inputUploadVideoName1,0)
		end
		registerSetString(reg, "upload_fileName",selectFileName)
	end

	local textUploadFileNameImg = FindChildSprite(sprite,"textUploadFileNameImg")
	local buttonUploadFileBrowseImg = FindChildSprite(sprite,"buttonUploadFileBrowseImg")
	local inputUploadVideoNameImg = FindChildSprite(sprite,"inputUploadVideoNameImg")
	local inputUploadVideoDescImg = FindChildSprite(sprite,"inputUploadVideoDescImg")

	local buttonUploadFileBrowse = FindChildSprite(sprite,"buttonUploadFileBrowse")
	local inputUploadVideoDesc = FindChildSprite(sprite,"inputUploadVideoDesc")
	
	registerSetInteger(reg,"textUploadFileNameImg",textUploadFileNameImg)
	registerSetInteger(reg,"buttonUploadFileBrowseImg",buttonUploadFileBrowseImg)
	registerSetInteger(reg,"inputUploadVideoNameImg",inputUploadVideoNameImg)
	registerSetInteger(reg,"inputUploadVideoDescImg",inputUploadVideoDescImg)
	
	registerSetInteger(reg,"inputUploadVideoName",inputUploadVideoName)
	registerSetInteger(reg,"inputUploadVideoDesc",inputUploadVideoDesc)
	registerSetInteger(reg,"buttonUploadFileBrowse",buttonUploadFileBrowse)

	local spriteDesc1 = FindChildSprite(sprite,"inputDesc1")
	local spriteDesc = FindChildSprite(sprite,"inputDesc")
	SetSpriteVisible(spriteDesc1,1)
	SetSpriteVisible(spriteDesc,0)
	return 1
end

function OnPluginEvent(message, Param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if message == 105 then
		local reg = registerCreate("uploadinfor")
		local fileName = registerGetString(reg,"filename")
		local nodeTree = xmlLoadFile(fileName)
		local urlpath = nil
		local param = nil
		
		if nodeTree ~= 0 then
			local nodeRoot = xmlFindElement(nodeTree, nodeTree, "RESULT")
			if nodeRoot ~= 0 then
				local nodeUrl = xmlFindElement(nodeTree, nodeRoot, "URL")
				if nodeUrl ~= 0 then
					urlpath = xmlGetText(nodeUrl)
				end
				local nodeParam = xmlFindElement(nodeTree, nodeRoot, "PARAM")
				if nodeParam ~= 0 then
					param = xmlGetText(nodeParam)
				end	
			else
				exitLoading()
				require "module.dialog.useDialog"
				setDialogParam("提示", "网络数据错误", "BT_OK",sceneUpload ,sceneUpload,nil)
				Go2Scene(sceneDialog)
				return
			end
		else
			exitLoading()
			require "module.dialog.useDialog"
			setDialogParam("提示", "网络数据错误", "BT_OK",sceneUpload ,sceneUpload,nil)
			Go2Scene(sceneDialog)
			return
		end
		local uType = fileExt(filedir)
		local videoname = VideofileTitle
		local videodesc = VideoInstruction
		if urlpath and urlpath ~= 0 and param and param ~= 0 then
			pluginInvoke(upload, "Append", urlpath , param, filedir, videoname, videodesc, uType )	
			exitLoading()
			WriteLogs(videoname.." task is appended")
			
			local Curscene = GetCurScene()
			FreeScene(Curscene)
			Go2Scene(sceneUploadingInfo)
		else
			exitLoading()
			require "module.dialog.useDialog"
			setDialogParam("提示", "网络数据错误", "BT_OK",sceneUpload ,sceneUpload,nil)
			Go2Scene(sceneDialog)
			return
		end	
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneUpload, sceneUpload)
	elseif message > 32768 then 
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneUpload, sceneUpload, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function buttonUploadOnSelect(sprite)
	local spriteRoot = GetRootSprite(sprite)
	local spriteName = FindChildSprite(spriteRoot,"inputUploadVideoName")
	local spriteEvent = FindChildSprite(spriteRoot,"event")
	local name = GetSpriteText(spriteName)
	require "module.common.io"
	local ext = fileExt(filedir)
	local len = GetFileLength(filedir)
	require "module.setting"
	--local filter = Cfg.GetFileter()
	filter = {"*.3gp","*.3GP","*.wmv","*.avi","*.mpg","*.mp4"}
	local matchext = 0
	WriteLogs("table.max"..table.maxn(filter))
	for i=1,table.maxn(filter) do
		WriteLogs("string.sub "..string.sub(filter[i],3))
		if ext == string.sub(filter[i],3) then
			matchext = 1
			break
		end
	end
	saveTouchFocus(sprite)
	require "module.common.io"
	local spriteScroll = FindChildSprite(spriteRoot,"labelUploadVideoName")
	local DirText = GetSpriteText(spriteScroll)
	local fileExist = fileExist(DirText)
	if fileExist ~= nil then
		if	filedir==nil or name==nil or editText==nil or filedir == "" or name== "" or editText== "" then
			require "module.dialog.useDialog"
			setDialogParam("无法上传", "上传参数为空，请输入参数!", "BT_OK",sceneUpload ,sceneUpload,nil)
			Go2Scene(sceneDialog)
		elseif matchext == 0 then
			require "module.dialog.useDialog"
			setDialogParam("无法上传", "上传文件格式不支持", "BT_OK",sceneUpload ,sceneUpload,nil)
			Go2Scene(sceneDialog)
		elseif len > 5*1024*1024 then
			require "module.dialog.useDialog"
			setDialogParam("无法上传", "文件超过容量限制", "BT_OK",sceneUpload ,sceneUpload,nil)
			Go2Scene(sceneDialog)
		else
			local loadarea = FindChildSprite(spriteRoot ,"loadarea")
			enterLoading(loadarea)
	
			local reg = registerCreate("uploadinfor")
			registerSetString(reg,"upload-name",name)
			registerSetString(reg,"upload-desc",editText)
			registerSetInteger(reg,"upload-enter",1)
			require ("module.setting")
			local uploadUrl = Cfg.GetServer().."/ugcapp/uploadFile/UGC_GetUploadUrl.html"
			require "module.common.io"
			
			VideofileName = DirText
			require "module.protocol.protocol_systime"
			local jsonfile = OnSysDataDecode()
			if jsonfile and jsonfile.sysDate then
				VideoCreatTime = string.format("%s_%s",string.sub(jsonfile.sysDate,1,8),string.sub(jsonfile.sysDate,9,14))
			else
				VideoCreatTime = "20110101_010101"
			end
			VideofileTitle = name
			VideoInstruction = editText
			videoType = fileExt(DirText)
			MaxLen = GetFileLength(DirText)
			threads = 1
			type = "001"
			
			local postdata = string.format("FILE_NAME=%s&FILE_CREATE_TIME=%s&C_TITLE=%s&C_DESC=%s&C_TYPE=%s&C_LEN=%d&THREADS=%d&T_TYPE=%s",VideofileName,VideoCreatTime,VideofileTitle,VideoInstruction, videoType, MaxLen,threads,type)
			local fileName = GetLocalFilename(uploadUrl..postdata)
			registerSetString(reg,"filename",fileName)
			local regSystem = registerCreate("System")
			local http = registerGetInteger(regSystem, "comHttpPipe")
			local observer = pluginGetObserver()
			pluginInvoke(http, "AppendCommand", 1, uploadUrl, postdata, fileName, observer, 105, 0, 1)
		end
	else
		require "module.dialog.useDialog"
		setDialogParam("无法上传", "没有找到文件", "BT_OK",sceneUpload ,sceneUpload,nil)
		Go2Scene(sceneDialog)
	end
	
end

--背景变化了需要画不同的背景
function FocusChangedToDrawDiffBgImg(sprite)
	local reg = registerCreate("uploadinfor")
	local textUploadFileNameImg = registerGetInteger(reg,"textUploadFileNameImg")
	local buttonUploadFileBrowseImg = registerGetInteger(reg,"buttonUploadFileBrowseImg")
	local inputUploadVideoNameImg = registerGetInteger(reg,"inputUploadVideoNameImg")
	local inputUploadVideoDescImg = registerGetInteger(reg,"inputUploadVideoDescImg")
	
	local inputUploadVideoName = registerGetInteger(reg,"inputUploadVideoName")
	local inputUploadVideoDesc = registerGetInteger(reg,"inputUploadVideoDesc")
	local buttonUploadFileBrowse = registerGetInteger(reg,"buttonUploadFileBrowse")

	
	if  sprite == buttonUploadFileBrowse then
	   --选择文件
		SetSpriteProperty(textUploadFileNameImg, "src", "file:///image/UploadInfor/sc_con_jd.png")	
		SetSpriteProperty(buttonUploadFileBrowseImg, "src", "file:///image/UploadInfor/sc_ll_jd.png")	
		SetSpriteProperty(inputUploadVideoNameImg, "src", "file:///image/UploadInfor/sc_word.png")	
		SetSpriteProperty(inputUploadVideoDescImg, "src", "file:///image/UploadInfor/sc_con2.png")	   
	else
	    if sprite == inputUploadVideoName then
		   --修改视频名称
			SetSpriteProperty(textUploadFileNameImg, "src", "file:///image/UploadInfor/sc_con.png")	
			SetSpriteProperty(buttonUploadFileBrowseImg, "src", "file:///image/UploadInfor/sc_ll.png")	
			SetSpriteProperty(inputUploadVideoNameImg, "src", "file:///image/UploadInfor/sc_word_jj.png")	
			SetSpriteProperty(inputUploadVideoDescImg, "src", "file:///image/UploadInfor/sc_con2.png")	
		else
		   --修改视频注释信息
			SetSpriteProperty(textUploadFileNameImg, "src", "file:///image/UploadInfor/sc_con.png")	
			SetSpriteProperty(buttonUploadFileBrowseImg, "src", "file:///image/UploadInfor/sc_ll.png")	
			SetSpriteProperty(inputUploadVideoNameImg, "src", "file:///image/UploadInfor/sc_word.png")	
			SetSpriteProperty(inputUploadVideoDescImg, "src", "file:///image/UploadInfor/sc_con2_jd.png")	
		end
	end
end

function buttonUploadFileBrowseOnSelect(sprite)
	FocusChangedToDrawDiffBgImg( sprite )
	local reg = registerCreate("uploadinfor")
	
	local directory = registerGetString(reg,"current-directory")
	if directory == nil or directory == "" then
		require("module.setting")
		directory = Cfg.GetPhoneDownloadPath()
		registerSetString(reg,"current-directory",directory)
	end
	SetReturn( sceneUpload, sceneUploadSelect)
	FreeScene(GetCurScene())
	Go2Scene(sceneUploadSelect )
end

--更新 Videoname
function inputUploadVideoNameOnTextChanged(sprite)
	FocusChangedToDrawDiffBgImg( sprite )
	local inputUploadVideoName1 = FindChildSprite(GetCurScene(),"inputUploadVideoName1")
	SetSpriteVisible(inputUploadVideoName1,0)
end

--更新 Desc
function inputUploadVideoDescOnTextChanged(sprite)
	FocusChangedToDrawDiffBgImg( sprite )
	local parent = GetSpriteParent(sprite)
	local inputDesc = FindChildSprite(parent,"inputDesc")
	local inputDesc1 = FindChildSprite(parent,"inputDesc1")
	SetSpriteVisible(inputDesc1,0)
	SetSpriteVisible(inputDesc,1)
	
	editText =  GetSpriteText(sprite)
	if editText then
		SetSpriteProperty(inputDesc,"text",GetSpriteText(sprite))
		SetSpriteVisible(sprite,0)
	end
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	end
end

function OnSpriteEvent(message, params)

end

function TextOnSelected(sprite)
	local rootSprite = GetRootSprite(sprite)
	SetSpriteCapture(rootSprite)
end

function VideoNameOnTextChanged(sprite)
	ReleaseSpriteCapture(sprite)
	local rootSprite = GetRootSprite(sprite)
  	local sendSprite = FindChildSprite(rootSprite,"scapegoat")
  	SetSpriteFocus(sendSprite)
	local spriteLabelUploadVideoName1 = FindChildSprite(rootSprite,"labelUploadVideoName1")
	SetSpriteVisible(spriteLabelUploadVideoName1,0)
end

function UpLoadListKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	WriteLogs("@@@@@@@@@@@"..keyCode)
	local focus={"labelUploadVideoName","inputUploadVideoName","inputUploadVideoDesc","buttonUpload"}
	local focus2={"labelUploadVideoName","buttonUploadFileBrowse"}
	local name=GetSpriteName(sprite)
	 
	for i=1,4 do
		if focus[i]==name then
		focusNum=i
		break
		end
	end
	WriteLogs("SSSSSSSSSS"..name)
	if keyCode==ApKeyCode_Down and focusNum<=4 then 
		--[[if focusNum<2 then
		cursprite=FindChildSprite(GetSpriteParent(sprite),focus[focusNum+1])--]]
		if name==focus[4] then
		return 1
		elseif name=="buttonUploadFileBrowse" then
		cursprite=FindChildSprite(GetSpriteParent(sprite),focus[focusNum+1])
		else
		cursprite=FindChildSprite(GetSpriteParent(GetSpriteParent(sprite)),focus[focusNum+1])
		end
		SetSpriteFocus(cursprite)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2 then
		require("module.menuopen")
		WriteLogs("999999999999999999999999999999999999999999")
		returnButtonOnSelect(sprite)
		
	
	elseif keyCode==ApKeyCode_Up and focusNum>=2 then
		if  focusNum=="buttonUpload" then
		cursprite=FindChildSprite(GetSpriteParent(sprite),focus[focusNum-1])
		else
		cursprite=FindChildSprite(GetSpriteParent(GetSpriteParent(sprite)),focus[focusNum-1])
		end
	SetSpriteFocus(cursprite)
	elseif keyCode==ApKeyCode_Right and name=="labelUploadVideoName" then
		WriteLogs("dw!!!!!!!!!!!!!")
	cursprite=FindChildSprite(GetSpriteParent(GetSpriteParent(sprite)),"buttonUploadFileBrowse")
	SetSpriteFocus(cursprite)
	elseif keyCode==ApKeyCode_Left and name=="buttonUploadFileBrowse" then
		
		cursprite=FindChildSprite(FindChildSprite(GetSpriteParent(sprite),"frame"),"labelUploadVideoName")
		SetSpriteFocus(cursprite)
	end
		
	
	
	
	return 0
	end
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	