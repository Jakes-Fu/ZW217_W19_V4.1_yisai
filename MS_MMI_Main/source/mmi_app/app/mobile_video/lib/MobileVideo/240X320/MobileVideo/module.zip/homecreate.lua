--
require "module.keyCode.keyCode"
require "module.common.SceneUtils"
require("module.loading.useLoading")
local subPerPageItemCount=nil
local channelPerPageItemCount=nil
local pairPerPageItemCount=nil

function createKeywordList(sprite)
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.10-----------------------------]]--
	pageIndexReg= registerCreate("pageIndex")
	registerSetNumber(pageIndexReg,"subjectPageIndex",0)
	registerSetNumber(pageIndexReg,"channelPageIndex",0)
	registerSetNumber(pageIndexReg,"pairPageIndex",0)
	registerSetNumber(pageIndexReg,"searchItemIndex",0)
	registerSetNumber(pageIndexReg,"keyWordItemIndex",0)
	registerSetNumber(pageIndexReg,"subjectItemIndex",0)
	registerSetNumber(pageIndexReg,"channelItemIndex",0)
	registerSetNumber(pageIndexReg,"pairItemIndex",0)
	homeLastFoucsReg= registerCreate("homeLastFoucs")
	registerSetNumber(homeLastFoucsReg,"keyWordFirstFlag",1)  --是否第一次进入keyWord区域0表示否，1表示是
	registerSetNumber(homeLastFoucsReg,"channelFirstFlag",1)  --是否第一次进入keyWord区域0表示否，1表示是
	registerSetNumber(homeLastFoucsReg,"pairFirstFlag",1)  --是否第一次进入keyWord区域0表示否，1表示是
------------------------------------------------------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"KeyFlag",0)
	local spriteList = FindChildSprite(sprite, "hot-keywordslist")
	local l,t,w,h = GetSpriteRect(spriteList)
	local width2, height2 = GetTextSize("更多...")
	local imgWidth = 4
	local border = 3
	
	local left = 0
	local height = 20
	if homeData and homeData.keyword then
		local n = table.maxn(homeData.keyword)
		local xmlNode=xmlLoadFile("MODULE:\\keywordListItem.xml")
		for i=0, n do
			if i ==0 then
				local firstWidth, firstheight2 = GetTextSize(homeData.keyword[i].value)
				if (left + width2 + firstWidth) < w then
					local root = GetRootSprite(sprite)
					local searchSprite = FindChildSprite(root,"search-box")
					local searchEdit = FindChildSprite( searchSprite, "edit-text")
					SetSpriteProperty(searchEdit,"text",homeData.keyword[i].value)
				end
			end
			local width, height2 = GetTextSize(homeData.keyword[i].value)
			local width3 = 0
			if homeData.keyword[i+1] then
				width3 = GetTextSize(homeData.keyword[i+1].value)
			end
			if (left + width2 + border + 2*imgWidth + width) < w then
				local homeKeywordSprite = CreateSprite("listitem")
				LoadSpriteFromNode(homeKeywordSprite, xmlNode)
				SetSpriteRect(homeKeywordSprite, left, 0, width + imgWidth + imgWidth, height)
				local spriteButton = FindChildSprite(homeKeywordSprite, "keywordButton")
				SetSpriteRect(spriteButton, 0, 0, width + imgWidth + imgWidth, height)
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.5-----------------------------]]--			
				SetSpriteProperty(spriteButton,"name",string.format("keyword-button-%d", i))
				SetSpriteProperty(spriteButton,"OnKeyUp","homeCreateButtonHotKeywordsKeyUp")
-----------------------------------------------------------------------------------------------------			
				local spriteButtonLabel = FindChildSprite(homeKeywordSprite, "keywordslistLabel")
				if spriteButtonLabel then
					SetSpriteProperty(spriteButtonLabel, "text", homeData.keyword[i].value)
					SetSpriteRect(spriteButtonLabel, 0, 0, width + imgWidth + imgWidth, height)
				end
				local spriteButtonLabelFocus = FindChildSprite(homeKeywordSprite, "keywordslistLabelFocus")
				if spriteButtonLabelFocus then
					SetSpriteProperty(spriteButtonLabelFocus, "text", homeData.keyword[i].value)
					SetSpriteRect(spriteButtonLabelFocus, 0, 0, width + imgWidth + imgWidth, height)
				end
				left = left + width + imgWidth + imgWidth + border
				SpriteList_AddListItem(spriteList, homeKeywordSprite, 1)
			else
				break
			end
		end
		xmlRelease(xmlNode)
	end
	
	--添加更多
	local homeKeywordSprite = CreateSprite("listitem")
	LoadSprite(homeKeywordSprite, "MODULE:\\keywordListItem.xml")
	SetSpriteRect(homeKeywordSprite, left, 0, width2 + imgWidth + imgWidth, height)
	
	local spriteButton = FindChildSprite(homeKeywordSprite, "keywordButton")
	SetSpriteProperty(spriteButton, "name", "moreButton")
	SetSpriteProperty(spriteButton, "OnKeyUp", "homeCreateButtonHotKeywordsKeyUp")
	SetSpriteRect(spriteButton, 0, 0, width2 + imgWidth + imgWidth, height)
	
	local spriteButtonLabel = FindChildSprite(homeKeywordSprite, "keywordslistLabel")
	if spriteButtonLabel then
		SetSpriteProperty(spriteButtonLabel, "text", "更多...")
		SetSpriteRect(spriteButtonLabel, 0, 0, width2 + imgWidth + imgWidth, height)	
	end
	local spriteButtonLabelFocus = FindChildSprite(homeKeywordSprite, "keywordslistLabelFocus")
	if spriteButtonLabelFocus then
		SetSpriteProperty(spriteButtonLabelFocus, "text", "更多...")
		SetSpriteRect(spriteButtonLabelFocus, 0, 0, width2 + imgWidth + imgWidth, height)
	end
	SpriteList_AddListItem(spriteList, homeKeywordSprite, 1)
end

function createSubjectList(sprite)
	local spriteList = FindChildSprite(sprite, "subject-list")
	if homeData and homeData.subject then
		local subjectDataArray = homeData.subject
		local n = table.maxn(subjectDataArray)
		local xmlNode=xmlLoadFile("MODULE:\\homesubject.xml")
		for i=0, n do
			if ( "3" == subjectDataArray[i].nodeDisplayType ) then
					local phreg = registerCreate("paihang")
					registerSetString(phreg,"urlpath" , subjectDataArray[i].urlPath)
			end
			local homeSubjectSprite = CreateSprite("listitem")
			LoadSpriteFromNode(homeSubjectSprite, xmlNode)
			SetSpriteRect(homeSubjectSprite, 0, 0, 40, 27)
			
			local spriteButton = FindChildSprite(homeSubjectSprite, "buttonChangeName")
			SetSpriteProperty(spriteButton, "name", string.format("subject-button-%d", i))
			SetSpriteProperty(spriteButton, "OnSelect", "OnSelectFromSubjectButton")
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.5-----------------------------]]--			
			SetSpriteProperty(spriteButton,"OnKeyUp","homeCreateButtonSubjectKeyUp")
-----------------------------------------------------------------------------------------------------			
			SetSpriteRect(spriteButton, 0, 0, 40, 27)	
			
			local spriteSmallImg = FindChildSprite(homeSubjectSprite, "smallImg")
			if subjectDataArray[i].smallImg then
				SetSpriteProperty(spriteSmallImg, "src", subjectDataArray[i].smallImg)
			end
			
			--热点关键词栏目的字是图片，这里为了方便调试，暂时把字打印出来。
			local spriteNormalText = FindChildSprite(homeSubjectSprite, "textFocus")
			local spriteNormalText2 = FindChildSprite(homeSubjectSprite, "textFocus2")
			if subjectDataArray[i].channelName then
				SetSpriteProperty(spriteNormalText, "text", subjectDataArray[i].channelName)
				SetSpriteProperty(spriteNormalText2, "text", subjectDataArray[i].channelName)
				local channelNameWidth, channelNameHeight = GetTextSize(subjectDataArray[i].channelName)
				if channelNameWidth > 24 then 
					SetSpriteRect(spriteNormalText, 3,-1,36,27)
					SetSpriteRect(spriteNormalText2, 4,-1,36,27)
				end
			end

			local spriteNormalText = FindChildSprite(homeSubjectSprite, "textNormal")
			local spriteNormalText2 = FindChildSprite(homeSubjectSprite, "textNormal2")
			if subjectDataArray[i].channelName then
				SetSpriteProperty(spriteNormalText, "text", subjectDataArray[i].channelName)
				SetSpriteProperty(spriteNormalText2, "text", subjectDataArray[i].channelName)
				local channelNameWidth, channelNameHeight = GetTextSize(subjectDataArray[i].channelName)
				if channelNameWidth > 24 then 
					SetSpriteRect(spriteNormalText, 4,-2,33,27)
					SetSpriteRect(spriteNormalText2, 5,-2,33,27)
				end
			end
			SpriteList_AddListItem(spriteList, homeSubjectSprite, 1)
		end
		xmlRelease(xmlNode)
		SpriteList_Adjust(spriteList)
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.5-----------------------------]]--
		SetTimer(1,1,"SubjectListOnTimer")
--		local sprite1 = FindChildSprite(spriteList,"subject-button-0")
--		SetSpriteFocus(sprite1)
--		saveTouchFocus(sprite1)
--------------------------------------------------------------------------------------------------
--		local spriteLeftImage = FindChildSprite(sprite, "subject-left-enable-image")
--		local spriteRightImage = FindChildSprite(sprite, "subject-right-enable-image")
--		local start = SpriteList_GetStartItem(spriteList)
--		local step = SpriteList_GetItemPerPage(spriteList)
--		local total = SpriteList_GetListItemCount(spriteList)
--		DisplayButton(spriteLeftImage, spriteRightImage, start, step, total)
----[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.10-----------------------------]]--	
--		pageIndexReg= registerCreate("pageIndex")
--		registerSetNumber(pageIndexReg,"subjectPageTotal",(total%5==0 and total/5) or (math.ceil(total/5)))
--		homeLastFoucsReg= registerCreate("homeLastFoucs")
--		registerSetInteger(homeLastFoucsReg,"homeBackSprite",sprite1)
-----------------------------------------------------------------------------------------------------
	end
	subPerPageItemCount=SpriteList_GetItemPerPage(spriteList)
end

function SubjectListOnTimer()
	local reg = registerCreate("home")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "subject-list")
	local sprite1 = FindChildSprite(spriteList,"subject-button-0")
	SetSpriteFocus(sprite1)
	saveTouchFocus(sprite1)
------------------------------------------------------------------------------------------------
	local spriteLeftImage = FindChildSprite(sprite, "subject-left-enable-image")
	local spriteRightImage = FindChildSprite(sprite, "subject-right-enable-image")
	local start = SpriteList_GetStartItem(spriteList)
	local step = SpriteList_GetItemPerPage(spriteList)
	local total = SpriteList_GetListItemCount(spriteList)
	DisplayButton(spriteLeftImage, spriteRightImage, start, step, total)
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.10-----------------------------]]--	
	pageIndexReg= registerCreate("pageIndex")
	registerSetNumber(pageIndexReg,"subjectPageTotal",(total%5==0 and total/5) or (math.ceil(total/5)))
	homeLastFoucsReg= registerCreate("homeLastFoucs")
	registerSetInteger(homeLastFoucsReg,"homeBackSprite",sprite1)
end

--垂直栏目
function createChannelList(sprite)
	local spriteList = FindChildSprite(sprite, "channel-list")
	if homeData and homeData.specialChannel then
		local specialChannelDataArray = homeData.specialChannel
		local n = table.maxn(specialChannelDataArray)
		local xmlNode=xmlLoadFile("MODULE:\\homechannal.xml")
		for i=0, n do
			local homeChannelSprite = CreateSprite("listitem")
			LoadSpriteFromNode(homeChannelSprite, xmlNode)
			SetSpriteRect(homeChannelSprite, 0, 0, 47, 43)
			
			local spriteButton = FindChildSprite(homeChannelSprite, "buttonChangeName")
			SetSpriteProperty(spriteButton, "name", string.format("channel-button-%d", i))
			SetSpriteProperty(spriteButton, "OnSelect", "OnSelectFromChannelButton")
			SetSpriteRect(spriteButton, 0, 0, 47, 43)
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.9-----------------------------]]--	
			SetSpriteProperty(spriteButton,"OnKeyUp","homeCreateButtonChannelKeyUp")
-----------------------------------------------------------------------------------------------------			
			
			local spriteSmallImg = FindChildSprite(homeChannelSprite, "smallImg")
			if specialChannelDataArray[i].smallImg then
				SetSpriteProperty(spriteSmallImg, "src", specialChannelDataArray[i].smallImg)
			end
			local spriteNormalText = FindChildSprite(homeChannelSprite, "textFocus")
			if specialChannelDataArray[i].channelName then
				SetSpriteProperty(spriteNormalText, "text", specialChannelDataArray[i].channelName)
			end
			local spriteNormalText = FindChildSprite(homeChannelSprite, "textNormal")
			if specialChannelDataArray[i].channelName then
				SetSpriteProperty(spriteNormalText, "text", specialChannelDataArray[i].channelName)
			end
			SpriteList_AddListItem(spriteList, homeChannelSprite, 1)
		end
		xmlRelease(xmlNode)
		local reg_home = registerCreate("home")
		SpriteList_Adjust(spriteList)
		
		local spriteLeftImage = FindChildSprite(sprite, "channel-left-enable-image")
		local spriteRightImage = FindChildSprite(sprite, "channel-right-enable-image")
		local start = SpriteList_GetStartItem(spriteList)
		local step = SpriteList_GetItemPerPage(spriteList)
		local total = SpriteList_GetListItemCount(spriteList)
		DisplayButton(spriteLeftImage, spriteRightImage, start, step, total)
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.10-----------------------------]]--	
		pageIndexReg= registerCreate("pageIndex")
		registerSetNumber(pageIndexReg,"channelPageTotal",(total%8==0 and total/8) or (math.ceil(total/8)))
-----------------------------------------------------------------------------------------------------		
	end
	channelPerPageItemCount=SpriteList_GetItemPerPage(spriteList)
end


--合作专区
function createPairList(sprite)
	local spriteList = FindChildSprite(sprite, "pair-list")
	if homeData and homeData.channel then
		local channelDataArray = homeData.channel
		local n = table.maxn(channelDataArray)
		local xmlNode=xmlLoadFile("MODULE:\\homepartner.xml")
		for i=0, n do
			local homePairSprite = CreateSprite("listitem")
			LoadSpriteFromNode(homePairSprite, xmlNode)
			SetSpriteRect(homePairSprite, 0, 0, 68, 27)
			
			local spriteButton = FindChildSprite(homePairSprite, "buttonChangeName")
			SetSpriteProperty(spriteButton, "name", string.format("pair-button-%d", i))
			SetSpriteProperty(spriteButton, "OnSelect", "OnSelectFromPairButton")
			SetSpriteRect(spriteButton, 0, 0, 68, 27)
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.9-----------------------------]]--	
			SetSpriteProperty(spriteButton,"OnKeyUp","homeCreateButtonPairKeyUp")
-----------------------------------------------------------------------------------------------------				
			local spriteSmallImg = FindChildSprite(homePairSprite, "smallImg")
			if channelDataArray[i].img then
				SetSpriteProperty(spriteSmallImg, "src", channelDataArray[i].img)
			end
			SpriteList_AddListItem(spriteList, homePairSprite, 1)
		end
		xmlRelease(xmlNode)
		SpriteList_Adjust(spriteList)
		local spriteLeftImage = FindChildSprite(sprite, "pair-left-enable-image")
		local spriteRightImage = FindChildSprite(sprite, "pair-right-enable-image")
		local start = SpriteList_GetStartItem(spriteList)
		local step = SpriteList_GetItemPerPage(spriteList)
		local total = SpriteList_GetListItemCount(spriteList)
		DisplayButton(spriteLeftImage, spriteRightImage, start, step, total)
--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.10-----------------------------]]--	
		pageIndexReg= registerCreate("pageIndex")
		registerSetNumber(pageIndexReg,"pairPageTotal",(total%6==0 and total/6) or (math.ceil(total/6)))
-----------------------------------------------------------------------------------------------------	
	end
	pairPerPageItemCount=SpriteList_GetItemPerPage(spriteList)
end

function DisplayButton(spriteLeftImage, spriteRightImage, start, step, total)
	if spriteLeftImage and spriteLeftImage ~= 0 then
		if start >= step then
			SetSpriteVisible(spriteLeftImage, 1)
		else
			SetSpriteVisible(spriteLeftImage, 0)
		end
	end
	if spriteRightImage and spriteRightImage ~= 0 then
		if start + step < total then
			SetSpriteVisible(spriteRightImage, 1)
		else
			SetSpriteVisible(spriteRightImage, 0)
		end
	end
end

--[[--------------------------修改人：yaoxiangyin 修改日期：2010.8.5-----------------------------]]--
--[[
	registerSetNumber(pageIndexReg,"searchItemIndex",0)
	registerSetNumber(pageIndexReg,"keyWordItemIndex",0)
	registerSetNumber(pageIndexReg,"subjectItemIndex",0)
	registerSetNumber(pageIndexReg,"channelItemIndex",0)
	registerSetNumber(pageIndexReg,"pairItemIndex",0)
]]--
--hot-keywordslist区域的键盘操作
--【更多】有问题
function homeCreateButtonHotKeywordsKeyUp(sprite,keyCode)
	local hotKeywordsList={}  --存放热词中的Button名
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	--hot-keywordslist区域内操作
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --hot-keywordslist节点
	
	local keywordName = GetSpriteName(sprite)
	local keywordFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	--列表项各节点名存入临时表中
	for i=0,itemCount-1 do
		hotKeywordsList[i]="keyword-button-"..i
	end
	hotKeywordsList[itemCount-1]="moreButton"
	for i=0,itemCount-1 do
		WriteLogs("@@@@@@@@@@@$$$$$$$$$$$$$$"..hotKeywordsList[i])
		
	end
	
	--hotKeywordsList[itemCount-1]="moreButton"
	--寻找当前Button节点名
	for i=0,itemCount-1 do  
	  if hotKeywordsList[i]==keywordName then
	    keywordFocusNum=i
		WriteLogs("@@@@@@@@@@@$$$$$$$$$$$$$$"..hotKeywordsList[i])
	  end
	end
	local homeSpriteList=GetSpriteParent(GetSpriteParent(spriteList))  --主界面home节点
	
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
	registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
	registerSetNumber(homeLastFoucsReg,"lastFocusFlag",1)
	----------------------------ksw-------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	------------------------------------------------------------------
	registerSetInteger(homeLastFoucsReg,"lastKeywordFocusSprite",sprite)
	registerSetInteger(homeLastFoucsReg,"homeBackSprite",sprite)
	if keyCode == ApKeyCode_Left and keywordFocusNum>=1 then
		local sprite1=FindChildSprite(spriteList,hotKeywordsList[keywordFocusNum-1])
		SetSpriteFocus(sprite1)
		saveTouchFocus(sprite1)
	elseif keyCode == ApKeyCode_Right and keywordFocusNum<=itemCount-2 then
		local sprite1=FindChildSprite(spriteList,hotKeywordsList[keywordFocusNum+1])
		WriteLogs("@@@@@@@@@@@$$$$$$$$$$$$$$"..hotKeywordsList[keywordFocusNum+1])
		SetSpriteFocus(sprite1)
		saveTouchFocus(sprite1)
	elseif keyCode== ApKeyCode_Up then --执行向上操作
		--hot-keywordslist上边界操作
		registerSetNumber(pageIndexReg,"keyWordItemIndex",keywordFocusNum)
		local searchListSprite=FindChildSprite(FindChildSprite(homeSpriteList,"search-region"),"search-list")  --searchlist节点
		local defaultSearchButton
		if registerGetInteger(pageIndexReg,"searchItemIndex")==0 then
			defaultSearchButton=FindChildSprite(SpriteList_GetListItem(searchListSprite,0),"searchButton1")  
			local defaultEditText=FindChildSprite(defaultSearchButton,"edit-text")  --设置默认选中项
			SetSpriteFocus(defaultEditText)
			saveTouchFocus(defaultEditText)
		elseif registerGetInteger(pageIndexReg,"searchItemIndex")==1 then
			defaultSearchButton=FindChildSprite(SpriteList_GetListItem(searchListSprite,1),"searchButton2")  
			SetSpriteFocus(defaultSearchButton)
			saveTouchFocus(defaultSearchButton)
		end
	elseif keyCode== ApKeyCode_Down then --执行向下操作
		--hot-keywordslist下边界操作
		local subjectListSprite=FindChildSprite(SpriteList_GetListItem(homeSpriteList,2),"subject-list")  --searchlist节点
		--WriteLogs("@@@@@@@@@@@totalNum=="..(keywordFocusNum+5*registerGetInteger(pageIndexReg, "subjectPageIndex")))
		--keyword跳至subject非最后一页和最后一页区域的综合处理
		registerSetInteger(homeLastFoucsReg,"lastKeywordFocusSprite",sprite)
		local defaultSubjectButton
		--[[
		for i=keywordFocusNum,0,-1 do
			if FindChildSprite(SpriteList_GetListItem(subjectListSprite,i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")),"subject-button-"..(i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")))~=0 then
				defaultSubjectButton=FindChildSprite(SpriteList_GetListItem(subjectListSprite,i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")),"subject-button-"..(i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")))  --设置默认选中项
				WriteLogs("@@@@@@@@@@@defaultSubjectButtonIndex=="..i+5*registerGetInteger(pageIndexReg, "subjectPageIndex"))
				WriteLogs(FindChildSprite(SpriteList_GetListItem(subjectListSprite,i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")),"subject-button-"..(i+5*registerGetInteger(pageIndexReg, "subjectPageIndex"))))
				break
			end
		end
		]]--
		defaultSubjectButton=registerGetInteger(homeLastFoucsReg,"lastSubjectFocusSprite")
		SetSpriteFocus(defaultSubjectButton)
		saveTouchFocus(defaultSubjectButton)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_Enter then
		searchKeywordButtonOnSelect(sprite)
	end
end

--subjectlist区域的键盘操作
function homeCreateButtonSubjectKeyUp(sprite,keyCode)
	local homeInitFoucsReg= registerCreate("homeInitFoucs")
	registerSetInteger(homeInitFoucsReg,"InitFocusSprite",sprite)
	local subjectList={}  --存放列表项中的Button名
	require("module.homeOnButton")
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	--subject-list区域内操作
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --subject-list节点
	local spriteRightArrow=FindChildSprite(GetSpriteParent(spriteList),"subject-right-button")  --与subject-list节点平级的向右翻页按钮
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(spriteList),"subject-left-button")    --与subject-list节点平级的向左翻页按钮
	local subjectName = GetSpriteName(sprite)
	local ListCount = SpriteList_GetItemPerPage(spriteList)
	local subjectFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	for j=0,itemCount-1 do
		subjectList[j]="subject-button-"..j
	end
	local pageNum --总页数
	if itemCount%ListCount==0 then
		pageNum=itemCount/ListCount
	else
		pageNum=itemCount/ListCount+1
	end
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if subjectList[i]==subjectName then
	    subjectFocusNum=i
	  end
	end
	local homeSpriteList=GetSpriteParent(GetSpriteParent(spriteList))  --主界面home节点
	
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
	registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
	registerSetNumber(homeLastFoucsReg,"lastFocusFlag",1)
	----------------------------------ksw-------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	---------------------------------------------------------------------------
	registerSetInteger(homeLastFoucsReg,"homeBackSprite",sprite)
	
	if keyCode == ApKeyCode_Left and subjectFocusNum>=1 then
		if (subjectFocusNum%ListCount)==0 then --执行向左翻页
			--registerSetNumber(pageIndexReg,"subjectPageIndex",(registerGetInteger(pageIndexReg, "subjectPageIndex")-1))
			subjectButtonOnSelect(spriteLeftArrow)
		else --执行向左移动
			if subjectList[subjectFocusNum-1]~=nil then
				local sprite1=FindChildSprite(spriteList,"subject-button-"..(subjectFocusNum-1))
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		end
	elseif keyCode == ApKeyCode_Right and subjectFocusNum<=itemCount-2 then
		if ((subjectFocusNum+1)%ListCount)==0 then --执行向右翻页
			--registerSetNumber(pageIndexReg,"subjectPageIndex",(registerGetInteger(pageIndexReg, "subjectPageIndex")+1))
			subjectButtonOnSelect(spriteRightArrow)
		else ----执行向右移动
			if subjectList[subjectFocusNum+1]~=nil then
				local sprite1=FindChildSprite(spriteList,"subject-button-"..(subjectFocusNum+1))
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		end
	elseif keyCode== ApKeyCode_Up then --执行向上操作
		--subject-list上边界操作
		registerSetInteger(homeLastFoucsReg,"lastSubjectFocusSprite",sprite)--存储subject-list跨区域之前最近一次焦点
		local keywordslistSprite=FindChildSprite(FindChildSprite(homeSpriteList,"hot-keywords"),"hot-keywordslist")  --hot-keywordslist节点
		local defaultKeywordButton
		if registerGetNumber(homeLastFoucsReg,"keyWordFirstFlag")==1 then
			local defaultFocusIndex=subjectFocusNum%5
			if defaultFocusIndex==4 then
				--defaultKeywordButton=FindChildSprite(SpriteList_GetListItem(keywordslistSprite,defaultFocusIndex),"moreButton")  --设置默认选中项
				if FindChildSprite(SpriteList_GetListItem(keywordslistSprite,0),"keyword-button-0")~=0 then 
					defaultKeywordButton=FindChildSprite(SpriteList_GetListItem(keywordslistSprite,0),"keyword-button-0")  --设置默认选中项
				else
					defaultKeywordButton=FindChildSprite(keywordslistSprite,"moreButton")  --设置默认选中项
				end
			else
				--defaultKeywordButton=FindChildSprite(SpriteList_GetListItem(keywordslistSprite,defaultFocusIndex),"keyword-button-"..defaultFocusIndex)  --设置默认选中项
				if FindChildSprite(SpriteList_GetListItem(keywordslistSprite,0),"keyword-button-0")~=0 then 
					defaultKeywordButton=FindChildSprite(SpriteList_GetListItem(keywordslistSprite,0),"keyword-button-0")  --设置默认选中项
				else
					defaultKeywordButton=FindChildSprite(keywordslistSprite,"moreButton")  --设置默认选中项
				end
			end
			registerSetInteger(homeLastFoucsReg,"keyWordFirstFlag",0)
		else
			defaultKeywordButton=registerGetInteger(homeLastFoucsReg,"lastKeywordFocusSprite")
			--defaultKeywordButton=FindChildSprite(SpriteList_GetListItem(keywordslistSprite,0),"keyword-button-0")
		end
		registerSetInteger(homeLastFoucsReg,"lastKeywordFocusSprite",defaultKeywordButton)
		SetSpriteFocus(defaultKeywordButton)
		saveTouchFocus(defaultKeywordButton)
	elseif keyCode== ApKeyCode_Down then --执行向下操作
		--subject-list下边界操作
		registerSetInteger(homeLastFoucsReg,"lastSubjectFocusSprite",sprite)--存储subject-list跨区域之前最近一次焦点
		local channelListSprite=FindChildSprite(homeSpriteList,"channel-list") 
		local defaultFocusIndex=subjectFocusNum%5
		if defaultFocusIndex>=3 then
			defaultFocusIndex=defaultFocusIndex-1
		end
		
		--subject跳至channel非最后一页和最后一页区域的综合处理
		local defaultChannelButton
		if registerGetInteger(homeLastFoucsReg,"channelFirstFlag")==1 then
			for i=defaultFocusIndex,0,-1 do 
				if FindChildSprite(SpriteList_GetListItem(channelListSprite,i+channelPerPageItemCount*registerGetInteger(pageIndexReg, "channelPageIndex")),"channel-button-"..(i+channelPerPageItemCount*registerGetInteger(pageIndexReg, "channelPageIndex")))~=0 then
					defaultChannelButton=FindChildSprite(SpriteList_GetListItem(channelListSprite,i+channelPerPageItemCount*registerGetInteger(pageIndexReg, "channelPageIndex")),"channel-button-"..(i+channelPerPageItemCount*registerGetInteger(pageIndexReg, "channelPageIndex")))  --设置默认选中项
					WriteLogs("@@@@@@@@@@@defaultSubjectButtonIndex=="..i+channelPerPageItemCount*registerGetInteger(pageIndexReg, "channelPageIndex"))
					WriteLogs(FindChildSprite(SpriteList_GetListItem(channelListSprite,i+channelPerPageItemCount*registerGetInteger(pageIndexReg, "channelPageIndex")),"channel-button-"..(i+channelPerPageItemCount*registerGetInteger(pageIndexReg, "channelPageIndex"))))
					break
				end
			end	
			registerSetInteger(homeLastFoucsReg,"channelFirstFlag",0)
		else
			defaultChannelButton=registerGetInteger(homeLastFoucsReg,"lastChannelFocusSprite")
		end
		
		--local defaultChannelButton=FindChildSprite(SpriteList_GetListItem(channelListSprite,defaultFocusIndex+8*registerGetInteger(pageIndexReg, "channelPageIndex")),"channel-button-"..(defaultFocusIndex+8*registerGetInteger(pageIndexReg, "channelPageIndex")))  --设置默认选中项
		registerSetInteger(homeLastFoucsReg,"lastChannelFocusSprite",defaultChannelButton)
		SetSpriteFocus(defaultChannelButton)
		saveTouchFocus(defaultChannelButton)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
	
		SysGetSeceSprite(sprite)	
		menuButtonOnSelect(sprite)
		
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_Enter then
		OnSelectFromSubjectButton(sprite)
	end
end

--channellist区域的键盘操作
function homeCreateButtonChannelKeyUp(sprite,keyCode)
	local channelList={}  --存放列表项中的Button名
	require("module.homeOnButton")
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	--channel-list区域内操作
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --channel-list节点
	local spriteRightArrow=FindChildSprite(GetSpriteParent(GetSpriteParent(spriteList)),"channel-right-button")  --与channel-list节点平级的向右翻页按钮
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(GetSpriteParent(spriteList)),"channel-left-button")    --与channel-list节点平级的向左翻页按钮
	local channelName = GetSpriteName(sprite)
	local channelFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	local ListLine = SpriteList_GetLineCount(spriteList)		--行数1 2
	local ListCol = SpriteList_GetColCount(spriteList)		--列数5 4
	local ListCount = SpriteList_GetItemPerPage(spriteList)		--总数5 8
	for j=0,itemCount-1 do
		channelList[j]="channel-button-"..j
	end
	
	local pageNum --总页数
	if itemCount%ListCount==0 then
		pageNum=itemCount/ListCount
	else
		pageNum=math.ceil(itemCount/ListCount) 
	end
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if channelList[i]==channelName then
	    channelFocusNum=i
	  end
	end
	local upPositionFlag=0  --当前位置是否在上段标志0表示否，1表示是
	for i=0,pageNum-1 do
		if channelFocusNum>=i*ListCount and channelFocusNum<=i*ListCount+ListCol-1 then
			upPositionFlag=1
			break
		end
	end
	
	local lineNum --总行数
	if itemCount%ListCol==0 then
		lineNum=itemCount/ListCol
	else
		lineNum=math.ceil(itemCount/ListCol) 
	end
	local rightEdgeFalg=0 --当前位置是否在右边缘标志0表示否，1表示是
	local leftEdgeFalg=0  --当前位置是否在左边缘标志0表示否，1表示是
	for i=0,lineNum-1 do
		if channelFocusNum==i*ListCol+ListCol-1 then
			rightEdgeFalg=1
			break
		elseif channelFocusNum==i*ListCol then
			leftEdgeFalg=1
			break
		end
	end
	
	local homeSpriteList=GetSpriteParent(GetSpriteParent(GetSpriteParent(spriteList)))   --主界面home节点
	
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
	registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
	registerSetInteger(homeLastFoucsReg,"lastChannelFocusSprite",sprite)  --存储跳转区域之前最新channellist上焦点
	registerSetNumber(homeLastFoucsReg,"lastFocusFlag",1)
	registerSetInteger(homeLastFoucsReg,"homeBackSprite",sprite)
	
	----------------------------------------ksw-------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	------------------------------------------------------------------------------------------------
	if keyCode== ApKeyCode_Down then
		if upPositionFlag==1 then --channellist区域内向下移动
			
			if channelList[channelFocusNum+ListCol]~=nil and ListLine ~= 1 then 
				local sprite1=FindChildSprite(spriteList,channelList[channelFocusNum+ListCol])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			else
				local defaultFocusIndex
				if ListLine == 2 and ListCol == 4 then
					if channelFocusNum%ListCol==0 then
						defaultFocusIndex=0
					elseif channelFocusNum%ListCol==1 or channelFocusNum%4==2 then
						defaultFocusIndex=1
					elseif channelFocusNum%ListCol==3 then
						defaultFocusIndex=2
					end
				elseif ListLine == 1 and ListCol == 5 then
					if channelFocusNum%ListCol==0 then
						defaultFocusIndex=0
					elseif channelFocusNum%ListCol==1 or channelFocusNum%ListCol==2 or channelFocusNum%ListCol==3 then
						defaultFocusIndex=1
					elseif channelFocusNum%ListCol==4 then
						defaultFocusIndex=2
					end
				end
				local pairListSprite=FindChildSprite(homeSpriteList,"pair-list") 
				--channel跳至pair非最后一页和最后一页区域的综合处理
				local defaultPairButton
				for i=defaultFocusIndex,0,-1 do
					if FindChildSprite(SpriteList_GetListItem(pairListSprite,i+pairPerPageItemCount*registerGetInteger(pageIndexReg, "pairPageIndex")),"pair-button-"..(i+pairPerPageItemCount*registerGetInteger(pageIndexReg, "pairPageIndex")))~=0 then
						defaultPairButton=FindChildSprite(SpriteList_GetListItem(pairListSprite,i+pairPerPageItemCount*registerGetInteger(pageIndexReg, "pairPageIndex")),"pair-button-"..(i+pairPerPageItemCount*registerGetInteger(pageIndexReg, "pairPageIndex")))  --设置默认选中项
						--WriteLogs("@@@@@@@@@@@defaultSubjectButtonIndex=="..i+6*registerGetInteger(pageIndexReg, "pairPageIndex"))
						--WriteLogs(FindChildSprite(SpriteList_GetListItem(pairListSprite,i+6*registerGetInteger(pageIndexReg, "pairPageIndex")),"pair-button-"..(i+6*registerGetInteger(pageIndexReg, "pairPageIndex"))))
						break
					end
				end
			
			--local defaultPairButton=FindChildSprite(SpriteList_GetListItem(pairListSprite,defaultFocusIndex+6*registerGetInteger(pageIndexReg, "pairPageIndex")),"pair-button-"..(defaultFocusIndex+6*registerGetInteger(pageIndexReg, "pairPageIndex")))  --设置默认选中项
			registerSetInteger(homeLastFoucsReg,"lastPairFocusSprite",defaultPairButton)
			SetSpriteFocus(defaultPairButton)
			saveTouchFocus(defaultPairButton)
			end
		elseif upPositionFlag==0 or ListLine == 1 then --channellist下边界操作
			local defaultFocusIndex
			if ListLine == 2 and ListCol == 4 then
				if channelFocusNum%ListCount==4 then
					defaultFocusIndex=0
				elseif channelFocusNum%ListCount==5 or channelFocusNum%ListCount==6 then
					defaultFocusIndex=1
				elseif channelFocusNum%ListCount==7 then
					defaultFocusIndex=2
				end
			elseif ListLine == 1 and ListCol == 5 then
				if channelFocusNum%ListCount==0 then
					defaultFocusIndex=0
				elseif channelFocusNum%ListCount==1 or channelFocusNum%ListCount==2 or channelFocusNum%ListCount==3 then
					defaultFocusIndex=1
				elseif channelFocusNum%ListCount==4 then
					defaultFocusIndex=2
				end				
			end
			local pairListSprite=FindChildSprite(homeSpriteList,"pair-list") 
			
			--channel跳至pair非最后一页和最后一页区域的综合处理
			local defaultPairButton
			if registerGetInteger(homeLastFoucsReg,"pairFirstFlag")==1 then
				for i=defaultFocusIndex,0,-1 do
					if FindChildSprite(SpriteList_GetListItem(pairListSprite,i+6*registerGetInteger(pageIndexReg, "pairPageIndex")),"pair-button-"..(i+6*registerGetInteger(pageIndexReg, "pairPageIndex")))~=0 then
						defaultPairButton=FindChildSprite(SpriteList_GetListItem(pairListSprite,i+6*registerGetInteger(pageIndexReg, "pairPageIndex")),"pair-button-"..(i+6*registerGetInteger(pageIndexReg, "pairPageIndex")))  --设置默认选中项
						--WriteLogs("@@@@@@@@@@@defaultSubjectButtonIndex=="..i+6*registerGetInteger(pageIndexReg, "pairPageIndex"))
						--WriteLogs(FindChildSprite(SpriteList_GetListItem(pairListSprite,i+6*registerGetInteger(pageIndexReg, "pairPageIndex")),"pair-button-"..(i+6*registerGetInteger(pageIndexReg, "pairPageIndex"))))
						break
					end
				end
				registerSetInteger(homeLastFoucsReg,"pairFirstFlag",0)
			else
				defaultPairButton=registerGetInteger(homeLastFoucsReg,"lastPairFocusSprite")  
			end
			--local defaultPairButton=FindChildSprite(SpriteList_GetListItem(pairListSprite,defaultFocusIndex+6*registerGetInteger(pageIndexReg, "pairPageIndex")),"pair-button-"..(defaultFocusIndex+6*registerGetInteger(pageIndexReg, "pairPageIndex")))  --设置默认选中项
			registerSetInteger(homeLastFoucsReg,"lastPairFocusSprite",defaultPairButton)
			SetSpriteFocus(defaultPairButton)
			saveTouchFocus(defaultPairButton)
		end
	elseif keyCode== ApKeyCode_Up then
		if upPositionFlag==0 then --channellist区域内向上移动
			local sprite1=FindChildSprite(spriteList,channelList[channelFocusNum-4])
		    SetSpriteFocus(sprite1)
			saveTouchFocus(sprite1)
		elseif upPositionFlag==1 then  --channellist上边界操作
			registerSetInteger(homeLastFoucsReg,"lastChannelFocusSprite",sprite)  --存储跳转区域之前最新channellist上焦点
			local defaultFocusIndex=channelFocusNum%4
			if defaultFocusIndex>=2 then
				defaultFocusIndex=defaultFocusIndex+1
			end
			local subjectListSprite=FindChildSprite(SpriteList_GetListItem(homeSpriteList,2),"subject-list")  --searchlist节点
			--channel跳至subject非最后一页和最后一页区域的综合处理		
			local defaultSubjectButton
			--[[
			for i=defaultFocusIndex,0,-1 do
				if FindChildSprite(SpriteList_GetListItem(subjectListSprite,i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")),"subject-button-"..(i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")))~=0 then
				defaultSubjectButton=FindChildSprite(SpriteList_GetListItem(subjectListSprite,i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")),"subject-button-"..(i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")))  --设置默认选中项
				--WriteLogs("@@@@@@@@@@@defaultSubjectButtonIndex=="..i+5*registerGetInteger(pageIndexReg, "subjectPageIndex"))
				--WriteLogs(FindChildSprite(SpriteList_GetListItem(subjectListSprite,i+5*registerGetInteger(pageIndexReg, "subjectPageIndex")),"subject-button-"..(i+5*registerGetInteger(pageIndexReg, "subjectPageIndex"))))
				break
				end
			end
			]]--
			defaultSubjectButton=registerGetInteger(homeLastFoucsReg,"lastSubjectFocusSprite")
			--local defaultSubjectButton=FindChildSprite(SpriteList_GetListItem(subjectListSprite,defaultFocusIndex+5*registerGetInteger(pageIndexReg, "subjectPageIndex")),"subject-button-"..(defaultFocusIndex+5*registerGetInteger(pageIndexReg, "subjectPageIndex")))  --设置默认选中项
			SetSpriteFocus(defaultSubjectButton)
			saveTouchFocus(defaultSubjectButton)
		end
	elseif keyCode== ApKeyCode_Right then	
		if rightEdgeFalg==0 then --channellist区域内向右移动
			if channelList[channelFocusNum+1]~=nil then
				local sprite1=FindChildSprite(spriteList,channelList[channelFocusNum+1])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		elseif rightEdgeFalg==1 then --channellist右边界操作
			if registerGetInteger(pageIndexReg,"channelPageIndex")<pageNum-1 then
				--registerSetNumber(pageIndexReg,"channelPageIndex",(registerGetInteger(pageIndexReg, "channelPageIndex")+1))
				channelButtonOnSelect(spriteRightArrow)
			end
		end
	elseif keyCode== ApKeyCode_Left then	
		if leftEdgeFalg==0 then --channellist区域内向左移动
			if channelList[channelFocusNum-1]~=nil then
				local sprite1=FindChildSprite(spriteList,channelList[channelFocusNum-1])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		elseif leftEdgeFalg==1 then  --channellist左边界操作
			if registerGetInteger(pageIndexReg,"channelPageIndex")>0 then
				--registerSetNumber(pageIndexReg,"channelPageIndex",(registerGetInteger(pageIndexReg, "channelPageIndex")-1))
				channelButtonOnSelect(spriteLeftArrow)
			end
		end
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_Enter then
		OnSelectFromChannelButton(sprite)
	end
end

--pair-list区域的键盘操作
function homeCreateButtonPairKeyUp(sprite,keyCode)
	local pairList={}  --存放列表项中的Button名
	require("module.homeOnButton")
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	--pair-list区域内操作
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --pair-list节点
	--WriteLogs("@@@@@@@@@@@"..GetSpriteName(spriteList))
	local spriteRightArrow=FindChildSprite(GetSpriteParent(spriteList),"pair-right-button")  --与pair-list节点平级的向右翻页按钮
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(spriteList),"pair-left-button")    --与pair-list节点平级的向左翻页按钮
	local pairName = GetSpriteName(sprite)
	local pairFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	local ListLine = SpriteList_GetLineCount(spriteList)		--行数1 2
	local ListCol = SpriteList_GetColCount(spriteList)		--列数4 3
	local ListCount = SpriteList_GetItemPerPage(spriteList)		--总数4 6
	for j=0,itemCount-1 do
		pairList[j]="pair-button-"..j
	end
	
	local pageNum --总页数
	if itemCount%ListCount==0 then
		pageNum=itemCount/ListCount
	else
		pageNum=math.ceil(itemCount/ListCount)
	end
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if pairList[i]==pairName then
	    pairFocusNum=i
	  end
	end
	
	local upPositionFlag=0  --当前位置是否在上段标志0表示否，1表示是
	for i=0,pageNum-1 do
		if pairFocusNum>=i*ListCount and pairFocusNum<=i*ListCount+ListCol-1 then
			upPositionFlag=1
			break
		end
	end
	
	local lineNum --总行数
	if itemCount%ListCol==0 then
		lineNum=itemCount/ListCol
	else
		lineNum=math.ceil(itemCount/ListCol) 
	end
	local rightEdgeFalg=0 --当前位置是否在右边缘标志0表示否，1表示是
	local leftEdgeFalg=0  --当前位置是否在左边缘标志0表示否，1表示是
	for i=0,lineNum-1 do
		if pairFocusNum==i*ListCol+ListCol-1 then
			rightEdgeFalg=1
			break
		elseif pairFocusNum==i*ListCol then
			leftEdgeFalg=1
			break
		end
	end
	
	local homeSpriteList=GetSpriteParent(GetSpriteParent(spriteList))   --主界面home节点
	local menuBarListSprite=FindChildSprite(homeSpriteList,"QuickLauncherBar") 
			WriteLogs("@@@@@@@@@@@"..GetSpriteName(menuBarListSprite))
	
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
	registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
	registerSetNumber(homeLastFoucsReg,"lastFocusFlag",1)
	---------------------------------------ksw---------------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	------------------------------------------------------------------------------------------------------
	registerSetInteger(homeLastFoucsReg,"lastPairFocusSprite",sprite)
	registerSetInteger(homeLastFoucsReg,"homeBackSprite",sprite)
	
	if keyCode== ApKeyCode_Down then
		--if upPositionFlag==1 then --pairlist区域内向下移动
			if pairList[pairFocusNum+ListCol]~=nil and ListLine ~=1 then
				local prePageIndex=math.floor(pairFocusNum/ListCount)
				local nextPageIndex=math.floor((pairFocusNum+ListCol)/ListCount)
				if prePageIndex==nextPageIndex then
					local sprite1=FindChildSprite(spriteList,pairList[pairFocusNum+ListCol])
					SetSpriteFocus(sprite1)
					saveTouchFocus(sprite1)
				end
			end
		--elseif upPositionFlag==0 then --pairlist下边界操作
			--local menuBarListSprite=FindChildSprite(homeSpriteList,"QuickLauncherBar") 
			--WriteLogs("@@@@@@@@@@@"..GetSpriteName(menuBarListSprite))
			--local defaultPairButton=FindChildSprite(SpriteList_GetListItem(pairListSprite,0),"pair-button-0")  --设置默认选中项
			--SetSpriteFocus(defaultPairButton)
		--end
	elseif keyCode== ApKeyCode_Up then
		if upPositionFlag==0 then --pairlist区域内向上移动
			local sprite1=FindChildSprite(spriteList,pairList[pairFocusNum-3])
		    SetSpriteFocus(sprite1)
			saveTouchFocus(sprite1)
		elseif upPositionFlag==1 then  --pairlist上边界操作
			registerSetInteger(homeLastFoucsReg,"lastPairFocusSprite",sprite)  --存储Pairlist区域跳转之前最新焦点
			local defaultFocusIndex
			if pairFocusNum%ListCount==0 then
				defaultFocusIndex=4
			elseif pairFocusNum%ListCount==1 then
				defaultFocusIndex=5
			elseif pairFocusNum%ListCount==2 then
				defaultFocusIndex=7
			end
			local channelListSprite=FindChildSprite(homeSpriteList,"channel-list") 
			--pair跳至channel非最后一页和最后一页区域的综合处理		
			local defaultChannelButton
			--WriteLogs("@@@@@@@@@@@##########"..upPositionFlag)
			--[[
			for i=defaultFocusIndex,0,-1 do
				if FindChildSprite(SpriteList_GetListItem(channelListSprite,i+8*registerGetInteger(pageIndexReg, "channelPageIndex")),"channel-button-"..(i+8*registerGetInteger(pageIndexReg, "channelPageIndex")))~=0 then
					defaultChannelButton=FindChildSprite(SpriteList_GetListItem(channelListSprite,i+8*registerGetInteger(pageIndexReg, "channelPageIndex")),"channel-button-"..(i+8*registerGetInteger(pageIndexReg, "channelPageIndex")))  --设置默认选中项
					--WriteLogs("@@@@@@@@@@@defaultSubjectButtonIndex=="..i+8*registerGetInteger(pageIndexReg, "channelPageIndex"))
					--WriteLogs(FindChildSprite(SpriteList_GetListItem(channelListSprite,i+8*registerGetInteger(pageIndexReg, "channelPageIndex")),"channel-button-"..(i+8*registerGetInteger(pageIndexReg, "channelPageIndex"))))
					break
				end
			end			
			]]--
			defaultChannelButton=registerGetInteger(homeLastFoucsReg,"lastChannelFocusSprite")
			--local defaultChannelButton=FindChildSprite(SpriteList_GetListItem(channelListSprite,defaultFocusIndex+8*registerGetInteger(pageIndexReg, "channelPageIndex")),"channel-button-"..(defaultFocusIndex+8*registerGetInteger(pageIndexReg, "channelPageIndex")))  --设置默认选中项
			SetSpriteFocus(defaultChannelButton)
			saveTouchFocus(defaultChannelButton)
		end
	elseif keyCode== ApKeyCode_Right then	
		if rightEdgeFalg==0 then --pairlist区域内向右移动
			if pairList[pairFocusNum+1]~=nil then
				local sprite1=FindChildSprite(spriteList,pairList[pairFocusNum+1])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		elseif rightEdgeFalg==1 then --pairlist右边界操作
			if registerGetInteger(pageIndexReg,"pairPageIndex")<pageNum-1 then
			--registerSetNumber(pageIndexReg,"pairPageIndex",(registerGetInteger(pageIndexReg, "pairPageIndex")+1))
			pairButtonOnSelect(spriteRightArrow)
			end
		end
	elseif keyCode== ApKeyCode_Left then	
		if leftEdgeFalg==0 then --pairlist区域内向左移动
			if pairList[pairFocusNum-1]~=nil then
				local sprite1=FindChildSprite(spriteList,pairList[pairFocusNum-1])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		elseif leftEdgeFalg==1 then  --pairlist左边界操作
			if registerGetInteger(pageIndexReg,"pairPageIndex")>0 then
			--registerSetNumber(pageIndexReg,"pairPageIndex",(registerGetInteger(pageIndexReg, "pairPageIndex")-1))
			pairButtonOnSelect(spriteLeftArrow)
			end
		end
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("@@@@@@！！！！！！！！！！%%%%:----------------------:aaaaaaaaaaabbbbbbbccccccccc")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		WriteLogs("123213213213213214213213")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		WriteLogs("123213213213213214213213")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_Enter then
		OnSelectFromPairButton(sprite)
	end
end
--------------------------------------------------------------------------------------------------------


