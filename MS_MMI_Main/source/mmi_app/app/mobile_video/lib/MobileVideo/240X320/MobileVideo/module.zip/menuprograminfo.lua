--@author xf_pan
--@date 2010/06/15

-- ���浱ǰ�����urlPath
function SetProgramInfoUrlPath(urlPath)
	local regSystem = registerCreate("ProgramInfoUrlPath")
	registerSetString(regSystem, "ProgramInfoUrlPath_value", urlPath)
end

-- ��ȡ��ǰ�����urlPath
function GetProgramInfoUrlPath()
	local regSystem = registerCreate("ProgramInfoUrlPath")
	return registerGetString(regSystem, "ProgramInfoUrlPath_value")
end