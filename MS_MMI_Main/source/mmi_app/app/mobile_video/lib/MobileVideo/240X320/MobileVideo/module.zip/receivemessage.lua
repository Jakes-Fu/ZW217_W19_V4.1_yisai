﻿--@module receivemessage
--@note 收件箱一级菜单
--@author jianglei,modified by cuiyizhou
--@date 2010/06/01
--Modified by Chen Zhonglong
--Date 2010/08/26

require "module.common.registerScene"
require "module.common.SceneUtils"
require "module.keyCode.keyCode"

--收件箱列表--
function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("receive")   
	registerSetInteger(reg, "root", sprite)
	--[[  读取数据  ]]--  
	ListDataName = {}
	ListDataKey = {}
	ListData = {}
	itemIndex = {}
	xmltest()
	CreateMsgList(sprite)
	createMsgBoxList()
	local spriteSelect = FindChildSprite(sprite,"select")
	SetSpriteVisible(spriteSelect, 1)			
	SetSpriteEnable(spriteSelect, 1)
	SetSpriteFocus(FindChildSprite(sprite, "columnbtn"))
	saveTouchFocus(FindChildSprite(sprite, "columnbtn"))
	clickCount = 0
	return 1
end
 
function xmltest()
	local reg = registerCreate("temp")
	registerLoad(reg, "MODULE:\\videoexpress\\categoryID0.xml")
	local count = registerGetInteger(reg,"count")
	for i=1,count do
		local name = FindValue(reg,"item"..i,"MsgTitle")
		local receiveData = FindValue(reg,"item"..i,"receiveData")
		if name and receiveData then
			table.insert(ListDataName,name)
			table.insert(ListDataKey,"item"..i)
			table.insert(ListData,receiveData)
		end
	end
	registerRelease("temp")
end

function FindValue(reg,itemNo,categoryName)
	local data = registerGetString(reg,itemNo)
	local i,j = string.find(data,"{"..categoryName.."}")
	if j then 
		i = string.find(data,"{",j+1)
		j = string.find(data,"}",j+1)
		return string.sub(data,i+1,j-1)
	else
		return nil
	end
end

--@function	getMsgListToTable
--@brief	获取并返回列表项表
function getMsgListToTable()
	local temp = registerCreate("temp")
	registerLoad(temp, "MODULE:\\videoexpress\\categoryID0.xml")
	local totalcount = registerGetInteger(temp,"totalcount")
	local count = registerGetInteger(temp,"count")
	local itemlist = {"未读消息("..count..")"}     

	for i=1, totalcount do
		local filepath = "MODULE:\\videoexpress\\categoryID"..i..".xml"
		local dir = OpenDirectory(filepath)
	 	if dir then
			registerLoad(temp, filepath)
			local name = registerGetString(temp,"categoryName")
			local count = registerGetString(temp,"count")
			table.insert(itemlist,name.."("..count..")")
			table.insert(itemIndex,i)
		end
	end
	registerRelease("temp")
	return itemlist
end

--@function	getMsgBoxListToTable
--@brief	获取并返回列表子项表
function getMsgBoxListToTable()
	return ListDataName
end

--@function	bodyOnSpriteEvent
--@brief	返回free事件
function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_USER + 99 then
		FreeScene(GetCurScene())
	elseif message == MSG_SMS then
		requestMsgContent()
	elseif message == 1001 then
		require "module.common.reveiveMsgCtrl"
		local reg = registerCreate("receive")   
		local sprite = registerGetInteger(reg, "deleteSprite")
		receiveMsgDelete(sprite)
		local curSprite = GetCurScene()
		FreeScene(curSprite)
		Go2Scene(sceneReceiveMessage)
	elseif message == 1002 then
		local Curscene = GetCurScene()
		FreeScene(Curscene)
		Go2Scene(sceneReceiveMessage)
	end
end

--@function	CreateMsgList
--@brief	创建列表
function CreateMsgList(sprite)
	local spriteList = FindChildSprite(sprite, "message-list")
	local msgTitle = getMsgListToTable()
	local xmlNode=xmlLoadFile("MODULE:\\receivemessageListItem.xml")
	for i = 1, #msgTitle do
		local recemsgSprite = CreateSprite("listitem")
		LoadSpriteFromNode(recemsgSprite, xmlNode)
				
		--给列表项赋值
		local spriteItemText = FindChildSprite(recemsgSprite,"item-Msg-Text")
		local spriteItemUnText = FindChildSprite(recemsgSprite,"item-Msg-UnText")
		SetSpriteProperty(spriteItemText, "text", msgTitle[i])
		SetSpriteProperty(spriteItemUnText, "text", msgTitle[i])
		
		SetSpriteRect(recemsgSprite, 5, 0, 223, 27)		
		AddChildSprite(spriteList, recemsgSprite)
		SpriteList_AddListItem(spriteList, recemsgSprite)
	end
	xmlRelease(xmlNode)
	SpriteList_Adjust(spriteList)
end
--@function	createMsgBoxList
--@brief	创建列表子项
function createMsgBoxList()
	local reg = registerCreate("receive")   
	local root = registerGetInteger(reg, "root")
	local spriteBoxlist = FindChildSprite(root, "item-list")
	
	local msgListText = getMsgBoxListToTable()
	local xmlNode=xmlLoadFile("MODULE:\\receivemessageboxListItem.xml")
	for j = 1, 3 do
		if msgListText[j] then
			--列表子项
			local recemsglistSprite = CreateSprite("listitem")
			LoadSpriteFromNode(recemsglistSprite, xmlNode)
			
			--给列表项赋值
			local spriteBoxItemText = FindChildSprite(recemsglistSprite,"item-MsgBox-Text")
			local spriteBoxItemUnText = FindChildSprite(recemsglistSprite,"item-MsgBox-UnText")
			local spriteBoxItemDate = FindChildSprite(recemsglistSprite, "item-list-select-title")
			
			SetSpriteProperty(spriteBoxItemText, "text", msgListText[j])
			SetSpriteProperty(spriteBoxItemUnText, "text", msgListText[j])
			SetSpriteProperty(spriteBoxItemDate, "text", ListData[j])
			--SetSpriteProperty(spriteBoxItemDate, "text", "2010-06-01 17:08:56")
	
			SetSpriteRect(recemsglistSprite, 0, 1, 223, 25)
			AddChildSprite(spriteBoxlist, recemsglistSprite)
			SpriteList_AddListItem(spriteBoxlist, recemsglistSprite)
		end
	end
	xmlRelease(xmlNode)
	SpriteList_Adjust(spriteBoxlist)
end


function itemShowAllBtnOnSelect(sprite)
	local spriteName = GetSpriteName(sprite)
	if spriteName == "select-btn-check-all" then
		local curSprite = GetCurScene()
		FreeScene(curSprite)
		local reg = registerCreate("receive_secondary")
		registerSetString(reg, "loadpath", "MODULE:\\videoexpress\\categoryID0.xml")
		registerSetString(reg, "istodelete", "1")
		Go2Scene(sceneReceiveSecondary)
		SetReturn(sceneReceiveMessage,sceneReceiveSecondary)
	end
end

function btnItemOptionOnSelect(sprite)
	require "module.Loading.useLoading"
	local spriteName = GetSpriteName(sprite)
	local reg = registerCreate("receive")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root ,"loadarea")	
	--[[  浏览操作  ]]--
	if spriteName == "item-list-select-tosee" then
		enterLoading(loadarea)
		require "module.common.reveiveMsgCtrl"
		local returnValue = receiveMsgBrowse(sprite)
		if returnValue == "4" then					--专题消息
			local curSprite = GetCurScene()				--跳转专题列表
			FreeScene(curSprite)
			Go2Scene(sceneReceiveThird)
			SetReturn(sceneReceiveMessage,sceneReceiveThird)	

		elseif returnValue == "5" then 					--视频杂志
			local reg_f = registerCreate("friendsrecommended_detail")
			local itemNo = registerGetString(reg_f,"ItemNo")
			local listNo = registerGetString(reg_f,"ListNo")
			local reg_c = registerCreate("categoryID")
			registerLoad(reg_c, "MODULE:\\videoexpress\\categoryID"..listNo..".xml")
			local name = FindValue(reg_c,"item"..itemNo,"msgContent")
			local urlpath = FindValue(reg_c,"item"..itemNo,"UrlPath")
			if urlpath then	
				local path = string.gsub(urlpath,"MODULE:\\",GetModuleFolder())
				local dir = OpenDirectory(path)	
				if dir then
					require "module.Loading.useLoading"
					local loadarea = FindChildSprite(GetCurScene(), "loadarea")
					require "module.Loading.useLoading"
					enterLoading(loadarea)
					require("module.protocol.protocol_magazine")
					local reg_maga = registerCreate("magazine")
					registerSetString(reg_maga, "magazinename", name)
					FreeScene(GetCurScene())
					SetReturn(sceneReceiveMessage,sceneMagazine)
					RequestMagazine(108, urlpath)
				else
					require("module.dialog.useDialog")
					setDialogParam("收件箱", "文件已损坏，请删除后重新下载", "BT_OK", sceneReceiveMessage, sceneReceiveMessage)
					Go2Scene(sceneDialog)
				end
			end
		else								--其余跳到消息详情界面
			local curSprite = GetCurScene()
			FreeScene(curSprite)
			GoAndFreeScene(sceneFriendsRecommended)
			SetReturn(sceneReceiveMessage,sceneFriendsRecommended)
		end
	end
	--[[  删除操作  ]]--
	if spriteName == "item-list-select-delete" then
		require("module.dialog.useDialog")
		setDialogParam("收件箱", "是否需要删除这条信息？", "BT_OK_CANCEL", sceneReceiveMessage, sceneReceiveMessage, GetCurScene())
		Go2Scene(sceneDialog)
		local reg = registerCreate("receive")   
		registerSetInteger(reg, "deleteSprite", sprite)
	end
end

--@function boxListItemOnSelect
--@tag-name item-list-select-tosee in receivemessageboxListItem.xml
--@tag-action button:OnMouseDown
--@brief 未读消息下拉菜单单击按钮逻辑
function boxListItemOnSelect(sprite)
	--[[  如果存在前一个被点击的按钮，先恢复该按钮区域  ]]--
	if prespriteitem then
		SetSpriteRect(prespriteitem, 0, 1, 223, 25)
	end
	if presprite then
		SetSpriteRect(presprite, 0, 0, 218, 25)
	end
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	--[[  从全局量中获取根节点  ]]--  
	local reg = registerCreate("receive")   
	local root = registerGetInteger(reg, "root")
	--[[  找到整个list  ]]--  
	local spriteList = FindChildSprite(root, "item-list")
	--[[  改变单击到的某个按钮的区域大小  ]]--  
	local spriteitem = GetSpriteParent(sprite)
	SetSpriteRect(spriteitem, 0, 1, 223, 47)
	SetSpriteRect(sprite, 0, 0, 218, 47)
	--[[  重新调整list内所有item位置  ]]--  
	SpriteList_Adjust(spriteList)
	--[[  保存这个按钮，下次需要恢复  ]]--  
	prespriteitem = spriteitem
	presprite = sprite
end

--//start
function boxListItemOnFocus(sprite)
	--[[  如果存在前一个被点击的按钮，先恢复该按钮区域  ]]--
	if prespriteitem then
		SetSpriteRect(prespriteitem,0, 1, 223, 25 )
	end
	if presprite then
		SetSpriteRect(presprite, 0, 0, 218, 25)
	end
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	--[[  从全局量中获取根节点  ]]--  
	local reg = registerCreate("receive")   
	local root = registerGetInteger(reg, "root")
	--[[  找到整个list  ]]--  
	local spriteList = FindChildSprite(root, "item-list")
	--[[  改变单击到的某个按钮的区域大小  ]]--  
	local spriteitem = GetSpriteParent(sprite)
	SetSpriteRect(spriteitem, 0, 1, 223, 25)
	SetSpriteRect(sprite, 0, 0, 218, 25)	
	--[[  重新调整list内所有item位置  ]]--  
	SpriteList_Adjust(spriteList)
	--[[  保存这个按钮，下次需要恢复  ]]--  
	prespriteitem = spriteitem
	presprite = sprite
end
--//end

--@function listItemOnSelect
--@tag-name columnbtn in receivemessageListItem.xml
--@tag-action button:OnSelect 
--@brief 列表按钮点击逻辑
function listItemOnSelect(sprite)
	--[[  从全局量中获取根节点  ]]--  
	local reg = registerCreate("receive")   
	local root = registerGetInteger(reg, "root")
	--[[  获取当前item  ]]--
  	local spritemsg = GetSpriteParent(sprite)
 	--[[  使item内部内容可见  ]]--
	local spriteSelect = FindChildSprite(sprite,"select")
	local spriteUnSelect = FindChildSprite(sprite,"unselect")
	SetSpriteVisible(spriteSelect, 1)			
	SetSpriteEnable(spriteSelect, 1)
	--[[  获取列表按钮所在的list  ]]--
	local spriteList = FindChildSprite(root, "message-list")
	--[[  获取未读邮件中 显示所有 按钮的sprite  ]]--
	local btnshowdetail = FindChildSprite(spritemsg,"select-btn-check-all")
	--[[  获取选中的行  ]]--
	local select = SpriteListItem_GetIndex(spritemsg) + 1
	if select ~= 1 then
		--[[  如果不是未读邮件项 则跳转页面  ]]--
		local curSprite = GetCurScene()
		FreeScene(curSprite)
		local reg = registerCreate("receive_secondary")
		
		registerSetString(reg, "loadpath", "MODULE:\\videoexpress\\categoryID"..itemIndex[select-1]..".xml")
		registerSetString(reg, "istodelete", "0")
		registerSetString(reg, "categoryID", itemIndex[select-1])
		Go2Scene(sceneReceiveSecondary)
		SetReturn(sceneReceiveMessage,sceneReceiveSecondary)
	else
		--[[  未读邮件的背景图所在sprite  ]]--
		local focusbg = FindChildSprite(sprite,"focus_bg")
		--local normalbg = FindChildSprite(sprite,"normal_bg")
		--[[  如果是未读邮件，展开或者收缩详细  ]]--
		if clickCount == 0 then
			SetSpriteVisible(btnshowdetail, 1)
			SetSpriteEnable(btnshowdetail, 1)
			--[[  显示未读邮件中的内容 改变区域大小  ]]--
			SetSpriteProperty(focusbg,"src","file://image//receive//bg_wdxx.png")
			---SetSpriteRect(spritemsg, 0, 0, 223, 100)
			SetSpriteRect(spritemsg,  0, 0, 223, 127)
			--SetSpriteRect(sprite, 0, 0, 223, 127)
			SetSpriteProperty(FindChildSprite(sprite, "item-Msg-Text"), "color", "#ee4791")
			clickCount = 1
		  --[[  默认未读邮件的第一封为焦点，并调整布局  ]]--
		  local itemlist = FindChildSprite(root,"item-list")
		  local spriteItem = SpriteList_GetListItem(itemlist, 0)
		  --//start
		  ---local focus = FindChildSprite(spriteItem,"item-list-select-tosee") 
		  local focus = FindChildSprite(spriteItem,"unselect") 
		  --//end

		  SetSpriteRect(spriteItem, 0, 1, 223, 25)
		  SetSpriteRect(focus, 0, 0, 218, 25)
		  --[[  保存这个按钮，下次需要恢复  ]]-- 
		  prespriteitem = spriteItem
		  presprite = focus
		  --//start
		  focus=FindChildSprite(spriteItem,"item-button")
		  SetSpriteFocus(focus)
		  saveTouchFocus(focus)
		  --//end

		  SpriteList_Adjust(itemlist)    
		  --[[  显示子列表区域  ]]-- 
			local boxlistitem = FindChildSprite(root ,"item-list")
			SetSpriteVisible(boxlistitem, 1)			
			SetSpriteEnable(boxlistitem, 1)
		else
			SetSpriteVisible(btnshowdetail, 0)
			SetSpriteEnable(btnshowdetail, 0)
			--[[  恢复布局，背景  ]]-- 
			SetSpriteProperty(focusbg,"src","file://image//receive//bg_wdxx2.png")
			SetSpriteRect(spritemsg, 0, 0, 223, 27)
			SetSpriteRect(sprite, 0, 0, 223, 27)
			SetSpriteProperty(FindChildSprite(sprite, "item-Msg-Text"), "color", "#585858")
			clickCount = 0
			--[[  隐藏子列表区域  ]]-- 
			local boxlistitem = FindChildSprite(root ,"item-list")
			SetSpriteVisible(boxlistitem, 0)			
			SetSpriteEnable(boxlistitem, 0)
			
			--[[  恢复上次保存的那个按钮区域  ]]-- 
		  SetSpriteRect(prespriteitem, 0, 1, 223, 25)
		  SetSpriteRect(presprite, 0, 0, 218, 25)
		end
	end
	SpriteList_Adjust(spriteList)
end


function OnPluginEvent(message, Param)
	require "module.videoexpress-common"
	if message == 108 then	
		require("module.protocol.protocol_magazine")
		local json = MagazineNetworkData()
		exitLoading()
		FreeScene(GetCurScene())
		if json ~= nil and json ~= "" then
			SetReturn(sceneReceiveMessage,sceneMagazine)
			Go2Scene(sceneMagazine)
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "服务器返回数据错误", "BT_OK", sceneReceiveMessage, sceneReceiveMessage, nil)
			Go2Scene(sceneDialog)
		end
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneReceiveMessage, sceneReceiveMessage)
	elseif message > 32768 and message ~= MSG_SMS_ID + 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneReceiveMessage, sceneReceiveMessage, nil)
		Go2Scene(sceneDialog)
	end
end

function FindValue(reg,itemNo,categoryName)
	local data = registerGetString(reg,itemNo)
	local i,j = string.find(data,"{"..categoryName.."}")
	if j then 
		i = string.find(data,"{",j+1)
		j = string.find(data,"}",j+1)
		if j == i+1 then 
			return 0
		else
			return string.sub(data,i+1,j-1)
		end
	else
		return 0
	end
end
function ButtonKeyUp(sprite, keyCode)
	local name = GetSpriteName(sprite)
	WriteLogs("Key event begin !")
	WriteLogs("Key event is "..keyCode)
	WriteLogs("Current button Sprite is "..name)
	local ToDigReg = registerCreate("ToDigReg")  --add by yaoxiangyin
	registerSetInteger(ToDigReg,"ToDigFocus",sprite) --add by yaoxiangyin
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local spritefocus = nil
	local root = GetRootSprite(sprite)
	if keyCode == ApKeyCode_Up then
		if name == "columnbtn" then	
			local spritemsg = GetSpriteParent(sprite)
			local spriteList = FindChildSprite(root, "message-list")
			local select = SpriteListItem_GetIndex(spritemsg) - 1
			WriteLogs("---Current message-list select is "..(select + 1))
			local nextmsgItem = SpriteList_GetListItem(spriteList,select)
			WriteLogs("Next message-list select is "..select)
			if nextmsgItem ~= 0 then
				if clickCount == 0 then
					local spriteSelect = FindChildSprite(sprite,"select")
					SetSpriteVisible(spriteSelect, 1)			
					SetSpriteEnable(spriteSelect, 1)
					spritefocus = FindChildSprite(nextmsgItem,"columnbtn")
					SetSpriteFocus(spritefocus)
					saveTouchFocus(spritefocus)
				else
					local itemlist = FindChildSprite(root,"item-list")
					local spriteItem = 0
					for i = 0, 2 do 
						if SpriteList_GetListItem(itemlist, i) ~= 0 and  SpriteList_GetListItem(itemlist, i+1) == 0 then
							spriteItem = SpriteList_GetListItem(itemlist, i)
						end						
					end
					if spriteItem ~= 0 and select == 0 then
						--//start
						---boxListItemOnSelect(FindChildSprite(spriteItem,"item-list-select-tosee"))
						---local Itemfocus = FindChildSprite(spriteItem,"item-list-select-tosee") 
						---spritefocus = FindChildSprite(Itemfocus, "item-list-select-tosee")
						---SetSpriteFocus(spritefocus)
						boxListItemOnFocus(FindChildSprite(spriteItem,"item-button"))
						spritefocus = FindChildSprite(spriteItem,"item-button")
						SetSpriteFocus(spritefocus)
						saveTouchFocus(spritefocus)
						--//end
					else
						local spriteSelect = FindChildSprite(sprite,"select")
						SetSpriteVisible(spriteSelect, 1)			
						SetSpriteEnable(spriteSelect, 1)
						spritefocus = FindChildSprite(nextmsgItem,"columnbtn")
						SetSpriteFocus(spritefocus)
						saveTouchFocus(spritefocus)
					end
				end
			end
		--//start
		elseif (name == "item-button") then
			local spritemsg = GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite)))
			local spriteitm = GetSpriteParent(GetSpriteParent(sprite))
			local spriteList = FindChildSprite(root, "item-list")
			local select = SpriteListItem_GetIndex(spriteitm) - 1
			WriteLogs("Current message-list select is "..(select ))
			local nextitemItem = SpriteList_GetListItem(spriteList,select)
			if nextitemItem ~= 0 then
				--WriteLogs("Current button parent is "..GetSpriteName(GetSpriteParent(sprite)))
				--WriteLogs("Current item-list index is "..SpriteListItem_GetIndex(GetSpriteParent(GetSpriteParent(sprite))))
				boxListItemOnFocus(FindChildSprite(nextitemItem,"item-button"))
				spritefocus = FindChildSprite(nextitemItem,"item-button")
				--WriteLogs(GetSpriteName(spritefocus))
				SetSpriteFocus(spritefocus)
				saveTouchFocus(spritefocus)
			else
				local spriteSelect = FindChildSprite(sprite,"select")
				SetSpriteVisible(spriteSelect, 1)			
				SetSpriteEnable(spriteSelect, 1)
				spritefocus = FindChildSprite(root, "columnbtn")
				SetSpriteFocus(spritefocus)
				saveTouchFocus(spritefocus)
			end
		--//end
		elseif (name == "item-list-select-tosee" and GetSpriteName(GetSpriteParent(sprite)) == "focus") or (name == "item-list-select-delete" and GetSpriteName(GetSpriteParent(sprite)) == "focus")then
			local spritemsg = GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite)))
			WriteLogs("Current button parent is "..GetSpriteName(GetSpriteParent(sprite)))
			WriteLogs("Current button grandparent is "..GetSpriteName(GetSpriteParent(GetSpriteParent(sprite))))
			local spriteList = FindChildSprite(root, "item-list")
			local select = SpriteListItem_GetIndex(spritemsg) - 1
			WriteLogs("Current message-list select is "..(select ))
			local nextitemItem = SpriteList_GetListItem(spriteList,select)
			if nextitemItem ~= 0 then
				--//start
				---boxListItemOnSelect(FindChildSprite(nextitemItem,"item-list-select-tosee"))
				---spritefocus = FindChildSprite(FindChildSprite(nextitemItem,"item-list-select-tosee"),"item-list-select-tosee")
				---SetSpriteFocus(spritefocus)
				boxListItemOnFocus(FindChildSprite(nextitemItem,"item-button"))
				spritefocus = FindChildSprite(nextitemItem,"item-button")
				SetSpriteFocus(spritefocus)
				saveTouchFocus(spritefocus)
				--//end
			else
				boxListItemOnFocus(FindChildSprite(nextitemItem,"item-button"))
				local spriteSelect = FindChildSprite(sprite,"select")
				SetSpriteVisible(spriteSelect, 1)			
				SetSpriteEnable(spriteSelect, 1)
				spritefocus = FindChildSprite(root, "columnbtn")
				SetSpriteFocus(spritefocus)
				saveTouchFocus(spritefocus)
			end
		end
	elseif keyCode == ApKeyCode_Down then
		if name == "columnbtn" then  
			local spritemsg = GetSpriteParent(sprite)
			local spriteList = FindChildSprite(root, "message-list")
			local select = SpriteListItem_GetIndex(spritemsg) + 1
			local nextmsgItem = SpriteList_GetListItem(spriteList,select)
			if nextmsgItem ~= 0 then
				if clickCount == 0 then
					local spriteSelect = FindChildSprite(sprite,"select")
					SetSpriteVisible(spriteSelect, 1)			
					SetSpriteEnable(spriteSelect, 1)
					spritefocus = FindChildSprite(nextmsgItem,"columnbtn")
					SetSpriteFocus(spritefocus)
					saveTouchFocus(spritefocus)
				else
					local itemlist = FindChildSprite(root,"item-list")
					local spriteItem = SpriteList_GetListItem(itemlist, 0)
					if spriteItem ~= 0 and select == 1 then
						--//start
						---boxListItemOnSelect(FindChildSprite(spriteItem,"item-list-select-tosee"))
						---local Itemfocus = FindChildSprite(spriteItem,"item-list-select-tosee") 
						---spritefocus = FindChildSprite(Itemfocus, "item-list-select-tosee")
						---SetSpriteFocus(spritefocus)
						boxListItemOnFocus(FindChildSprite(spriteItem,"item-button"))
						spritefocus = FindChildSprite(spriteItem,"item-button")
						SetSpriteFocus(spritefocus)
						saveTouchFocus(spritefocus)
						--//end
					else
						local spriteSelect = FindChildSprite(sprite,"select")
						SetSpriteVisible(spriteSelect, 1)			
						SetSpriteEnable(spriteSelect, 1)
						spritefocus = FindChildSprite(nextmsgItem,"columnbtn")
						SetSpriteFocus(spritefocus)
						saveTouchFocus(spritefocus)
					end
				end			
			end
		--//start
		elseif (name == "item-button") then
			local spritemsg = GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite)))
			local spriteitm = GetSpriteParent(GetSpriteParent(sprite))
			local spriteList = FindChildSprite(root, "item-list")
			local select = SpriteListItem_GetIndex(spriteitm) + 1
			WriteLogs("Current message-list select is "..(select ))
			local nextitemItem = SpriteList_GetListItem(spriteList,select)
			if nextitemItem ~= 0 and select<3 then
				WriteLogs("Current button parent is "..GetSpriteName(GetSpriteParent(sprite)))
				WriteLogs("Current item-list index is "..SpriteListItem_GetIndex(GetSpriteParent(GetSpriteParent(sprite))))
				boxListItemOnFocus(FindChildSprite(nextitemItem,"item-button"))
				spritefocus = FindChildSprite(nextitemItem,"item-button")
				WriteLogs(GetSpriteName(spritefocus))
				SetSpriteFocus(spritefocus)
				saveTouchFocus(spritefocus)
			else
				--local spriteroot = FindChildSprite(root, "columnbtn")
				--listItemOnSelect(spriteroot)
				local spriteList = FindChildSprite(root, "message-list")
				local nextmsgItem = SpriteList_GetListItem(spriteList,1)
				if nextmsgItem ~= 0 then
					local spriteSelect = FindChildSprite(sprite,"select")
					SetSpriteVisible(spriteSelect, 1)			
					SetSpriteEnable(spriteSelect, 1)
					spritefocus = FindChildSprite(nextmsgItem,"columnbtn")
					SetSpriteFocus(spritefocus)
					saveTouchFocus(spritefocus)
				end
			end
		--//end
		elseif (name == "item-list-select-delete" and GetSpriteName(GetSpriteParent(sprite)) == "focus") or (name == "item-list-select-tosee" and GetSpriteName(GetSpriteParent(sprite)) == "focus") then
			local spritemsg = GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite)))
			local spriteList = FindChildSprite(root, "item-list")
			local select = SpriteListItem_GetIndex(spritemsg) + 1
			WriteLogs("Current message-list select is "..(select )..SpriteList_GetListItemCount(spritemsg))
			local nextitemItem = SpriteList_GetListItem(spriteList,select)
			if nextitemItem ~= 0 and select<3 then
				WriteLogs("Current button parent is "..GetSpriteName(GetSpriteParent(sprite)))
				WriteLogs("Current button grandparent is "..GetSpriteName(GetSpriteParent(GetSpriteParent(sprite))))
				--//start
				---boxListItemOnSelect(FindChildSprite(nextitemItem,"item-list-select-tosee"))
				---spritefocus = FindChildSprite(FindChildSprite(nextitemItem,"item-list-select-tosee"),"item-list-select-tosee")
				---SetSpriteFocus(spritefocus)
				boxListItemOnFocus(FindChildSprite(nextitemItem,"item-button"))
				spritefocus = FindChildSprite(nextitemItem,"item-button")
				SetSpriteFocus(spritefocus)
				saveTouchFocus(spritefocus)
				--//end
			else
				boxListItemOnFocus(FindChildSprite(nextitemItem,"item-button"))
				local spriteList = FindChildSprite(root, "message-list")
				
				--[[local nextmsgItem = SpriteList_GetListItem(spriteList,0)
				if nextmsgItem ~= 0 then					
					spritefocus = FindChildSprite(nextmsgItem,"columnbtn")
					listItemOnSelect(spritefocus)
					
					focusbg = FindChildSprite(spritefocus,"focus_bg")
					SetSpriteProperty(focusbg,"src","file://image//receive//bg_wdxx2_jd2.png")
					local spriteSelect = FindChildSprite(nextmsgItem,"select")
					SetSpriteVisible(spriteSelect, 0)
					SetSpriteEnable(spriteSelect, 0)
					local spriteSelect = FindChildSprite(nextmsgItem,"unselect")
					SetSpriteVisible(spriteSelect, 1)
					SetSpriteEnable(spriteSelect, 1)
				end--]]
				
				local nextmsgItem = SpriteList_GetListItem(spriteList,1)
				if nextmsgItem ~= 0 then
					local spriteSelect = FindChildSprite(sprite,"select")
					SetSpriteVisible(spriteSelect, 1)
					SetSpriteEnable(spriteSelect, 1)
					spritefocus = FindChildSprite(nextmsgItem,"columnbtn")
					SetSpriteFocus(spritefocus)
					saveTouchFocus(spritefocus)
				end
			end
		elseif name == "select-btn-check-all" then 
			local spritemsg = GetSpriteParent(GetSpriteParent(sprite))
			local spriteList = FindChildSprite(root, "message-list")
			local select = SpriteListItem_GetIndex(spritemsg) + 1
			local nextmsgItem = SpriteList_GetListItem(spriteList,select)
			if nextmsgItem ~= 0 then			
				local itemlist = FindChildSprite(root,"item-list")
				local spriteItem = SpriteList_GetListItem(itemlist, 0)
				if spriteItem ~= 0 then
					--//start
					---boxListItemOnSelect(FindChildSprite(spriteItem,"item-list-select-tosee"))
					---local Itemfocus = FindChildSprite(spriteItem,"item-list-select-tosee") 
					---spritefocus = FindChildSprite(Itemfocus, "item-list-select-tosee")
					---SetSpriteFocus(spritefocus)
					boxListItemOnFocus(FindChildSprite(spriteItem,"item-button"))
					spritefocus = FindChildSprite(spriteItem,"item-button")
					SetSpriteFocus(spritefocus)
					saveTouchFocus(spritefocus)
					--//end
				else
					local spriteSelect = FindChildSprite(sprite,"select")
					SetSpriteVisible(spriteSelect, 1)			
					SetSpriteEnable(spriteSelect, 1)
					spritefocus = FindChildSprite(nextmsgItem,"columnbtn")
					SetSpriteFocus(spritefocus)
					saveTouchFocus(spritefocus)
				end
			end
		end
	elseif keyCode == ApKeyCode_Left then
		if name == "item-list-select-delete" and GetSpriteName(GetSpriteParent(sprite)) == "focus" then			
			local spritepar = GetSpriteParent(sprite)
			spritefocus = FindChildSprite(spritepar, "item-list-select-tosee")
			SetSpriteFocus(spritefocus)
			saveTouchFocus(spritefocus)
		elseif name == "select-btn-check-all" then  
			local spritemsg = GetSpriteParent(GetSpriteParent(sprite))
			local spriteList = FindChildSprite(root, "message-list")
			local select = SpriteListItem_GetIndex(spritemsg) - 1
			local nextmsgItem = SpriteList_GetListItem(spriteList,select)
			if nextmsgItem == 0 and clickCount == 1 then
				local spriteSelect = FindChildSprite(sprite,"select")
				SetSpriteVisible(spriteSelect, 1)			
				SetSpriteEnable(spriteSelect, 1)
				spritefocus = FindChildSprite(root,"columnbtn")
				SetSpriteFocus(spritefocus)
				saveTouchFocus(spritefocus)
			end
		end
	elseif keyCode == ApKeyCode_Right then
		if name == "item-list-select-tosee" and GetSpriteName(GetSpriteParent(sprite)) == "focus" then 
			local spritepar = GetSpriteParent(sprite)
			spritefocus = FindChildSprite(spritepar, "item-list-select-delete")
			SetSpriteFocus(spritefocus)
			saveTouchFocus(spritefocus)
		elseif name == "columnbtn" then  
			local spritemsg = GetSpriteParent(sprite)
			local spriteList = FindChildSprite(root, "message-list")
			local select = SpriteListItem_GetIndex(spritemsg) - 1
			local nextmsgItem = SpriteList_GetListItem(spriteList,select)
			--WriteLogs("nextmsgItem is "..nextmsgItem)
			--WriteLogs("nextmsgItem is "..keyCode)
			if nextmsgItem == 0 and clickCount == 1 then
				local spriteSelect = FindChildSprite(sprite,"select")
				SetSpriteVisible(spriteSelect, 1)			
				SetSpriteEnable(spriteSelect, 1)
				spritefocus = FindChildSprite(sprite,"select-btn-check-all")
				SetSpriteFocus(spritefocus)
				saveTouchFocus(spritefocus)
			end
		end
	elseif keyCode == ApKeyCode_Enter then
		if name == "columnbtn" then			
			listItemOnSelect(sprite)
			local spritemsg = GetSpriteParent(sprite)
			local spriteList = FindChildSprite(root, "message-list")
			local select = SpriteListItem_GetIndex(spritemsg) + 1
			
			if select == 1 then
				if clickCount == 0 then
					--[[
					local spriteSelect = FindChildSprite(sprite,"select")
					local spriteunSelect = FindChildSprite(sprite,"unselect")
					SetSpriteVisible(spriteSelect, 1)			
					SetSpriteEnable(spriteSelect, 1)
					SetSpriteVisible(spriteunSelect, 0)			
					SetSpriteEnable(spriteunSelect, 0)
					]]--
					spritefocus = FindChildSprite(root, "columnbtn")
					--[[spritefocus = FindChildSprite(SpriteList_GetListItem(spriteList,0), "columnbtn")
					local spriteSelect = FindChildSprite(spritefocus,"select")
					SetSpriteVisible(spriteSelect, 1)			
					SetSpriteEnable(spriteSelect, 1)--]]
					SetSpriteFocus(spritefocus)
					saveTouchFocus(spritefocus)
					WriteLogs("---Run here in call")
					focusbg = FindChildSprite(spritefocus,"focus_bg")
					SetSpriteProperty(focusbg,"src","file://image//receive//bg_wdxx2_jd2.png")

				elseif clickCount == 1 then
					local itemlist = FindChildSprite(root,"item-list")
					local spriteItem = SpriteList_GetListItem(itemlist, 0)
					--//start
					---local Itemfocus = FindChildSprite(spriteItem,"item-list-select-tosee") 
					---spritefocus = FindChildSprite(Itemfocus, "item-list-select-tosee")
					---SetSpriteFocus(spritefocus)
					if spriteItem ~= 0 then
						boxListItemOnFocus(FindChildSprite(spriteItem,"item-button"))
						spritefocus = FindChildSprite(spriteItem,"item-button")
						SetSpriteFocus(spritefocus)
						saveTouchFocus(spritefocus)
					end
					--//end
				end
			end
		elseif (name == "item-list-select-delete" and GetSpriteName(GetSpriteParent(sprite)) == "focus") or (name == "item-list-select-tosee" and GetSpriteName(GetSpriteParent(sprite)) == "focus") then
			btnItemOptionOnSelect(sprite)
		--//start
		elseif (name == "item-button") then
			local spriteitm = GetSpriteParent(GetSpriteParent(sprite))			
			boxListItemOnSelect(FindChildSprite(spriteitm,"item-list-select-tosee"))
			spritefocus = FindChildSprite(FindChildSprite(spriteitm,"item-list-select-tosee"),"item-list-select-tosee")
			SetSpriteFocus(spritefocus)
			saveTouchFocus(spritefocus)
		--//end
		elseif name == "select-btn-check-all" then 
			--WriteLogs("Run here --- show all")
			itemShowAllBtnOnSelect(sprite)
		end			
	elseif keyCode == ApKeyCode_Cancel or keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)		
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)

	else
		WriteLogs("Other Key event !")
	end	
	if spritefocus ~= nil then
		WriteLogs("Next button Sprite is "..GetSpriteName(spritefocus))
	end
	WriteLogs("Key event has done !")	
	return 1
end
--local focusbg = FindChildSprite(sprite,"focus_bg")
--SetSpriteProperty(focusbg,"src","file://image//receive//bg_wdxx2.png")

--//start
function btnItemSelect(sprite)
	--WriteLogs("Tuns here")
	local spriteitm = GetSpriteParent(GetSpriteParent(sprite))			
	boxListItemOnSelect(FindChildSprite(spriteitm,"item-list-select-tosee"))
	spritefocus = FindChildSprite(FindChildSprite(spriteitm,"item-list-select-tosee"),"item-list-select-tosee")
	SetSpriteFocus(spritefocus)
	saveTouchFocus(spritefocus)
end
--//end