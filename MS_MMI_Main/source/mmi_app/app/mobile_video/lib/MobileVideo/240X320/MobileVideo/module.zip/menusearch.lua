--@module menusearch
--@note �����ؼ��ֽ���

require "module.Loading.useLoading"
require "module.protocol.protocol_search_result"
require "module.protocol.protocol_menusearch"
require "module.common.registerScene"
require "module.common.SceneUtils"
require "module.videoexpress-common"
require "module.keyCode.keyCode"

HOT_LINES_COUNT = 7 --�����Ƽ�����

function bodyBuildChildrenFinished(sprite)
	WriteLogs("menusearch-start")
	--[[  ��ø��ڵ㲢������ȫ������  ]]--
	regCreate = registerCreate("menusearch")
	registerSetInteger(regCreate, "root", sprite)
	json = OnMenuSearchDecode()
	createMenuSearchData()
	--[[  ����С�ļ����б� ]]--
	local myProblemFlag=1
	if json.sortNames then
		myProblemFlag=createHotKeywordList()
	end
	
	--licj--
	local root = registerGetInteger(regCreate, "root")
	
	HotKeyMovie = FindChildSprite(root,"buttonChangeName0-0") --��һ���Ƽ���Ŀ
	SearchEditText=FindChildSprite(root,"searchEdit") --������edittext
	SearchBtn=FindChildSprite(root,"searchButton") --������ť
	if myProblemFlag==0 then
		SetSpriteFocus(HotKeyMovie)
		saveTouchFocus(HotKeyMovie)
	else
		SetSpriteFocus(SearchBtn)
		saveTouchFocus(SearchBtn)
	end
	WriteLogs("menusearch-end")
	ii=0 --���Źؼ�������x
	jj=0 --���Źؼ�������y
	isAdvanced=0
	return 1
end

function createHotKeywordList()
	--[[  ������������ڵ�  ]]--
	local sprite = registerGetInteger(regCreate, "root")
	--[[  Ѱ��Ŀ���б�  ]]-- 
	local spriteListline = FindChildSprite(sprite, "search-keywordslist-line")
	local spriteList = FindChildSprite(sprite, "search-keywordslist")
	--[[  ѭ�������б��б�������Ӧ������������  ]]-- 
	local nMax = math.min(table.maxn(json.sortNames), 8)  -- [0,8] �ܹ�9��
	
	HOT_LINES_COUNT=nMax+1; --�Ƽ�������
	--��ÿ��ͼƬ
	local xmlNode_line=xmlLoadFile("MODULE:\\menuSearchlist_line.xml")
	for i=0, nMax  do
		local searchKeywordSprite = CreateSprite("listitem")
		LoadSpriteFromNode(searchKeywordSprite, xmlNode_line)
		SetSpriteRect(searchKeywordSprite, 0, 0, 35, 24)
			--ͼƬ
			local spriteImageList = FindChildSprite(searchKeywordSprite, "imgSearchListItem")
			SetSpriteProperty(spriteImageList, "src", "file:///image/search/list_bg.png")
			SetSpriteRect(spriteImageList, 3, 3, 218, 24)
			--����
			local spriteSearchListItemText = FindChildSprite(searchKeywordSprite, "SearchListItemText") 
			SetSpriteProperty(spriteSearchListItemText, "name", "SearchListItemText"..i)
			SetSpriteProperty(spriteSearchListItemText, "text", json.sortNames[i].sortName)
			SetSpriteRect(spriteSearchListItemText, 6, 3, 24, 20)
		--[[	����Щ�ڵ���뵽������	]]--
		AddChildSprite(spriteListline, searchKeywordSprite)
		SpriteList_AddListItem(spriteListline, searchKeywordSprite)	
	end
	xmlRelease(xmlNode_line)
	SpriteList_Adjust(spriteListline)
	local problemFlag=0
	a = {}
	--���ؼ����б�,�ö�ά�������
	local xmlNode=xmlLoadFile("MODULE:\\menuSearchlist.xml")
	for i=0, nMax  do
		local strLineWidth = 5 --������ʾ�ĳ���
		local strLineHeight = 0 --����Ļ��ʾ�ĸ߶�
		local offsetX = 3
		local offsetY = 3
		local nItemMax
		if json and json.sortNames[i] and json.sortNames[i].keyword then
			nItemMax = math.min(table.maxn(json.sortNames[i].keyword), 4)
			for j=0, nItemMax do
				--���ñ༭�����Źؼ��֣�ȡ��һ��
				if 0==i and 0 == j then
					local spriteSearchEdit = FindChildSprite(sprite, "searchEdit")
					SetSpriteProperty(spriteSearchEdit, "text", json.sortNames[i].keyword[j].value)
				end
				--���ַ�������ĳ���
				local strWidth, strHeight = GetTextSize(json.sortNames[i].keyword[j].value)
				strHeight = 24 *(i)
				local suposeLineWidth = strLineWidth + strWidth +35
				if   suposeLineWidth  > 195 then  --205 ��ȥ�������ͼƬ����󣬹ؼ��� ������������ĳ��� 240*320
					break
				else
					local searchKeywordSprite = CreateSprite("listitem")
					LoadSpriteFromNode(searchKeywordSprite, xmlNode)
					SetSpriteRect(searchKeywordSprite, 0, 0, 63, 24)
				
					--��̬������ť����������ѡ�кͷ�ѡ������
					local spriteBtnNormal = FindChildSprite(searchKeywordSprite, "buttonChangeName")
					SetSpriteRect(spriteBtnNormal, 35+strLineWidth+0, strHeight+0, strWidth+5, 20)
					local newname = "buttonChangeName"..i.."-"..j;
					SetSpriteProperty(spriteBtnNormal, "name", newname)
					--���ò�ѡ�н���	
					--��ʾ��ѡ�е�����
					local spriteLabelNormal = FindChildSprite(searchKeywordSprite, "NormalButtontext")
					SetSpriteProperty(spriteLabelNormal, "text", json.sortNames[i].keyword[j].value)
					SetSpriteRect(spriteLabelNormal, offsetX, offsetY, strWidth, 20)
					local spriteLabelForcus = FindChildSprite(searchKeywordSprite, "FocusButtontext")
					SetSpriteProperty(spriteLabelForcus, "text", json.sortNames[i].keyword[j].value)
					SetSpriteRect(spriteLabelForcus,offsetX, offsetY, strWidth, 20)
					--��ʾѡ�е�ͼƬ��ť
					local spriteImgForcus = FindChildSprite(searchKeywordSprite, "buttonFocus1")
					SetSpriteRect(spriteImgForcus, 0, 5, 4,20)
					local spriteImgForcus2 = FindChildSprite(searchKeywordSprite, "buttonFocus2")
					SetSpriteRect(spriteImgForcus2, 4, 5, strWidth-3, 20)
					local spriteImgForcus3 = FindChildSprite(searchKeywordSprite, "buttonFocus3")
					SetSpriteRect(spriteImgForcus3, strWidth+1, 5, 4, 20)
					
					--licj added
					local result=SetSpriteProperty(searchKeywordSprite, "OnKeyUp", "listKeyUp")
					--����Ѿ���ʾ�����峤�ȴ����ܳ��Ȼ���
					if (35+strLineWidth > 195)then
						break
					end
					strLineWidth = strLineWidth + strWidth
					strLineWidth = strLineWidth + 5
					strLineHeight = strLineHeight + strHeight
					strLineHeight = strLineHeight + 5
					--[[	����Щ�ڵ���뵽������	]]--
					AddChildSprite(spriteList, searchKeywordSprite)
					SpriteList_AddListItem(spriteList, searchKeywordSprite)	
				end
				a[i+1]=j
			end
		else
			problemFlag=1
		end	
	end		
	xmlRelease(xmlNode)	
	return problemFlag
end

--����ؼ��ְ�ť�¼�
function btnOnSelect(sprite)
	--����ѡ�н���
	ReleaseSpriteCapture(sprite)
	local name0 = GetSpriteName(sprite)
	local is,js
	local name = ""
	local i,j
	name = string.sub(name0,1,16)
	is = string.sub(name0,17,17)
	js = string.sub(name0,19,19)
	if ""~=is and nil ~= is then
		i = tonumber (is)
	end
	if ""~=js and nil ~= js then
		j = tonumber (js)
	end
	if name == "buttonChangeName" then
		local spriteListItem = GetSpriteParent(sprite)
		local nIndex = SpriteListItem_GetIndex(spriteListItem)
		if  json.sortNames[i] and  json.sortNames[i].keyword[j] and menuSearchDataArray[i] then
			if ("" ~= json.sortNames[i].keyword[j].value) and  ("" ~= menuSearchDataArray[i].searchUrl) then
				local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadarea")
				enterLoading(nodeLoading)
				RequestSearchResult(101, 1, menuSearchDataArray[i].searchUrl, json.sortNames[i].keyword[j].value)
			end
		end
	end
	require "module.searchInfo"
	SaveSearchReqSortType("time")
end

--����ؼ��ְ�ť�¼�
function searchButtonOnSelect(sprite)
	ReleaseSpriteCapture(sprite)
	local name = GetSpriteName(sprite)
	if name == "searchButton" then
		local spriteListItem = GetSpriteParent(sprite)
		local nIndex = SpriteListItem_GetIndex(spriteListItem)
		local spriteRoot = registerGetInteger(regCreate, "root")
		local spriteEditLabel = FindChildSprite(spriteRoot, "searchEdit")
		local text = GetSpriteText(spriteEditLabel)
		--����nIndexȡ���д���Ӧ��ȥĳһ�е�URL
		if ("" ~= text) and ("" ~= menuSearchDataArray[0].searchUrl) then
			local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadarea")
			enterLoading(nodeLoading)
			if isAdvanced == 1 then
				RequestSearchResult(101,1,menuSearchDataArray[0].searchUrl,text,nil,1)
			else
				RequestSearchResult(101,1,menuSearchDataArray[0].searchUrl,text)
			end
		end
	end
	require "module.searchInfo"
	SaveSearchReqSortType("time")
end

--�������������ص������ؼ�������
function createMenuSearchData()
	menuSearchDataArray = {}
	if json.sortNames then
		for i=0, table.maxn(json.sortNames) do
			menuSearchDataArray[i] = {
				searchUrl = json.sortNames[i].searchUrl,
				sortName = json.sortNames[i].sortName,
				}
		end
	end
end

function bodyOnPluginEvent(message, param)
	if message == 101 then
		exitLoading()
		SetReturn(sceneSearch, sceneSearchResult)
		FreeScene(GetCurScene())
		Go2Scene(sceneSearchResult)
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneSearch, sceneSearch)
	elseif message > 32768 then 
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("��ʾ", "��ȡ��������ʧ��", "BT_OK", sceneSearch, sceneSearch, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function bodyOnSpriteEvent(message, params)
	require("module.common.commonMsg")
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
end

function editTextOnTextChanged(sprite)
	ReleaseSpriteCapture(sprite)
	local rootSprite = GetRootSprite(sprite)
	local sendSprite = FindChildSprite(rootSprite,"scapegoat")
	SetSpriteFocus(sendSprite)
	saveTouchFocus(sendSprite)
end

function TextOnSelected(sprite)
	local rootSprite = GetRootSprite(sprite)
	SetSpriteCapture(rootSprite)
end

function AdsearchButtonOnSelect(sprite)
	local reg_m = registerCreate("menusearch")
	local root = registerGetInteger(reg_m, "root")
	local advanedarea = FindChildSprite(root,"advanced_searcharea")
	SetSpriteVisible(advanedarea,1)
	SetSpriteEnable(advanedarea,1)
	ChangeButtonPosition(sprite)
	local list = FindChildSprite(root,"hot-keywords")
	SetSpriteEnable(list,0)
	
	local advanced_frame = FindChildSprite(advanedarea,"advanced_frame")
	local advanced_pannel = FindChildSprite(advanced_frame,"advanced_pannel")
	local a,b,c,d = GetSpriteRect(advanced_frame)
	if advanced_pannel == 0 then
		local node = CreateSprite("node")
		SetSpriteProperty(node,"name","advanced_pannel")
	 	LoadSprite(node,"MODULE:\\menusearch_advancedpannel.xml")
		AddChildSprite(advanced_frame, node)
		SetSpriteRect(node,a,-d,c,d)
		local reg_a = registerCreate("advancedsearch")
		registerSetInteger(reg_a, "advanced_pannel",node)
	else
		SetSpriteRect(advanced_pannel,a,-d,c,d)
		local reg_a = registerCreate("advancedsearch")
		registerSetInteger(reg_a, "advanced_pannel",advanced_pannel)
	end
	------------�����ѡ��󽫽��������ڵ�һ����������------------
	local comboboxButton1 = FindChildSprite(advanced_frame,"combobox1")
	SetSpriteFocus(comboboxButton1)
	saveTouchFocus(comboboxButton1)
	isAdvanced = 1
	SetTimer(1,1,"MoveThePannel")
end

function CloseAdsearchOnSelect(sprite)
	local reg_m = registerCreate("menusearch")
	local root = registerGetInteger(reg_m, "root")
	local advanedarea = FindChildSprite(root,"advanced_searcharea")
	SetSpriteVisible(advanedarea,0)
	SetSpriteEnable(advanedarea,0)
	ChangeButtonPosition(sprite)
	local list= FindChildSprite(root,"hot-keywords")
	SetSpriteEnable(list,1)
	HideComboboxlist()
	isAdvanced = 0
	-----�����������ڸ�ѡ��δѡ��״̬-----------
	SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite),"advanced"))
	saveTouchFocus(FindChildSprite(GetSpriteParent(sprite),"advanced"))
end

function ChangeButtonPosition(sprite)
	local nodesprite = GetSpriteParent(sprite)
	local advanced = FindChildSprite(nodesprite,"advanced")
	local closeadvanced = FindChildSprite(nodesprite,"closeadvanced")
	local a,b,c,d = GetSpriteRect(advanced)
	local e,f,g,h = GetSpriteRect(closeadvanced)
	SetSpriteRect(advanced,a,f,c,d)
	SetSpriteRect(closeadvanced,e,b,g,h)
end

function MoveThePannel(idevent)
	local reg_a = registerCreate("advancedsearch")
	local advanced_pannel = registerGetInteger(reg_a, "advanced_pannel")
	if idevent == 1 then
		local a,b,c,d = GetSpriteRect(advanced_pannel)
		SetSpriteRect(advanced_pannel,a,-(d*0.44),c,d)
		SetTimer(2,1,"MoveThePannel")
	elseif idevent == 2 then
		local a,b,c,d = GetSpriteRect(advanced_pannel)
		SetSpriteRect(advanced_pannel,a,-(d*0.22),c,d)
		SetTimer(3,1,"MoveThePannel")
	elseif idevent == 3 then
		local a,b,c,d = GetSpriteRect(advanced_pannel)
		SetSpriteRect(advanced_pannel,a,-(d*0.11),c,d)
		SetTimer(4,1,"MoveThePannel")
	elseif idevent == 4 then
		local a,b,c,d = GetSpriteRect(advanced_pannel)
		SetSpriteRect(advanced_pannel,a,0,c,d)	
	end
end

function HideComboboxlist()
	local comboList1 = FindChildSprite(GetCurScene(),"comboList1")
	SetSpriteEnable(comboList1,0)
	SetSpriteVisible(comboList1,0)
	local hidecombolist_upper = FindChildSprite(GetCurScene(),"hidecombolist_upper")
	local hidecombolist_lower = FindChildSprite(GetCurScene(),"hidecombolist_lower")
	SetSpriteEnable(hidecombolist_upper,0)
	SetSpriteEnable(hidecombolist_lower,0)
	require "module.common.commonScroll"
	HideScrollArea()
end

--licj 2010.8.11
--Deal Key Events
function listKeyUp(sprite, keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	--buttonChangeName i-j
	--WriteLogs("KeyCode====="..keyCode)
	local name0 = GetSpriteName(sprite)
	WriteLogs("Search button selected! name="..name0);
	local is,js  --buttonChangeName"..i.."-"..j
	is = string.sub(name0,17,17);
	js = string.sub(name0,19,19);	
	if ""~=is and nil ~= is then
	  ii = tonumber (is)
	end	
	if ""~=js and nil ~= js then
	  jj = tonumber (js)
	end
	
	--����
	if keyCode == ApKeyCode_Up then
		if ii==0  then --��һ��������
			SetSpriteFocus(SearchEditText)
			saveTouchFocus(SearchEditText)
			return 0
		end;
		
		if ii>0 then
			ii = ii-1
			if a[ii+1] then
				if a[ii+1]<jj then
					jj=a[ii+1]
				end
			else
				local focusBtn=FindBestFocus(ii,sprite,"up")
				if focusBtn~=0 then
					SetSpriteFocus(focusBtn)
					saveTouchFocus(focusBtn)
				else
					SetSpriteFocus(SearchBtn)
					saveTouchFocus(SearchBtn)
				end
			end
		end
		--WriteLogs("x,y=="..ii..jj..a[1])
		--WriteLogs("UP")
	--����
	elseif keyCode==ApKeyCode_Down then
		if ii<HOT_LINES_COUNT-1 then
			ii = ii+1
			if a[ii+1] then
				if a[ii+1]<jj then
					jj=a[ii+1]
				end
			else
				local focusBtn=FindBestFocus(ii,sprite,"down")
				if focusBtn~=0 then
					SetSpriteFocus(focusBtn)
					saveTouchFocus(focusBtn)
				end
			end
		end
		--WriteLogs("x,y=="..ii..jj..a[1])
		--WriteLogs("DOWN")
	--����
	elseif keyCode==ApKeyCode_Left then
		if jj>0 then
		  jj = jj-1
		end;	
		--WriteLogs("Left")
	--����
	elseif keyCode==ApKeyCode_Right then
		if jj<a[ii+1] then
		  jj = jj+1
		end;
		--WriteLogs("Right")
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1;
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	--ȷ��
	elseif keyCode==ApKeyCode_Enter then
		btnOnSelect(sprite)
		--WriteLogs("Enter")
	
	end
	
	
	--WriteLogs("ii,jj="..ii..","..jj)
	local root = registerGetInteger(regCreate, "root")
	local curKeyWord = FindChildSprite(root,"buttonChangeName"..ii.."-"..jj)
	--WriteLogs("CurKeyWord=="..curKeyWord);
	SetSpriteFocus(curKeyWord)
	saveTouchFocus(curKeyWord)
end

--����������¼�
function editTextKeyUp(sprite, keyCode)
	if keyCode==ApKeyCode_Right then --����
		SetSpriteFocus(SearchBtn)
		saveTouchFocus(SearchBtn)
	elseif keyCode==ApKeyCode_Down then --����
		if isAdvanced ~= 1 then
			ii=0
			jj=0
			if HotKeyMovie~=0 then
				SetSpriteFocus(HotKeyMovie)
				saveTouchFocus(HotKeyMovie)
			else
				local focusBtn=FindBestFocus(ii,sprite,"down")
				if focusBtn~=0 then
					SetSpriteFocus(focusBtn)
					saveTouchFocus(focusBtn)
				end
			end
		else
			SetSpriteFocus(FindChildSprite(GetCurScene(),"combobox1"))
			saveTouchFocus(FindChildSprite(GetCurScene(),"combobox1"))
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--������ť�����¼�
function SearchBtnKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	if keyCode==ApKeyCode_Down then --����
		if isAdvanced ~= 1 then
			ii=0
			jj=0
			if HotKeyMovie~=0 then
				SetSpriteFocus(HotKeyMovie)
				saveTouchFocus(HotKeyMovie)
			else
				local focusBtn=FindBestFocus(ii,sprite,"down")
				if focusBtn~=0 then
					SetSpriteFocus(focusBtn)
					saveTouchFocus(focusBtn)
				end
			end
		else
			SetSpriteFocus(FindChildSprite(GetCurScene(),"combobox1"))
			saveTouchFocus(FindChildSprite(GetCurScene(),"combobox1"))
		end
	elseif keyCode==ApKeyCode_Left then --����
		SetSpriteFocus(SearchEditText)
		saveTouchFocus(SearchEditText)
	elseif keyCode == ApKeyCode_Right then
		local advanceeParent = GetSpriteParent(GetSpriteParent(sprite))
		local advancedButton = FindChildSprite(advanceeParent,"advanced")
		local closeadvancedButton = FindChildSprite(advanceeParent,"closeadvanced")
		if isAdvanced ~= 1 then
			SetSpriteFocus(advancedButton)
			saveTouchFocus(advancedButton)
		else
			SetSpriteFocus(closeadvancedButton)
			saveTouchFocus(closeadvancedButton)
		end
	elseif keyCode==ApKeyCode_Enter then --ȷ��
		searchButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--�߼�������ť�ļ����¼�
function advancedKeyUp(sprite,keyCode)
	if keyCode==ApKeyCode_Left then
		SetSpriteFocus(SearchBtn)
		saveTouchFocus(SearchBtn)
	elseif keyCode == ApKeyCode_Down then --����
		if isAdvanced ~= 1 then 
			ii=0
			jj=0
			SetSpriteFocus(HotKeyMovie)
			saveTouchFocus(HotKeyMovie)
		else
			SetSpriteFocus(FindChildSprite(GetCurScene(),"combobox1"))
			saveTouchFocus(FindChildSprite(GetCurScene(),"combobox1"))
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	else
		return 0
	end
end

--���������������ݳ�����ʱ���Խ�����ƶ��߼�����Ӧ��������ֹ�����޷��ƶ���Ԥ��λ��
function FindBestFocus(startLineIndex,sprite,direct)
	local root=GetRootSprite(sprite)
	local nMax = math.min(table.maxn(json.sortNames), 8)  -- [0,8] �ܹ�9��
	if direct=="down" then
		for i=startLineIndex, nMax  do
			if json and json.sortNames[i] and json.sortNames[i].keyword then
				local nItemMax = math.min(table.maxn(json.sortNames[i].keyword), 4)
				for j=0, nItemMax do
					local testButton=FindChildSprite(root,string.format("buttonChangeName%d-%d",i,j))
					if testButton~=0 then
						return testButton
					end
				end
			end
		end
	else
		for i=startLineIndex,0,-1 do
			if json and json.sortNames[i] and json.sortNames[i].keyword then
				local nItemMax = math.min(table.maxn(json.sortNames[i].keyword), 4)
				for j=0, nItemMax do
					local testButton=FindChildSprite(root,string.format("buttonChangeName%d-%d",i,j))
					if testButton~=0 then
						return testButton
					end
				end
			end
		end
	end
	return 0
end