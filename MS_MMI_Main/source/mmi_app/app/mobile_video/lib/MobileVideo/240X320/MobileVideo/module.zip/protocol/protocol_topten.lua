﻿--
function RequestTopTen(protocolNumber, topTenURL, isFromMenu)
	--WriteLogs("RequestTopTen() ")
	local fileName = GetLocalFilename(topTenURL)
	local reg = registerCreate("topTen")
	registerSetString(reg, "TopTenUrlFileName", fileName)

	WriteLogs("RequestTopTen url="..topTenURL)
	WriteLogs("cache file:"..fileName);


	local observer = nil
	if isFromMenu then
		local regObserver = registerCreate("saveObserver")
		observer = registerGetInteger(regObserver, "observer")
	else
		observer = pluginGetObserver()
	end
	pluginInvoke(http, "AppendCommand", 0, topTenURL, 0, fileName, observer, protocolNumber, 0,0)
end

--该方法是为了得到Json对象是否正确
function TopTenNetworkData()
	return LoadJsonTopTenNetworkData()
end

--该方法是得到Json的对象
function LoadJsonTopTenNetworkData()
	local reg = registerCreate("topTen")
	local fileName = registerGetString(reg, "TopTenUrlFileName")
	if fileName then
		local jsonString = jsonLoadFile(fileName)
		if jsonString then
			return jsonString
		end
	end
	return nil
end
