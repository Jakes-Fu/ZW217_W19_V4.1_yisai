--
function RequestChannel(protocolNumber, channelURL)
	local fileName = GetLocalFilename(channelURL)
	local reg = registerCreate("product")
	WriteLogs("RequestChannelCacheFile = "..fileName)
	registerSetString(reg,"channelURL",channelURL)
	registerSetString(reg, "channelURLFileName", fileName)
	local _,j = string.find(channelURL,"foucsProgramId=")
	if j and j ~= 0 then
		local k = string.find(channelURL,"&", j+1)
		if k and k ~= 0 then
			registerSetString(reg,"foucsProgramId",string.sub(channelURL,j+1,k-1))
		else
			registerSetString(reg,"foucsProgramId",string.sub(channelURL,j+1,string.len(channelURL)))
		end
	else
		registerSetString(reg,"foucsProgramId","")
	end
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, channelURL, 0, fileName, observer, protocolNumber, 0,0)
end

--该方法是为了得到Json对象是否正确
function ChannelNetworkData()
	local reg = registerCreate("product")
	local fileName = registerGetString(reg, "channelURLFileName")
	return jsonLoadFile(fileName)
end

--该方法是释放保存的Json对象
function ReleaseChannelNetworkData()
	
end

--该方法是得到Json的对象
function LoadJsonChannelNetworkData()
	return ChannelNetworkData()
end
