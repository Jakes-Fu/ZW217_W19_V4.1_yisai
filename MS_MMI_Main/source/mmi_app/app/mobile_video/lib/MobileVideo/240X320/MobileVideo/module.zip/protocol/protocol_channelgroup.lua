--
function RequestChannelGroup(protocolNumber, channelURL)
	WriteLogs("*. RequestChannelGroup() ")
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	if http == nil or http == 0 then
		http = pluginCreate("HttpPipe")
		registerSetInteger(regSystem, "comHttpPipe", http)
	end

	ReleaseChannelGroupData()
	local reg = registerCreate("guide")
	local fileName = GetLocalFilename(channelURL)
	registerSetString(reg, "channelGroupURLFileName", fileName)

	WriteLogs("channelGroupURLFileName = "..fileName );

	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, channelURL, 0, fileName, observer, protocolNumber, 0,0)
end

function ChannelGroupData()
	local reg = registerCreate("guide")
	local json = registerGetInteger(reg, "channelGroupNetwork")
	if not json or json == 0 then
		return LoadChannelGroupData()
	end
	return json
end

function LoadChannelGroupData()
	local reg = registerCreate("guide")
	local fileName = registerGetString(reg, "channelGroupURLFileName")
	local jsonNetworkData = registerGetInteger(reg, "channelGroupNetwork")
	if jsonNetworkData ~= 0 then
		jsonRelease(jsonNetworkData)
		registerSetInteger(reg, "channelGroupNetwork", 0)
	end
	WriteLogs("channelGroupURLFileName = "..fileName)
	if fileName then
		local jsonString = jsonOpenFile(fileName)
		if jsonString and jsonString ~= 0 then
			registerSetInteger(reg, "channelGroupNetwork", jsonString)
			return jsonString
		else
			registerSetInteger(reg, "channelGroupNetwork", 0)
		end
	end
	return nil
end

--该方法是释放保存的Json对象
function ReleaseChannelGroupData()
	local reg = registerCreate("guide")
	local jsonNetworkData = registerGetInteger(reg, "channelGroupNetwork")
	if jsonNetworkData ~= 0 then
		jsonRelease(jsonNetworkData)
		registerSetInteger(reg, "channelGroupNetwork", 0)
	end
end
