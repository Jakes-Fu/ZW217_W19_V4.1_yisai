--author xf_pan
--date  2010/05/31
--Param  title  �Ի������
--Param  message  ��ʾ��Ϣ
--Param  type  ���� BT_NULL : û�а�ť BT_OK : ��ʾ"ȷ��"��ť  BT_OK_CANCEL��ʾ"ȷ��""ȡ��"��ť
--Param  backScene  ���س�������
--Param  background  �Ի��򱳾� (��Ϊnil ��ȡbackScene)
--Param  observer  ����ȷ��/ȡ�� ֪ͨ�Ķ��� 1001ȷ�� 1002ȡ��
--Param	 backSceneMenu ���س��� �Ƿ���Ҫ�˵� nilΪ��Ҫ��1Ϊ����Ҫ
function setDialogParam(title, message, type, backScene, background, observer, backSceneMenu , dlgImg, leftText, rightText)

	local regDialog = registerCreate("dialog-param")
	dbcReg = registerCreate("UseDialogReg")
	if type == "BT_OK" then		
		registerSetInteger(dbcReg,"UseDialogFlag",1)
		WriteLogs("usedialog usedialogflag line16")
	else
		registerSetInteger(dbcReg,"UseDialogFlag",2)
		WriteLogs("usedialog usedialogflag line18")
	end
	
	registerSetString(regDialog, "dialog-title", title)
	registerSetString(regDialog, "dialog-message", message)
	registerSetString(regDialog, "dialog-type", type)
	registerSetString(regDialog, "dialog-back-scene", backScene)
	registerSetString(regDialog, "dialog-background", background or backScene)
	if observer ~= nil then
		registerSetInteger(regDialog, "dialog-observer", observer)
	end
	if backSceneMenu ~= nil then
		registerSetInteger(regDialog, "dialog-backScene-menu", backSceneMenu)
	end
	
	if dlgImg ~= nil then
	  if dlgImg.OK_N_IMG then
		    registerSetString( regDialog , "OK_N_IMG", dlgImg.OK_N_IMG )
		else
		    registerSetString( regDialog , "OK_N_IMG", "file:///image/dialog/ok.png" )
	  end
		
		if dlgImg.OK_F_IMG then
		    registerSetString( regDialog , "OK_F_IMG", dlgImg.OK_F_IMG )
		else
		    registerSetString( regDialog , "OK_F_IMG", "file:///image/dialog/ok_alt.png" )
		end

		if dlgImg.CANCEL_N_IMG then
		    registerSetString( regDialog , "CANCEL_N_IMG", dlgImg.CANCEL_N_IMG )
		else
		    registerSetString( regDialog , "CANCEL_N_IMG", "file:///image/dialog/cancel.png" )
		end

		if dlgImg.CANCEL_F_IMG then
		    registerSetString( regDialog , "CANCEL_F_IMG", dlgImg.CANCEL_F_IMG )
		else
		    registerSetString( regDialog , "CANCEL_F_IMG", "file:///image/dialog/cancel_alt.png" )
		end
	else
		registerSetString( regDialog , "OK_N_IMG", "file:///image/dialog/ok.png" ) 
	  registerSetString( regDialog , "OK_F_IMG", "file:///image/dialog/ok_alt.png" )
	  registerSetString( regDialog , "CANCEL_N_IMG", "file:///image/dialog/cancel.png" )
	  registerSetString( regDialog , "CANCEL_F_IMG", "file:///image/dialog/cancel_alt.png" )    	
	end
	if leftText ~= nil then
		registerSetString( regDialog , "leftText", leftText )
	end
	if rightText ~= nil then
		registerSetString( regDialog , "rightText", rightText )
	end
end

--return value  ѡ�еİ�ťֵ "ok"  "cancel"
function getDialogReturnValue()
	local regDialog = registerCreate("dialog-param")
	return registerGetString(regDialog, "dialog-return-value")
end

--------------------------------------------------------
function getDialogParam()

	local regDialog = registerCreate("dialog-param")

	return	registerGetString(regDialog, "dialog-title"),registerGetString(regDialog, "dialog-message"),registerGetString(regDialog, "dialog-type"),registerGetString(regDialog, "dialog-back-scene"),registerGetString(regDialog, "dialog-background"),registerGetInteger(regDialog, "dialog-observer"),registerGetInteger(regDialog, "dialog-backScene-menu"),
	        registerGetString(regDialog, "OK_N_IMG"),
			registerGetString(regDialog, "OK_F_IMG"),
			registerGetString(regDialog, "CANCEL_N_IMG"),
			registerGetString(regDialog, "CANCEL_F_IMG"),
			registerGetString(regDialog, "leftText"),
			registerGetString(regDialog, "rightText")
end

function clearDialogParam()

	local regDialog = registerCreate("dialog-param")
	registerRemove(regDialog, "dialog-title")
	registerRemove(regDialog, "dialog-message")
	registerRemove(regDialog, "dialog-type")
	registerRemove(regDialog, "dialog-back-scene")
	registerRemove(regDialog, "dialog-background")
	registerRemove(regDialog, "dialog-observer")
	registerRemove(regDialog, "dialog-backScene-menu")

end

function setDialogReturnParam(value)
	local regDialog = registerCreate("dialog-param")
	registerSetString(regDialog, "dialog-return-value", value)
end

-- release this file
function FreeFunction()
	setDialogParam 			= nil
	getDialogReturnValue 	= nil
	getDialogParam			= nil
	setDialogReturnParam 	= nil
end