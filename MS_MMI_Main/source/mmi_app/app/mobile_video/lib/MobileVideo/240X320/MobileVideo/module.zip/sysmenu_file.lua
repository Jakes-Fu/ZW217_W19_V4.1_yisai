﻿--@module 	SystemMenu
--@note 		底部菜单
--@author 	chengzhongjie
--@date 		2010/05/25
--@brief 		用于显示弹出菜单

require "module.sysmenu"
function downloadMngrOnSelect(sprite)
	hideMenuSprite()
	WriteLogs("downloadMngrOnSelect")
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\downloadingInfor.xml")
	Go2Scene("MODULE:\\downloadingInfor.xml")
end

function uploadMngrOnSelect(sprite)
	hideMenuSprite()
	VerifyWhiteList("uploading")
end

function uploadFileOnSelect(sprite)
	hideMenuSprite()
	VerifyWhiteList("upload")
end

--白名单验证
function VerifyWhiteList(kind)
	require "module.protocol.protocol_usercheck"
	local whitelistUrl = "http://c2.cmvideo.cn/ugcapp/uploadFile/UGC_CheckUser.html"
	local T_TYPE = "?T_TYPE=001"
	whitelistUrl = whitelistUrl..T_TYPE
	local Status = -1
	if kind == "uploading" then 
		Status = GetUserAuthority(123,"001")
	elseif kind == "upload" then 
		Status = GetUserAuthority(124,"001")
	end
	require "module.protocol.protocol_usercheck"
	require "module.dialog.useDialog"
	require "module.common.registerScene"
	require "module.common.SceneUtils"
	local regHandle = registerCreate("SCMngr_handle")
	local SceneName = registerGetString(regHandle, string.format("%d", GetCurScene()))
	if Status == 3 then
		if kind == "uploading" then
			SetReturn1(sceneUploadingInfo)
			Go2Scene(sceneUploadingInfo)
		elseif kind == "upload" then
			SetReturn1(sceneUpload)
			Go2Scene(sceneUpload)
		end	
	elseif Status == 1 then
		setDialogParam("上传管理", "您不是白名单用户", "BT_OK",SceneName, SceneName,spriteEvent)	
		Go2Scene(sceneDialog)
	elseif Status == 2 then
		SetReturn1(sceneRegisterInformation)
		Go2Scene(sceneRegisterInformation)
	else
		setDialogParam("上传管理", "网络错误", "BT_OK",SceneName ,SceneName,spriteEvent)	
		Go2Scene(sceneDialog)
	end
end

function sysFileKeyUp(sprite,keyCode)
	filereg=registerCreate("fileButtonSprite")
	registerSetInteger(filereg,"fileButton",FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"down"))
	local reg=registerCreate("PassLeft")
	registerSetInteger(reg,"spritePassLeft",sprite)
	item=GetParentSprite(sprite)
	local menuList=GetParentSprite(GetParentSprite(sprite))
	itemCount = SpriteList_GetListItemCount(menuList)
	index = SpriteListItem_GetIndex(item)
	local list={"down","upload","uploadFile"}
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
	local lastFocus=registerGetInteger(homeLastFoucsReg,"lastFocusSprite")
	if keyCode==10 and index <=itemCount-1 then
		listitem=SpriteList_GetListItem(menuList, index+1)
		cursprite=FindChildSprite(listitem,list[index+2])
		if IsSpriteEnable(cursprite) ~= 0 then
			SetSpriteFocus(cursprite)
		end
	elseif keyCode == 1 then
		reg = registerCreate("sysSprite")
		SenceSprite=registerGetInteger(reg,"sprite_name")
		require("module.menuopen")
		SetSpriteFocus(SenceSprite)
		returnButtonOnSelect(sprite)
	elseif keyCode ==2  then
		require("module.menuopen")
		reg = registerCreate("sysSprite")
		SenceSprite=registerGetInteger(reg,"sprite_name")
		SetSpriteFocus(SenceSprite)
		returnButtonOnSelect(sprite)
	elseif keyCode==7  then
		flag=1
		local flagReg=registerCreate("flagnum")
		registerSetInteger(flagReg,"flagnum",flag)
		local regInfor=registerCreate("passSprite")
		local senceSprite=registerGetInteger(regInfor,"CurSprite")
		SetSpriteFocus(senceSprite)
		local reg=registerCreate("popS")
		popSprite=registerGetInteger(reg,"pop")
		ShowPopupMenu(popSprite,0)
	elseif keyCode==9 and index>=1 then
		if index==0 then return 0
		else 
			listitem=SpriteList_GetListItem(menuList, index-1)
			cursprite=FindChildSprite(listitem,list[index])
			SetSpriteFocus(cursprite)
		end
	end
		return 0
end

function ShowPopupMenu(popSprite, show)
	if show == 0 then
		SetSpriteVisible(popSprite, 0)
		SetSpriteEnable(popSprite, 0)
		childPopSprite = FindChildSpriteByClass(popSprite, "list")
		if childPopSprite ~= 0 then
			SpriteList_SetCurItem(childPopSprite, -1)
		end
	else
		SetSpriteVisible(popSprite, 1)
		SetSpriteEnable(popSprite, 1)
	end
end


function hidePopupSprites()
	local	reg = registerCreate(keyQuickLauncherBar)
	local	rootSprite = registerGetInteger(reg, "rootSprite")
	
	if hideMenuSprite(rootSprite) == 1 then	return	1	end
	if hideBottomSprite(rootSprite) == 1 then	return	1 end
	return	0
end

