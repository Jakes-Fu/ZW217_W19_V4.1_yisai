--@module protocol_vote.lua
--@note ��ȡͶƱ��Ϣ
--@author cuiyizhou
--@date 2010/06/16
function RequestVote(protocolNumber, voteURL)
	--[[  ����httppipe�������ȡ��������  ]]-- 
	local regSystem = registerCreate("System")
	http = registerGetInteger(regSystem, "comHttpPipe")
	local fileName = GetLocalFilename(voteURL)
	local reg = registerCreate("vote")
	registerSetString(reg, "voteUrlFileName", fileName)
	local observer = pluginGetObserver()
	local reg_p = registerCreate("product")
	local contentId =	registerGetString(reg_p,"contentid")
	registerSetString(reg_p,contentId,"1")
	pluginInvoke(http, "AppendCommand", 0, voteURL, 0, fileName, observer, protocolNumber, 0 ,1)
--	pluginRelease(http)
	return 1
end

function OnVoteDecode()
	--[[  ����RequestVolume�����ɵ��ļ�����ȡ������json  ]]-- 
	local reg = registerCreate("vote")
	local fileName = registerGetString(reg, "voteUrlFileName")
	return jsonLoadFile(fileName)
end

function DeleteCacheFile()
	local reg = registerCreate("vote")
	local fileName = registerGetString(reg, "voteUrlFileName")
	os.remove(fileName)
	return 1
end