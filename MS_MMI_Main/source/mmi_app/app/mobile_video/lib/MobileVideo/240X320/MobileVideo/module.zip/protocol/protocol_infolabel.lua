--@module infovolume.lua
--@note ��ǩʽ�������ݻ�ȡ
--@author cuiyizhou
--@date 2010/06/02
function Requestlabel(protocolNumber, labelURL)
	require("module.menuprograminfo")
	SetProgramInfoUrlPath(labelURL)
	--[[  ����httppipe�������ȡ��������  ]]--
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	local fileName = GetLocalFilename(labelURL)
	local reg = registerCreate("menuprograminfo_label")
	registerSetString(reg, "labelUrlFileName", fileName)

	-- add by xf_pan
	require("module.video_groupinfo")
	SavaGroupFileName(fileName)

	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, labelURL, 0, fileName, observer, protocolNumber, 0,0)
	return 1
end

function OnLabelDecode()
	--[[  ����RequestVolume�����ɵ��ļ�����ȡ������json  ]]--
	local reg = registerCreate("menuprograminfo_label")
	local fileName = registerGetString(reg, "labelUrlFileName")
	return jsonLoadFile(fileName)
end

function FreeLabelFuncs()
	Requestlabel = nil
	OnLabelDecode = nil
end
