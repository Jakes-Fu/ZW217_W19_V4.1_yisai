
--@author zhouzhicheng
--@date   2010/06/12
--@brief ����ĺ�����Ҫ��ģ����ʵͶƱ



function VoteLoad()
    local voteInfo={}
    local key = registerCreate("VOTE_DBG")
  
    -- local voteInfo={
	-- VOTE_RIGHT_BASE = 485 ,
	-- VOTE_WRONG_BASE = 87,
	-- VOTE_TIME_BASE = 1276300000 ,-- 2010/06/12 10:30


	-- --������ͶƱ�У�Ͷ֧��Ʊ�ͷ�Ʊ�ı���
	-- VOTE_RIGHT_CAP_MIN = 82,
	-- VOTE_RIGHT_CAP_MAX = 100,

	-- --����ÿ��ͶƱ����10�����200
	-- VOTE_SPEED_MIN = 10,
	-- VOTE_SPEED_MAX = 200,
	-- }

    voteInfo.VOTE_RIGHT_BASE = 485;
	voteInfo.VOTE_WRONG_BASE = 87;
	voteInfo.VOTE_TIME_BASE = 1276300000 ;-- 2010/06/12 10:30

	-- --������ͶƱ�У�Ͷ֧��Ʊ�ͷ�Ʊ�ı���
	voteInfo.VOTE_RIGHT_CAP_MIN = 82;
	voteInfo.VOTE_RIGHT_CAP_MAX = 100;

	-- --����ÿ��ͶƱ����10�����200
	voteInfo.VOTE_SPEED_MIN = 10;
	voteInfo.VOTE_SPEED_MAX = 200;

	voteInfo.VOTE_TIME_LAST = registerGetNumber(key,"VOTE_TIME_LAST")
	voteInfo.VOTE_RIGHT = registerGetNumber(key,"VOTE_RIGHT")
	voteInfo.VOTE_WRONG = registerGetNumber(key,"VOTE_WRONG")
	
	--registerLoad(key, "MODULE:\\debug\\voteDbg.xml",0);
	
	return voteInfo;
end

function VoteSave( voteInfo )
    local key = registerCreate("VOTE_DBG")

	registerSetNumber(key,"VOTE_TIME_LAST" , voteInfo.VOTE_TIME_LAST)
	registerSetNumber(key,"VOTE_RIGHT" , voteInfo.VOTE_RIGHT)
	registerSetNumber(key,"VOTE_WRONG" , voteInfo.VOTE_WRONG)  
	-- registerSetNumber(key,"VOTE_RIGHT_BASE" , voteInfo.VOTE_RIGHT_BASE)  
	-- registerSetNumber(key,"VOTE_WRONG_BASE" , voteInfo.VOTE_WRONG_BASE)  
	-- registerSetNumber(key,"VOTE_TIME_BASE" , voteInfo.VOTE_TIME_BASE)  
	-- registerSetNumber(key,"VOTE_RIGHT_CAP_MIN" , voteInfo.VOTE_RIGHT_CAP_MIN)  
	-- registerSetNumber(key,"VOTE_RIGHT_CAP_MAX" , voteInfo.VOTE_RIGHT_CAP_MAX)  
	-- registerSetNumber(key,"VOTE_SPEED_MIN" , voteInfo.VOTE_SPEED_MIN)  
	-- registerSetNumber(key,"VOTE_SPEED_MAX" , voteInfo.VOTE_SPEED_MAX)  
	
	--registerSave(key, "MODULE:\\debug\\voteDbg.xml");
end

function Vote( isRight )
   math.randomseed( os.time())

   --��ʼ����������
   local vi = VoteLoad()
   
   --�ݴ�����
   if vi.VOTE_RIGHT == nil or vi.VOTE_RIGHT <    vi.VOTE_RIGHT_BASE then
      vi.VOTE_RIGHT = vi.VOTE_RIGHT_BASE
   end
   
   if vi.VOTE_WRONG == nil or vi.VOTE_WRONG < vi.VOTE_WRONG_BASE then
      vi.VOTE_WRONG = vi.VOTE_WRONG_BASE
   end
   
   if vi.VOTE_TIME_LAST == nil or vi.VOTE_TIME_LAST <= 0 then
      vi.VOTE_TIME_LAST  = vi.VOTE_TIME_BASE
   end
   
   require "module.debug.printDbg"
   printData( vi )

   --�����ģ��ʱ�俪ʼ������ǰ�����Ӷ���Ʊ��
   local vote_speed = math.random( vi.VOTE_SPEED_MIN, vi.VOTE_SPEED_MAX )
   local voteCalcTotal = (os.time() - vi.VOTE_TIME_LAST)*vote_speed/(24.0*3600.0)
   
   
   --���������ӵ�Ʊ���У��ж�����֧��Ʊ�������Ƿ�Ʊ
   local vote_right_cap = math.random( vi.VOTE_RIGHT_CAP_MIN , vi.VOTE_RIGHT_CAP_MAX ) / 100
   local vote_wrong_cap = 1.0 - vote_right_cap
   local voteCalcRight = math.floor( vote_right_cap * voteCalcTotal )
   local voteCalcWrong = math.floor( vote_wrong_cap * voteCalcTotal )

   if isRight == true then
      voteCalcRight = voteCalcRight + 1
   else
      voteCalcWrong = voteCalcWrong + 1
   end
   
   --����ǰλ�õ��ۼ�Ʊ��
   vi.VOTE_RIGHT = vi.VOTE_RIGHT + voteCalcRight
   vi.VOTE_WRONG = vi.VOTE_WRONG + voteCalcWrong

   --
   -- WriteLogs("vote_speed :"..vote_speed);
   -- WriteLogs("voteCalcTotal :"..voteCalcTotal);
   -- WriteLogs("vote_right_cap :"..vote_right_cap);
   -- WriteLogs("voteCalcRight :"..voteCalcRight);
   -- WriteLogs("voteCalcWrong :"..voteCalcWrong);
   --
   vi.VOTE_TIME_LAST = os.time()	
   
   WriteLogs("=====================")
   printData( vi )
   
   --
   VoteSave( vi );
   --
   return vi.VOTE_RIGHT, vi.VOTE_WRONG
end

