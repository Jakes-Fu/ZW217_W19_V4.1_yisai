--
function RequestHome(protocolNumber, homeURL)
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	if http == nil or http == 0 then
		http = pluginCreate("HttpPipe")
		registerSetInteger(regSystem, "comHttpPipe", http)
	end
	fileName = GetLocalFilename(homeURL)
	local reg = registerCreate("home")
	registerSetString(reg, "HomeUrlFileName", fileName)
	ReleaseHomeNetworkData()
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, homeURL, 0, fileName, observer, protocolNumber, 0,0)
end

--该方法是为了得到Json对象是否正确
function HomeNetworkData()
	local reg = registerCreate("home")
	local fileName = registerGetString(reg, "HomeUrlFileName")
	WriteLogs("fileName: " .. fileName)
	local strNetworkData = registerGetInteger(reg, "HomeNetwork")
	if strNetworkData ~= 0 then
		jsonRelease(strNetworkData)
		registerSetInteger(reg, "HomeNetwork", 0)
	end
	local jsonString = jsonOpenFile(fileName)
	if jsonString and jsonString ~= 0 then
		registerSetInteger(reg, "HomeNetwork", jsonString)
		return jsonString
	end
	return nil
end

--该方法是释放保存的Json对象
function ReleaseHomeNetworkData()
	local reg = registerCreate("home")
	local strNetworkData = registerGetInteger(reg, "HomeNetwork")
	if strNetworkData ~= 0 then
		jsonRelease(strNetworkData)
		registerSetInteger(reg, "HomeNetwork", 0)
	end
end

--该方法是得到Json的对象
function LoadJsonHomeNetworkData()
	local reg = registerCreate("home")
	local strNetworkData = registerGetInteger(reg, "HomeNetwork")
	if strNetworkData then
		return jsonToTable(strNetworkData)
	end
	return nil
end

function deleteHomeCacheFile()
	folder = GetModuleFolder()
	if fileName and fileName ~= "" then
		local deletefile = string.gsub(fileName,"MODULE:\\",GetModuleFolder())
		--os.remove(deletefile)
		--os.remove(GetModuleFolder().."cache\\lastmodified.dat")
		--os.remove(GetModuleFolder().."cache\\etag.dat")
	end
end
