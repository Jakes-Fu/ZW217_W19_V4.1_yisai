--
function RequestChannelGroup(protocolNumber, channelURL)
	WriteLogs("*. RequestChannelGroup() ")
	local fileName = GetLocalFilename(channelURL)
	local reg = registerCreate("guide")
	registerSetString(reg, "channelGroupURLFileName", fileName)

	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, channelURL, 0, fileName, observer, protocolNumber, 0,0)
end

function OnChannelGroupDecode()
	local reg = registerCreate("guide")
	local fileName = registerGetString(reg, "channelGroupURLFileName")
	return jsonLoadFile(fileName)
end
