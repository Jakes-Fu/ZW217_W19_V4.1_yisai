require ("module.setting")

function RequestLogin(protocolNumber, uuid, clientVesion, playerVersion, skinVersion, moduleVersion)
	if uuid then
		require ("module.common.partiners")
		local partiner = GetPartiners()
		require("module.ver")
		local clientLogin = Cfg.GetServer()..Cfg.GetPortal().."/commonCommunication.msp"
		if clientVersion == nil then clientVersion = G_CLIENT_VER end
		if playerVersion == nil then playerVersion = G_MEDIAPLAYER_VER end
		if skinVersion == nil then skinVersion = G_SKIN_VER end
		if moduleVersion == nil then moduleVersion = G_MODULE_VER end
		local postData = string.format("q=<?xml version=\"1.0\" encoding=\"UTF-8\"?><Root><header></header><body><request type=\"Login\" serial=\"1\"><uuid>%s</uuid><dealer>%s</dealer><clientInfo>%s</clientInfo></request><request type=\"CheckVersion\" serial=\"1\"><component id=\"MobileVideo\" version=\"%s\"/><component id=\"MediaPlayer\" version=\"%s\"/><component id=\"Skin\" version=\"%s\"/><component id=\"Module\" version=\"%s\"/><dealer>%s</dealer></request></body></Root>", uuid, partiner, G_CLIENT_INFO, clientVersion, playerVersion, skinVersion, moduleVersion, partiner)
		loginURLFileName = GetLocalFilename(string.format("%s%s",clientLogin,postData))
		local reg = registerCreate("welcome")
		registerSetString(reg, "LoginUrlFileName", loginURLFileName)
		WriteLogs("LoginUrlFileName = "..loginURLFileName)

		local regSystem = registerCreate("System")
		local http = registerGetInteger(regSystem, "comHttpPipe")
		local observer = pluginGetObserver()
		pluginInvoke(http, "AppendCommand", 1, clientLogin, postData, loginURLFileName, observer, protocolNumber, 0,0)
	end
end

function OnPipeLoginDecode()
	local reg = registerCreate("welcome")
	local fileName = registerGetString(reg, "LoginUrlFileName")

	local resLogin = nil
	local resVersion = nil
	local nodeTree = xmlLoadFile(fileName)
	if nodeTree ~= 0 then
		local nodeRoot = xmlFindElement(nodeTree, nodeTree, "Root")
		if nodeRoot ~= 0  then
			local nodeBody = xmlFindElement(nodeTree, nodeRoot, "body")
			if nodeBody ~= 0  then
				local nodeResponse = xmlFindElement(nodeRoot, nodeBody, "response")
				resLogin = DecodeLoginInfo(nodeResponse, nodeBody)
				if resLogin then
				  resLogin.Phone = DecodePhoneInfo(nodeResponse, nodeBody)
					local nodeResponse2 = xmlFindElement(nodeBody, nodeResponse, "response")
					resVersion = DecodeVersionInfo(nodeResponse2, nodeBody)
				end
			end
		end
	end
	xmlRelease(nodeTree)
	return resLogin, resVersion
end

function DecodePhoneInfo(nodeResponse, nodeBody)
		local resPhone = nil
		local nodePhoneNum = xmlFindElement(nodeBody, nodeResponse, "phoneNum")
		if nodePhoneNum ~= 0 then
			resPhone = xmlGetText(nodePhoneNum)
		end
      return resPhone
end

function DecodeLoginInfo(nodeResponse, nodeBody)
	if nodeResponse ~= 0 then
		local resTable = nil
		local nodeCode = xmlFindElement(nodeBody, nodeResponse, "code")

		local nodeSessionID = xmlFindElement(nodeBody, nodeResponse, "sessionID")
		local nodeChannelDataTime = xmlFindElement(nodeBody, nodeResponse, "channelDataTime")
		local nodeChannelDataUrl = xmlFindElement(nodeBody, nodeResponse, "channelDataUrl")
		local nodeDefaultUrl = xmlFindElement(nodeBody, nodeResponse, "defaultDataUrl")
		local nodeDefaultDataTime = xmlFindElement(nodeBody, nodeResponse, "defaultDataTime")

		local nodeWelcomeUrl = xmlFindElement(nodeBody, nodeResponse, "welcomeUrl")
		local nodeWelcomeDataTime = xmlFindElement(nodeBody, nodeResponse, "welcomeDataTime")
		local nodeImagesPackingUrl = xmlFindElement(nodeBody, nodeResponse, "imagesPackingUrl")

		if nodeCode ~= 0 then
			local code = xmlGetText(nodeCode)
			resTable = {code = code }
		else
			return resTable
		end
		if nodeDefault ~= 0 then
			resTable.deafultDataTime = xmlGetText(nodeDefaultDataTime)
		end
		if nodeSessionID ~= 0 then
			resTable.sessionID = xmlGetText(nodeSessionID)
		end
		if nodeChannelDataTime ~= 0 then
			resTable.channelDataTime = xmlGetText(nodeChannelDataTime)
		end
		if nodeChannelDataUrl ~= 0 then
			resTable.channelDataUrl = xmlGetText(nodeChannelDataUrl)
		end
		if nodeDefaultUrl ~= 0 then
			resTable.defaultDataUrl = xmlGetText(nodeDefaultUrl)
		end
		if nodeWelcomeUrl ~= 0 then
			resTable.welcomeUrl = xmlGetText(nodeWelcomeUrl)
		end
		if nodeWelcomeDataTime ~= 0 then
			resTable.welcomeDataTime = xmlGetText(nodeWelcomeDataTime)
		end
		if nodeImagesPackingUrl ~= 0 then
			resTable.imagePackingUrl = xmlGetText(nodeImagesPackingUrl)
		end
		return resTable
	end
end

function DecodeVersionInfo(nodeResponse2,nodeBody)
	local i = 0
	resVersion = {}
	local nodeComponent = xmlFindElement(nodeResponse2, nodeBody, "component")
	local system = registerCreate("System")
	while nodeComponent ~= 0 do
		local id = xmlElementGetAttr(nodeComponent, "id")
		local version = xmlElementGetAttr(nodeComponent, "version")
		local flags = xmlElementGetAttr(nodeComponent, "flags")
		local url = xmlElementGetAttr(nodeComponent, "url")
		resVersion[i] = {id=id, version=version, flags=flags, url=url}
		registerSetInteger(system,"updateComponentCount",i)
		i = i + 1
		nodeComponent = xmlFindElement(nodeComponent, nodeResponse2, "component")
	end
	return resVersion
end

function deleteLoginCacheFile()
	folder = GetDefaultFolder(WDFIDL_MODULE)
	if loginURLFileName and loginURLFileName ~= "" then
		os.remove(loginURLFileName)
		os.remove(folder.."cache\\lastmodified.dat")
		os.remove(folder.."cache\\etag.dat")
	end
end

function RequestWelcomeNew(protocolNumber,welcomeUrl)
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, welcomeUrl, 0, "MODULE:\\welcomeNew_1.xml", observer, protocolNumber, 0,1)
end
