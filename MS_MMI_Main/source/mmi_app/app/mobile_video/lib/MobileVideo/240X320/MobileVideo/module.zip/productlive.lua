﻿
require "module.keyCode.keyCode"
require "module.common.commonScroll"
require "module.Loading.useLoading"
local firstIndex
function SetTimeSprites(spriteRectNode, timeBegin, timeEnd)
	if spriteRectNode and spriteRectNode ~= 0 then
		local spriteTimeBegin = FindChildSprite(spriteRectNode, "label-time-begin")
		if spriteTimeBegin and spriteTimeBegin ~= 0 then
			SetSpriteProperty(spriteTimeBegin, "text", timeBegin)
		end
		local spriteTimeEnd = FindChildSprite(spriteRectNode, "label-time-end")
		if spriteTimeEnd and spriteTimeEnd ~= 0 then
			SetSpriteProperty(spriteTimeEnd, "text", timeEnd)
		end
	end
end

function productLiveChannelDaySelect(sprite)
	local DaySelect = GetSpriteName(sprite)
	local reg = registerCreate("product")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root ,"loadarea")
	if jsonChannel.imgListNavi and #jsonChannel.imgListNavi >= 0 and jsonChannel.imgListNavi[0] then
		if DaySelect == "beforeYesterday" then
			if jsonChannel.imgListNavi[0].beforeYesterdayUrl then
				require ("module.protocol.protocol_channel")
				RequestChannel(111, jsonChannel.imgListNavi[0].beforeYesterdayUrl)
				enterLoading(loadarea)
			end
		end
		if DaySelect == "yesterday" then
			if jsonChannel.imgListNavi[0].beforeYesterdayUrl then
				require ("module.protocol.protocol_channel")
				RequestChannel(111, jsonChannel.imgListNavi[0].yesterdayUrl)
				enterLoading(loadarea)
			end
		end
		if DaySelect == "today" then
			if jsonChannel.imgListNavi[0].beforeYesterdayUrl then
				require ("module.protocol.protocol_channel")
				RequestChannel(111, jsonChannel.imgListNavi[0].todayUrl)
				enterLoading(loadarea)
			end
		end
		if DaySelect == "tomorrow" then
			if jsonChannel.imgListNavi[0].beforeYesterdayUrl then
				require ("module.protocol.protocol_channel")
				RequestChannel(111, jsonChannel.imgListNavi[0].tomorrowUrl)
				enterLoading(loadarea)
			end
		end
	end
end

function SetListItemInfo(spriteList, text, imgWidth, border, left, height, bSelected , btnName)
	local channelDaySprite = CreateSprite("listitem")
	LoadSprite(channelDaySprite, "MODULE:\\product\\channelDayListItem.xml")
	local width = 44
	SetSpriteRect(channelDaySprite, left, 0, width + imgWidth + imgWidth, height)
	local spriteButton = FindChildSprite(channelDaySprite, "keywordButton")
	SetSpriteRect(spriteButton, 0, 0, width + imgWidth + imgWidth, height)
	local spriteButtonLabel = FindChildSprite(channelDaySprite, "keywordslistLabel")
	local spriteButtonImg=FindChildSprite(channelDaySprite, "keywordslistImg")
	if spriteButtonLabel then
		SetSpriteProperty(spriteButtonLabel, "text", text)
-----------------------------------add by yaoxiangyin-----------------------------------------------------------------------------
		if text=="前天" then
			SetSpriteProperty(spriteButtonImg, "src","file:///image/product/1.png")
		elseif text=="昨天" then
			SetSpriteProperty(spriteButtonImg, "src","file:///image/product/3.png")
		elseif text=="今天" then
			SetSpriteProperty(spriteButtonImg, "src","file:///image/product/7.png")
		else
			SetSpriteProperty(spriteButtonImg, "src","file:///image/product/9.png")
		end
-----------------------------------------------------------------------------------------------------------------------------------
		SetSpriteRect(spriteButtonLabel, 0, 0, width + imgWidth + imgWidth, height)	
		if bSelected then
			SetSpriteProperty(spriteButtonLabel, "color", "#EE4791")
		end
	end
	local spriteButtonLabelFocus = FindChildSprite(channelDaySprite, "keywordslistLabelFocus")
	if spriteButtonLabelFocus then
		SetSpriteProperty(spriteButtonLabelFocus, "text", text)
		SetSpriteRect(spriteButtonLabelFocus, 0, 0, width + imgWidth + imgWidth, height)
	end
	SetSpriteProperty( spriteButton , "name", btnName )
	AddChildSprite(spriteList, channelDaySprite)
	SpriteList_AddListItem(spriteList, channelDaySprite)
	return left + width + imgWidth + imgWidth + border
end

function setChannelInfoDisable(sprite)
	--[[
	local spriteLabel = FindChildSprite(sprite, "product-channel-label")
	if spriteLabel and spriteLabel ~= 0 then
		SetSpriteVisible(spriteLabel, 0)
	end
	]]--
	local spriteListItem = FindChildSprite(sprite, "product-live-channel-day")
	if spriteListItem and spriteListItem ~= 0 then
		SetSpriteVisible(spriteListItem, 0)
		SetSpriteEnable(spriteListItem, 0)
	end
end

function setChannelDay(sprite)
	--[[
	local spriteLabel = FindChildSprite(sprite, "product-channel-label")
	if spriteLabel and spriteLabel ~= 0 then
		SetSpriteVisible(spriteLabel, 0)
	end
	]]--
	local spriteListItem = FindChildSprite(sprite, "product-live-channel-day")
	if spriteListItem and spriteLabelItem ~= 0 then
		SetSpriteVisible(spriteListItem, 1)
		SetSpriteEnable(spriteListItem, 1)
	end
	
	local spriteList = FindChildSprite(spriteListItem, "product-live-channel-day-list")
	if spriteList and spriteList ~= 0 then
		local imgWidth = 4
		local border = 6
		
		local left = 0
		local height = 20
		
		if jsonChannel.imgListNavi and #jsonChannel.imgListNavi >= 0 and jsonChannel.imgListNavi[0] then
			if jsonChannel.imgListNavi[0].beforeYesterday then
				left = SetListItemInfo(spriteList, 
								jsonChannel.imgListNavi[0].beforeYesterday, 
								imgWidth, 
								border, 
								left, 
								height, 
								jsonChannel.imgListNavi[0].liveData == "beforeYesterday",
								"beforeYesterday")
			end
			if jsonChannel.imgListNavi[0].yesterday then
				left = SetListItemInfo(spriteList, 
								jsonChannel.imgListNavi[0].yesterday, 
								imgWidth, 
								border, 
								left, 
								height, 
								jsonChannel.imgListNavi[0].liveData == "yesterday",
								"yesterday")
			end
			if jsonChannel.imgListNavi[0].today then
				left = SetListItemInfo(spriteList, 
								jsonChannel.imgListNavi[0].today, 
								imgWidth, 
								border, 
								left, 
								height, 
								jsonChannel.imgListNavi[0].liveData == "today",
								"today")
			end
			if jsonChannel.imgListNavi[0].tomorrow then
				left = SetListItemInfo(spriteList, 
								jsonChannel.imgListNavi[0].tomorrow, 
								imgWidth, 
								border, 
								left, 
								height, 
								jsonChannel.imgListNavi[0].liveData == "tomorrow",
								"tomorrow")
			end
		end
	end
end

function createLiveVideoList(sprite)
	createLiveTodayVideoList(sprite, GetCurLiveVideoIndex())
end
--[[ 今天的直播列表创建 ]]--
function createLiveTodayVideoList(sprite , indexLive)
	local spriteList = FindChildSprite(sprite, "product-programgroup-list-live")
	SpriteList_SetStartItem(spriteList, 0)
	local index = GetCurLiveVideoIndex()
	require "module.protocol.protocol_videoloading"
	local regVideo = registerCreate("video")
	registerSetString(regVideo, "startTime", jsonChannel.programList[index].startTime)
	registerSetString(regVideo, "endTime", jsonChannel.programList[index].endTime)
	local reg_p = registerCreate("product")
	registerSetString(reg_p,"playurl",jsonChannel.programList[index].playUrl)
	registerSetString(reg_p,"contentid",jsonChannel.programList[index].contentId)
	--[[  预播放的播放请求  ]]--
	local reg_g = registerCreate("product")
	local LiveTableIndex = 1
	local LiveTable = {}
	--[[  是否由搜索来到此界面的标志，影响到当前列表选中项  ]]--
	local foucsProgramId = registerGetString(reg_g,"foucsProgramId")
	foucsIndex = nil
	if jsonChannel.programList then
		local nMax = #jsonChannel.programList
		--[[  读取本地的预约信息  ]]--
	 	local temp = registerCreate("temp") 
	 	registerLoad(temp, "MODULE:\\..\\temp\\booking.xml")
		for i=0, nMax do
			local productVideoSprite = CreateSprite("listitem")
			if foucsProgramId ~= "" and foucsProgramId == jsonChannel.programList[i].contentId then
				foucsIndex = i
			end
			if i < indexLive then  --[[ 回放列表 ]]--
				LoadSprite(productVideoSprite, "MODULE:\\product\\product_reviewitem.xml")
				local spriteRectNode = FindChildSprite(productVideoSprite, "select-display")
				local spriteRectNode2 = FindChildSprite(productVideoSprite, "unselect-display")
				SetSpriteProperty(productVideoSprite, "name", "video-sprite-"..i)
				local titleSprite = FindChildSprite(productVideoSprite, "video-title")
				SetSpriteProperty(titleSprite, "text", jsonChannel.programList[i].contentName)
				SetSpriteProperty(titleSprite, "color", "#FCDCEB")
				local titleSprite2 = FindChildSprite(productVideoSprite, "video-title2")
				SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[i].contentName)
				SetTimeSprites(spriteRectNode, jsonChannel.programList[i].startTime, jsonChannel.programList[i].endTime)
				SetTimeSprites(spriteRectNode2, jsonChannel.programList[i].startTime, jsonChannel.programList[i].endTime)
				AddChildSprite(spriteList, productVideoSprite)
				SpriteList_AddListItem(spriteList, productVideoSprite)
			elseif i == indexLive then --[[ 直播项 ]]--
				local productVideoSprite = CreateSprite("listitem")
				LoadSprite(productVideoSprite, "MODULE:\\product\\product_liveitem.xml")
				local spriteRectNode = FindChildSprite(productVideoSprite, "select-display")
				local spriteRectNode2 = FindChildSprite(productVideoSprite, "unselect-display")
				SetSpriteProperty(productVideoSprite, "name", "video-sprite-"..indexLive)
				local titleSprite = FindChildSprite(productVideoSprite, "video-title")
				SetSpriteProperty(titleSprite, "text", jsonChannel.programList[indexLive].contentName)
				SetSpriteProperty(titleSprite, "color", "#FCDCEB")
				local titleSprite2 = FindChildSprite(productVideoSprite, "video-title2")
				SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[indexLive].contentName)
				SetTimeSprites(spriteRectNode, jsonChannel.programList[indexLive].startTime, jsonChannel.programList[indexLive].endTime)
				SetTimeSprites(spriteRectNode2, jsonChannel.programList[indexLive].startTime, jsonChannel.programList[indexLive].endTime)
				
				GetSysTime()
				local regLive = registerCreate("live")
				local sysTime = registerGetString(regLive, "sysTime")
				local year, month, day, hour, minute, second = ParseDate(sysTime)
				local curTime = hour ..":" ..minute
				local curTimeInt = getTimeFoString(curTime)
				local sime = jsonChannel.programList[indexLive].startTime 
				local etime = jsonChannel.programList[indexLive].endTime 
				local startTimeInt = getTimeFoString(sime)
				local endTimeInt = getTimeFoString(etime)
				local percent = (curTimeInt-startTimeInt)/(endTimeInt-startTimeInt)
				if percent > 1 then
					percent = 1
				end
				local width = 107*percent
				local progressSprite = FindChildSprite(spriteRectNode, "image-time-progress-bar")
				local progressSprite1 = FindChildSprite(spriteRectNode2, "image-time-progress-bar")
				SetSpriteRect(progressSprite,50,24,width,7)
				SetSpriteRect(progressSprite1,50,24,width,7)
				AddChildSprite(spriteList, productVideoSprite)
				SpriteList_AddListItem(spriteList, productVideoSprite)
				--[[  modified by：yaoxiangyin @2010.09.07  ]]--
				registerSetInteger(reg_g, "liveIndex",indexLive)
				productVideoSprite=FindChildSprite(productVideoSprite,"list-item-button")
				SetSpriteFocus(productVideoSprite)
				saveTouchFocus(productVideoSprite)
			elseif i > indexLive then --[[ 预约列表 ]]--
				LoadSprite(productVideoSprite, "MODULE:\\product\\product_subscribeitem.xml")
				local spriteRectNode = FindChildSprite(productVideoSprite, "select-display")
				local spriteRectNode2 = FindChildSprite(productVideoSprite, "unselect-display")
				SetSpriteProperty(productVideoSprite, "name", "video-sprite-"..i)
				local titleSprite = FindChildSprite(productVideoSprite, "video-title")
				SetSpriteProperty(titleSprite, "text", jsonChannel.programList[i].contentName)
				SetSpriteProperty(titleSprite, "color", "#FCDCEB")
				local titleSprite2 = FindChildSprite(productVideoSprite, "video-title2")
				SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[i].contentName)
				--[[  如果预约存在 则显示图标  ]]--
				local contentId = registerGetString(temp,jsonChannel.programList[i].contentId)
				if contentId == "1" then
					local icon = FindChildSprite(productVideoSprite,"icon-sel")
					SetSpriteVisible(icon, 1)
		 		end
				SetTimeSprites(spriteRectNode, jsonChannel.programList[i].startTime, jsonChannel.programList[i].endTime)
				SetTimeSprites(spriteRectNode2, jsonChannel.programList[i].startTime, jsonChannel.programList[i].endTime)
				AddChildSprite(spriteList, productVideoSprite)
				SpriteList_AddListItem(spriteList, productVideoSprite)
				local reg_Livelist = registerCreate("LiveList")
				registerSetString(reg_Livelist, "contentName"..LiveTableIndex, jsonChannel.programList[i].contentName)
				registerSetString(reg_Livelist, "startTime"..LiveTableIndex, jsonChannel.programList[i].startTime)
				registerSetString(reg_Livelist, "endTime"..LiveTableIndex, jsonChannel.programList[i].endTime)
				registerSetInteger(reg_Livelist, "listCount", LiveTableIndex)
				registerSetInteger(reg_Livelist, "listIndex", 1)
				LiveTableIndex = LiveTableIndex + 1
			end
		end
		registerRelease("temp")
	end
	SetSpriteProperty(spriteList, "line", #jsonChannel.programList+1)
	resetLiveVideoItem(spriteList, 0, index)
	--[[  创建滚动条  ]]--
	CreateScrollBar(sprite,"product-programgroup-list-live",24*(#jsonChannel.programList+1)+24,61)
	SetSpriteRect(spriteList,0,0,222,163)	--将product-programgroup-list-live位置重置，否则第二次进入直播界面位置会累计偏移
	local x,y,w,h = GetSpriteRect(spriteList)
	if foucsProgramId == "" or foucsIndex == nil then
		SetSpriteRect(spriteList,x,y-24*indexLive,w,h)
		ScrollBarAdjust(indexLive,5,0)
		firstIndex=indexLive
	else
		SetSpriteRect(spriteList,x,y-24*foucsIndex,w,h)
		local spriteItem = SpriteList_GetListItem(spriteList, foucsIndex)
		local fbtn = FindChildSprite(spriteItem,"list-item-button")
		SetSpriteFocus(fbtn)
		ScrollBarAdjust(foucsIndex,5,0)
		firstIndex=foucsIndex
	end
end
--[[ 昨天的回放列表创建 ]]--
function createYesterdayVideoList(spriteList)
	local nMax = #jsonChannel.programList
	SetSpriteProperty(spriteList, "line", "6")
	local reg_g = registerCreate("product")
	local foucsProgramId = registerGetString(reg_g,"foucsProgramId")
	foucsIndex = nil
	--[[  读取本地的预约信息  ]]--
 	local temp = registerCreate("temp") 
 	registerLoad(temp, "MODULE:\\..\\temp\\booking.xml")
	local xmlNode=xmlLoadFile("MODULE:\\product\\product_reviewitem.xml")
	for i=0, nMax do
		if foucsProgramId ~= "" and foucsProgramId == jsonChannel.programList[i].contentId then
			foucsIndex = i
		end
		local productVideoSprite = CreateSprite("listitem")
	  if i==0 then
			  sprite2=productVideoSprite
			  WriteLogs("@@@@@@@@@@@@@@@@@"..sprite2)
	  end
		LoadSpriteFromNode(productVideoSprite, xmlNode)
		SetSpriteProperty(productVideoSprite, "name", "video-sprite-"..i)
		
		local titleSprite = FindChildSprite(productVideoSprite, "video-title")
		SetSpriteProperty(titleSprite, "text", jsonChannel.programList[i].contentName)
		SetSpriteProperty(titleSprite, "color", "#FCDCEB")
		local titleSprite2 = FindChildSprite(productVideoSprite, "video-title2")
		SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[i].contentName)
		
		local spriteRectNode = FindChildSprite(productVideoSprite, "select-display")
		local spriteRectNode2 = FindChildSprite(productVideoSprite, "unselect-display")	
		SetTimeSprites(spriteRectNode, jsonChannel.programList[i].startTime, jsonChannel.programList[i].endTime)
		SetTimeSprites(spriteRectNode2, jsonChannel.programList[i].startTime, jsonChannel.programList[i].endTime)
--[[--------------------------------修改人：yaoxiangyin 修改时间：2010.09.09-----------------------------------------]]--		
		local productVideoBtn=FindChildSprite(productVideoSprite,"list-item-button")
		SetSpriteProperty(productVideoBtn,"OnKeyUp","listKeyUp_yesterday")
----------------------------------------------------------------------------------------------------------		
		--[[  如果预约存在 则显示图标  ]]--
	 	local contentId = registerGetString(temp,jsonChannel.programList[i].contentId)
 		if contentId == "1" then 
 			local icon = FindChildSprite(productVideoSprite,"icon-sel")
	 		SetSpriteVisible(icon, 1)
 		end
		AddChildSprite(spriteList, productVideoSprite)
		SpriteList_AddListItem(spriteList, productVideoSprite)
	end
	xmlRelease(xmlNode)
	registerRelease("temp")
	resetLiveVideoItem(spriteList, 0, 0)
	SetSpriteProperty(spriteList, "line", #jsonChannel.programList+1)
	--[[  创建滚动条  ]]--
	--require "module.common.commonScroll"
	CreateScrollBar(GetRootSprite(spriteList),"product-programgroup-list",24*(nMax+1),61)
	SetSpriteRect(spriteList,0,0,222,163)
	--[[  移动列表至顶  ]]
	if foucsProgramId == "" or foucsIndex == nil then
		spriteB = FindChildSprite(sprite2,"list-item-button")
		ScrollBarAdjust(0,3,0)
		SetSpriteFocus(spriteB)
		saveTouchFocus(spriteB)
		firstIndex=0
	else
		local x,y,w,h = GetSpriteRect(spriteList)
		SetSpriteRect(spriteList,x,y-24*foucsIndex,w,h)
		local spriteItem = SpriteList_GetListItem(spriteList, foucsIndex)
		local fbtn = FindChildSprite(spriteItem,"list-item-button")
		SetSpriteFocus(fbtn)
		saveTouchFocus(fbtn)
		firstIndex=foucsIndex
		ScrollBarAdjust(foucsIndex,5,0)
	end
end

function createLiveAllVideoList(sprite)
	if jsonChannel.imgListNavi and  #jsonChannel.imgListNavi >= 0 then
		local spriteList = FindChildSprite(sprite, "product-programgroup-list")
		SpriteList_SetStartItem(spriteList, 0)
		if jsonChannel.programList then
			if jsonChannel.imgListNavi[0].liveData == "tomorrow" then	
				local nMax = #jsonChannel.programList
				SetSpriteProperty(spriteList, "line", "6")
				local xmlNode=xmlLoadFile("MODULE:\\product\\product_subscribeitem.xml")
				local reg_g = registerCreate("product")
				local foucsProgramId = registerGetString(reg_g,"foucsProgramId")
				foucsIndex = nil
				--[[  读取本地的预约信息  ]]--
				local temp = registerCreate("temp") 
				registerLoad(temp, "MODULE:\\..\\temp\\booking.xml")
				for i=0, nMax do
					if foucsProgramId ~= "" and foucsProgramId == jsonChannel.programList[i].contentId then
						foucsIndex = i
					end
					local productVideoSprite = CreateSprite("listitem")
					LoadSpriteFromNode(productVideoSprite, xmlNode)
					SetSpriteProperty(productVideoSprite, "name", "video-sprite-"..i)
					local titleSprite = FindChildSprite(productVideoSprite, "video-title")
					SetSpriteProperty(titleSprite, "text", jsonChannel.programList[i].contentName)
					SetSpriteProperty(titleSprite, "color", "#FCDCEB")
					local titleSprite2 = FindChildSprite(productVideoSprite, "video-title2")
					SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[i].contentName)
					
					local spriteRectNode = FindChildSprite(productVideoSprite, "select-display")
					local spriteRectNode2 = FindChildSprite(productVideoSprite, "unselect-display")	
					SetTimeSprites(spriteRectNode, jsonChannel.programList[i].startTime, jsonChannel.programList[i].endTime)
					SetTimeSprites(spriteRectNode2, jsonChannel.programList[i].startTime, jsonChannel.programList[i].endTime)
--[[------------------------------------------------------------------------------------------------------------------------]]--					
					local productVideoBtn=FindChildSprite(productVideoSprite,"list-item-button")
					WriteLogs("@@@@@@@@@@@########### the name of productVideoSprite_tomorrow is "..GetSpriteName(productVideoSprite))
					WriteLogs("@@@@@@@@@@@########### the name of productVideoBtn_tomorrow is "..GetSpriteName(productVideoBtn))
					SetSpriteProperty(productVideoBtn,"OnKeyUp","listKeyUp_tomorrow")
					
--------------------------------------------------------------------------------------------------------------------------------					
					--[[  如果预约存在 则显示图标  ]]--
					local contentId = registerGetString(temp,jsonChannel.programList[i].contentId)
					if contentId == "1" then 
						local icon = FindChildSprite(productVideoSprite,"icon-sel")
						SetSpriteVisible(icon, 1)
					end
					AddChildSprite(spriteList, productVideoSprite)
					SpriteList_AddListItem(spriteList, productVideoSprite)
					if i==0 then
						sprite2=productVideoSprite
					end
				end
				xmlRelease(xmlNode)
				resetLiveVideoItem(spriteList, 0, 0)
				SetSpriteProperty(spriteList, "line", #jsonChannel.programList+1)
				--[[  创建滚动条  ]]--
				CreateScrollBar(sprite,"product-programgroup-list",24*(#jsonChannel.programList+1),61)
				SetSpriteRect(spriteList,0,0,222,163)	--将product-programgroup-list-live位置重置，否则第二次进入直播界面位置会累计偏移 add by yaoxiangyin
				ScrollBarAdjust(0,3,0)
--[[--------------------------------------------------------------------------------------------------------------------]]--
				--[[  移动列表至顶  ]]--
				if foucsProgramId == "" or foucsIndex == nil then
					spriteB = FindChildSprite(sprite2,"list-item-button")
					SetSpriteFocus(spriteB)
					saveTouchFocus(spriteB)
					firstIndex=0
				else
					local x,y,w,h = GetSpriteRect(spriteList)
					SetSpriteRect(spriteList,x,y-24*foucsIndex,w,h)
					local spriteItem = SpriteList_GetListItem(spriteList, foucsIndex)
					local fbtn = FindChildSprite(spriteItem,"list-item-button")
					SetSpriteFocus(fbtn)
					saveTouchFocus(fbtn)
					firstIndex=foucsIndex
					ScrollBarAdjust(foucsIndex,5,0)
				end
-----------------------------------------------------------------------------------------------------------------------------				
			elseif jsonChannel.imgListNavi[0].liveData == "today" then
				--[[ 今天的直播列表创建 ]]--
				createLiveTodayVideoList(sprite, GetCurLiveVideoIndex())
			elseif jsonChannel.imgListNavi[0].liveData == "yesterday" then
				--[[ 昨天的回放列表创建 ]]--
				createYesterdayVideoList(spriteList)
			elseif jsonChannel.imgListNavi[0].liveData == "beforeYesterday" then
				--[[ 前天天的回放列表创建 ]]--
				createYesterdayVideoList(spriteList)
			end
		else
			local defaultBtn=FindChildSprite(GetRootSprite(spriteList),"defaultBtn")
			SetSpriteFocus(defaultBtn)
			saveTouchFocus(defaultBtn)
		end
	end
end

--begin [、Jone]
--当焦点遗失后, 焦点落到日期上, 响应日期上的OnKeyUp事件
function listKeyUp_Live_ListIsNull(sprite, keyCode)
	WriteLogs("[、Jone]----->sprite:"..sprite.."      keyCode:"..keyCode);
	changeDayList(sprite, keyCode);
end
--end

function resetLiveVideoItem(spriteList, topIndex, selectIndex)
	local top = 0
	if jsonChannel.programList then
		local nMax = math.max(#jsonChannel.programList, 5)
		for index = topIndex, topIndex + nMax do
			local productVideoSprite = SpriteList_GetListItem(spriteList, index)
			local spriteRectNode = FindChildSprite(productVideoSprite, "select-display")
			local spriteRectNode2 = FindChildSprite(productVideoSprite, "unselect-display")
			local titleSprite = FindChildSprite(productVideoSprite, "video-title")
			local buttonVideoItemSprite = FindChildSprite(productVideoSprite, "list-item-button")
			if index == selectIndex then
				local l,t,w,h = GetSpriteRect(spriteRectNode)
				SetSpriteRect(productVideoSprite, 0, top, w, h)
				SetSpriteRect(buttonVideoItemSprite, 0, 0, w, h)
				top = h
				SetSpriteProperty(titleSprite, "color", "#FCDCEB")
				SetSpriteVisible(spriteRectNode, 1)
				SetSpriteEnable(spriteRectNode, 1)
				
				SetSpriteVisible(spriteRectNode2, 0)
				SetSpriteEnable(spriteRectNode2, 0)
			else
				local l,t,w,h = GetSpriteRect(spriteRectNode2)
				SetSpriteRect(productVideoSprite, 0, top, w, h)
				SetSpriteRect(buttonVideoItemSprite, 0, 0, w, h)
				top = h + top
				SetSpriteProperty(titleSprite, "color", "#585858")
				SetSpriteVisible(spriteRectNode, 0)
				SetSpriteEnable(spriteRectNode, 0)
				
				SetSpriteEnable(spriteRectNode2, 1)
				SetSpriteVisible(spriteRectNode2, 1)
			end
		end
		SpriteList_Adjust(spriteList)
	end
end

function videoLiveListItemButtonOnSetFocus(spriteButton, loser, leaveCount)
	local spriteItem = GetSpriteParent(spriteButton)
	local nSelectIndex = SpriteListItem_GetIndex(spriteItem)
	local spriteList = GetSpriteParent(spriteItem)
	local start = SpriteList_GetStartItem(spriteList)
	resetLiveVideoItem(spriteList, start, nSelectIndex)
	if ScrollAdjustFlag and ScrollAdjustFlag == 1 then
		local totalcount = SpriteList_GetListItemCount(spriteList)
		if totalcount - nSelectIndex < 5  then
			firstIndex = totalcount - 5 - 1
		else
			firstIndex = nSelectIndex
		end
		WriteLogs("within setfocus")
	end
end

function videoReviewListItemButtonOnSetFocus(spriteButton, loser, leaveCount)
	local spriteItem = GetSpriteParent(spriteButton)
	local nSelectIndex = SpriteListItem_GetIndex(spriteItem)
	local spriteList = GetSpriteParent(spriteItem)
	local start = SpriteList_GetStartItem(spriteList)
	resetLiveVideoItem(spriteList, start, nSelectIndex)
	if ScrollAdjustFlag and ScrollAdjustFlag == 1 then
		local totalcount = SpriteList_GetListItemCount(spriteList)
		if totalcount - nSelectIndex < 5  then
			firstIndex = totalcount - 5 - 1
		else
			firstIndex = nSelectIndex
		end
		WriteLogs("within setfocus")
	end
end

function videoSubscribeListItemButtonOnSetFocus(spriteButton, loser, leaveCount)
	local spriteItem = GetSpriteParent(spriteButton)
	local nSelectIndex = SpriteListItem_GetIndex(spriteItem)
	local spriteList = GetSpriteParent(spriteItem)
	local start = SpriteList_GetStartItem(spriteList)
	resetLiveVideoItem(spriteList, start, nSelectIndex)
	if ScrollAdjustFlag and ScrollAdjustFlag == 1 then
		local totalcount = SpriteList_GetListItemCount(spriteList)
		if totalcount - nSelectIndex < 5  then
			firstIndex = totalcount - 5 - 1
		else
			firstIndex = nSelectIndex
		end
		WriteLogs("within setfocus")
	end
end

function reviewButtonOnSelect(sprite)
	--[[ 先stop播放器 ]]--
	local reg_vi = registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg_vi, "MediapalyPlugin")
	if MediapalyPlugin ~= 0 then
		pluginInvoke(MediapalyPlugin, "Stop")
		pluginInvoke(MediapalyPlugin, "Show" , 0)
	end
	local reg = registerCreate("product")
	local root = registerGetInteger(reg, "root")
	local spriteListItem = GetSpriteParent(sprite)
	local spriteList = GetSpriteParent(spriteListItem)
	local index = SpriteListItem_GetIndex(spriteList)
	local reg_video = registerCreate("video")  
	registerSetString(reg_video, "IsReview", "true")
	
	require "module.protocol.protocol_videoloading"
	RequestVideo(103, jsonChannel.programList[index].playUrl, jsonChannel.programList[index].urlPath, jsonChannel.programList[index].contentName ,"demand")
	registerSetString(reg,"playurl",jsonChannel.programList[index].playUrl)
	registerSetString(reg,"contentid",jsonChannel.programList[index].contentId)
	local loadarea = FindChildSprite(root ,"loadarea")
	enterLoading(loadarea)
	local reg_r = registerCreate("recommend")   
	registerSetInteger(reg_r, "isDownloadDisable", 1)
end

function liveButtonOnSelect(sprite)
	--[[local reg = registerCreate("product")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root ,"loadarea")
	enterLoading(loadarea)
	RequestPlay_NB(sceneProduct)]]--
	local reg_vi = registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg_vi, "MediapalyPlugin")
	if MediapalyPlugin ~= 0 then
		pluginInvoke(MediapalyPlugin, "Stop")
		pluginInvoke(MediapalyPlugin, "Show" , 0)
	end
	
	local reg = registerCreate("product")
	local root = registerGetInteger(reg, "root")
	
	local spriteListItem = GetSpriteParent(sprite)
	local spriteList = GetSpriteParent(spriteListItem)
	local index = SpriteListItem_GetIndex(spriteList)
	require "module.protocol.protocol_videoloading"
	RequestVideo(114, jsonChannel.programList[index].playUrl, jsonChannel.programList[index].urlPath, jsonChannel.programList[index].contentName ,"live")
	registerSetString(reg,"playurl",jsonChannel.programList[index].playUrl)
	registerSetString(reg,"contentid",jsonChannel.programList[index].contentId)
	local loadarea = FindChildSprite(root ,"loadarea")
	enterLoading(loadarea)
	local reg_r = registerCreate("recommend")   
	registerSetInteger(reg_r, "isDownloadDisable", 1)
end

function subscribeButtonOnSelect(sprite)
	local reg = registerCreate("product")
	local root = registerGetInteger(reg, "root")
	local spriteListItem = GetSpriteParent(sprite)
	local spriteList = GetSpriteParent(spriteListItem)
	local index = SpriteListItem_GetIndex(spriteList)
	
	if jsonChannel.programList[index].remindUrl then
		local dir = OpenDirectory("MODULE:\\..\\temp\\booking.xml")
		if not dir then
			local temp = registerCreate("temp")
			registerSave(temp,"MODULE:\\..\\temp\\booking.xml")
			registerRelease("temp")
		end
		local temp = registerCreate("temp")
		registerLoad(temp, "MODULE:\\..\\temp\\booking.xml")
		local contentId = registerGetString(temp,jsonChannel.programList[index].contentId)
		if contentId == "1" then 
			require("module.dialog.useDialog")
			setDialogParam("提示", "该节目已经预定", "BT_OK", sceneProduct, sceneProduct, GetCurScene())
			Go2Scene(sceneDialog)
			registerRelease("temp")
			return
		else
			registerSetString(reg,"remindurl",jsonChannel.programList[index].remindUrl)
			local icon = FindChildSprite(sprite,"icon-sel")
			registerSetInteger(reg,"remindprogram",icon)
			registerSetInteger(reg,"remindprogramId",jsonChannel.programList[index].contentId)
			require("module.dialog.useDialog")
			local bookconfirm = FindChildSprite(root,"bookconfirm")
			setDialogParam("提示", "是否确认预约该节目?", "BT_OK_CANCEL", sceneProduct, sceneProduct, bookconfirm)
			Go2Scene(sceneDialog)
		end
	else
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取预约信息失败", "BT_OK", sceneProduct, sceneProduct, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function channelDayButtonOnSelect(sprite)
	local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadingNode")
	local spriteListItem = GetSpriteParent(sprite)
	local nIndex = SpriteListItem_GetIndex(spriteListItem)
	WriteLogs(string.format("nIndex [%d]", nIndex))
	if nIndex == 0 and jsonChannel.imgListNavi[0].beforeYesterdayUrl then
		WriteLogs(string.format("2.nIndex [%d]", nIndex))
		RequestChannel(101, jsonChannel.imgListNavi[0].beforeYesterdayUrl)
	end
end

-- get current video
function GetCurLiveVideoIndex()
	GetSysTime()
	local regLive = registerCreate("live")
	local sysTime = registerGetString(regLive, "sysTime")
	local year, month, day, hour, minute, second = ParseDate(sysTime)
	local curTime = hour..":" ..minute
	local curTimeInt = getTimeFoString(curTime)
	
	if jsonChannel and jsonChannel.programList then
		for i=0, #jsonChannel.programList do
			local starTime = jsonChannel.programList[i].startTime
			local endTime  = jsonChannel.programList[i].endTime
			if curTimeInt >= getTimeFoString(starTime) and curTimeInt < getTimeFoString(endTime) then
				return i
			end
		end
	end
	return 0
end
--12:00
function getTimeFoString(stringTime)
	if stringTime then
		local a, b,tt, mm =string.find(stringTime, "(%d+):(%d+)")
		return tt*60 + mm
	end
	return 0
end

--时间格式20100621125251
function ParseDate(time)
	local year = string.sub(time,1,4)
	local month = string.sub(time,5,6)
	local day = string.sub(time,7,8)
	local hour = string.sub(time,9,10)
	local minute = string.sub(time,11,12)
	local second = string.sub(time,13,14)
	return year, month, day, hour, minute, second
end

function GetSysTime()
	require ("module.protocol.protocol_systime")
	local jsonfile = OnSysDataDecode()
	if jsonfile and jsonfile.sysDate then
		local regLive = registerCreate("live")
		registerSetString(regLive, "sysTime", jsonfile.sysDate)
	end
	--获取当前时间
	require ("module.protocol.protocol_systime")
	RequestSysTime(113)
	tickTime = 0	
end

--begin [、Jone]
--用来处理日期切换(前天、昨天、今天、明天)
function changeDayList(sprite, keyCode)

	local spr = registerGetInteger(registerCreate("product"), "root", sprite)

	--WriteLogs("productLive.lua-->listKeyUp_Live-->keyCode:"..keyCode)
	if keyCode==ApKeyCode_Char1 then 
     sprite1=FindChildSprite(spr,"beforeYesterday")
     productLiveChannelDaySelect(sprite1)
	end
	if keyCode==ApKeyCode_Char3 then 
		sprite1=FindChildSprite(spr,"yesterday")
		productLiveChannelDaySelect(sprite1)
	end
	if keyCode==ApKeyCode_Char7 then 
		sprite1=FindChildSprite(spr,"today")
		productLiveChannelDaySelect(sprite1)
	end  
	if keyCode==ApKeyCode_Char9 then 
		sprite1=FindChildSprite(spr,"tomorrow")
		productLiveChannelDaySelect(sprite1)
  end  
end
--end

function listKeyUp_Live(sprite, keyCode)
	local regProductLive = registerCreate("productlive")
	registerSetInteger(regProductLive,"lastFocusSprite",sprite)
	registerSetInteger(regProductLive,"lastFocusFlag",1)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local productReg = registerCreate("product")
	registerSetInteger(productReg,"productDemand",sprite)
	registerSetInteger(productReg, "lastFocusFlag",1)
	local curIndex=SpriteListItem_GetIndex(GetParentSprite(sprite))
	local reg_g = registerCreate("product")
	local liveIndex=registerGetInteger(reg_g, "liveIndex")
	local homeLastFoucsReg= registerCreate("homeLastFoucs")				--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)	--dw
	if keyCode == ApKeyCode_Enter  then
		if curIndex==liveIndex then		--直播
			local sprite1=FindChildSprite(sprite,"live")
			liveButtonOnSelect(sprite1)
		elseif curIndex>liveIndex then  --预约
			local sprite1=FindChildSprite(sprite,"live")
			subscribeButtonOnSelect(sprite1)
		elseif curIndex<liveIndex then  --回放
			local sprite1=FindChildSprite(sprite,"review-button")
			reviewButtonOnSelect(sprite1)
		end
	end
	name= GetSpriteName(sprite)
	if keyCode == ApKeyCode_Left and LoadingFlag() then
		spriteRoot = GetRootSprite(sprite)
		ReSetChannel(sprite,"left")
		spritelist=FindChildSprite(spriteRoot,"product-programgroup-list-live")
		start = SpriteList_GetStartItem(spritelist)
		spriteItem = SpriteList_GetListItem(spritelist, start)
		sprite2=spriteItem
		spriteItem=FindChildSprite(spriteItem,"playbutton")
		if spriteItem==0 then
			spriteItem=FindChildSprite(sprite2, "playbutton1")
		end
		SetSpriteFocus(spriteItem)
		saveTouchFocus(spriteItem)
	elseif keyCode == ApKeyCode_Right and LoadingFlag() then
		spriteRoot = GetRootSprite(sprite)
		ReSetChannel(sprite,"right")
		spritelist=FindChildSprite(spriteRoot,"product-programgroup-list-live")
		start = SpriteList_GetStartItem(spritelist)
		spriteItem = SpriteList_GetListItem(spritelist, start)
		sprite2=spriteItem
		spriteItem=FindChildSprite(spriteItem,"playbutton")
		if spriteItem==0 then
			spriteItem=FindChildSprite(sprite2, "playbutton1")        
		end
		SetSpriteFocus(spriteItem)
		saveTouchFocus(spriteItem)
	elseif keyCode == ApKeyCode_Down then
		sprite1=GetSpriteParent(sprite)
		index=SpriteListItem_GetIndex(sprite1)
		if index<(SpriteList_GetListItemCount(GetSpriteParent(sprite1))-1) then
			sprite1=SpriteList_GetListItem(GetSpriteParent(sprite1),index+1)
			sprite1 = FindChildSprite(sprite1, "list-item-button")
			SetSpriteFocus(sprite1)
			saveTouchFocus(sprite1)
			if index==firstIndex+5 or (ScrollAdjustFlag and ScrollAdjustFlag == 1) then
				local spritelist=FindChildSprite(GetRootSprite(sprite),"product-programgroup-list-live")
				sprite_x,sprite_y,sprite_w,sprite_h=GetSpriteRect(spritelist)
				--[[  这里是鼠标移动过滑块后的第一次按键的处理  ]]--
				if ScrollAdjustFlag and ScrollAdjustFlag == 1 then
					SetSpriteRect(spritelist,sprite_x,-(firstIndex)*24,sprite_w,sprite_h)
					ChangeScrollPositon(sprite,"up")
					ScrollAdjustFlag = 0
				else
					--[[  这里计算了绝对位置（不是行高的偏移）便于鼠标移动过滑块后再按按键的计算  ]]--
					SetSpriteRect(spritelist,sprite_x,-(firstIndex + 1)*24,sprite_w,sprite_h)
					--[[  根据sprite的index 改变滚动条滑块位置  ]]--
					ChangeScrollPositon(sprite,"down")
					firstIndex=firstIndex + 1
				end
			end
		end
	elseif keyCode == ApKeyCode_Up then
		sprite1=GetSpriteParent(sprite)
		index=SpriteListItem_GetIndex(sprite1)
		if index>=1 then
			sprite1=SpriteList_GetListItem(GetSpriteParent(sprite1),index-1)
			sprite1 = FindChildSprite(sprite1, "list-item-button")
			SetSpriteFocus(sprite1)
			saveTouchFocus(sprite1)
			if index==firstIndex or (ScrollAdjustFlag and ScrollAdjustFlag == 1) then
				local spritelist=FindChildSprite(GetRootSprite(sprite),"product-programgroup-list-live")
				sprite_x,sprite_y,sprite_w,sprite_h=GetSpriteRect(spritelist)
				--[[  这里是鼠标移动过滑块后的第一次按键的处理  ]]--
				WriteLogs("after setfocus")
				if ScrollAdjustFlag and ScrollAdjustFlag == 1 then
					SetSpriteRect(spritelist,sprite_x,-(firstIndex)*24,sprite_w,sprite_h)
					ChangeScrollPositon(sprite,"up")
					ScrollAdjustFlag = 0
				else
					--[[  这里计算了绝对位置（不是行高的偏移）便于鼠标移动过滑块后再按按键的计算  ]]--
					SetSpriteRect(spritelist,sprite_x,-(firstIndex - 1)*24,sprite_w,sprite_h)
					--[[  根据sprite的index 改变滚动条滑块位置  ]]--
					ChangeScrollPositon(sprite,"up")
					firstIndex=firstIndex - 1
				end
			end
		end
	end
	--[[ modified by 、Jone 此处用来调用日期切换函数 ]]--
	changeDayList(sprite, keyCode)
	if keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end 

function listKeyUp_yesterday(sprite,keyCode)
	local regProductLive = registerCreate("productlive")
	registerSetInteger(regProductLive,"lastFocusSprite",sprite)
	registerSetInteger(regProductLive,"lastFocusFlag",1)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local productReg = registerCreate("product")
	registerSetInteger(productReg,"productDemand",sprite)
	registerSetInteger(productReg, "lastFocusFlag",1)
	local curIndex=SpriteListItem_GetIndex(GetParentSprite(sprite))
	local spritelist=FindChildSprite(GetRootSprite(sprite),"product-programgroup-list")
	local itemCount=SpriteList_GetListItemCount(spritelist)
	local spriteRoot=GetRootSprite(sprite)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	
	if keyCode == ApKeyCode_Down then
		if curIndex<(itemCount-1) then
			local sprite1=SpriteList_GetListItem(spritelist,curIndex+1)
			local spriteBtn = FindChildSprite(sprite1, "list-item-button")
			SetSpriteFocus(spriteBtn)
			saveTouchFocus(spriteBtn)
			if curIndex==firstIndex+5+1 then
				sprite_x,sprite_y,sprite_w,sprite_h=GetSpriteRect(spritelist) 
				SetSpriteRect(spritelist,sprite_x,sprite_y-24,sprite_w,sprite_h)
				ChangeScrollPositon(sprite,"down")
				firstIndex=firstIndex+1
			end
		end
	elseif keyCode == ApKeyCode_Up then
		if curIndex>0 then
			local sprite1=SpriteList_GetListItem(spritelist,curIndex-1)
			local spriteBtn = FindChildSprite(sprite1, "list-item-button")
			SetSpriteFocus(spriteBtn)
			saveTouchFocus(spriteBtn)
			if curIndex==firstIndex then
				sprite_x,sprite_y,sprite_w,sprite_h=GetSpriteRect(spritelist) 
				SetSpriteRect(spritelist,sprite_x,sprite_y+24,sprite_w,sprite_h)
				ChangeScrollPositon(sprite,"up")
				firstIndex=firstIndex-1
			end
		end
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_Right and LoadingFlag() then
		ReSetChannel(sprite,"right")
	elseif keyCode == ApKeyCode_Left and LoadingFlag() then
		ReSetChannel(sprite,"left")
	elseif keyCode == ApKeyCode_Enter then
		local sprite1=FindChildSprite(sprite,"review-button")
		reviewButtonOnSelect(sprite1)
	end
	changeDayList(sprite, keyCode)
end

function listKeyUp_tomorrow(sprite,keyCode)
	local regProductLive = registerCreate("productlive")
	registerSetInteger(regProductLive,"lastFocusSprite",sprite)
	registerSetInteger(regProductLive,"lastFocusFlag",1)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local productReg = registerCreate("product")
	registerSetInteger(productReg,"productDemand",sprite)
	registerSetInteger(productReg, "lastFocusFlag",1)
	local curIndex=SpriteListItem_GetIndex(GetParentSprite(sprite))
	local spritelist=FindChildSprite(GetRootSprite(sprite),"product-programgroup-list")
	local itemCount=SpriteList_GetListItemCount(spritelist)
	local spriteRoot=GetRootSprite(sprite)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	
	if keyCode == ApKeyCode_Down then
		if curIndex<(itemCount-1) then
			local sprite1=SpriteList_GetListItem(spritelist,curIndex+1)
			local spriteBtn = FindChildSprite(sprite1, "list-item-button")
			SetSpriteFocus(spriteBtn)
			saveTouchFocus(spriteBtn)
			if curIndex==firstIndex+5+1 then
				sprite_x,sprite_y,sprite_w,sprite_h=GetSpriteRect(spritelist) 
				SetSpriteRect(spritelist,sprite_x,sprite_y-24,sprite_w,sprite_h)
				ChangeScrollPositon(sprite,"down")
				firstIndex=firstIndex+1
			end
		end
	elseif keyCode == ApKeyCode_Up then
		if curIndex>0 then
			local sprite1=SpriteList_GetListItem(spritelist,curIndex-1)
			local spriteBtn = FindChildSprite(sprite1, "list-item-button")
			SetSpriteFocus(spriteBtn)
			saveTouchFocus(spriteBtn)
			if curIndex==firstIndex then
				sprite_x,sprite_y,sprite_w,sprite_h=GetSpriteRect(spritelist) 
				SetSpriteRect(spritelist,sprite_x,sprite_y+24,sprite_w,sprite_h)
				ChangeScrollPositon(sprite,"up")
				firstIndex=firstIndex-1
			end
		end
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_Right and LoadingFlag() then
		ReSetChannel(sprite,"right")
	elseif keyCode == ApKeyCode_Left and LoadingFlag() then
		ReSetChannel(sprite,"left")
	elseif keyCode == ApKeyCode_Enter then
		local sprite1=FindChildSprite(sprite,"live")
		subscribeButtonOnSelect(sprite1)
	end
	changeDayList(sprite, keyCode)
end

function defaultBtnKeyUp(sprite,keyCode)
	WriteLogs("-----------------------defaultBtnKeyUp   begin----------------------")
	local regProductLive = registerCreate("productlive")
	registerSetInteger(regProductLive,"lastFocusSprite",sprite)
	registerSetInteger(regProductLive,"lastFocusFlag",1)
	-------------------------------------------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	local spriteRoot=GetRootSprite(sprite)
	changeDayList(sprite, keyCode)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode == ApKeyCode_Right and LoadingFlag() then
		ReSetChannel(sprite,"right")
	elseif keyCode == ApKeyCode_Left and LoadingFlag() then
		ReSetChannel(sprite,"left")
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	WriteLogs("-----------------------defaultBtnKeyUp   end----------------------")
end

--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(sprite)
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	require "module.common.commonScroll"
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,5,0)
	else
		ScrollBarAdjust(CurIndex + 1,5,1)
	end
end

--按左右切换频道的新方法，解决频道小于5项时无法切换频道问题，因为之前调用的是频道翻页按钮的onslect方法，频道小于5项该方法将无法使用。
function ReSetChannel(sprite,direct)
	local spriteChannelList=FindChildSprite(GetRootSprite(sprite),"product-channel-list")  --product-channel-list节点
	local channelCount=SpriteList_GetListItemCount(spriteChannelList)
	local channelFocusNum
	for i=0,channelCount-1 do
		local testChannelSprite=SpriteList_GetListItem(spriteChannelList,i)
		local x,y,width,height=GetSpriteRect(testChannelSprite)
		if width==product_nSelSizeX then
			channelFocusNum=i
			break
		end
	end
	local preIndex
	local nextIndex
	if channelFocusNum==0 then
		preIndex=1
		nextIndex=2
	elseif channelFocusNum==1 then
		preIndex=3
		nextIndex=0
	elseif channelFocusNum==2 then
		preIndex=0
		nextIndex=4
	elseif channelFocusNum==3 then
		preIndex=4
		nextIndex=1
	elseif channelFocusNum==4 then        
		preIndex=2
		nextIndex=3
	end
	
	if direct=="left" then
		local preChannelButtonSprite=FindChildSprite(spriteChannelList,"channel-button-"..preIndex) 
		if preChannelButtonSprite~=0 and dnr == nil then
			dnr = 1
			SetTimer(1,2500,"changeDnr")
			channelListiItemOnSelect(preChannelButtonSprite)
		end
	else
		local nextChannelButtonSprite=FindChildSprite(spriteChannelList,"channel-button-"..nextIndex) 
		if nextChannelButtonSprite~=0 and dnr == nil then
			dnr = 1
			SetTimer(1,2500,"changeDnr")
			channelListiItemOnSelect(nextChannelButtonSprite)
		end
	end
end

function changeDnr()
	dnr = nil
end
