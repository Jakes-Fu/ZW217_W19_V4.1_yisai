--@author xf_pan

--require "module.loading.useloading"
require "module.protocol.protocol_search_result"
require "module.common.registerscene"
require "module.common.sceneutils"
require "module.protocol.protocol_infovolume"
require "module.common.ascertaintargetscene"
require "module.videoexpress-common"
require "module.keyCode.keyCode"
searchResult_VideoItemRect = {5,2,205,14}
local pageNum
local curPageIndex=1
local selectButton=nil
local buttonType=nil --play表示播放按钮 desc表示详情按钮
--Search Result Indicate , SRI 
SRI = {
				SCENE =	{
									ID = "ID_OF_SEARCH_RESULT",
								},
				ROOT =	{
									KEY = "ROOT_SCENE",
								},
				SORTTYPE = {
									TIME_TAGS = {
																NORMAL = "TIME_NORMAL_TAG",
																FOCUS  = "TIME_FOCUS_TAG",
															},
									HOT_TAGS =	{
																NORMAL = "HOT_NORMAL_TAG",
																FOCUS  = "HOT_FOCUS_TAG",
															},
									},
				R_RECOMMEND = {   --相关推荐的各个句柄
									COUNT = 2,  --页面上，现在只做了2个相关推荐关键字
											},
			}

PAGE_LINE_COUNT = 5
globalCurrentPage = 0
globalPreviousSelItem = nil

focusIndex =0 --第一个选中结果
--@function bodyBuildChildrenFinished
--@tag-name body
--@tag-action BuildChildrenFinished 
--@brief 初始化场景数据
function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate( SRI.SCENE.ID )
	registerSetInteger(reg, SRI.ROOT.KEY, sprite)
	emptyBt=FindChildSprite(sprite,"emptybutton")
	createSortTypeTags( reg , sprite)
	createRelateRecommendTags( reg , sprite )
	require "module.protocol.protocol_systime"
	RequestSysTime(502)
	isAdvanced=0
	return 1
end

function createSortTypeTags( reg , sprite )
	local search_result = FindChildSprite( sprite , "search-result")
	registerSetInteger( reg, SRI.SORTTYPE.TIME_TAGS.NORMAL, FindChildSprite( search_result, "time-sort-icon-normal") )
	registerSetInteger( reg, SRI.SORTTYPE.TIME_TAGS.FOCUS, FindChildSprite( search_result, "time-sort-icon-focus") )
	registerSetInteger( reg, SRI.SORTTYPE.HOT_TAGS.NORMAL, FindChildSprite( search_result, "hot-sort-icon-normal") )
	registerSetInteger( reg, SRI.SORTTYPE.HOT_TAGS.FOCUS, FindChildSprite( search_result, "hot-sort-icon-focus") )
	
	--默认的排序方式
	require "module.searchinfo"
	local sorttype = GetSearchReqSortType()
	if(sorttype == nil or sorttype =="") then sorttype="time" end
	sortTypeChange( sorttype , reg)
end

function createRelateRecommendTags( reg , sprite )
	setRelateRecommend( )
 end

--相关推荐的按钮被激活
function recmdBtnClick(sprite)
	local sprite_name = GetSpriteName(sprite)
	WriteLogs("recmdBtnClick name="..sprite_name)

	local idx_s = string.sub(sprite_name,7,7)
	setLoading()
	local tag = FindChildSprite(sprite, "recmd_text_normal_"..idx_s)
	local searchText = GetSpriteText( tag )
	WriteLogs(" recmdBtnClick text="..searchText)
	RequestSearchResult(105, 1, GetSearchUrl(), searchText)
end

function bodyOnSpriteEvent(message, params)
	require("module.common.commonmsg")
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_ACTIVATE then
		WriteLogs("MSG_ACTIVATE")
		local reg = registerCreate( SRI.SCENE.ID )
		local sprite = registerGetInteger(reg, SRI.ROOT.KEY)
		createSortTypeTags( reg , sprite)
		buildSearchSceneData()
	elseif message == MSG_DEACTIVATE then
		WriteLogs("MSG_DEACTIVATE")
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
end

-- 设置场景数据
function buildSearchSceneData()
	local reg = registerCreate( SRI.SCENE.ID )
	local rootSprite = registerGetInteger(reg, SRI.ROOT.KEY)
	setSearchRequestValue( rootSprite )
	createSearchResultData()
	setRelateRecommend()
	setRecommend()
	setSearchResult()
end

--@function createSearchResultData
--@brief 协议解析
function createSearchResultData()
	json = OnSearchResultDecode()
	resultDataArray = {}
	if json==nil or json.searchResults==nil or json.searchResults.searchResult == nil then
		SetSpriteFocus(emptyBt)
		saveTouchFocus(emptyBt)
		searchResult_empty = 1
		return 0
	end
	if json and json.searchResults and json.searchResults.searchResult ~= nil then
		searchResult_empty = 0
		for i=0, table.maxn(json.searchResults.searchResult) do
			if json.searchResults.searchResult[i].content ~= nil then
				resultDataArray[i] = {
					channelName	=	json.searchResults.searchResult[i].content.channelName,
					formType		=	json.searchResults.searchResult[i].content.formType,
					channelId		=	json.searchResults.searchResult[i].content.channelId,
					packageId		=	json.searchResults.searchResult[i].content.packageId,
					urlPath			=	json.searchResults.searchResult[i].content.urlPath,
					contentName	=	json.searchResults.searchResult[i].content.contentName,
					type				=	json.searchResults.searchResult[i].content.type,
					endTime			=	json.searchResults.searchResult[i].content.endTime,
					contentId		=	json.searchResults.searchResult[i].content.contentId,
					playUrl			=	json.searchResults.searchResult[i].content.playUrl,
					startTime		=	json.searchResults.searchResult[i].content.startTime,
					starLevel		=	json.searchResults.searchResult[i].content.starLevel,
					category		=	json.searchResults.searchResult[i].content.category,
					displayType	=	json.searchResults.searchResult[i].content.displayType,
					resultType	=	json.searchResults.searchResult[i].content.resultType,
					remindUrl		= json.searchResults.searchResult[i].content.remindUrl
					}
			elseif json.searchResults.searchResult[i].channel ~= nil then
				resultDataArray[i] = {
					channelType	=	json.searchResults.searchResult[i].channel.channelType,
					urlPath			=	json.searchResults.searchResult[i].channel.urlPath,
					channelName	=	json.searchResults.searchResult[i].channel.channelName,
					contentName	=	json.searchResults.searchResult[i].channel.contentName,
					resultType	=	json.searchResults.searchResult[i].channel.resultType,
					startTime		=	json.searchResults.searchResult[i].channel.startTime
					}
			end
		end
	end
	
	recommendDataArray = {}
	if json and json.recommend ~= nil then
		for i=0, table.maxn(json.recommend) do
			recommendDataArray[i] = {
					category	=	json.recommend[i].category,
					formType	=	json.recommend[i].formType,
					displayType	=	json.recommend[i].displayType,
					contentName	=	json.recommend[i].contentName,
					urlPath		=	json.recommend[i].urlPath,
					type		=	json.recommend[i].type,
					contentId	=	json.recommend[i].contentId,
					}
		end
	else
		recommendDataArray = nil
	end
	
	if json then
		sortByTimeUrl = json.sortByTimeUrl
	end
end

--@function setSearchRequestValue
--@tag-name setSearchRequestValue
--@tag-action null
--@brief 在搜索结果页面中，允许再次搜索，在搜索框中，需要存放最近
function setSearchRequestValue(rootSprite)
	local editSprite= FindChildSprite( rootSprite ,  "searchEditBox")
	require "module.searchinfo"
	local sv = GetSearchReqVal()
	WriteLogs("last request value:"..sv)
	SetSpriteProperty( editSprite, "text", sv )
end

--@function setRelateRecommend
--@tag-name related-recommend
--@tag-action null
--@brief 设置相关推荐关键字
function setRelateRecommend()
	local reg = registerCreate( SRI.SCENE.ID )
	local sprite = registerGetInteger(reg, SRI.ROOT.KEY )
	local relate_recommend = FindChildSprite( sprite, "relate-recommend")
	require "module.searchinfo"
	local reqV = GetSearchReqVal()
	local recmd_text_normal_1 = FindChildSprite( relate_recommend , "recmd_text_normal_1")
	local recmd_text_normal_2 = FindChildSprite( relate_recommend , "recmd_text_normal_2")
	local recmd_text_focus_1 = FindChildSprite( relate_recommend , "recmd_text_focus_1")
	local recmd_text_focus_2 = FindChildSprite( relate_recommend , "recmd_text_focus_2")
	
	local sx1 = ""
	if ( string.find( reqV, "下载" ) ~= nil or string.find( reqV, "详情" ) ) ~= nil then
		sx1 = reqV
	else
		sx1 = reqV.."下载"
	end
	SetSpriteProperty( recmd_text_normal_1 , "text", sx1)
	SetSpriteProperty( recmd_text_focus_1 , "text", sx1)
	
	local sx2 = ""
	if ( string.find( reqV, "下载" ) ~= nil or string.find( reqV, "详情" ) ) ~= nil then
		sx2 = reqV
	else
		sx2 = reqV.."详情"
	end
	--避免出现两个一样的推荐
	if sx1 == sx2 then
		sx2 = ""
	end
	SetSpriteProperty( recmd_text_normal_2 , "text", sx2)
	SetSpriteProperty( recmd_text_focus_2 , "text", sx2)
end
--@function setRecommend
--@tag-name recommend-one
--@tag-action null 
--@brief 设置相关推荐
function setRecommend()
	local reg = registerCreate( SRI.SCENE.ID )
	local sprite = registerGetInteger(reg, SRI.ROOT.KEY )
	local spriteRecommendOne = FindChildSprite(sprite, "recommend-one")
	local spriteRecommendTwo = FindChildSprite(sprite, "recommend-two")
	local spriteRecommendBtnOne = FindChildSprite(sprite, "recommend-one-button")
	local spriteRecommendBtnTwo = FindChildSprite(sprite, "recommend-two-button")
	
	if recommendDataArray ~= nil then
		if table.maxn(recommendDataArray) >= 0 then
			if recommendDataArray[0].contentName ~= nil then
				SetSpriteProperty(spriteRecommendOne, "text", recommendDataArray[0].contentName)
			end
			if recommendDataArray[0].channelName ~= nil then
				SetSpriteProperty(spriteRecommendOne, "text", recommendDataArray[0].channelName)
			end
			SetSpriteEnable(spriteRecommendBtnOne, 1)
			--added by licj For KeyBoardVersion
			SetSpriteProperty(spriteRecommendBtnOne,"OnKeyUp","RecommendListKeyUp")
		end
		
		if table.maxn(recommendDataArray) >= 1 then
			if recommendDataArray[1].contentName ~= nil then
				SetSpriteProperty(spriteRecommendTwo, "text", recommendDataArray[1].contentName)
			end
			if recommendDataArray[1].channelName ~= nil then
				SetSpriteProperty(spriteRecommendTwo, "text", recommendDataArray[1].channelName)
			end
			SetSpriteEnable(spriteRecommendBtnTwo, 1)
			--added by licj For KeyBoardVersion
			SetSpriteProperty(spriteRecommendBtnTwo,"OnKeyUp","RecommendListKeyUp")
		end
	else
		SetSpriteEnable(spriteRecommendBtnOne, 0)
		SetSpriteEnable(spriteRecommendBtnTwo, 0)
	end
end

--@function showDetailButtonOnSelect
--@tag-name video-bottom
--@tag-action button:OnSelect 
--@brief 控制详情显示区域的大小
function setSearchResult()
	local reg = registerCreate( SRI.SCENE.ID )
	local sprite = registerGetInteger(reg, SRI.ROOT.KEY )
	local searchResultList = FindChildSprite(sprite, "search-result-list")
	--[[ 清掉list 数据 ]]--
	SpriteList_SetStartItem(searchResultList, 0)
	SpriteList_ClearListItem(searchResultList, 1, 1)
	globalPreviousSelItem = nil
	local x,y,w,h 	= 5,2,205,14
	local nMax = nil
	if searchResult_empty and searchResult_empty == 1 then
		nMax = -1
	else
		nMax	= table.maxn(resultDataArray)
	end
	if nMax > -1 then 
		SpriteList_LoadListItem(searchResultList, "WONDER:\\module\\search-result-item.xml", nMax + 1 )
		local noContent = FindChildSprite(sprite,"noContent")
		SetSpriteVisible(noContent,0)
		for i=0, nMax do
			local resultVideoSprite	 = SpriteList_GetListItem(searchResultList, i)
			if resultVideoSprite and resultVideoSprite ~= 0 then
				SetSpriteRect(resultVideoSprite, searchResult_VideoItemRect[1], searchResult_VideoItemRect[2],searchResult_VideoItemRect[3], searchResult_VideoItemRect[4])
				local videoLabel = FindChildSprite(resultVideoSprite, "video-title")
--[[----------------------------修改人：yaoxiangyin 修改时间：2010.8.24-----------------------------------------]]--
				local videoItem=FindChildSprite(resultVideoSprite,"video-item-button")
				SetSpriteProperty(videoItem, "name","item-button-"..i)
-------------------------------------------------------------------------------------------------------------------
				local videoScrollLabel = FindChildSprite(resultVideoSprite, "video-title-scroll")
				local normalNode = FindChildSprite(resultVideoSprite, "node-normal")
				local selectedNode = FindChildSprite(resultVideoSprite, "node-selected")
				local buttonPlay = FindChildSprite(selectedNode, "play")
				local buttonDesc = FindChildSprite(selectedNode, "desc")
				SetSpriteProperty(buttonPlay, "name", "play_"..i)
				SetSpriteProperty(buttonDesc, "name", "desc_"..i)
--[[----------------------------修改人：yaoxiangyin 修改时间：2010.8.24-----------------------------------------]]--
				SetSpriteVisible(buttonPlay,0)
				SetSpriteVisible(buttonDesc,0)
-----------------------------------------------------------------------------------------------------------				
				if videoLabel ~= nil and resultDataArray and resultDataArray[i] then
					if resultDataArray[i].contentName and resultDataArray[i].contentName ~= "" then
						SetSpriteProperty(videoLabel, "text", resultDataArray[i].contentName)
						SetSpriteProperty(videoScrollLabel, "text", resultDataArray[i].contentName)
					elseif resultDataArray[i].channelName ~= nil then
						SetSpriteProperty(videoLabel, "text", resultDataArray[i].channelName)
						SetSpriteProperty(videoScrollLabel, "text", resultDataArray[i].channelName)
					end
				end
				if resultDataArray and resultDataArray[i] and resultDataArray[i].resultType and (resultDataArray[i].resultType == "03" or resultDataArray[i].resultType == "01") then
					SetSpriteEnable(buttonPlay, 0)
					SetSpriteVisible(buttonPlay, 0)
					local Date = resultDataArray[i].startTime
					if Date and Date ~= "" then
						local strDate = string.format("  %s:%s %s-%s",string.sub(Date,9,10),string.sub(Date,11,12),string.sub(Date,5,6),string.sub(Date,7,8))
						SetSpriteProperty(videoLabel, "text", resultDataArray[i].contentName..strDate)
						SetSpriteProperty(videoScrollLabel, "text", resultDataArray[i].contentName..strDate)
					end
				elseif resultDataArray and resultDataArray[i] and resultDataArray[i].resultType and resultDataArray[i].resultType == "02" then
					SetSpriteEnable(buttonPlay, 0)
					SetSpriteVisible(buttonPlay, 0)
					SetSpriteVisible(buttonDesc, 0)
				end
				SetSpriteVisible(normalNode, 1)
				SetSpriteEnable(normalNode, 1)
				SetSpriteVisible(selectedNode, 0)
				SetSpriteEnable(selectedNode, 0)
			end
		end
	else
		local noContent = FindChildSprite(sprite,"noContent")
		SetSpriteVisible(noContent,1)
	end
	SpriteList_Adjust(searchResultList)
	resetPageMessage()
end

function is2remind(curDate,programeDate)
	local year_c = string.format("%d",(string.sub(curDate,1,4)))
	local year_p = string.format("%d",(string.sub(programeDate,1,4)))
	if year_p ~= year_c then
		if year_p > year_c then
			return 1
		else
			return 0
		end
	end
	local month_c = string.format("%d",(string.sub(curDate,5,6)))
	local month_p = string.format("%d",(string.sub(programeDate,5,6)))
	if month_p ~= month_c then
		if month_p > month_c then
			return 1
		else
			return 0
		end
	end
	local day_c = string.format("%d",(string.sub(curDate,7,8)))
	local day_p = string.format("%d",(string.sub(programeDate,7,8)))
	if day_p ~= day_c then
		if day_p > day_c then
			return 1
		else
			return 0
		end
	end
	local time_c = string.format("%d",(string.sub(curDate,9,10)))*60 + string.format("%d",(string.sub(curDate,11,12)))
	local time_p = string.format("%d",(string.sub(programeDate,9,10)))*60 + string.format("%d",(string.sub(programeDate,11,12)))
	if time_p ~= time_c then
		if time_p > time_c then
			return 1
		else
			return 0
		end
	end
	return 0
end

function resetPageMessage()
	local reg		= registerCreate( SRI.SCENE.ID )
	local rootSprite= registerGetInteger(reg, SRI.ROOT.KEY )
	local searchResultList 	= FindChildSprite(rootSprite, "search-result-list")
	local currentStartPos 	= SpriteList_GetStartItem(searchResultList)
	local pageItemPerPage 	= SpriteList_GetItemPerPage(searchResultList)
	local maxListItem				= table.maxn(resultDataArray) + 1
	local pageCount					= math.floor(maxListItem / pageItemPerPage)
	local __remains__ = maxListItem % pageItemPerPage
	if ( __remains__ ) > 0 then
		pageCount = pageCount + 1
	end
	if pageCount == 0 then
		pageCount = 1 
	end
	local lablePageInfo		= FindChildSprite(rootSprite, "page-info")
	local buttonPageUp		= FindChildSprite(rootSprite, "page-up-button")
	local imgPageUp				= FindChildSprite(buttonPageUp, "page-up-icon")
	local imgPageUpEnable	= FindChildSprite(buttonPageUp, "page-up-icon-enable")
	local buttonPageDown	= FindChildSprite(rootSprite, "page-down-button")
	local imgPageDown			= FindChildSprite(buttonPageDown, "page-down-icon")
	local imgPageDownEnable	= FindChildSprite(buttonPageDown, "page-down-icon-enable")
	
	-- 当前页加每页最大数小于总记录
	if currentStartPos + pageItemPerPage < maxListItem then
		setSpriteAllFlag(imgPageUpEnable, 1)
		SetSpriteActive(buttonPageUp, 1)
		SetSpriteEnable(buttonPageUp, 1)
	else
		setSpriteAllFlag(imgPageUpEnable, 0)
		SetSpriteActive(buttonPageUp, 0)
		SetSpriteEnable(buttonPageUp, 0)
	end
	-- 当前开始外置非0
	if currentStartPos > 0 then
		setSpriteAllFlag(imgPageDownEnable, 1)
		SetSpriteActive(buttonPageDown, 1)
		SetSpriteEnable(buttonPageDown, 1)
	else
		setSpriteAllFlag(imgPageDownEnable, 0)
		SetSpriteActive(buttonPageDown, 0)
		SetSpriteEnable(buttonPageDown, 0)
	end
	
	-- page info
	local curPage	= math.floor(currentStartPos / pageItemPerPage)
	if ( currentStartPos % pageItemPerPage ) > 0 then
		curPage = curPage + 1
	end
	
	if 	searchResult_empty and searchResult_empty == 1 then
		local info		= string.format("第0页/共0页")
		SetSpriteProperty(lablePageInfo, "text", info)
	else
		local info		= string.format("第%d页/共%d页", curPage +1 , pageCount )
		SetSpriteProperty(lablePageInfo, "text", info)
	end
	SetDefaultFocus()
end

-- set all property
function setSpriteAllFlag(sprite, value)
	SetSpriteVisible(sprite, value)
	SetSpriteActive(sprite, value)
	SetSpriteEnable(sprite, value)
end

function pageUpOnSelect(sprite)
	local reg = registerCreate( SRI.SCENE.ID )
	local rootSprite = registerGetInteger(reg, SRI.ROOT.KEY )
	local searchResultList 	= FindChildSprite(rootSprite, "search-result-list")
	local currentStartPos	= SpriteList_GetStartItem(searchResultList)
	local pageItemPerPage	= SpriteList_GetItemPerPage(searchResultList)
	local curPos = currentStartPos + pageItemPerPage
	SpriteList_SetStartItem(searchResultList, curPos)
	resetPageMessage()
end

function pageDownOnSelect(sprite)
	local reg = registerCreate( SRI.SCENE.ID )
	local rootSprite = registerGetInteger(reg, SRI.ROOT.KEY )
	local searchResultList 	= FindChildSprite(rootSprite, "search-result-list")
	local currentStartPos	= SpriteList_GetStartItem(searchResultList)
	local pageItemPerPage	= SpriteList_GetItemPerPage(searchResultList)
	local curPos = currentStartPos - pageItemPerPage
	SpriteList_SetStartItem(searchResultList, curPos)
	resetPageMessage()
end

-- 搜索按钮事件
function searchButtonOnSelect(sprite)
	ReleaseSpriteCapture(sprite)
	curPageIndex=1
	setLoading()
	local root = GetRootSprite(sprite)
	local editSprite= FindChildSprite(root, "searchEditBox")
	local searchText = GetSpriteText(editSprite)
	if isAdvanced == 1 then
		RequestSearchResult(103,1,GetSearchUrl(),searchText,nil,1)
		local reg_a = registerCreate("advancedsearch")
		registerSetInteger(reg_a, "useAdvancedOption",1)
	else
		RequestSearchResult(103,1,GetSearchUrl(),searchText)
		--[[  决定是否使用用高级条件，在时间热度排序中用到  ]]--
		local reg_a = registerCreate("advancedsearch")
		registerSetInteger(reg_a, "useAdvancedOption",0)
	end
	require "module.searchinfo"
	SaveSearchReqVal(searchText)
end

--排序方式调整
function sortTypeChange( stype , key )
	WriteLogs(" sortTypeChange type="..stype)
	if key == nil then
		key = registerCreate( SRI.SCENE.ID )
	end
	local t_n = registerGetInteger( key, SRI.SORTTYPE.TIME_TAGS.NORMAL )
	local t_f = registerGetInteger( key, SRI.SORTTYPE.TIME_TAGS.FOCUS )
	local h_n = registerGetInteger( key, SRI.SORTTYPE.HOT_TAGS.NORMAL )
	local h_f = registerGetInteger( key, SRI.SORTTYPE.HOT_TAGS.FOCUS )
	if ( stype == "time") then
		SetSpriteVisible( t_n , 0 )
		SetSpriteVisible( t_f , 1 )
		SetSpriteVisible( h_n , 1 )
		SetSpriteVisible( h_f , 0 )
	elseif (stype == "hot" ) then
		SetSpriteVisible( t_n , 1 )
		SetSpriteVisible( t_f , 0 )
		SetSpriteVisible( h_n , 0 )
		SetSpriteVisible( h_f , 1 )
	else
		SetSpriteVisible( t_n , 0 )
		SetSpriteVisible( t_f , 1 )
		SetSpriteVisible( h_n , 1 )
		SetSpriteVisible( h_f , 0 )
	end
	require "module.searchinfo"
	SaveSearchReqSortType( stype )
end

-- 按时间排序
function timeSortOnSelect(sprite)
	curPageIndex=1
	WriteLogs("search_result timeSortOnSelect invoked!")
	setLoading()
	local root = GetRootSprite(sprite)
	local editSprite = FindChildSprite(root, "searchEditBox")
	local searchText = GetSpriteText(editSprite)
	local reg_a = registerCreate("advancedsearch")
	local filter = registerGetInteger(reg_a, "useAdvancedOption")
	if filter == 1 then
		RequestSearchResult(104,1,GetSearchUrl(),searchText,"t",1)
	else
		RequestSearchResult(104,1,GetSearchUrl(),searchText,"t")
	end
end

-- 按热度排序
function hotSortOnSelect(sprite)
	curPageIndex=1
	setLoading()
	local root = GetRootSprite(sprite)
	local editSprite= FindChildSprite(root, "searchEditBox")
	local searchText = GetSpriteText(editSprite)
	local reg_a = registerCreate("advancedsearch")
	local filter = registerGetInteger(reg_a, "useAdvancedOption")
	if filter == 1 then
		RequestSearchResult(106,1,GetSearchUrl(),searchText,"h",1)
	else
		RequestSearchResult(106,1,GetSearchUrl(),searchText,"h")
	end
end

-- 处理结果单选中事件
function videoItemOnSelect(sprite)
	WriteLogs("do videoItemOnSelect begin")
	WriteLogs("the name of sprite=="..GetSpriteName(sprite))
	if GetSpriteName(sprite)=="video-item-button-sel" then
		local selectItem 	= GetSpriteParent(GetSpriteParent(sprite))
		local curIndex = SpriteListItem_GetIndex(selectItem)
		local playNode= FindChildSprite(selectItem,"play_"..curIndex)
		local descNode=	FindChildSprite(selectItem,"desc_"..curIndex)
		SetSpriteVisible(playNode, 1)
		SetSpriteEnable(playNode, 1)
		SetSpriteVisible(descNode, 1)
		SetSpriteEnable(descNode, 1)
		SetSpriteFocus(playNode)
		saveTouchFocus(playNode)
		return 
	end
	if globalPreviousSelItem ~= nil then
		local normalNode = FindChildSprite(globalPreviousSelItem, "node-normal")
		local selectedNode = FindChildSprite(globalPreviousSelItem, "node-selected")
		SetSpriteVisible(normalNode, 1)
		SetSpriteEnable(normalNode, 1)
		SetSpriteVisible(selectedNode, 0)
		SetSpriteEnable(selectedNode, 0)
	end
	-- 焦点设置
	do 
		local selectItem 	= GetSpriteParent(GetSpriteParent(sprite))
		local curIndex = SpriteListItem_GetIndex(selectItem)
		local normalNode	= FindChildSprite(selectItem, "node-normal")
		local selectedNode	= FindChildSprite(selectItem, "node-selected")
		local playNode= FindChildSprite(selectItem,"play_"..curIndex)
		local descNode=	FindChildSprite(selectItem,"desc_"..curIndex)	
		SetSpriteVisible(normalNode, 0)
		SetSpriteEnable(normalNode, 0)
		SetSpriteVisible(selectedNode, 1)
		SetSpriteEnable(selectedNode, 1)
		SetSpriteVisible(playNode, 1)
		SetSpriteEnable(playNode, 1)
		SetSpriteVisible(descNode, 1)
		SetSpriteEnable(descNode, 1)
		globalPreviousSelItem = selectItem
	end
	
	--Added by licj 在原触摸版基础上加键盘功能
	--用于处理多选问题
	--2010.8.13
	--WriteLogs("ssssssssssss"..focusIndex)
	do
		local reg = registerCreate( SRI.SCENE.ID )
		local root = registerGetInteger(reg, SRI.ROOT.KEY )
		local searchResultList 	= FindChildSprite(root, "search-result-list")
		local lastVideo=SpriteList_GetListItem(searchResultList,focusIndex)	
		killFocusSprite(lastVideo)
		
		focusIndex=SpriteList_GetCurItem(searchResultList) --新的选项
		
		local CurVideo = SpriteList_GetListItem(searchResultList,focusIndex)
		focusSprite(CurVideo)
	end
end

function videoItemPlayOnSelect(sprite)
	ReleaseSpriteCapture(sprite)
	local name = GetSpriteName(sprite)
	WriteLogs("videoItemPlayOnSelect name="..name)
	local is = string.sub(name,6,string.len(name))
	local nIndex  =0 
	if nil ~= is and "" ~= is then
		nIndex = tonumber(is)
	end
	setLoading()
	require "module.protocol.protocol_videoloading"
	if resultDataArray[nIndex].resultType == "04" and resultDataArray[nIndex].category == "5" then
		RequestVideo(101,resultDataArray[nIndex].playUrl,resultDataArray[nIndex].urlPath, resultDataArray[nIndex].contentName, "group")
	else
		RequestVideo(101,resultDataArray[nIndex].playUrl,resultDataArray[nIndex].urlPath, resultDataArray[nIndex].contentName, "demand")
	end
	if resultDataArray[nIndex].contentName ~= nil and resultDataArray[nIndex].contentName ~= "" then
		if resultDataArray[nIndex].category and resultDataArray[nIndex].category == "5" then
		else
			--[[ 不需要响应这个请求，只是为了得到互动界面中的下载地址 ]]--
			RequestVolume(999, resultDataArray[nIndex].urlPath)
		end
	end
end

function videoItemDescOnSelect(sprite)
	ReleaseSpriteCapture(sprite)
	local name = GetSpriteName(sprite)
	local is = string.sub(name,6,string.len(name))
	local nIndex  =0
	if nil ~= is and "" ~= is then
		nIndex = tonumber(is)
	end
	setLoading()
	if resultDataArray[nIndex].resultType ~= "03" and resultDataArray[nIndex].resultType ~= "01" then
		if resultDataArray[nIndex].contentName ~= nil and resultDataArray[nIndex].contentName ~= "" then
			if resultDataArray[nIndex].category and resultDataArray[nIndex].category == "5" then
				require "module.protocol.protocol_infolabel"
				Requestlabel(107, resultDataArray[nIndex].urlPath)
			else
				RequestVolume(102, resultDataArray[nIndex].urlPath)
			end
		end
	else
		require("module.protocol.protocol_channel")
		if resultDataArray[nIndex].urlPath and resultDataArray[nIndex].urlPath ~= "" then
			RequestChannel(108, resultDataArray[nIndex].urlPath)
		end
	end
end

function recommendOneOnButtonClick(sprite)
	if recommendDataArray[0] ~= nil then
		local requestUrl = recommendDataArray[0].urlPath
		RequestVolume(102, requestUrl)
		setLoading()
	end
end

function recommendTwoOnButtonClick(sprite)
	if recommendDataArray[1] ~= nil then 
		local requestUrl = recommendDataArray[1].urlPath
		RequestVolume(102, requestUrl)
		setLoading()
	end
end

function OnPluginEvent(message, Param)
	if message == 101 then
		exitLoading()
		RequestPlay(sceneSearchResult)
	elseif message == 102 then
		exitLoading()
		local json = OnVolumeDecode()
		if json ~= nil and json ~= "" then
			FreeScene(GetCurScene())
			SetReturn(sceneSearchResult, scenePrograminfo_volume)
			GoAndFreeScene(scenePrograminfo_volume)
		end
	elseif message == 103 then  --[[ 搜索 ]]--
		exitLoading()
		local closeadvanced = FindChildSprite(GetCurScene(),"closeadvanced")
		if isAdvanced == 1 then
			CloseAdsearchOnSelect(closeadvanced)
		end
		local json = OnSearchResultDecode()
		if json ~= nil and json ~= "" then
			buildSearchSceneData()
			sortTypeChange( "" , reg)
		end	
	elseif message == 104 then  --[[ 时间排序 ]]--
		exitLoading()
		local json = OnSearchResultDecode()
		if json ~= nil and json ~= "" then
			buildSearchSceneData()
			sortTypeChange( "time" , reg)
		end	
	elseif message == 105 then  --[[ 推荐 ]]--
		exitLoading()
		local json = OnSearchResultDecode()
		if json ~= nil and json ~= "" then
			buildSearchSceneData()
			sortTypeChange( "" , reg)
		end
	elseif message == 106 then  --[[ 热度排序 ]]--
		exitLoading()
		local json = OnSearchResultDecode()
		if json ~= nil and json ~= "" then
			buildSearchSceneData()
			sortTypeChange( "hot" , reg)
		end	
	elseif message == 107 then  --[[ 内容排序 ]]--
		exitLoading()
		local json = OnLabelDecode()
		if json ~= nil and json ~= "" then
			FreeScene(GetCurScene())
			SetReturn(sceneSearchResult, scenePrograminfo_label)
			GoAndFreeScene(scenePrograminfo_label)
		end
	elseif message == 108 then
		exitLoading()
		local jason = ChannelNetworkData()
		if jason and jason.imgListNavi then
			SetReturn(sceneSearchResult,sceneProduct)
			FreeScene(GetCurScene())
			GoAndFreeScene("MODULE:\\product.xml")
		else
			require("module.dialog.usedialog")
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneSearchResult, sceneSearchResult,nil)
			Go2Scene(sceneDialog)
		end
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneSearchResult, sceneSearchResult)
	elseif message > 32768 then 
		exitLoading()
		require("module.dialog.usedialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneSearchResult, sceneSearchResult, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function requestProgramInfo(url)
	skipToProgramInfo()
end

function skipToProgramInfo()
	--[[	切换页面	]]--
	--local programInfoSprite = CreateSprite()
	local regSystem = registerCreate("system")
	registerSetInteger(regSystem, "dialog-back-scene", GetCurScene())
	setLoading()
end

function setLoading()
	require "module.loading.useloading"
	local reg = registerCreate( SRI.SCENE.ID )
	root = registerGetInteger(reg, SRI.ROOT.KEY )
	local nodeLoading = FindChildSprite(root, "loadingNode")
	enterLoading(nodeLoading)
end

function editOnTextChanged(sprite)
	ReleaseSpriteCapture(sprite)
	local rootSprite = GetRootSprite(sprite)
	local sendSprite = FindChildSprite(rootSprite,"scapegoat")
	SetSpriteFocus(sendSprite)
end

function TextOnSelected(sprite)
	local rootSprite = GetRootSprite(sprite)
	SetSpriteCapture(rootSprite)
end

function CancelItemSelectState(sprite)
	if globalPreviousSelItem ~= nil then
		local normalNode = FindChildSprite(globalPreviousSelItem, "node-normal")
		local selectedNode = FindChildSprite(globalPreviousSelItem, "node-selected")
		SetSpriteVisible(normalNode, 1)
		SetSpriteEnable(normalNode, 1)
		SetSpriteVisible(selectedNode, 0)
		SetSpriteEnable(selectedNode, 0)
	end
	SetSpriteFocus(sprite)
	local spriteName=GetSpriteName(sprite)
	if spriteName=="recommend-one-button" then
		recommendOneOnButtonClick(sprite)
	else
		recommendTwoOnButtonClick(sprite)
	end
end

function AdsearchButtonOnSelect(sprite)
	local reg_m = registerCreate(SRI.SCENE.ID)
	local root = registerGetInteger(reg_m, SRI.ROOT.KEY)
	local advanedarea = FindChildSprite(root,"advanced_searcharea")
	SetSpriteVisible(advanedarea,1)
	SetSpriteEnable(advanedarea,1)
	ChangeButtonPosition(sprite)
	local list = FindChildSprite(root,"search-result")
	SetSpriteEnable(list,0)
	local recomendlist = FindChildSprite(root,"recommend")
	SetSpriteEnable(recomendlist,0)
	local advanced_frame = FindChildSprite(advanedarea,"advanced_frame")
	local advanced_pannel = FindChildSprite(advanced_frame,"advanced_pannel")
	local a,b,c,d = GetSpriteRect(advanced_frame)
	if advanced_pannel == 0 then
		local node = CreateSprite("node")
		SetSpriteProperty(node,"name","advanced_pannel")
	 	LoadSprite(node,"MODULE:\\menusearch_advancedpannel.xml")
		AddChildSprite(advanced_frame, node)
		SetSpriteRect(node,a,-d,c,d)
		local reg_a = registerCreate("advancedsearch")
		registerSetInteger(reg_a, "advanced_pannel",node)
	else
		SetSpriteRect(advanced_pannel,a,-d,c,d)
		local reg_a = registerCreate("advancedsearch")
		registerSetInteger(reg_a, "advanced_pannel",advanced_pannel)
	end
	------------点击复选框后将焦点设置在第一个下拉框上------------
	local comboboxButton1 = FindChildSprite(advanced_frame,"combobox1")
	SetSpriteFocus(comboboxButton1)
	isAdvanced = 1
	SetTimer(1,1,"MoveThePannel")
end

function CloseAdsearchOnSelect(sprite)
	local reg_m = registerCreate(SRI.SCENE.ID)
	local root = registerGetInteger(reg_m, SRI.ROOT.KEY)
	local advanedarea = FindChildSprite(root,"advanced_searcharea")
	SetSpriteVisible(advanedarea,0)
	SetSpriteEnable(advanedarea,0)
	ChangeButtonPosition(sprite)
	local list= FindChildSprite(root,"search-result")
	SetSpriteEnable(list,1)
	local recomendlist = FindChildSprite(root,"recommend")
	SetSpriteEnable(recomendlist,1)
	HideComboboxlist()
	isAdvanced = 0
	-----将焦点设置在复选框未选中状态-----------
	SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite),"advanced"))
end

function ChangeButtonPosition(sprite)
	local nodesprite = GetSpriteParent(sprite)
	local advanced = FindChildSprite(nodesprite,"advanced")
	local closeadvanced = FindChildSprite(nodesprite,"closeadvanced")
	local a,b,c,d = GetSpriteRect(advanced)
	local e,f,g,h = GetSpriteRect(closeadvanced)
	SetSpriteRect(advanced,a,f,c,d)
	SetSpriteRect(closeadvanced,e,b,g,h)
end

function MoveThePannel(idevent)
	local reg_a = registerCreate("advancedsearch")
	local advanced_pannel = registerGetInteger(reg_a, "advanced_pannel")
	if idevent == 1 then
		local a,b,c,d = GetSpriteRect(advanced_pannel)
		SetSpriteRect(advanced_pannel,a,-(d*0.44),c,d)
		SetTimer(2,1,"MoveThePannel")
	elseif idevent == 2 then
		local a,b,c,d = GetSpriteRect(advanced_pannel)
		SetSpriteRect(advanced_pannel,a,-(d*0.22),c,d)
		SetTimer(3,1,"MoveThePannel")
	elseif idevent == 3 then
		local a,b,c,d = GetSpriteRect(advanced_pannel)
		SetSpriteRect(advanced_pannel,a,-(d*0.11),c,d)
		SetTimer(4,1,"MoveThePannel")
	elseif idevent == 4 then
		local a,b,c,d = GetSpriteRect(advanced_pannel)
		SetSpriteRect(advanced_pannel,a,0,c,d)
	end
end

function HideComboboxlist()
	local comboList1 = FindChildSprite(GetCurScene(),"comboList1")
	SetSpriteEnable(comboList1,0)
	SetSpriteVisible(comboList1,0)
	local hidecombolist_upper = FindChildSprite(GetCurScene(),"hidecombolist_upper")
	local hidecombolist_lower = FindChildSprite(GetCurScene(),"hidecombolist_lower")
	SetSpriteEnable(hidecombolist_upper,0)
	SetSpriteEnable(hidecombolist_lower,0)
	require "module.common.commonscroll"
	HideScrollArea()
end

--2010.8.12 lichengjun 以下全是键盘版代码
--设置默认焦点
function SetDefaultFocus()
	--如果有搜索结果，默认是第一个搜索结果
	local reg = registerCreate( SRI.SCENE.ID )
	local rootSprite = registerGetInteger(reg, SRI.ROOT.KEY )
	
	local searchResultList 	= FindChildSprite(rootSprite, "search-result-list")
	local currentStartPos	= SpriteList_GetStartItem(searchResultList)
	local pageItemPerPage	= SpriteList_GetItemPerPage(searchResultList)
	
	local curPos = currentStartPos - pageItemPerPage
	--SpriteList_SetStartItem(searchResultList, curPos)
	
	local theFirstVideo=SpriteList_GetListItem(searchResultList,currentStartPos)--currentStartPos
	focusIndex=currentStartPos
	if theFirstVideo ~= 0 then
		focusSprite(theFirstVideo)
	end
end


--结果页定位
function focusSprite(sprite)
		--SetSpriteFocus(sprite)
		--WriteLogs("locate a new pos"..focusIndex)
		local normalNode		= FindChildSprite(sprite, "node-normal")
		local selectedNode		= FindChildSprite(sprite, "node-selected")
		
		SetSpriteVisible(normalNode, 0)
		SetSpriteEnable(normalNode, 0)
		SetSpriteVisible(selectedNode, 1)
		SetSpriteEnable(selectedNode, 1)
				
		local playBtn=FindChildSprite(sprite, "play_"..focusIndex)
		local descBtn=FindChildSprite(sprite, "desc_"..focusIndex)
		if resultDataArray and resultDataArray[focusIndex] and resultDataArray[focusIndex].resultType and (resultDataArray[focusIndex].resultType == "03" or resultDataArray[focusIndex].resultType == "01" or resultDataArray[focusIndex].resultType == "02") then
			SetSpriteFocus(descBtn)
			saveTouchFocus(descBtn)
			selectButton=descBtn
			buttonType="desc"
		else
			SetSpriteFocus(playBtn)
			saveTouchFocus(playBtn)
			selectButton=playBtn
			buttonType="play"
		end
end
--取消焦点 ，针对结果列表
function killFocusSprite(sprite)
		--KillSpriteFocus(sprite)
		local normalNode		= FindChildSprite(sprite, "node-normal")
		local selectedNode		= FindChildSprite(sprite, "node-selected")
		
		SetSpriteVisible(normalNode, 1)
		SetSpriteEnable(normalNode, 1)
		SetSpriteVisible(selectedNode, 0)
		SetSpriteEnable(selectedNode, 0)
		
		local playBtn=FindChildSprite(sprite, "play_"..focusIndex)
		local descBtn=FindChildSprite(sprite, "desc_"..focusIndex)
		SetSpriteVisible(playBtn, 0)
		SetSpriteVisible(descBtn, 0)
		KillSpriteFocus(playBtn)
end



--推荐影片键盘事件
function RecommendListKeyUp(sprite,keyCode)
	--WriteLogs("Recomend The key donw")
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	local reg = registerCreate( SRI.SCENE.ID )
	local root = registerGetInteger(reg, SRI.ROOT.KEY )

	local spriteRecommendOne = FindChildSprite(root, "recommend-one")
	local spriteRecommendTwo = FindChildSprite(root, "recommend-two")	
	local spriteRecommendBtnOne = FindChildSprite(root, "recommend-one-button")
	local spriteRecommendBtnTwo = FindChildSprite(root, "recommend-two-button")	
	
	local searchEditBox = FindChildSprite(root, "searchEditBox")	
	
	if keyCode==ApKeyCode_Up then
		if sprite==spriteRecommendBtnTwo then
			SetSpriteFocus(spriteRecommendBtnOne)
			saveTouchFocus(spriteRecommendBtnOne)
		elseif sprite==spriteRecommendBtnOne then
			SetSpriteFocus(searchEditBox)
			saveTouchFocus(searchEditBox)
		end;
		
	elseif keyCode==ApKeyCode_Down then
	
		if sprite==spriteRecommendBtnOne then
			SetSpriteFocus(spriteRecommendBtnTwo)
			saveTouchFocus(spriteRecommendBtnTwo)
		elseif sprite==spriteRecommendBtnTwo then
			setSortFocus()
		end
	elseif keyCode==ApKeyCode_Enter then
		recmdBtnClick()
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		WriteLogs("11111111111111111")
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--按时间排序
function timeSortKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	local reg = registerCreate( SRI.SCENE.ID )
	local rootSprite = registerGetInteger(reg, SRI.ROOT.KEY )
	local ResultList 	= FindChildSprite(rootSprite, "search-result")
	
	if keyCode==ApKeyCode_Right then
		local hotBtn = FindChildSprite(ResultList, "hot-sort-button")	
		SetSpriteFocus(hotBtn)
		saveTouchFocus(hotBtn)
		sortTypeChange("hot",nil)
	elseif keyCode==ApKeyCode_Down and searchResult_empty ==0 then
		SetDefaultFocus()
	elseif keyCode==ApKeyCode_Up then
		if recommendDataArray==nil or recommendDataArray[0].contentName == nil  or recommendDataArray[1].contentName == nil  then--dw
		SetSpriteFocus(FindChildSprite(GetRootSprite(sprite),"searchEditBox"))
		saveTouchFocus(FindChildSprite(GetRootSprite(sprite),"searchEditBox"))
		WriteLogs("推荐焦点："..HasSpriteFocus(FindChildSprite(GetRootSprite(sprite),"searchEditBox")))
		else
		FocusToTui(2)
		end
	elseif keyCode==ApKeyCode_Enter then
		timeSortOnSelect()
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		WriteLogs("2222222222222222")
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--按热度排序
function hotSortKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	local reg = registerCreate( SRI.SCENE.ID )
	local rootSprite = registerGetInteger(reg, SRI.ROOT.KEY )
	local ResultList 	= FindChildSprite(rootSprite, "search-result")
	
	if keyCode==ApKeyCode_Left then
		local timeBtn = FindChildSprite(ResultList, "time-sort-button")	
		SetSpriteFocus(timeBtn)
		saveTouchFocus(timeBtn)
		sortTypeChange("time",nil)
	elseif keyCode==ApKeyCode_Down and searchResult_empty ==0 then
		SetDefaultFocus()
	elseif keyCode==ApKeyCode_Up then
		 if recommendDataArray==nil or recommendDataArray[0].contentName == nil or recommendDataArray[1].contentName == nil then--dw
		SetSpriteFocus(FindChildSprite(GetRootSprite(sprite),"searchEditBox"))
		saveTouchFocus(FindChildSprite(GetRootSprite(sprite),"searchEditBox"))
		WriteLogs("推荐焦点："..HasSpriteFocus(FindChildSprite(GetRootSprite(sprite),"searchEditBox")))
		else
		FocusToTui(2)
		end
	elseif keyCode==ApKeyCode_Enter then
		hotSortOnSelect()
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		WriteLogs("33333333333333")
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--定位到推荐影片列表
function FocusToTui(i)
	local reg = registerCreate( SRI.SCENE.ID )
	local sprite = registerGetInteger(reg, SRI.ROOT.KEY )

	local spriteRecommendBtnOne = FindChildSprite(GetCurScene(), "recommend-one-button")
	local spriteRecommendBtnTwo = FindChildSprite(GetCurScene(), "recommend-two-button")
	if i==1 then
		SetSpriteFocus(spriteRecommendBtnOne)
		saveTouchFocus(spriteRecommendBtnOne)
	elseif i==2 then
		SetSpriteFocus(spriteRecommendBtnTwo)
		saveTouchFocus(spriteRecommendBtnTwo)
	end
end

function bookconfirm(message, params)
	if message == 1001 then
		local reg = registerCreate(SRI.SCENE.ID)
		local remindurl = registerGetString(reg,"remindurl")
		require("module.protocol.protocol_infovolume")
		setLoading()
		RequestVolume(108, remindurl)
	elseif message == 1002 then
		--[[  donothing  ]]--
	end
end

function bookDelay()
	require("module.protocol.protocol_infovolume")
	local remindjson = OnVolumeDecode()
	exitLoading()
	require("module.dialog.usedialog")
	if remindjson and remindjson.desc and remindjson.success then
		setDialogParam("提示", remindjson.desc, "BT_OK", sceneSearchResult, sceneSearchResult, GetCurScene())
		Go2Scene(sceneDialog)
		if remindjson.success == "true" then
			local reg = registerCreate(SRI.SCENE.ID)
			local remindprogramId = registerGetInteger(reg,"remindprogramId")
			local temp = registerCreate("temp")
			registerLoad(temp, "MODULE:\\..\\temp\\booking.xml")
			registerSetString(temp,remindprogramId,"1")
			registerSave(temp,"MODULE:\\..\\temp\\booking.xml")
			registerRelease("temp")
		end
	else
		setDialogParam("提示", "无法获取网络数据，预约失败", "BT_OK", sceneSearchResult, sceneSearchResult, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

--搜索框KEYUP事件
function searchEditTextKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	local reg = registerCreate( SRI.SCENE.ID )
	local root = registerGetInteger(reg, SRI.ROOT.KEY )
	local SearchBtn=FindChildSprite(root, "searchButton")

	if keyCode==ApKeyCode_Right then --向右
		SetSpriteFocus(SearchBtn)
		saveTouchFocus(SearchBtn)
	elseif keyCode==ApKeyCode_Down then --向下
		if isAdvanced ~= 1 then
			if recommendDataArray==nil or recommendDataArray[0].contentName == nil  or recommendDataArray[1].contentName == nil then
				setSortFocus()
			else
				FocusToTui(1)
			end
		else
			SetSpriteFocus(FindChildSprite(GetCurScene(),"combobox1"))
			saveTouchFocus(FindChildSprite(GetCurScene(),"combobox1"))
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		WriteLogs("444444444444")
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
--搜索确定按钮KEYUP事件
function SearchBtnKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	local reg = registerCreate( SRI.SCENE.ID )
	local root = registerGetInteger(reg, SRI.ROOT.KEY )
	local SearchEditText=FindChildSprite(root, "searchEditBox")	
	--local pageDownButton = FindChildSprite(root, "page-down-button")
	--local pageUpButton = FindChildSprite(root, "page-up-button")
	
	if keyCode==ApKeyCode_Down then --向下
		if isAdvanced ~= 1 then
			if recommendDataArray==nil or recommendDataArray[0].contentName == nil  or recommendDataArray[1].contentName == nil then
				setSortFocus()
			else
				FocusToTui(1)
			end
		else
			SetSpriteFocus(FindChildSprite(GetCurScene(),"combobox1"))
			saveTouchFocus(FindChildSprite(GetCurScene(),"combobox1"))
		end
	elseif keyCode==ApKeyCode_Left then --向左
		SetSpriteFocus(SearchEditText)
		saveTouchFocus(SearchEditText)
	elseif keyCode==ApKeyCode_Right then --向右
		local advanceeParent = GetSpriteParent(GetSpriteParent(sprite))
		local advancedButton = FindChildSprite(advanceeParent,"advanced")
		local closeadvancedButton = FindChildSprite(advanceeParent,"closeadvanced")
		if isAdvanced ~= 1 then
			SetSpriteFocus(advancedButton)
			saveTouchFocus(advancedButton)
		else
			SetSpriteFocus(closeadvancedButton)
			saveTouchFocus(closeadvancedButton)
		end
	elseif keyCode==ApKeyCode_Enter then
		searchButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		WriteLogs("5555555555555")
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--播放键事件
function PlayKeyUp(sprite,keyCode)
	local idx_s = string.sub(GetSpriteName(sprite),6,7)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	local SceneReg=registerCreate("SceneNameReg")
	local curScene=registerSetString(SceneReg,"SceneName","search-result")
	local reg = registerCreate( SRI.SCENE.ID )
	local root = registerGetInteger(reg, SRI.ROOT.KEY )
	local curDesc=FindChildSprite(root,"desc_"..idx_s)
	local pageDownButton = FindChildSprite(root, "page-down-button")
	local pageUpButton = FindChildSprite(root, "page-up-button")
	local curItem=FindChildSprite(root,"item-button-"..idx_s)
	local normalSprite=FindChildSprite(curItem,"node-normal")
	local selectedSprite=FindChildSprite(curItem,"node-selected")
	local spriteList=FindChildSprite(root,"search-result-list")
	pageNum=math.ceil(SpriteList_GetListItemCount(spriteList)/PAGE_LINE_COUNT)  --add by yaoxiangyin
	if keyCode==ApKeyCode_Enter  then 
		if IsSpriteVisible(sprite)==1 then
			curPageIndex=1
			videoItemPlayOnSelect(sprite)
		else
			SetSpriteVisible(sprite,1)
			SetSpriteVisible(curDesc,1)
		end
		return 1
	elseif keyCode==ApKeyCode_Right and IsSpriteVisible(sprite)==1 then 
		if IsSpriteEnable(curDesc) == 1 then
			SetSpriteFocus(curDesc)
			saveTouchFocus(curDesc)
			selectButton=curDesc
			buttonType="desc"
		end
		return 1
	elseif keyCode==ApKeyCode_Left then 
		return 1
	end
	
	--搜索结果上下移动
	local searchResultList 	= FindChildSprite(root, "search-result-list")
	local lastVideo=SpriteList_GetListItem(searchResultList,focusIndex)	
		
	if keyCode==ApKeyCode_Down then
			if isLastItemCurPage()~=1 then
				SetSpriteVisible(sprite,0)
				SetSpriteVisible(curDesc,0)
				focusIndex=focusIndex+1
			else
				return 1
			end
	elseif keyCode==ApKeyCode_Up then
		if isFirstItemCurPage()==1 then --如果是本页第一条
			killFocusSprite(lastVideo)
			setSortFocus()
			return 1
		end
		focusIndex=focusIndex-1	
		SetSpriteVisible(sprite,0)
		SetSpriteVisible(curDesc,0)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		WriteLogs("777777777777777")
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_CharA then
		if curPageIndex>1 then
		curPageIndex=curPageIndex-1
		killFocusSprite(lastVideo)
		pageDownOnSelect(pageDownButton)
		end
		return 1
	elseif keyCode == ApKeyCode_CharB  then
		if curPageIndex<pageNum then
		curPageIndex=curPageIndex+1
		killFocusSprite(lastVideo)
		pageUpOnSelect(pageUpButton)
		end
		return 1
	end
	--如果是本页最后一条
	--[[
	if isLastItemCurPage()==1 then
		SetSpriteFocus(sprite)
		saveTouchFocus(sprite)
		focusIndex=focusIndex-1
		if IsSpriteVisible(sprite)==1 then	
			SetSpriteVisible(sprite,1)
			SetSpriteVisible(curDesc,1)
		end
		return 1
	end
	]]--
	
	SpriteListItem_SetIndex(searchResultList,focusIndex)
	local CurrentVideo=SpriteList_GetListItem(searchResultList,focusIndex)
	killFocusSprite(lastVideo)
	
	focusSprite(CurrentVideo)
	
end
--详细键事件
function DescKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	local idx_s = string.sub(GetSpriteName(sprite),6,7)
	local reg = registerCreate( SRI.SCENE.ID )
	local root = registerGetInteger(reg, SRI.ROOT.KEY )
	local curPlay=FindChildSprite(root,"play_"..idx_s)
	local pageDownButton = FindChildSprite(root, "page-down-button")
	local pageUpButton = FindChildSprite(root, "page-up-button")
	local spriteList=FindChildSprite(root,"search-result-list")
	pageNum=math.ceil(SpriteList_GetListItemCount(spriteList)/PAGE_LINE_COUNT)
	
	if keyCode==ApKeyCode_Enter then 
		if IsSpriteVisible(sprite)==1 then
			videoItemDescOnSelect(sprite)
		else
			SetSpriteVisible(sprite,1)
			if resultDataArray and resultDataArray[idx_s] and resultDataArray[idx_s].resultType and (resultDataArray[idx_s].resultType ~= "03" and resultDataArray[idx_s].resultType ~= "01") then
				SetSpriteVisible(curPlay,1)
			end

		end
		return 1
	end
	
	if keyCode==ApKeyCode_Left then --
		if IsSpriteVisible(curPlay)==1 then
		SetSpriteFocus(curPlay)
		saveTouchFocus(curPlay)
		selectButton=curPlay
		buttonType="play"
		end
		return 1
	elseif keyCode==ApKeyCode_Right then 
		return 1
	end
	
	--搜索结果上下移动
	local searchResultList 	= FindChildSprite(root, "search-result-list")
	local lastVideo=SpriteList_GetListItem(searchResultList,focusIndex)	
		
	if keyCode==ApKeyCode_Down then
			if isLastItemCurPage()~=1 then
				SetSpriteVisible(sprite,0)
				SetSpriteVisible(curPlay,0)
				focusIndex=focusIndex+1
			else
				return 1
			end
	elseif keyCode==ApKeyCode_Up then
		if isFirstItemCurPage()==1 then --如果是本页第一条
			killFocusSprite(lastVideo)
			setSortFocus()
			return 1
		end
		--[[
		if topFlag==1 then
			killFocusSprite(lastVideo)
			local searchResult 	= FindChildSprite(root, "search-result")
			local hotBtn = FindChildSprite(searchResult, "time-sort-button")	
			SetSpriteFocus(hotBtn)
			saveTouchFocus(hotBtn)
			sortTypeChange("time",nil)
			SetSpriteVisible(sprite,0)
			SetSpriteVisible(curPlay,0)
			return 1
		end
		]]--
		SetSpriteVisible(sprite,0)
		SetSpriteVisible(curPlay,0)
		focusIndex=focusIndex-1	
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_CharA then
		if curPageIndex>1 then
		curPageIndex=curPageIndex-1
		killFocusSprite(lastVideo)
		pageDownOnSelect(pageDownButton)
		end
		return 1
	elseif keyCode == ApKeyCode_CharB then
		if curPageIndex<pageNum then
		curPageIndex=curPageIndex+1
		killFocusSprite(lastVideo)
		pageUpOnSelect(pageUpButton)
		end
		return 1
	end
	--[[
	if isLastItemCurPage()==1 then
		SetSpriteFocus(sprite)
		saveTouchFocus(sprite)
		focusIndex=focusIndex-1
		if IsSpriteVisible(sprite)==1 then
		SetSpriteVisible(sprite,1)
		SetSpriteVisible(curPlay,1)
		end
		return 1
	end
	]]--
	SpriteListItem_SetIndex(searchResultList,focusIndex)
	local CurrentVideo=SpriteList_GetListItem(searchResultList,focusIndex)
	killFocusSprite(lastVideo)
	focusSprite(CurrentVideo)
end

--向后翻页事件
function pageDownKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local reg = registerCreate( SRI.SCENE.ID )
	local root = registerGetInteger(reg, SRI.ROOT.KEY )
	local PageUpBtn=FindChildSprite(root,"page-up-button")
	
	if keyCode==ApKeyCode_Right then
		if IsSpriteEnable(PageUpBtn)==1 then
			SetSpriteFocus(PageUpBtn)
			saveTouchFocus(PageUpBtn)
		end
	elseif keyCode==ApKeyCode_Enter then
		pageDownOnSelect(sprite)
	elseif keyCode==ApKeyCode_Up then
		--SetDefaultFocus()
		local searchResultList 	= FindChildSprite(root, "search-result-list")
		local CurrentVideo=SpriteList_GetListItem(searchResultList,focusIndex)
		focusSprite(CurrentVideo)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		WriteLogs("99999999999999999")
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
--向前翻页事件
function pageUpKeyUp(sprite,keyCode)
	local reg = registerCreate( SRI.SCENE.ID )
	local root = registerGetInteger(reg, SRI.ROOT.KEY )
	local PageDownBtn=FindChildSprite(root,"page-down-button")
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	if keyCode==ApKeyCode_Left then
		if IsSpriteEnable(PageDownBtn)==1 then
			SetSpriteFocus(PageDownBtn)
			saveTouchFocus(PageDownBtn)
		end
	elseif keyCode==ApKeyCode_Enter then
		pageUpOnSelect(sprite)
	elseif keyCode==ApKeyCode_Up then
		local searchResultList 	= FindChildSprite(root, "search-result-list")
		local CurrentVideo=SpriteList_GetListItem(searchResultList,focusIndex)
		focusSprite(CurrentVideo)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		WriteLogs("100000000000")
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--判断是否为每页的最后一条
function isLastItemCurPage()
	local reg		= registerCreate( SRI.SCENE.ID )
	local rootSprite= registerGetInteger(reg, SRI.ROOT.KEY )	

	local searchResultList 	= FindChildSprite(rootSprite, "search-result-list")
	local currentStartPos	= SpriteList_GetStartItem(searchResultList)
	local pageItemPerPage	= SpriteList_GetItemPerPage(searchResultList)
	local maxListItem		= table.maxn(resultDataArray) + 1
	local pageCount			= math.ceil(maxListItem / pageItemPerPage)
	local __remains__           = maxListItem % pageItemPerPage
	local curPage	= math.floor(focusIndex / pageItemPerPage)
	--[[
	if ( currentStartPos % pageItemPerPage ) > 0 then
	    curPage = curPage + 1
	end
	]]--
	if curPage+1<pageCount then
		if focusIndex==((curPage+1)*pageItemPerPage-1) then
			return 1
		end;
	elseif focusIndex==maxListItem-1 then
		return 1
	end
	return 0
	
end

--判断是否为每页的第一条
function isFirstItemCurPage()
	local reg		= registerCreate( SRI.SCENE.ID )
	local rootSprite= registerGetInteger(reg, SRI.ROOT.KEY )	

	local searchResultList 	= FindChildSprite(rootSprite, "search-result-list")
	local currentStartPos	= SpriteList_GetStartItem(searchResultList)
	local pageItemPerPage	= SpriteList_GetItemPerPage(searchResultList)
	local maxListItem		= table.maxn(resultDataArray) + 1
	local pageCount			= math.floor(maxListItem / pageItemPerPage)
	local __remains__           = maxListItem % pageItemPerPage
	local curPage	= math.floor(currentStartPos / pageItemPerPage)
	if ( currentStartPos % pageItemPerPage ) > 0 then
	    curPage = curPage + 1
	end
	
	if focusIndex==(curPage) *pageItemPerPage then
		return 1
	end
	return 0
end

function emptyKeyUp(sprite,keyCode)
	require("module.keycode.keycode")
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local SrhRstReg= registerCreate("searchReg")
		registerSetInteger(SrhRstReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_Up or keyCode == ApKeyCode_Down or keyCode == ApKeyCode_Left or keyCode == ApKeyCode_Right then
		SetSpriteFocus(FindChildSprite(GetRootSprite(sprite),"searchEditBox"))
		saveTouchFocus(FindChildSprite(GetRootSprite(sprite),"searchEditBox"))
	end
end

function pageDownOnClick(sprite)
	if buttonType=="play" then
		PlayKeyUp(selectButton,ApKeyCode_CharA)
	elseif buttonType=="desc" then
		DescKeyUp(selectButton,ApKeyCode_CharA)
	end
end

function pageUpOnClick(sprite)
	if buttonType=="play" then
		PlayKeyUp(selectButton,ApKeyCode_CharB)
	elseif buttonType=="desc" then
		DescKeyUp(selectButton,ApKeyCode_CharB)
	end
end

--高级搜索按钮的键盘事件
function advancedKeyUp(sprite,keyCode)
	if keyCode==ApKeyCode_Down then --向下
		if isAdvanced ~= 1 then 
			if recommendDataArray==nil or recommendDataArray[0].contentName == nil or recommendDataArray[1].contentName == nil then
				setSortFocus()
			else
				FocusToTui(1)
			end
		else
			SetSpriteFocus(FindChildSprite(GetCurScene(),"combobox1"))
			saveTouchFocus(FindChildSprite(GetCurScene(),"combobox1"))
		end
	elseif keyCode==ApKeyCode_Left then --向左
		SetSpriteFocus(FindChildSprite(GetSpriteParent(GetSpriteParent(sprite)),"searchButton"))
		saveTouchFocus(FindChildSprite(GetSpriteParent(GetSpriteParent(sprite)),"searchButton"))
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	else
		return 0
	end
end

function setSortFocus()
	local sorttype = GetSearchReqSortType()
	if sorttype == "time" then
		local timeBtn = FindChildSprite(GetCurScene(), "time-sort-button")
		SetSpriteFocus(timeBtn)
		saveTouchFocus(timeBtn)
	else
		local hotBtn = FindChildSprite(GetCurScene(), "hot-sort-button")	
		SetSpriteFocus(hotBtn)
		saveTouchFocus(hotBtn)
	end
end
