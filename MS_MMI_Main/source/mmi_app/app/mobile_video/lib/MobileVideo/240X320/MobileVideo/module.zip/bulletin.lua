﻿--@module 	bulletin 
--@note 		公告
--@author 	chengzhongjie
--@date 		2010/05/30


--@tag-action	body:BuildChildrenFinished
--@brief	创建操作说明界面
require "module.protocol.protocol_bulletin"
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.keyCode.keyCode"

--记录这一次点击哪一行
CurItemIndex = 1
LastItemIndex = 0
	
totalheight = 454
	entryHeight = 100
	loginHeight = 100
	hotkeyHeight = 100
	close1 = 1
	close2 = 0
	close3 = 0
function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("bulletin")   
	registerSetInteger(reg, "root", sprite)	
	json = OnBulletinDecode()   	
	local spriteOper = FindChildSprite(sprite, "operButton")
	local EmptyBt=FindChildSprite(sprite,"emptyBt")
	WriteLogs("emptyBt:"..EmptyBt)
	SetSpriteFocus(EmptyBt)
	saveTouchFocus(EmptyBt)
	SetSpriteProperty(spriteOper,"normal","operationFocus")
	text_welcomeNew = registerGetString(reg, "name")	
	type = registerGetString(reg, "type")
	CreateOperation(sprite)	
	return 1
end

--@function	CreateOperation
--@brief	创建操作说明界面
function CreateOperation(sprite)	
	local curIndex=1
	close1 = 1
	close2 = 0
	close3 = 0
	local spriteList = FindChildSprite(sprite, "bulletin-list")
	--local operItemSprite = CreateSprite("listitem")
	if json and json.bulletins then
		local count = table.maxn(json.bulletins)
		if count==0 then
			
			return 0
		end
		local count1 = count+1
		SpriteList_LoadListItem(spriteList, "MODULE:\\bulletinItem.xml", count1)
	
		if  text_welcomeNew == "notice11" or text_welcomeNew == "notice22" or text_welcomeNew == "notice12" or text_welcomeNew == "notice21" or text_welcomeNew == "notice1" or text_welcomeNew == "notice2" or type == "notice" then		
			for i = 0, count do			
				local bltIndex = i+1	
				local ListItem = SpriteList_GetListItem(spriteList, i)	
				SetSpriteRect(ListItem,0,60,240,30)
				SetSpriteProperty(ListItem,"name","bulletin"..bltIndex)
				if json and json.bulletins and json.bulletins[i].contentName and json.bulletins[i].desc then
					local itemSprite = FindChildSprite(sprite, "bulletin"..bltIndex)
					local textarea = FindChildSprite(itemSprite, "bulletinText1")
					SetSpriteProperty(textarea,"text",json.bulletins[i].desc)
					local text = FindChildSprite(itemSprite, "titleBtnText")
					SetSpriteProperty(text,"text",json.bulletins[i].contentName)
				end
				if json.bulletins[i].haveData and json.bulletins[i].haveData == "true" then
					if type ~= "notice" then
						if text_welcomeNew == "notice12" and i == 0 then
							OpenOne(sprite,1)
							curIndex=1
						elseif text_welcomeNew == "notice22" and i == 1 then
							OpenOne(sprite,2)
							curIndex=2
						end
					else
						local item = SpriteList_GetListItem(spriteList, 1)
						local titleBtn = FindChildSprite(item, "title")
						SetSpriteFocus(titleBtn)
						saveTouchFocus(titleBtn)
					end
				end			
			end
		end
		SpriteList_Adjust(spriteList)
	else
		require("module.protocol.protocol_channelGroup")
		local jsonData = ChannelGroupData()
		if jsonData then
			json = jsonToTable(jsonData)
			
			SpriteList_LoadListItem(spriteList, "MODULE:\\bulletinItem.xml", 1)
			local ListItem = SpriteList_GetListItem(spriteList, 0)	
			SetSpriteRect(ListItem,0,60,240,30)
			SetSpriteProperty(ListItem,"name","bulletin"..1)
			if json and json.bulletin and json.bulletin[0].contentName and json.bulletin[0].content then
				local itemSprite = FindChildSprite(sprite, "bulletin"..1)
				local textarea = FindChildSprite(itemSprite, "bulletinText1")
				SetSpriteProperty(textarea,"text",json.bulletin[0].content)
				local text = FindChildSprite(itemSprite, "titleBtnText")
				SetSpriteProperty(text,"text",json.bulletin[0].contentName)
			end
			OpenOne(sprite,1)
			curIndex=1
		end
	end
end

--@function	entrybutton1OnSelect
--@tag-name	entrybutton1-button
--@tag-action	button:OnSelect
--@brief	用于响应公告标题按钮
function titleOnSelect(sprite)	

	local spriteRoot = GetCurScene()
	local list  = FindChildSprite(spriteRoot, "bulletin-list")				
	local bulletinItem = GetSpriteParent(sprite)	
	
	--记录这一次点击了哪一行
	CurItemIndex = SpriteListItem_GetIndex(bulletinItem)+1	
	
	local entrySprite = FindChildSprite(bulletinItem, "bulletinText1")		
	local itemButton  = FindChildSprite(bulletinItem, "titleBtn")
	local titleBtnText  = FindChildSprite(bulletinItem, "titleBtnText")
	local textBG  = FindChildSprite(bulletinItem, "textBG")
	if CurItemIndex ~= LastItemIndex then
		CloseLastItem()
		SetSpriteRect(bulletinItem,11,60,205,130)
		SetSpriteVisible(entrySprite,1)
		SetSpriteVisible(textBG,1)		
		totalheight = totalheight + entryHeight
		--SetSpriteProperty(itemButton,"src","file:///image/bulletin/item_button2.png")
		SetSpriteProperty(titleBtnText,"color","#FFFFFF")
		close1 = 1
	else
		if close1 == 1 then
		SetSpriteVisible(entrySprite,0)
		SetSpriteVisible(textBG,0)
		SetSpriteRect(bulletinItem,11,60,205,30)
		totalheight = totalheight - entryHeight
		--SetSpriteProperty(itemButton,"src","file:///image/bulletin/item_button1.png")
		SetSpriteProperty(titleBtnText,"color","#585858")
		close1 = 0
	elseif close1 == 0 then			
		SetSpriteRect(bulletinItem,11,60,205,130)
		SetSpriteVisible(entrySprite,1)
		SetSpriteVisible(textBG,1)		
		totalheight = totalheight + entryHeight
		--SetSpriteProperty(itemButton,"src","file:///image/bulletin/item_button2.png")
		SetSpriteProperty(titleBtnText,"color","#FFFFFF")
		close1 = 1
		end
	end	
	LastItemIndex = CurItemIndex
	SpriteList_Adjust(list)	
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
end

function Up_And_Down()
	local  spriteRoot= GetCurScene()
	local list  = FindChildSprite(spriteRoot, "bulletin-list")
	local lastItem = FindChildSprite(list, "bulletin"..LastItemIndex)			
	local titleBtnText  = FindChildSprite(lastItem, "titleBtnText")
	SetSpriteProperty(titleBtnText,"color","#585858")
end


function CloseLastItem()
	local spriteRoot = GetCurScene()
	local list  = FindChildSprite(spriteRoot, "bulletin-list")
	local lastItem = FindChildSprite(list, "bulletin"..LastItemIndex)
	
	local entrySprite = FindChildSprite(lastItem, "bulletinText1")		
	local itemButton  = FindChildSprite(lastItem, "titleBtn")
	local titleBtnText  = FindChildSprite(lastItem, "titleBtnText")
	local textBG  = FindChildSprite(lastItem, "textBG")
	
	SetSpriteRect(lastItem,11,60,205,30)
	SetSpriteVisible(entrySprite,0)
	SetSpriteVisible(textBG,0)		
	totalheight = totalheight - entryHeight
	--SetSpriteProperty(itemButton,"src","file:///image/bulletin/item_button1.png")
	SetSpriteProperty(titleBtnText,"color","#585858")
end


function OpenOne(sprite,index)
	local bulletinItem = FindChildSprite(sprite, "bulletin"..index)
	local entrySprite = FindChildSprite(bulletinItem, "bulletinText1")		
	local itemButton  = FindChildSprite(bulletinItem, "titleBtn")
	local titleBtnText  = FindChildSprite(bulletinItem, "titleBtnText")
	local textBG  = FindChildSprite(bulletinItem, "textBG")
	local list = FindChildSprite(sprite, "bulletin-list")
	SetSpriteRect(bulletinItem,11,60,205,130)
	SetSpriteVisible(entrySprite,1)
	SetSpriteVisible(textBG,1)		
	totalheight = totalheight + entryHeight
	--SetSpriteProperty(itemButton,"src","file:///image/bulletin/item_button2.png")
	SetSpriteProperty(titleBtnText,"color","#FFFFFF")
	LastItemIndex = index
	SpriteList_Adjust(list)	
	close1 = 1
	local focusSpriteBtn= FindChildSprite(bulletinItem, "title")
	SetSpriteFocus(focusSpriteBtn)
	saveTouchFocus(focusSpriteBtn)
end

function OnSpriteEvent(message, params)
	require("module.common.commonMsg")
	require "module.videoexpress-common"	
	if message == MSG_SMS then
		WriteLogs("bodyOnSpriteEvent-----------------------1")
		requestMsgContent()
		WriteLogs("bodyOnSpriteEvent-----------------------3")
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	elseif message == 1001 then
		if dailFail and dailFail == 1 then
			Exit()
		end
	end
	return 1
end

function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if MSG_SMS_ID == message then			
		DealMsgContent(sceneBulletin, sceneBulletin)
	elseif message == 32768 then
		require("module.dialog.useDialog")
		setDialogParam("提示", "拨号失败", "BT_OK", sceneBulletin, sceneBulletin, GetCurScene())
		dailFail = 1
		Go2Scene(sceneDialog)
	end
	return 1
end


--@tag-action	button:OnKeyUp
--@brief	处理按键事件
function listKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
  if keyCode == ApKeyCode_F1 then		
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	end
  if keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
  end
  itemButton=FindChildSprite(sprite, "titleBtn")
  sprite= GetParentSprite(sprite)
  local index = SpriteListItem_GetIndex(sprite)
  WriteLogs("@@@@@@@"..index)
  WriteLogs("@@@@@@@"..keyCode)
  WriteLogs("@@@@@@@"..SpriteList_GetListItemCount(GetParentSprite(sprite)))
  if keyCode == ApKeyCode_Down and index<=SpriteList_GetListItemCount(GetParentSprite(sprite))-1 then
	LastItemIndex=index+1
    local sprite1=SpriteList_GetListItem(GetParentSprite(sprite),index+1)
	local focusSpriteBtn= FindChildSprite(sprite1,"title")
	titleOnSelect(focusSpriteBtn)
  elseif keyCode == ApKeyCode_Up and index>=1 then
	LastItemIndex=index+1
    local sprite1=SpriteList_GetListItem(GetParentSprite(sprite),index-1)
	local focusSpriteBtn= FindChildSprite(sprite1,"title")
	titleOnSelect(focusSpriteBtn)
  elseif keyCode ==ApKeyCode_CharB then
	local bulletinItem = FindChildSprite(GetRootSprite(sprite), "bulletin1")
	local focusSpriteBtn= FindChildSprite(bulletinItem, "title")
	if HasSpriteFocus(focusSpriteBtn)==0 or close1 == 0 then
		titleOnSelect(focusSpriteBtn)
	end
	return 1
  end  
  if keyCode ==ApKeyCode_Enter then 
	return 0
  end
 
  return 1
end
function emptyOnkeyUp(sprite,keyCode)
	require("module.keyCode.keyCode")
	WriteLogs("keyCode:"..keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	if keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	return 0

end

function buttonOnLostFocus(sprite, loser, leaveCount)
	local parent = GetSpriteParent(sprite)
	local titleBtnText = FindChildSprite(parent,"titleBtnText")
	SetSpriteProperty(titleBtnText,"color","#585858")
end

