﻿require "module.Loading.useLoading"
require "module.common.registerScene"
require "module.common.SceneUtils"
require "module.keyCode.keyCode"
require "module.videoexpress-common"
function bodyBuildChildrenFinished(sprite)
	local root = GetRootSprite(sprite)
	local FocusSprite = FindChildSprite(root,"movie1")
	SetSpriteFocus(FocusSprite)
	WelcomeReg = registerCreate("WelcomeReg")
	registerSetInteger(WelcomeReg,"WelcomeFlag",0)
	local reg = registerCreate("welcomeNew")
	registerSetInteger(reg, "root", sprite)
	local text = registerGetString(reg,"text")
	local textlabel = FindChildSprite(sprite , "status-forground")
	SetSpriteProperty(textlabel, "text", "获取首页数据中...")
	SetSpriteCapture(textlabel)
	local _,_,w,h = GetSpriteRect(FindChildSprite(root,"loadarea"))
	if (w == 320 and h == 240) or (w == 640 and h == 480) then
		HideSomeItems(root)
	end
	local load = registerGetInteger(reg, "load")
	if load == 1 then
		local reloadWelcomeNew = registerGetInteger(WelcomeReg, "reloadWelcomeNew")
		if reloadWelcomeNew ~= 1 then
			SetSpriteProperty(textlabel, "text", "数据获取完成...")
		else
			SetSpriteProperty(textlabel, "text", "")
		end
		SetTimer(1,1000,"OnTimer")
		local gotoHomePage = FindChildSprite(sprite,"gotoHomePage")
		local textlabel = FindChildSprite(sprite , "status-forground")
		ReleaseSpriteCapture(textlabel)
		SetSpriteVisible(gotoHomePage,1)
		SetSpriteEnable(gotoHomePage,1)
	end
	require "module.protocol.clientInit"
	require "module.protocol.protocol_login"
	require "module.setting"
	return 1
end

function OnTimer(idEvent)
	if idEvent == 1 then
		local reg = registerCreate("welcomeNew")
		local root = registerGetInteger(reg, "root")
		local textlabel = FindChildSprite(root , "status-forground")
		SetSpriteProperty(textlabel,"text","")
	end
end

function OnPluginEvent(message, param)
	local CurSprite = GetCurScene()
	---------Modfiy Start------------
	local loadarea = FindChildSprite(CurSprite ,"loadarea")
	if loadarea and loadarea~= 0 then
		ReleaseSpriteCapture(loadarea)
	end
	---------Modfiy End------------
	if message == 101 then
		exitLoading()
		Go2Scene(sceneBulletin)
		--FreeScene(CurSprite)
	elseif message == 102 then
		exitLoading()
		Go2Scene(scenePrograminfo_volume)
		--FreeScene(CurSprite)
	elseif message == 103 then
		exitLoading()
		Go2Scene(scenePrograminfo_label)
		--FreeScene(CurSprite)
	elseif message == 104 then
		exitLoading()
		Go2Scene(scenePrograminfo_list)
		--FreeScene(CurSprite)
	elseif message == 106 then	
		require "module.protocol.protocol_bulletin"
		local json = OnBulletinDecode()
		if json and json.desc and json.contentName then
			local desc = json.desc
			local contentName = json.contentName
			local reg = registerCreate("bulletin")   
			registerSetString(reg, "desc", desc)
			registerSetString(reg, "contentName", contentName)
			RequestBulletin(106,url2)
		end
	elseif message == 105 then		
		exitLoading()
		Go2Scene(sceneBulletin)
		--FreeScene(CurSprite)
	elseif message > 32768 and message ~= MSG_SMS_ID + 32768 then
		exitLoading()
		--[[  弹框提示界面会出错，所以不弹框提示  ]]--
	elseif message == 32768 then
		require("module.dialog.useDialog")
		require "module.common.SceneUtils"
		require "module.common.registerScene"
		local regHandle = registerCreate("SCMngr_handle");
		local SceneName = registerGetString(regHandle, string.format("%d", GetCurScene()))
		setDialogParam("提示", "拨号失败", "BT_OK", SceneName, SceneName, GetCurScene())
		dailFail = 1
		Go2Scene(sceneDialog)
	end
end

function OnSpriteEvent(message, params)
	if message == 1001 then
		Exit()
	elseif message == 999 then
		--ReloadData()
		local CurSprite = GetCurScene()
		local progressnode = FindChildSprite(CurSprite,"progress_node")
		SetSpriteVisible(progressnode,1)
		SetTimer(1,1000,"RefreshFinished")
	end
end

function RefreshFinished(idevent)
	if idevent == 1 then
		local CurSprite = GetCurScene()
		local fc = FindChildSprite(CurSprite,"homereload_fc")
		local l,t,w,h = GetSpriteRect(fc)
		SetSpriteProperty(fc,l,t,240,h)
		SetTimer(2,2000,"RefreshFinished")
	elseif idevent == 2 then
		local CurSprite = GetCurScene()
		local regHandle = registerCreate("SCMngr_handle");
		local SceneName = registerGetString(regHandle, string.format("%d", CurSprite))
		if SceneName == "MODULE:\\welcomeNew_1.xml" then
			FreeScene(CurSprite)
			local reg = registerCreate("WelcomeReg")
			registerSetInteger(reg, "reloadWelcomeNew", 1)
			Go2Scene("MODULE:\\welcomeNew_1.xml",1)
		end
	end
end

function noticeOnSelect(sprite)
	local text=GetSpriteName(sprite)
	local url = GetSpriteText(FindChildSprite(sprite, "url"))
	if url and url ~= "" then
    	local loadarea = FindChildSprite(GetRootSprite(sprite) ,"loadarea")
    	enterLoading(loadarea)
    	local reg = registerCreate("bulletin")
    	registerSetString(reg, "type", "notice")
    	registerSetString(reg, "name", text)	
    	RequestGuide(url,"notice")
	end
end

function noticeOnSelect1(sprite)
	local text=GetSpriteName(sprite)
	local url = GetSpriteText(FindChildSprite(sprite, "url"))
	if url and url ~= "" then
    	local loadarea = FindChildSprite(GetRootSprite(sprite) ,"loadarea")
    	enterLoading(loadarea)
    	local reg = registerCreate("bulletin")
    	registerSetString(reg, "type", "open")
    	registerSetString(reg, "name", text)	
    	RequestGuide(url,"notice")
	end
end

function hotOnSelect(sprite)
	--local text=GetSpriteName(sprite)
	--local url=hotList[text]
	local url=GetSpriteText(FindChildSprite(sprite,"url"))
	
	if url and url ~= "" then
		
		local loadarea = FindChildSprite(GetRootSprite(sprite) ,"loadarea")
		WriteLogs("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
		enterLoading(loadarea)
		RequestGuide(url,"hot")
		WriteLogs("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB")
	end
end

function movieOnSelect(sprite)
	--local text=GetSpriteName(sprite)
	--local url=movieList[text]
	local url=GetSpriteText(FindChildSprite(sprite,"url"))
	if url and url ~= "" then
		local loadarea = FindChildSprite(GetRootSprite(sprite) ,"loadarea")
		enterLoading(loadarea)
		RequestGuide(url,"movie")
	end
end

function gotoHomePageOnSelect(sprite)
	local welcomeNewSprite=GetCurScene()
	Go2Scene(sceneHome)
	--FreeScene(welcomeNewSprite)
end

function RequestGuide(url,tag)
	if tag=="notice" then
		require("module.protocol.protocol_bulletin")
		RequestBulletin(105,url)
		
	elseif tag=="hot" then
		if GetInformationFromUrl(url,"category") == "1" then
			require("module.protocol.protocol_infovolume")
			RequestVolume(102, url)
		elseif GetInformationFromUrl(url,"category") == "5" then
			if GetInformationFromUrl(url,"formType") == "1" then
				require("module.protocol.protocol_infolabel")
				Requestlabel(103, url)
			elseif GetInformationFromUrl(url,"formType") == "2" then
				require("module.protocol.protocol_infolist")	
				RequestList(104, url)
			end
		else
			exitLoading()
			--[[  url出错,但不能弹框提示  ]]--
		end
	elseif tag=="movie" then
		if GetInformationFromUrl(url,"category") == "1" then
			require("module.protocol.protocol_infovolume")
			RequestVolume(102, url)
		elseif GetInformationFromUrl(url,"category") == "5" then
			if GetInformationFromUrl(url,"formType") == "1" then
				require("module.protocol.protocol_infolabel")
				Requestlabel(103, url)
			elseif GetInformationFromUrl(url,"formType") == "2" then
				require("module.protocol.protocol_infolist")	
				RequestList(104, url)
			end
		end
	end
end

function GetInformationFromUrl(url,param)
	--[[  从json中获取推荐信息  ]]--
	local i,j = string.find(url,"&"..param.."=")
	local paramvalue = nil
	if j then
		local k = string.find(url,"&",j+1)
		if k then
			paramvalue = string.sub(url,j+1,k-1)
		else
			paramvalue = string.sub(url,j+1,string.len(playurl))
		end
		return paramvalue
	else
		return nil
	end
end

function GetNoticeUrl()
	local reg = registerCreate("welcomeNew")
	local root = registerGetInteger(reg, "root")	
	local notice1 = FindChildSprite(root, "notice1")	
	local url1 = GetSpriteText(FindChildSprite(notice12,"url"))
	local notice2 = FindChildSprite(root, "notice2")
	local url2 = GetSpriteText(FindChildSprite(notice22,"url"))
	return url1,url2
end

function gotoHomePageKeyUp(sprite, keyCode)
	local arrayTemp = {"notice11","notice12","notice21","notice22","hot11","hot12","hot21","hot22","movie1","movie2","movie3","movie4"}
	local reg = registerCreate("welcomeNew")
	local load = registerGetInteger(reg, "load")
	if load ==1 then
		WriteLogs("Welcomenew_1.lua-->gotoHomePageKeyUp-->KeyUp-->KeyCode:"..keyCode)
		if keyCode == 3 then
			
			gotoHomePageOnSelect(sprite)
			return 1
		elseif keyCode == 9 then   --新增 当焦点落在【进入首页】上时点击向上翻页键能够向上移动焦点
			for t=table.getn(arrayTemp),1,-1 do
				local latestVisible = FindChildSprite(GetSpriteParent(sprite), arrayTemp[t])
				if IsSpriteVisible(latestVisible) == 1 then
					SetSpriteFocus(latestVisible)
					break
				end
			end
		elseif keyCode==1 then
		WriteLogs("----------------------  1  :dw")
			gotoHomePageOnSelect(sprite)
		
		elseif keyCode == 10 then
			for t=1,table.getn(arrayTemp) do
				local latestVisible = FindChildSprite(GetSpriteParent(sprite), arrayTemp[t])
				if IsSpriteVisible(latestVisible) == 1 then
					SetSpriteFocus(latestVisible)
					break
				end
			end
		end
	else 
		return 0
	end
end
function ReloadData()
	local reg = registerCreate("welcomeNew")
	local root = registerGetInteger(reg, "root")
	local rootnewdata = registerGetInteger(reg, "newdata")
	SetNewData(root,rootnewdata,"notice11")
	SetNewData(root,rootnewdata,"notice12")
	SetNewData(root,rootnewdata,"notice21")
	SetNewData(root,rootnewdata,"notice22")
	SetNewData(root,rootnewdata,"hot11")
	SetNewData(root,rootnewdata,"hot12")
	SetNewData(root,rootnewdata,"hot21")
	SetNewData(root,rootnewdata,"hot22")
	SetNewData(root,rootnewdata,"movie1")
	SetNewData(root,rootnewdata,"movie2")
	SetNewData(root,rootnewdata,"movie3")
	SetNewData(root,rootnewdata,"movie4")

end

function listKeyUp(sprite, keyCode)
	
  local Jiaodian = {"notice11","notice12","notice21","notice22","hot11","hot12","hot21","hot22","movie1","movie2","movie3","movie4","gotoHomePage"}
	local name = GetSpriteName(sprite)
	local jidodianNum
	local i
	for i=1,table.getn(Jiaodian) do
	  if Jiaodian[i] == name then
	    jiaodianNum = i
	  end
	end
	
	if keyCode == ApKeyCode_Down then
		if jiaodianNum <=8 then
			if jiaodianNum == 8 then
				SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite), Jiaodian[9]))
				return 1
			end
			for w = jiaodianNum+2,table.getn(Jiaodian),2 do
				if w == 8 then
					local number8 = FindChildSprite(GetSpriteParent(sprite), Jiaodian[8])
					if IsSpriteVisible(number8) == 1 then
						SetSpriteFocus(number8)
						break
					else
						SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite), Jiaodian[9]))
						break
					end 
				else
					local latestVisible = FindChildSprite(GetSpriteParent(sprite), Jiaodian[w])
					if IsSpriteVisible(latestVisible) == 1 then
						SetSpriteFocus(latestVisible)
						break
					end
				end
			end
		else
			for w = jiaodianNum+1,table.getn(Jiaodian) do
				local latestVisible = FindChildSprite(GetSpriteParent(sprite), Jiaodian[w])
				if IsSpriteVisible(latestVisible) == 1 then
					SetSpriteFocus(latestVisible)
					break
				end
			end
		end
	elseif keyCode == ApKeyCode_Up then
		if jiaodianNum <= 8 then
			for v=jiaodianNum-2,0,-2 do
				if v == 0 then
					SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite), Jiaodian[table.getn(Jiaodian)]))
					break
				else
					local latestVisible = FindChildSprite(GetSpriteParent(sprite), Jiaodian[v])
					if IsSpriteVisible(latestVisible) == 1 then
						SetSpriteFocus(latestVisible)
						break
					end
				end
			end
			if jiaodianNum == 1 then
				SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite), Jiaodian[table.getn(Jiaodian)]))
			end
		else
			for v=jiaodianNum-1,0,-1 do
				if v == 0 then
					SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite), Jiaodian[table.getn(Jiaodian)]))
					break
				else
					local latestVisible = FindChildSprite(GetSpriteParent(sprite), Jiaodian[v])
					if IsSpriteVisible(latestVisible) == 1 then
						SetSpriteFocus(latestVisible)
						break
					end
				end
			end
		end
	elseif keyCode == ApKeyCode_Left then
		WriteLogs("**********************ApKeyCode_Left***********************")
		WriteLogs("jiaodianNum = "..jiaodianNum)
		if jiaodianNum == 2 or jiaodianNum == 4 or jiaodianNum == 6 or jiaodianNum == 8  then
			local latestVisible = FindChildSprite(GetSpriteParent(sprite), Jiaodian[jiaodianNum-1])
			WriteLogs("&&&&&&&&&&&&&& latestVisible "..latestVisible)
			SetSpriteFocus(latestVisible)
		end
	elseif keyCode == ApKeyCode_Right then
		if jiaodianNum == 1 or jiaodianNum == 3 or jiaodianNum == 5 or jiaodianNum == 7  then
			local latestVisible = FindChildSprite(GetSpriteParent(sprite), Jiaodian[jiaodianNum+1])
			SetSpriteFocus(latestVisible)
		end
	
	elseif keyCode == ApKeyCode_F1 then 
	WriteLogs("---------------------------------------------------------------dw")
	    gotoHomePageOnSelect(sprite)
	else
		return 0
	end
end

function SetNewData(root,rootnewdata,tagname)
	local node_old = FindChildSprite(root,tagname)
	local node_new = FindChildSprite(rootnewdata,tagname)
	if node_old ~= 0 and node_new ~= 0 then
		local old = FindChildSprite(node_old,"url")
		local new = FindChildSprite(node_new,"url")
		if old ~= 0 and new ~= 0 then
			SetSpriteProperty(new,"text",GetSpriteText(old) == nil and "" or GetSpriteText(old))
		end
		
		local old = FindChildSprite(node_old,"buttonNormaltext")
		local new = FindChildSprite(node_new,"buttonNormaltext")
		if old ~= 0 and new ~= 0 then
			SetSpriteProperty(new,"text",GetSpriteText(old) == nil and "" or GetSpriteText(old))
		end
		
		local old = FindChildSprite(node_old,"buttonFocusText")
		local new = FindChildSprite(node_new,"buttonFocusText")
		if old ~= 0 and new ~= 0 then
			SetSpriteProperty(new,"text",GetSpriteText(old) == nil and "" or GetSpriteText(old))
		end
	end
end

function HideSomeItems(sprite)
	local buttonnotice21 = FindChildSprite(sprite,"notice21")
	local buttonnotice22 = FindChildSprite(sprite,"notice22")
	local buttonhot21 = FindChildSprite(sprite,"hot21")
	local buttonhot22 = FindChildSprite(sprite,"hot22")
	local buttonmovie3 = FindChildSprite(sprite,"movie3")
	local buttonmovie4 = FindChildSprite(sprite,"movie4")
	
	SetSpriteVisible(buttonnotice21,0)
	SetSpriteVisible(buttonnotice22,0)
	SetSpriteVisible(buttonhot21,0)
	SetSpriteVisible(buttonhot22,0)
	SetSpriteVisible(buttonmovie3,0)
	SetSpriteVisible(buttonmovie4,0)
end
