--@module myorder
--@note 我的订购
--@author Abigale
--@date 2010/05/31
require "module.Loading.useLoading"
require "module.common.registerScene"
require "module.common.SceneUtils"
require "module.keyCode.keyCode"

function bodyBuildChildrenFinished(sprite)
	SetSpriteFocus(FindChildSprite(sprite,"tempButton"))
	local reg = registerCreate("Myorder")
	registerSetInteger(reg, "root", sprite)
  --myOrderInit(sprite)
	return 1
end

function bodyOnPluginEvent(message, param)
	require "module.videoexpress-common"
	if message == 101 then
		exitLoading()
		local reg = registerCreate("Myorder")
		local sprite = registerGetInteger(reg,"root")
		CreateMyorderList(sprite)
	elseif message == 225 then
		exitLoading()
		local reg = registerCreate("monthguidelist")
		local fileName = registerGetString(reg, "monthguideUrlFileName")		
		local jsonString = jsonOpenFile(fileName)		
		if	jsonString and jsonString ~= 0 then 
			pathName = "MODULE:\\monthguidelist.xml"
			if pathName then
				local scene = FindScene(pathName)
			end
			if scene and scene ~= 0 then
				FreeScene(scene)
			end
			GoAndFreeScene(pathName)
			SetReturn(sceneMyOrder,sceneMonthGuideList)
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneMyOrder, sceneMyOrder, GetCurScene())
			Go2Scene(sceneDialog)		
		end
	elseif message == 226 then
		exitLoading()
		local jason = ChannelNetworkData()
		if jason.imgListNavi and jason.programList then
			WriteLogs("ChangeToProduct")
			GoAndFreeScene("MODULE:\\product.xml")
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneMyOrder, sceneMyOrder, GetCurScene())
			Go2Scene(sceneDialog)
		end
	elseif message == 227 then
		exitLoading()
		local navigationData = LoadNavigationData()
		if navigationData then
			WriteLogs("ChangeToNavigationData")
			GoAndFreeScene("MODULE:\\navigation.xml")
		end
	elseif message == 228 then
		exitLoading()
		local topTenData = LoadJsonTopTenNetworkData()
		if topTenData then
			WriteLogs("ChangeToguide")
			GoAndFreeScene("MODULE:\\paihang.xml")
		end
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneMyOrder, sceneMyOrder)
	end
end

function bodyOnSpriteEvent(message, param )
	require "module.videoexpress-common"
	require("module.common.commonMsg")
	if message == MSG_ACTIVATE then
	myOrderInit()
	elseif message == MSG_DEACTIVATE then
		WriteLogs("myorder  MSG_DEACTIVATE")
	elseif message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
end

function myOrderInit( sprite )
	if sprite == nil then
		local k = registerCreate ( "Myorder");
	  sprite = registerGetInteger( k, "root");
	end
	require "module.setting"
	local strMyorderUrl= Cfg.GetServer()..Cfg.GetPortal().."/msp/orderList.msp"
	MyorderUrl={strMyorderUrl}
	url=MyorderUrl
	RequestOrder(MyorderUrl[1], nil)
	local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadingNode")
	enterLoading(nodeLoading)
end

function RequestOrder(url,tag)
	fileName = GetLocalFilename(url)
	local reg = registerCreate("Myorder")
	registerSetString(reg, "myorderUrlFileName", fileName)
	local observer = pluginGetObserver()
	local regSystem = registerCreate("System")
	local http	= pluginCreate("HttpPipe")
	pluginInvoke(http, "AppendCommand", 0, url, 0, fileName, observer, 101, 0,1)
end

function OnMyOrderDecode()
	local reg = registerCreate("Myorder")
	local myorderfileName = registerGetString(reg, "myorderUrlFileName")
	return jsonLoadFile(myorderfileName)
end

prevSelectSprite = nil
itembutton =nil
preItem=nil
function CreateMyorderList(sprite)
	local spriteList = FindChildSprite(sprite, "myorder-list")
	WriteLogs("tigertiger-CreateMyorderList")
	SpriteList_ClearListItem(spriteList, 1, 1 )

	MyOrderData = OnMyOrderDecode()
	if MyOrderData.orderList == nil then
		SetSpriteFocus(FindChildSprite(sprite,"tempButton"))
		saveTouchFocus(FindChildSprite(sprite,"tempButton"))
	end
	
	if  MyOrderData and MyOrderData.orderList then
		MyOrderDataArray = MyOrderData.orderList
		local n = table.maxn(MyOrderDataArray)
		WriteLogs("==dw==table.maxn = "..n)
		count = n
		local xmlNode=xmlLoadFile("MODULE:\\myorderitem.xml")
		for i = 0, n  do
			myorderSprite = CreateSprite("listitem")
			LoadSpriteFromNode(myorderSprite, xmlNode)
			SetSpriteRect(myorderSprite, 0, 0, 205, 25)
			
			SetSpriteProperty(myorderSprite, "name", i)

			local spriteSel = FindChildSprite(myorderSprite,"selected")
			local spriteUnSel = FindChildSprite(myorderSprite,"normal")
			WriteLogs("wall-evc")
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)
			SetSpriteEnable(spriteUnSel, 1)
			SetSpriteRect(myorderSprite,  0, 0, 205, 25)
			---------------------设置每个listItem的默认选中选中------------------
			SetSpriteProperty(myorderSprite, "defaultFocusName", "item-button")
			local spritetextNTitle = FindChildSprite(myorderSprite, "title")
			local spritetextTitle = FindChildSprite(myorderSprite, "selected-title")
			local spritetextSFeed = FindChildSprite(myorderSprite, "selected-feed")
			local spritetextDetail= FindChildSprite(myorderSprite, "detail")
			SetSpriteProperty(spritetextNTitle, "text", MyOrderDataArray[i].productName)
			SetSpriteProperty(spritetextTitle, "text", MyOrderDataArray[i].productName)
			SetSpriteProperty(spritetextSFeed, "text", MyOrderDataArray[i].fee)
			if MyOrderDataArray[i].productType==nil then
				SetSpriteEnable(spritetextDetail,0)
				SetSpriteVisible(spritetextDetail,0)
			end
			AddChildSprite(spriteList, myorderSprite)
			SpriteList_AddListItem(spriteList, myorderSprite)
			
			---------------设置初始状态时按钮的焦点------------------
			if i == 0 then
				itembutton = FindChildSprite(myorderSprite, "item-button")
				SetSpriteFocus(itembutton)
				saveTouchFocus(itembutton)
			end
			--------------------------------------------------
		end
		xmlRelease(xmlNode)
		--if count <= 8 then
			local spriteImage = FindChildSprite(sprite,"scrollbar-image")
			local spriteScroll = FindChildSprite(sprite,"scroll")
			local spriteSplider = FindChildSprite(sprite,"splider-bar")
			SetSpriteVisible(spriteImage,1)
			SetSpriteVisible(spriteSplider,0)
			SetSpriteEnable(spriteScroll,0)
			SetSpriteEnable(spriteSplider,0)
		--end
	end
	SpriteList_Adjust(spriteList)
	require "module.common.commonScroll"
	if(count==nil) then count = 0 end
	CreateScrollBar(sprite,"myorder-list",(count)*25 + 45,82)
end

function myorderitemOnSelect(sprite)	
	local listitem = GetParentSprite(GetParentSprite(sprite))
	--if lastItem and lastItem ~= listitem then
		--selectedToUnselected(lastItem)
	--end
	lastItem = listitem
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "myorder-list")
	for i=0,(SpriteList_GetListItemCount(spriteList)-1) do
		local toUnselItem= SpriteList_GetListItem(spriteList,i)
		selectedToUnselected(toUnselItem)
	end
	local spriteParent = GetSpriteParent(sprite)
	local spriteMyorder = GetSpriteParent(spriteParent)
	local spriteSel2 = FindChildSprite(spriteMyorder,"selected")
	local spriteUnSel2 = FindChildSprite(spriteMyorder,"normal")
	SetSpriteVisible(spriteUnSel2, 0)
	SetSpriteEnable(spriteUnSel2, 0)
	SetSpriteVisible(spriteSel2, 1)
	SetSpriteEnable(spriteSel2, 1)
	SetSpriteRect(spriteMyorder, 0, 0, 205, 48)
	SpriteList_Adjust(spriteList)
	
	--------判断前一个listItem和当前listItem的位置关系并设定选中---------
	local detailButtonSelect=FindChildSprite(spriteMyorder,"detail")
	local cancelorderButtonSelect=FindChildSprite(spriteMyorder,"cancelorder")
	if IsSpriteVisible(detailButtonSelect)==1 then
		SetSpriteFocus(detailButtonSelect)
		saveTouchFocus(detailButtonSelect)
	else
		SetSpriteFocus(cancelorderButtonSelect)
		saveTouchFocus(cancelorderButtonSelect)
	end
	prevSelectSprite = spriteMyorder
	
	--listitem索引值保存，以待退订详情和退订选项界面数据展示时用。
	--FindChildSprite
	local SpriteItem = GetSpriteParent(sprite)
	local SpriteListItem = GetSpriteParent(SpriteItem)
	index = SpriteListItem_GetIndex(SpriteListItem)
	local regSystem = registerCreate("system")
	registerSetInteger(regSystem, "IndexData", index)
end
-- 进入九宫格
function go2detailOnSelect(sprite)
	local regSystem = registerCreate("system")
	index = registerGetInteger(regSystem, "IndexData")
	local json = OnMyOrderDecode()
	local pathName = 0

	if json and json.orderList[index].productType then
		local style = json.orderList[index].productType
		if style == "0" then
			if json.orderList[index].nodeUrl then
				local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadingNode")
				enterLoading(nodeLoading)
				if json.orderList[index].nodeDisplayType == "1" then		--1：平铺式
					url = json.orderList[index].nodeUrl
					require "module.protocol.protocol_monthguide"
					RequestMonthGuide(225,url)
				elseif json.orderList[index].nodeDisplayType == "0" then   	--0：列表式
					require("module.protocol.protocol_channel")
					url = json.orderList[index].nodeUrl
					RequestChannel(226, url)
				elseif json.orderList[index].nodeDisplayType == "2" then	--2：评书
					require("module.protocol.protocol_navigation")
					url = json.orderList[index].nodeUrl
					RequestNavigation(227, url)
				elseif json.orderList[index].nodeDisplayType == "3" then	--3: 排行榜
					require("module.protocol.protocol_topten")
					url = json.orderList[index].nodeUrl
					RequestTopTen(228, url)
				end
			end
		elseif style == "1" then
			local reg_o = registerCreate("Myorder")
			local root = registerGetInteger(reg_o, "root")
			local Monthlist = FindChildSprite(root, "Monthlist")
			if Monthlist == 0 or Monthlist == nil then
				Monthlist = CreateSprite("node", root)
				SetSpriteProperty(Monthlist,"name","Monthlist")
			end
			SetSpriteCapture(Monthlist)
			--[[  载入  ]]--
			local menu = CreateSprite("listitem")
		 	LoadSprite(menu,sceneMonthList)
			AddChildSprite(Monthlist, menu)
			----------------------------获得从前创建的数据仓库中的数据，使其获得焦点--------------------
			local reg2 = registerCreate("spriteF")                                                               
	        sprite2=registerGetInteger(reg2, "sprite")
			WriteLogs("###################"..HasSpriteFocus(sprite2))
			SetSpriteFocus(sprite2)
			
			local reg3 = registerCreate("spriteH")                                                               
	        sprite3=registerSetInteger(reg3, "Jsprite",sprite)
			--------------------------------------------------------------------------------------------
		else
			WriteLogs("sth wrong are running")
		end
	else
		require("module.dialog.usedialog")
		setDialogParam("提示", "该栏目还未发布", "BT_OK", sceneMyOrder, sceneMyOrder, nil)
		Go2Scene(sceneDialog)
	end
end
--进入退订
function cancelorderOnSelect(sprite)
	local pathName = "MODULE:\\orderdetail.xml"
	--SetReturn(sceneMyOrder,sceneCancelOrderDetail)
	local scene = FindScene(pathName)
	if scene and scene ~= 0 then
		FreeScene(scene)
	end
	GoAndFreeScene(pathName)
end

--@function SetScrollBarPos
--@tag-name scrollbar
--@tag-action button:OnMouseDown
--@brief 移动滚动条
function SetScrollBarPos(sprite,x,y)
	--flag = 1
	--[[  根据点击位置计算滚动百分比 ]]--
	local percent = y*100/200
	SetSpriteProperty(sprite,"pos",percent)
	SpriteScrollBar_Adjust(sprite)

	--[[  获取根节点 ]]--
	local reg = registerCreate("Myorder")
	local root = registerGetInteger(reg, "root")
	local spritelist = FindChildSprite(root,"myorder-list")

	--[[  完成滚动效果 ]]--
	local totalheight = 25*count
	local l,t,w,h = GetSpriteRect(spritelist)
	if totalheight >232 then
	SetSpriteRect(spritelist,l,0-percent*(totalheight-232)/100,w,h)
	end
end

function GoAndFreeScene(pathName)
	local scene = FindScene(pathName)
	if scene and scene ~= 0 then
		FreeScene(scene)
	end
	FreeScene(GetCurScene())
	SetReturn("MODULE:\\myorder.xml", pathName)
	Go2Scene(pathName, nil)
end

---------------------------------------------------------------

function tempButtonKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	if keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	end
end


function selectedToUnselected(listitem)
	local spriteSel = FindChildSprite(listitem,"selected")
	local spriteUnSel = FindChildSprite(listitem,"normal")
	local spriteList = GetParentSprite(listitem)
	SetSpriteVisible(spriteSel, 0)
	SetSpriteEnable(spriteSel, 0)
	SetSpriteVisible(spriteUnSel, 1)
	SetSpriteEnable(spriteUnSel, 1)
	SetSpriteRect(listitem, 0, 0, 205, 25)
	SpriteList_Adjust(spriteList)
end

function selectedbuttonOnKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	WriteLogs("~~~~~~~~~~~~~~~selectedbuttonOnKeyUp")
	local listitem = GetParentSprite(GetParentSprite(sprite))
	local list = GetParentSprite(listitem)
	local name = GetSpriteName(sprite)
	local index = SpriteListItem_GetIndex(listitem)
	local count = SpriteList_GetListItemCount(list)
	local _, y1 = GetSpriteRect(listitem)
	local x, y2, w, h = GetSpriteRect(list)
	local y = y1+y2
	if keyCode == ApKeyCode_Down then
		if index == (count-1) then return end
		if y >= 170 then
			SpriteScrollBar_Adjust(list)
			SetSpriteRect(list,x,y2-25,w,h)
			KeyAdjust(25,"down")
		end
		lastItem = SpriteList_GetListItem(list, index)
		local nextItem = SpriteList_GetListItem(list, index+1)
		local itembutton = FindChildSprite(nextItem, "item-button")
		selectedToUnselected(listitem)
		SetSpriteFocus(itembutton)
		saveTouchFocus(itembutton)
	elseif keyCode == ApKeyCode_Up then
		if index == 0 then return end
		if y <= 25 then
			SpriteScrollBar_Adjust(list)
			SetSpriteRect(list,x,y2+25,w,h)
			KeyAdjust(25,"up")
		end
		lastItem = SpriteList_GetListItem(list, index)
		local preItem = SpriteList_GetListItem(list, index-1)
		local itembutton = FindChildSprite(preItem, "item-button")
		selectedToUnselected(listitem)
		SetSpriteFocus(itembutton)
		saveTouchFocus(itembutton)
	elseif keyCode == ApKeyCode_Left then
		if name == "cancelorder" then
			local detail = FindChildSprite(listitem, "detail")
			if IsSpriteVisible(detail)==1 then
				SetSpriteFocus(detail)
				saveTouchFocus(detail)
			end
		end
	elseif keyCode ==ApKeyCode_Enter then
		 preItem = SpriteList_GetListItem(list, index-1)
		 itembutton = FindChildSprite(preItem, "item-button")
		if name == "item-button" then
			myorderitemOnSelect(sprite)
		elseif name == "detail" then
			go2detailOnSelect(sprite)
		elseif name == "cancelorder" then
			cancelorderOnSelect(sprite)
		end
	elseif keyCode == ApKeyCode_Right then
		if name == "detail" then
			local cancel = FindChildSprite(listitem, "cancelorder")
			SetSpriteFocus(cancel)
			saveTouchFocus(cancel)
		end
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

function cancelorderOnMouseDown(sprite)
	selectedbuttonOnKeyUp(sprite,ApKeyCode_Enter)
end		
