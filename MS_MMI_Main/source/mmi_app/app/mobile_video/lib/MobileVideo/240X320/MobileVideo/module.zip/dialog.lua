﻿--@module dialog
--@note 对话框
--@author xf_pan
--@date 2010/05/30
require "module.keyCode.keyCode"
require "module.dialog.useDialog"

SCENE_DIALOG 		= "dialog"
SCENE_DIALOG_ROOT	= "root"
--SHOW_FLAG 			= "show-flag"

function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate(SCENE_DIALOG)
	registerSetInteger(reg, SCENE_DIALOG_ROOT, sprite)
	--registerSetInteger(reg, SHOW_FLAG, 1)
	
	-- global
	local root = registerGetInteger(reg,"root")
	--SetSpriteProperty(root,"OnKeyUp","blankReturn")
	
	require "module.common.SceneUtils"
	dialogTitle, message, dialogType, backSceneName, background, observer,backSceneMenu , OK_N_IMG, OK_F_IMG, CANCEL_N_IMG, CANCEL_F_IMG = getDialogParam()
	clearDialogParam()
	backScene	= FindScene(backSceneName)
	resultMessage	= 1000
	createDialog()

	local backSceneSprite	= FindChildSprite(sprite, "back-scene")
	local dialogRootSprite	= FindChildSprite(sprite, "dialog")
	local backgroundScene	= FindScene(background)
	if backgroundScene ~= nil and backgroundScene ~= "" then
		WriteLogs(backgroundScene)
		AddChildSprite(backSceneSprite, backgroundScene)
	end
	SetSpriteCapture(dialogRootSprite)
	local rootTest = registerGetInteger(reg, "root")
	local ok_buttontSprite = FindChildSprite(rootTest,"ok-button_dilog")
	if ok_buttontSprite then
		SetSpriteFocus(ok_buttontSprite)
		WriteLogs("dialog.lua line41 ok_buttontSprite name:"..GetSpriteName(ok_buttontSprite))
		WriteLogs("result:"..HasSpriteFocus(ok_buttontSprite))
	end
	return 1
end

function blankReturn(sprite,keyCode)
	WriteLogs("blankReturn")
   if keyCode == ApKeyCode_F2 then
		WriteLogs("blankReturn ApKeyCode_F2")
		require("module.menuopen")
		returnButtonOnSelect(sprite)
   end
end
--@function	createDialog
--@brief	创建对话框元素
function createDialog()
	--[[	获取根节点	]]--
	local reg = registerCreate(SCENE_DIALOG)
	local root = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	
	local titleSprite	= FindChildSprite(root, "dialog-title")
	local title2Sprite	= FindChildSprite(root, "dialog-title2")
	local bodySprite	= FindChildSprite(root, "dialog-body")
	local areaSprite	= FindChildSprite(root, "dialog-area")
	local messageSprite	= FindChildSprite(root, "dialog-message")
	local okSprite		= FindChildSprite(root, "ok-button_dilog")
	local cancelSprite	= FindChildSprite(root, "cancel-Button")
	
	local okbtnImgN	= FindChildSprite(root, "okbtnImgN")
	local okbtnImgF	= FindChildSprite(root, "okbtnImgF")
	local cancelbtnImgN	= FindChildSprite(root, "cancelbtnImgN")
	local cancelbtnImgF	= FindChildSprite(root, "cancelbtnImgF")
	
	SetSpriteProperty( okbtnImgN,"src", OK_N_IMG );
	SetSpriteProperty( okbtnImgF,"src", OK_F_IMG );
	SetSpriteProperty( cancelbtnImgN,"src", CANCEL_N_IMG );
	SetSpriteProperty( cancelbtnImgF,"src", CANCEL_F_IMG );
	
	-- title
	if dialogTitle ~= "" then
		SetSpriteProperty(titleSprite, "text", dialogTitle)
		SetSpriteProperty(title2Sprite, "text", dialogTitle)
	else
		SetSpriteProperty(titleSprite, "text", "提示")
		SetSpriteProperty(title2Sprite, "text", "提示")
	end
	
	local labelHeight, buttonOffset, lableOffset	= 20, 25 , 10
	
	local body_x,   body_y, 	body_w,   body_h 	= GetSpriteRect(bodySprite)
	local message_x,message_y,message_w,message_h 	= GetSpriteRect(messageSprite)
	local area_x,   area_y, 	area_w,   area_h 	= GetSpriteRect(areaSprite)
	local ok_x, 	  ok_y, 	ok_w, 	  ok_h 		= GetSpriteRect(okSprite)
	local cancel_x, cancel_y, cancel_w, cancel_h 	= GetSpriteRect(cancelSprite)
	
	-- message is empty
	if message == "" then
		body_h = body_h - labelHeight
		body_y = body_y + labelHeight
		area_h = area_h - labelHeight
		ok_y   = ok_y   - labelHeight + 5
		cancel_y = cancel_y - labelHeight + 5
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
		SetSpriteRect(areaSprite, area_x, area_y, area_w, area_h)
		SetSpriteRect(okSprite, ok_x, ok_y, ok_w, ok_h)
		SetSpriteRect(cancelSprite, cancel_x, cancel_y, cancel_w, cancel_h)
	else
		SetSpriteProperty(messageSprite, "text", message)
	end
	
	-- button type
	if dialogType == "BT_NULL" then
		body_h = body_h - labelHeight
		body_y = body_y + labelHeight
		area_h = area_h - labelHeight
		message_y = message_y + lableOffset
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
		SetSpriteRect(areaSprite, area_x, area_y, area_w, area_h)
		SetSpriteRect(messageSprite,message_x,message_y,message_w,message_h)
		
		SetSpriteVisible(okSprite, 0)
		SetSpriteVisible(cancelSprite, 0)
		SetSpriteEnable(okSprite, 0)
		SetSpriteEnable(cancelSprite, 0)
	elseif dialogType == "BT_OK" then
		if message=="订购成功" then
			SetSpriteVisible(okSprite,0)
		end
		SetSpriteVisible(cancelSprite, 0)
		SetSpriteEnable(cancelSprite, 0)
		ok_x = ok_x + buttonOffset
		SetSpriteRect(okSprite, ok_x, ok_y, ok_w, ok_h)
	end
	local bodySprite	= FindChildSprite(root, "dialog-body")
	local body_x, body_y, body_w, body_h = GetSpriteRect(bodySprite)
	body_y = 200
	SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
	
end

function dialogBodyOnTick(sprite)

	
	return 1
end

function okButtonOnSelect(sprite)
	
	local reg = registerCreate(SCENE_DIALOG)
	setDialogReturnParam("ok")
	local root = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	resultMessage = 1001
	-- 刷新背景的情况下可以加动画
	--registerSetInteger(reg, SHOW_FLAG, 2)

	local bodySprite	= FindChildSprite(root, "dialog-body")
	local body_x, body_y, body_w, body_h = GetSpriteRect(bodySprite)
	body_y = 200
	SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
	local dialog = GetCurScene()
	skipToScene()
	FreeDialog(dialog)
	SendSpriteEvent(observer, resultMessage)
	---------------------------------------------
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	local curScene=registerGetString(SceneReg,"SceneName")
	-------------------------------------------
	if curScene~=nil and curScene=="history" then	
		local his_Reg=registerCreate("sc_Reg")
		local Button = registerGetInteger(his_Reg,"sprite_flag")
		SetSpriteFocus(Button)
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
		
	elseif curScene~=nil and curScene=="search-result" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="favorite" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="LocalFile" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="uploadingFile" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="uploadHistoryFile" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="menuSetingScene" then
		WriteLogs("menuSetting")
	    registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	end
	
	----------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	local TuchReg=registerCreate("PopMenuHide")
	local ToDigFocus 
	if registerGetInteger(ToDigReg,"KeyFlag")==1 then
		ToDigFocus = registerGetInteger(ToDigReg,"ToDigFocus")
		registerSetInteger(ToDigReg,"KeyFlag",0)
	else
		ToDigFocus = registerGetInteger(TuchReg,"sencePreFocus")
	end
	if ToDigFocus then
		SetSpriteFocus(ToDigFocus)
	end
	
	
	
end

function cancelButtonOnSelect(sprite)
	local reg = registerCreate(SCENE_DIALOG)
	setDialogReturnParam("cancel")
	local root = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	resultMessage = 1002
	
	-- 刷新背景的情况下可以加动画
	--registerSetInteger(reg, SHOW_FLAG, 2)
	
	local bodySprite	= FindChildSprite(root, "dialog-body")
	local body_x, body_y, body_w, body_h = GetSpriteRect(bodySprite)
	body_y = 200
	SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
	local dialog = GetCurScene()
	skipToScene()
	SendSpriteEvent(observer, resultMessage)
	FreeDialog(dialog)

	---------------------------------------------
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	local curScene=registerGetString(SceneReg,"SceneName")
	-------------------------------------------
	if curScene~=nil and curScene=="history" then
		WriteLogs("取消：")
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="search-result" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="favorite" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="LocalFile" then
		WriteLogs("*****************yao go to LocalFile..................")
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="uploadingFile" then
		WriteLogs("取消按钮")
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="uploadHistoryFile" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="menuSetingScene" then
		WriteLogs("menuSetting")
	    registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	end
	-------------------------------------------
	
	local ToDigReg = registerCreate("ToDigReg")
	local TuchReg=registerCreate("PopMenuHide")
	local ToDigFocus 
	if registerGetInteger(ToDigReg,"KeyFlag")==1 then
		ToDigFocus = registerGetInteger(ToDigReg,"ToDigFocus")
		registerSetInteger(ToDigReg,"KeyFlag",0)
	else
		ToDigFocus = registerGetInteger(TuchReg,"sencePreFocus")
	end
	if ToDigFocus then
		SetSpriteFocus(ToDigFocus)
	end
end

function skipToScene()
	--local programInfoSprite = CreateSprite()
	if backSceneName ~= nil and backSceneName ~= "" then
		if  backSceneMenu == 1  then -- 不需要菜单
			Go2Scene(backSceneName, 1)
		else
			Go2Scene(backSceneName)
		end	
	end
end

function FreeDialog(dialog)
	local backSceneNode  = FindChildSprite(dialog, "back-scene")
	local backgroundScene= FindScene(background)
	if backSceneNode and backSceneNode ~= 0 and backgroundScene and backgroundScene ~= 0 then
		RemoveChildSprite(backSceneNode, backgroundScene)
	end
	FreeScene(dialog)
end

function OnDialogSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_ACTIVATE then
		local ok_buttontSprite = FindChildSprite(GetCurScene(),"ok-button_dilog")
		if ok_buttontSprite then
			SetSpriteFocus(ok_buttontSprite)
		end
	end
	return 1
end

function OnDialogPluginEvent(message, params)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if MSG_SMS_ID == message then		
		require("module.common.registerScene")	
		DealMsgContent(sceneDialog, sceneDialog)
	end
	return 1
end

function DialogKeyUp(sprite, keyCode)
	WriteLogs("DialogKeyUp")
	if keyCode == ApKeyCode_Enter then
		return 0
	end
	WriteLogs("message:"..message)
	WriteLogs("keyCode:"..keyCode)
	if keyCode == ApKeyCode_F2 and message=="订购成功" then
		WriteLogs("do keyCode F2 begin")
		okButtonOnSelect(sprite)
		WriteLogs("do keyCode F2 end")
		return 1
	end
	local spritename = GetSpriteName(sprite)
	WriteLogs("dialog.lua line368 spritename = "..spritename)
	--[[	获取根节点	]]--
	local reg = registerCreate("dialog")
	local root = registerGetInteger(reg, "root")
	local dbcReg = registerCreate("UseDialogReg")
	UseDialogFlag = registerGetInteger(dbcReg,"UseDialogFlag")
	WriteLogs("UseDialogFlag dialog.lua line374")
	if spritename == nil then
		WriteLogs("dialog.lua lien376 spritename ==="..spritename)
		WriteLogs("warning.......................................")
	end
	if spritename =="ok-button_dilog" and UseDialogFlag and UseDialogFlag == 2 then
		if keyCode == ApKeyCode_Right then
			--WriteLogs("move right")
			local cancelButtonSpriteName = FindChildSprite(root,"cancel-Button")
			WriteLogs("cancelButtonSpriteName = "..cancelButtonSpriteName)
			SetSpriteFocus(cancelButtonSpriteName)
		end
		return 1
	end
	if spritename =="cancel-Button" then
		if keyCode == ApKeyCode_Left and UseDialogFlag == 2 then
			local okButtonSpriteName = FindChildSprite(root,"ok-button_dilog")
			SetSpriteFocus(okButtonSpriteName)
		end
		return 1
	end
	return 0
end
