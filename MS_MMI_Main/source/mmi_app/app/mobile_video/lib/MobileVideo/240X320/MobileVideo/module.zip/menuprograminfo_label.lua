﻿--@module menuprograminfo_label
--@note 标签式详情
--@author cuiyizhou
--@date 2010/05/28
require "module.Loading.useLoading"
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.keyCode.keyCode"
function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("menuprograminfo_label")   
	registerSetInteger(reg, "root", sprite)
	--[[  创建全局的标志位，控制详细信息面板的移动  ]]--  
	regflag = registerCreate("buttonclickflag")
	registerSetInteger(regflag, "flag", 0)
	registerSetInteger(regflag, "preflag", 1)
--[[--------------------------------------------------------------------------------------]]--
    registerSetInteger(reg,"subjectPageIndex",0)
-----------------------------------------------------------------------------------------------
	--[[  获取缓存中的数据  ]]--
	local fileName = registerGetString(reg, "labelUrlFileName")
	json = jsonLoadFile(fileName)
	--json = jsonLoadFile("MODULE:\\cache\\69dcf50db21b71d1b591e70df7b31cf1.txt")
	loadJsonData()
	--[[  创建小的集数列表 ]]--
	createSubjectList()
	
	--[[  根据json中数据判断是否需要显示上一节目或者下一节目]]--
	if json and json.prevId then
	else
		local backbtn = FindChildSprite(sprite,"button-backprogram")
		SetSpriteVisible(backbtn ,0)
		SetSpriteEnable(backbtn ,0)
	end
	if json and json.nextId then
	else
		local nextbtn = FindChildSprite(sprite,"button-nextprogram")
		SetSpriteVisible(nextbtn ,0)
		SetSpriteEnable(nextbtn ,0)
	end
	local leftbutton = FindChildSprite(sprite,"video-left")
	SetSpriteEnable(leftbutton,0)
	return 1
end

--@function showDetailButtonOnSelect
--@tag-name video-bottom
--@tag-action button:OnSelect 
--@brief 控制详情显示区域的大小
function showDetailButtonOnSelect(sprite)
	--[[  获取全局的标志位 ]]--
	regflag = registerCreate("buttonclickflag")
	preflag = registerGetInteger(regflag,"preflag")
	--[[  preflag中保存的是上一次的移动情况，当flag值不为0时，区域开始移动，1缩小，-1增大 改变区域的操作在OnTick中实现]]--
	if preflag == 1 then
		registerSetInteger(regflag, "flag" ,-1)
		local normal = FindChildSprite(sprite,"img_btnNormal")
		SetSpriteProperty(normal,"src","file://image//menuprograminfo//bt_gd2.png")
		local focus = FindChildSprite(sprite,"img_btnFocus")
		SetSpriteProperty(focus,"src","file://image//menuprograminfo//bt_gd2.png")
	else
		registerSetInteger(regflag, "flag" ,1)
		local normal = FindChildSprite(sprite,"img_btnNormal")
		SetSpriteProperty(normal,"src","file://image//menuprograminfo//bt_gd.png")
		local focus = FindChildSprite(sprite,"img_btnFocus")
		SetSpriteProperty(focus,"src","file://image//menuprograminfo//bt_gd.png")
	end     
end

--@function backButtonOnSelect
--@tag-name button-backprogram
--@tag-action button:OnSelect 
--@brief 上一节目
function backButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_label")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	if nil ~= json then
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		require "module.menuprograminfo"
--		--换节目也要将播放器stop
--		local reg = registerCreate("video")
--		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
--		if MediapalyPlugin ~= 0 then
--			pluginInvoke(MediapalyPlugin, "Stop")
--		end
		--[[  这里应该动态获取点击按钮的具体url  ]]--
		if json.prevId[0].category == "1" then
			local volumeurl = json.prevId[0].urlPath
			require "module.protocol.protocol_infovolume"
			RequestVolume(109, volumeurl)
			--[[ sava urlPath ]]--
			SetProgramInfoUrlPath(volumeurl)
		elseif json.prevId[0].category == "5" then
			if json.prevId[0].displayType == "5" then
				local listurl = json.prevId[0].urlPath
				require "module.protocol.protocol_infolist"
				RequestList(112, listurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(listurl)
			elseif json.prevId[0].displayType == "1" then
				local labelurl = json.prevId[0].urlPath
				require "module.protocol.protocol_infolabel"
				Requestlabel(111, labelurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(labelurl)
			end
		end
	end
end

--@function nextButtonOnSelect
--@tag-name button-nextprogram
--@tag-action button:OnSelect 
--@brief 下一节目
function nextButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_label")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	if nil ~= json then
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		require "module.menuprograminfo"
--		--换节目也要将播放器stop
--		local reg = registerCreate("video")
--		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
--		if MediapalyPlugin ~= 0 then
--			pluginInvoke(MediapalyPlugin, "Stop")
--		end
		--[[  这里应该动态获取点击按钮的具体url  ]]--
		if json.nextId[0].category == "1" then
			local volumeurl = json.nextId[0].urlPath
			require "module.protocol.protocol_infovolume"
			RequestVolume(109, volumeurl)
			--[[ sava urlPath ]]--
			SetProgramInfoUrlPath(volumeurl)
		elseif json.nextId[0].category == "5" then
			if json.nextId[0].displayType == "5" then
				local listurl = json.nextId[0].urlPath
				require "module.protocol.protocol_infolist"
				RequestList(112, listurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(listurl)
			elseif json.nextId[0].displayType == "1" then
				local labelurl = json.nextId[0].urlPath
				require "module.protocol.protocol_infolabel"
				Requestlabel(111, labelurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(labelurl)
			end
		end
	end
end

--@function OnSpriteEvent
--@tag-name body
--@tag-action sprite:OnSpriteEvent 
--@brief 响应消息
function OnSpriteEvent(message, params)
	require("module.common.commonMsg")
	require "module.videoexpress-common"
	--[[  收藏事件  ]]--
	if message == MSG_ADD_FAV then --add my fav
		require("module.protocol.protocol_addmyfav")
		require("module.menuprograminfo")
		local reg = registerCreate("product")
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
		local urlPath = GetProgramInfoUrlPath()
		WriteLogs("addfavorite urlPath---"..urlPath)
		urlPath = string.gsub(urlPath,"&","|")
		WriteLogs("gsub urlPath---"..urlPath)
		
		local playUrl = json.subIds[0].playUrl
		WriteLogs("playUrl---"..playUrl)
		local pos = string.find(playUrl,"nodeId",0)
		if pos then
			local nodeId = string.sub(playUrl,pos+7)
			WriteLogs("nodeId---"..nodeId)		
			RequestAddMyfav(110, 1, nodeId, json.contentId, urlPath)
		end
	end
	--[[  返回事件  ]]--
	if message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
	if message == MSG_SMS then
		requestMsgContent()
	end
	return 1
end

--@function	createSubjectList
--@brief	创建所有集数的按钮子项，在bodyBuildChildrenFinished中调用
function createSubjectList()
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_label")   
	local sprite = registerGetInteger(reg, "root")
	--[[  寻找目标列表  ]]-- 
	local spriteList = FindChildSprite(sprite, "subject-list")
	
	--[[  循环插入列表列表，这里应该用网络数据  ]]-- 
	if json and json.subIds then
		count = table.maxn(json.subIds)+1
		SpriteList_LoadListItem(spriteList, "MODULE:\\menuprograminfo_labelItem.xml", count)
		for i=1, count do
			local menuprograminfoSprite = SpriteList_GetListItem(spriteList,i-1)
			SetSpriteProperty(menuprograminfoSprite,0,0,49,19)
			local changeNameButton=FindChildSprite(SpriteList_GetListItem(spriteList,i-1), "subject-button-1")
			SetSpriteProperty(changeNameButton,"name",string.format("subject-button-%d",i-1))
			--[[	设置按钮文字，这里应该使用网络数据	]]--
			local spritetextN = FindChildSprite(menuprograminfoSprite, "subjectButtontextN")
			local spritetextF = FindChildSprite(menuprograminfoSprite, "subjectButtontextF")
			--if i<10 then
			--	SetSpriteProperty(spritetextN, "text", "第0"..i.."集")
			--	SetSpriteProperty(spritetextF, "text", "第0"..i.."集")
			--else
			SetSpriteProperty(spritetextN, "text", json.subIds[i-1].subName)
			SetSpriteProperty(spritetextF, "text", json.subIds[i-1].subName)
			--end
		end
--[[---------------------------------修改人：yaoxiangyin 修改时间：2010.8.18---------------------------------------------------]]--	
		local defaultMenuprograminfoButton=FindChildSprite(SpriteList_GetListItem(spriteList,0), "subject-button-0")
		SetSpriteFocus(defaultMenuprograminfoButton)
		registerSetInteger(reg, "lastFocus",defaultMenuprograminfoButton)
--------------------------------------------------------------------------------------------------------------		
		--[[	重新计算这些节点位置，根据list标签中的offset	]]--
		SpriteList_Adjust(spriteList)
		if count >=13 then
			if count >=16 then
				local left = FindChildSprite(sprite,"video-left")
				local right = FindChildSprite(sprite,"video-right")
				SetSpriteVisible(left, 1)
				SetSpriteVisible(right, 1)
			end
			return 1
		end
	else
		count = 0
	end
	--[[	如果集数少于12个，要在这里进行界面调整	]]--
	--[[  蓝色框区域  ]]--
	local bluebkmid = FindChildSprite(sprite,"blue-background-mid")
	local bluebkbot = FindChildSprite(sprite,"blue-background-bottom")
	--[[  灰色框区域  ]]--
	local introduceframe = FindChildSprite(sprite,"item-video-introduce")
	--[[  文字描述区域  ]]--
	local textframe = FindChildSprite(sprite,"distinct-introduce")
	if count <= 12 then
		SetSpriteRect(bluebkmid,11,4,218,68)
		SetSpriteRect(bluebkbot,11,72,218,4)
		SetSpriteRect(introduceframe,0,226,240,62)
		SetSpriteRect(textframe,19,230,214,52)
	end
	if count <= 8 then
		SetSpriteRect(bluebkmid,11,4,218,44)
		SetSpriteRect(bluebkbot,11,48,218,4)
		SetSpriteRect(introduceframe,0,202,240,86)
		SetSpriteRect(textframe,19,206,214,76)
	end
	if count <= 4 then
		SetSpriteRect(bluebkmid,11,4,218,20)
		SetSpriteRect(bluebkbot,11,24,218,4)
		SetSpriteRect(introduceframe,0,178,240,110)
		SetSpriteRect(textframe,19,182,214,100)
	end
	return 1
end

--@function introduceOnTick
--@tag-name item-video-introduce
--@tag-action list-item:OnTick
--@brief 实现控制详情显示区域的大小
function introduceOnTick(sprite)
	--[[  获取全局的标志位 ]]--
	regflag = registerCreate("buttonclickflag")
	flag = registerGetInteger(regflag, "flag")
	--[[  flag值为0代表不移动，直接返回 ]]--
	if flag == 0 then
		return 1
	end
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_label")   
	local root = registerGetInteger(reg, "root")
	--[[  寻找目标列表  ]]-- 
	introduceframe = FindChildSprite(root, "distinct-introduce")
	--[[  由于节目集数的不同造成显示区域需要调整  ]]-- 
	local textframe_top = 250
	if count <= 12 then
		textframe_top = 250-24
	end
		if count <= 8 then
		textframe_top = 250-48
	end
		if count <= 4 then
		textframe_top = 250-72
	end
	--[[  开始变化  ]]--
	if flag == 1 then
		--[[  减小显示区域  ]]-- 
		local l,t,w,h = GetSpriteRect(sprite)
		local ll,tt,ww,hh = GetSpriteRect(introduceframe)
			t = t + 8
			h = h - 8
			tt = tt + 8
			hh = hh - 8
			if t >= textframe_top then
				--[[  改变区域大小完成，设置falg标志位为0  ]]-- 
				registerSetInteger(regflag, "preflag", flag)
				registerSetInteger(regflag, "flag", "0")
			end
				SetSpriteRect(sprite, l, t, w, h)
				SetSpriteRect(introduceframe, ll, tt, ww, hh)
		return	1
	else
		--[[  增大显示区域  ]]-- 
		local l,t,w,h = GetSpriteRect(sprite)
		local ll,tt,ww,hh = GetSpriteRect(introduceframe)
			t = t - 8
			h = h + 8
			tt = tt - 8
			hh = hh + 8
			if t <= 148 then
				--[[  改变区域大小完成，设置falg标志位为0  ]]-- 
				registerSetInteger(regflag, "preflag", flag)
				registerSetInteger(regflag, "flag", "0")
				SetSpriteProperty(introduceframe,"top",0)
			end
				SetSpriteRect(sprite, l, t, w, h)
				SetSpriteRect(introduceframe, ll, tt, ww, hh)
		return 1
	end
end

--@function OnVolumeClick
--@tag-name subject-button
--@tag-action button:OnSelect
--@brief 选择集数完成跳转
function OnVolumeClick(sprite)	
	--SetReturn(sprite)
	--[[  获取全局的标志位 ]]--
	local regflag = registerCreate("buttonclickflag")
	local flag = registerGetInteger(regflag, "flag")
	local preflag = registerGetInteger(regflag, "preflag")
	--[[  只有在详细信息区域为小，并且显示区域不在移动状态时，才做跳转页面 ]]--
	if preflag == 1 and flag == 0 then
		--[[  获得根节点  ]]--  
		local reg = registerCreate("menuprograminfo_label")   
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		
		local reg_g = registerCreate("group")
		registerSetString(reg_g, "scenename","menuprograminfo_label")
		
		local listitem = GetSpriteParent(sprite)
		local index = SpriteListItem_GetIndex(listitem)
		-- sava current item
		local regVideo = registerCreate("video")
		registerSetInteger(regVideo, "groupCurItem", index)
		require("module.menuprograminfo")
		require "module.protocol.protocol_videoloading"
		RequestVideo(101, json.subIds[index].playUrl, GetProgramInfoUrlPath(), json.contentName.." "..json.subIds[index].subName ,"group")
		local reg_p = registerCreate("product")
		registerSetString(reg_p,"playurl",json.subIds[index].playUrl)
		registerSetString(reg_p,"contentid",json.subIds[index].subId)
		--[[  这里应该动态获取点击按钮的具体url  ]]--
		--local volumeurl = "http://c2.cmvideo.cn/sup/data/clt/v2/content.jsp?contentId=4658&channelId=246"
		--http = pluginCreate("HttpPipe", "GetVolume")
		--require "module.protocol.protocol_infovolume"
		--RequestVolume(101, volumeurl)
	end
end

--@function pagechangeOnBtnClick
--@tag-name video-left,video-right
--@tag-action button:OnSelect
--@brief 显示集数面板的翻页功能按钮
function pagechangeOnBtnClick(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_label")   
	local root = registerGetInteger(reg, "root")
	--[[  寻找目标列表  ]]-- 
	local spriteList = FindChildSprite(root, "subject-list")
	local name = GetSpriteName(sprite)
	local start = SpriteList_GetStartItem(spriteList)
	if name == "video-right" then
		if count - start > 16 then
			SpriteList_SetStartItem(spriteList, start+16)
--[[----------------------------------------------------------------------------------]]--	
			local defaultFocusButton=FindChildSprite(SpriteList_GetListItem(spriteList,start+16),"subject-button-"..(start+16))
			SetSpriteFocus(defaultFocusButton)
------------------------------------------------------------------------------------------		
			local left = FindChildSprite(GetCurScene(),"video-left")
			SetSpriteEnable(left, 1)
		end
		if count < start + 32 then
			SetSpriteEnable(sprite, 0)
		else
			SetSpriteEnable(sprite, 1)
		end
	else
		if start >= 16 then
			SpriteList_SetStartItem(spriteList, start-16)
--[[----------------------------------------------------------------------------------]]--	
			local defaultFocusButton=FindChildSprite(SpriteList_GetListItem(spriteList,start-16),"subject-button-"..(start-16))
			SetSpriteFocus(defaultFocusButton)
------------------------------------------------------------------------------------------
			local right = FindChildSprite(GetCurScene(),"video-right")
			SetSpriteEnable(right, 1)
		end
		if start - 16 == 0 then
			SetSpriteEnable(sprite, 0)
		else
			SetSpriteEnable(sprite, 1)
		end
	end
end

--@function	loadJsonData
--@brief	从缓存中读取数据，完成数据回填，在bodyBuildChildrenFinished中调用
function loadJsonData()
	--[[  获取根节点 ]]--
	local reg = registerCreate("menuprograminfo_label")   
	local root = registerGetInteger(reg, "root")
	
	if json then
		--[[  数据回填 ]]--
		local sprite = FindChildSprite(root , "info-content-caption")
		SetSpriteProperty(sprite,"text",json.path)
		local sprite = FindChildSprite(root , "distinct-introduce")
		SetSpriteProperty(sprite,"text",json.desc)
		local starlevel = FindChildSprite(root , "starlevel")
		local width1 = math.floor(json.starLevel)*8
		local width2 = (json.starLevel - math.floor(json.starLevel))*12
		SetSpriteRect(starlevel,0,0,width1+width2,12)
		local contentName1 = FindChildSprite(root , "item-video-caption1")
		SetSpriteProperty(contentName1,"text",json.contentName)
		local contentName2 = FindChildSprite(root , "item-video-caption2")
		SetSpriteProperty(contentName2,"text",json.contentName)
		local content = FindChildSprite(root , "item-video-caption3")
		if json.subIds ~= nil then
			SetSpriteProperty(content,"text","共"..(table.maxn(json.subIds)+1).."集")
		end
		--[[  设置海报图片内容  ]]--  
		postpic = FindChildSprite(root, "item-video-caption-postpic")
		SetSpriteProperty(postpic, "src", json.img)
	end
end


--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	if message == 101 then
		RequestPlay(scenePrograminfo_label)
	elseif message == 109 then
		local volumeData = OnVolumeDecode()
		FreeVolumeFuncs()
		if volumeData then
			exitLoading()
			local volumeSprite = GetCurScene()
			FreeScene(volumeSprite)
			Go2Scene(scenePrograminfo_volume)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_label, scenePrograminfo_label, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeVolumeFuncs()
	elseif message == 110 then
		require("module.dialog.useDialog")		
		reslut, desc = OnPipeAddMyFav()
		exitLoading()
		setDialogParam("提示", desc, "BT_OK", scenePrograminfo_label, scenePrograminfo_label, GetCurScene())
		Go2Scene(sceneDialog)
	elseif message == 111 then
		local labelData = OnLabelDecode() 
		if labelData then
			exitLoading()
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			Go2Scene(scenePrograminfo_label)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_label, scenePrograminfo_label, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeLabelFuncs()
	elseif message == 112 then
		local listData = OnListDecode() 
		if listData then
			exitLoading()
			local listSprite = GetCurScene()
			FreeScene(listSprite)
			Go2Scene(scenePrograminfo_list)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_label, scenePrograminfo_label, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeListFuncs()
	elseif message > 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", scenePrograminfo_label, scenePrograminfo_label, GetCurScene())
		Go2Scene(sceneDialog)
	elseif MSG_SMS_ID == message then
		DealMsgContent(scenePrograminfo_label, scenePrograminfo_label)
	end
	return 1
end

--[[-----------------------------------修改人：yaoxiangyin 修改时间：2010.8.18------------------------------------------------]]--
--组节目集数区域
function menuLabelButtonSubjectKeyUp(sprite,keyCode)
	local reg = registerCreate("menuprograminfo_label")
	registerSetInteger(reg,"menulabelFocusSprite",sprite)  --解决对话框后丢失焦点问题
	registerSetNumber(reg,"lastFocusFlag",1)
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	local subjectList={}  --存放列表项中的Button名
	local spriteList =GetParentSprite(GetParentSprite(sprite)) --subject-list节点
	local spriteRightArrow=FindChildSprite(GetSpriteParent(spriteList),"video-right")   --与subject-list节点平级的向右翻页按钮
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(spriteList), "video-left")    --与subject-list节点平级的向左翻页按钮
	
	local subjectName = GetSpriteName(sprite)
	local subjectFocusNum
	
	local itemCount=SpriteList_GetListItemCount(spriteList)
	for j=0,itemCount-1 do
		subjectList[j]="subject-button-"..j
	end
	local pageNum=math.ceil(itemCount/16) --总页数
	
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if subjectList[i]==subjectName then
	    subjectFocusNum=i
	  end
	end
	
	local downPositionFlag=0  --当前位置是否在下段标志0表示否，1表示是
	local upPositionFlag=0    --当前位置是否在上段标志0表示否，1表示是
	for i=0,pageNum-1 do
		if subjectFocusNum>=i*16+12 and subjectFocusNum<=i*16+15 then
			downPositionFlag=1
			break
		elseif subjectFocusNum>=i*16 and subjectFocusNum<=i*16+3 then
			upPositionFlag=1
			break
		end
	end
	
	local lineNum=math.ceil(itemCount/4) --总行数
	
	local rightEdgeFalg=0 --当前位置是否在右边缘标志0表示否，1表示是
	local leftEdgeFalg=0  --当前位置是否在左边缘标志0表示否，1表示是
	for i=0,lineNum-1 do
		if subjectFocusNum==i*4+3 then
			rightEdgeFalg=1
			break
		elseif subjectFocusNum==i*4 then
			leftEdgeFalg=1
			break
		end
	end
	
	local menuprograminfoSprite=GetSpriteParent(GetSpriteParent(spriteList))   --menuprograminfo节点
	
	if keyCode== ApKeyCode_Right then
		if rightEdgeFalg==0 then --组节目集数区域内向右移动
			if subjectList[subjectFocusNum+1]~=nil then
				local sprite1=FindChildSprite(spriteList,subjectList[subjectFocusNum+1])
				SetSpriteFocus(sprite1)
			end
		elseif rightEdgeFalg==1 then --组节目集数区域内右边界操作
			if registerGetInteger(reg,"subjectPageIndex")<pageNum-1 then
			registerSetNumber(reg,"subjectPageIndex",(registerGetInteger(reg,"subjectPageIndex")+1))
			pagechangeOnBtnClick(spriteRightArrow)
			end
		end
	elseif keyCode== ApKeyCode_Left then
		if leftEdgeFalg==0 then --组节目集数区域内向左移动
			if subjectList[subjectFocusNum-1]~=nil then
				local sprite1=FindChildSprite(spriteList,subjectList[subjectFocusNum-1])
				SetSpriteFocus(sprite1)
			end
		elseif leftEdgeFalg==1 then
			if registerGetInteger(reg,"subjectPageIndex")>0 then
			registerSetNumber(reg,"subjectPageIndex",(registerGetInteger(reg,"subjectPageIndex")-1))
			pagechangeOnBtnClick(spriteLeftArrow)
			end
		end
		
	elseif keyCode== ApKeyCode_Up then
		if upPositionFlag~=1 then  --组节目集数区域内向上移动
			if subjectList[subjectFocusNum-4]~=nil then 
				local sprite1=FindChildSprite(spriteList,subjectList[subjectFocusNum-4])
				SetSpriteFocus(sprite1)
			end
		elseif upPositionFlag==1 then --上边界操作
			if 	IsSpriteVisible(FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,1),"button-backprogram"))~=0 then
				registerSetInteger(reg, "lastFocus",sprite)
				defaultFocusButton=FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,1),"button-backprogram")
				SetSpriteFocus(defaultFocusButton)
				
			else
				if IsSpriteVisible(FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,1),"button-nextprogram"))~=0 then
				registerSetInteger(reg, "lastFocus",sprite)
				defaultFocusButton=FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,1),"button-nextprogram")
				SetSpriteFocus(defaultFocusButton)
				end
			end
		end
	elseif keyCode== ApKeyCode_Down then
		if downPositionFlag~=1 then  --组节目集数区域内向下移动
			if subjectList[subjectFocusNum+4]~=nil then
				local sprite1=FindChildSprite(spriteList,subjectList[subjectFocusNum+4])
				SetSpriteFocus(sprite1)
			end
		end
	elseif keyCode== ApKeyCode_CharB then
		--registerSetInteger(reg, "lastFocus", sprite)
		local videoBottomButton=FindChildSprite(GetParentSprite(menuprograminfoSprite),"video-bottom")
		showDetailButtonOnSelect(videoBottomButton)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	end
	return 0
end

--节目翻页的两个按钮
function menuLabelButtonProgramKeyUp(sprite, keyCode)
	local reg = registerCreate("menuprograminfo_label")
	registerSetInteger(reg,"menulabelFocusSprite",sprite) --解决对话框后丢失焦点问题
	registerSetNumber(reg,"lastFocusFlag",1)
	local ItemName = GetSpriteName(sprite)
	local defaultFocusButton
	local menuprograminfoSprite=GetParentSprite(GetParentSprite(sprite))
	if keyCode== ApKeyCode_Right and ItemName=="button-backprogram" and IsSpriteVisible(FindChildSprite(GetParentSprite(sprite),"button-nextprogram"))~=0  then
		defaultFocusButton=FindChildSprite(GetParentSprite(sprite),"button-nextprogram")
		SetSpriteFocus(defaultFocusButton)
	elseif keyCode== ApKeyCode_Left and ItemName=="button-nextprogram" and IsSpriteVisible(FindChildSprite(GetParentSprite(sprite),"button-backprogram"))~=0  then
		defaultFocusButton=FindChildSprite(GetParentSprite(sprite),"button-backprogram")
		SetSpriteFocus(defaultFocusButton)
	elseif keyCode== ApKeyCode_Down then
		local defaultFocusButton=registerGetInteger(reg,"lastFocus")
		SetSpriteFocus(defaultFocusButton)
	elseif keyCode== ApKeyCode_CharB then
		--registerSetInteger(reg, "lastFocus", sprite)
		local videoBottomButton=FindChildSprite(GetParentSprite(menuprograminfoSprite),"video-bottom")
		showDetailButtonOnSelect(videoBottomButton)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	end
	return 0
end
----------------------------------------------------------------------------------------------------------------------------------



