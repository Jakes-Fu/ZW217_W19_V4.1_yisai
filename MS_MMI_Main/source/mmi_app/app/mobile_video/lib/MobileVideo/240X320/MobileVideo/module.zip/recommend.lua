﻿--@module recommend
--@note 互动及播放结束界面
--@author cuiyizhou
--@date 2010/05/25
require "module.Loading.useLoading"
require "module.common.SceneUtils"
require "module.common.registerScene"
function bodyBuildChildrenFinished(sprite)
	SetSpriteFocus(FindChildSprite(sprite,"recommendframe-btnarea-replay"))  --默认焦点
	saveTouchFocus(FindChildSprite(sprite,"recommendframe-btnarea-replay"))
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("recommend")   
	registerSetInteger(reg, "root", sprite)
	local regvideo = registerCreate("video")
	local fileName = registerGetString(regvideo, "videoFileName")
	--[[  获取缓存中的数据  ]]--
	json = jsonLoadFile(fileName)
	--[[  创建2个列表信息  ]]--  
	createRelatedRecommends()
	createRelatedVideos()
	local videotype =  registerGetString(regvideo, "videoType")
	local toSetIsReview = registerGetString(regvideo, "toSetIsReview")
	local historyReview = registerGetString(regvideo, "historyReview")
	if (toSetIsReview and toSetIsReview =="true") or historyReview == "true" then
		local downloaddisabled = FindChildSprite(sprite,"recommendframe-btnarea-download")
		local normal = FindChildSprite(downloaddisabled,"normal")
		SetSpriteProperty(normal,"src","file:///image/recommend/ico_xiazai_disable.png")
		SetSpriteEnable(downloaddisabled,0)
		local sharedisabled = FindChildSprite(sprite,"recommendframe-btnarea-share")
		local normal = FindChildSprite(sharedisabled,"normal")
		SetSpriteProperty(normal,"src","file:///image/recommend/ico_fenxiang_disable.png")
		SetSpriteEnable(sharedisabled,0)
	end
	if videotype == "live" then
		local replaydisabled = FindChildSprite(sprite,"recommendframe-btnarea-replay")
		local normal = FindChildSprite(replaydisabled,"normal")
		SetSpriteProperty(normal,"src","file:///image/recommend/ico_chongbo_disable.png")
		SetSpriteEnable(replaydisabled,0)
		local downloaddisabled = FindChildSprite(sprite,"recommendframe-btnarea-download")
		local normal = FindChildSprite(downloaddisabled,"normal")
		SetSpriteProperty(normal,"src","file:///image/recommend/ico_xiazai_disable.png")
		SetSpriteEnable(downloaddisabled,0)
		local sharedisabled = FindChildSprite(sprite,"recommendframe-btnarea-share")
		local normal = FindChildSprite(sharedisabled,"normal")
		SetSpriteProperty(normal,"src","file:///image/recommend/ico_fenxiang_disable.png")
		SetSpriteEnable(sharedisabled,0)
		local defaultBtn=FindChildSprite(sprite,"groupbutton")
		if defaultBtn~=0 then
			SetSpriteFocus(defaultBtn)
			saveTouchFocus(defaultBtn)
		else
			SetSpriteFocus(FindChildSprite(sprite,"recommendframe-btnarea-comment"))
			saveTouchFocus(FindChildSprite(sprite,"recommendframe-btnarea-comment"))
		end
	end
--	local isDownloadDisable =	registerGetInteger(reg, "isDownloadDisable")
--	if isDownloadDisable == 1 then
--		local downloaddisabled = FindChildSprite(sprite,"recommendframe-btnarea-download")
--		local normal = FindChildSprite(downloaddisabled,"normal")
--		SetSpriteProperty(normal,"src","file:///image/recommend/ico_xiazai_disable.png")
--		SetSpriteEnable(downloaddisabled,0)
--	end
	return 1
end

--@function	createRelatedRecommends
--@brief	创建"相关视频"列表中的3个元素，在bodyBuildChildrenFinished中调用
function createRelatedRecommends()
	--[[	获取根节点	]]--
	local reg = registerCreate("recommend")
	local root = registerGetInteger(reg, "root")
	local relatedrecommendssprite = FindChildSprite(root, "recommendframe-relatedrecommends")
	--[[	创建listitem类的节点	]]--
	if json then
		if json.commend2 then
			local xmlNode=xmlLoadFile("MODULE:\\recommend_item.xml")
			for i=0, 2 do
				if json.commend2[i] then
					local relatedrecommendsitem = CreateSprite("listitem")
					SetSpriteProperty(relatedrecommendsitem,"name","correlation")
					--[[	用已有模板中数据填充该节点	]]--
					LoadSpriteFromNode(relatedrecommendsitem, xmlNode)
					SetSpriteRect(relatedrecommendsitem, 0, 0, 220, 21)
					local NormalButtontext = FindChildSprite(relatedrecommendsitem,"NormalButtontext")				
					SetSpriteProperty(NormalButtontext,"text",json.commend2[i].contentName)
					local FocusButtontext = FindChildSprite(relatedrecommendsitem,"FocusButtontext")
					SetSpriteProperty(FocusButtontext,"text",json.commend2[i].contentName)
				
					--[[	把该节点插入到场景中	]]--
					AddChildSprite(relatedrecommendssprite, relatedrecommendsitem)          
					SpriteList_AddListItem(relatedrecommendssprite, relatedrecommendsitem)
					--[[	把第一项设置为焦点	]]--
					shareReg = registerCreate("shareReturn")
					shareFlag = registerGetInteger(shareReg, "shareFlag")
					WriteLogs("shareFlag = "..shareFlag)
					if shareFlag ==1 then
						sprite1=FindChildSprite(root,"recommendframe-btnarea-share")
						SetSpriteFocus(sprite1)	
						saveTouchFocus(sprite1)
					--[[	把第一项设置为焦点	]]--
					elseif i == 0 then
						local groupbuttonSpriteName = FindChildSprite(root,"groupbutton")
						SetSpriteFocus(groupbuttonSpriteName)
						saveTouchFocus(groupbuttonSpriteName)
				  end				
				end
			end
			xmlRelease(xmlNode)
		end
	end
	--[[	自动调整间距	]]--
	SpriteList_Adjust(relatedrecommendssprite)
	return 1
end

--@function	createRelatedVideos
--@brief	创建"看过此节目的用户还看过"列表中的3个元素，在bodyBuildChildrenFinished中调用
function createRelatedVideos()
	--[[	获取根节点	]]--
	local reg = registerCreate("recommend")
	local root = registerGetInteger(reg, "root")
	local relatedrecommendssprite = FindChildSprite(root, "recommendframe-relatedvideos")
	--[[	创建listitem类的节点	]]--
	if json then
		if json.correlation then
			local xmlNode=xmlLoadFile("MODULE:\\recommend_item.xml")
			for i=0, table.maxn(json.correlation) do
				if json.correlation[i] then
					local relatedrecommendsitem = CreateSprite("listitem")
					SetSpriteProperty(relatedrecommendsitem,"name","commend2")
					--[[	用已有模板中数据填充该节点	]]--
					LoadSpriteFromNode(relatedrecommendsitem, xmlNode)
					SetSpriteRect(relatedrecommendsitem, 0, 0, 220, 21)
					local NormalButtontext = FindChildSprite(relatedrecommendsitem,"NormalButtontext")
					SetSpriteProperty(NormalButtontext,"text",json.correlation[i].contentName)
					local FocusButtontext = FindChildSprite(relatedrecommendsitem,"FocusButtontext")
					SetSpriteProperty(FocusButtontext,"text",json.correlation[i].contentName)
					--[[	把该节点插入到场景中	]]--
					AddChildSprite(relatedrecommendssprite, relatedrecommendsitem)          
					SpriteList_AddListItem(relatedrecommendssprite, relatedrecommendsitem)
				end
			end
			xmlRelease(xmlNode)
		end
	end
	--[[	自动调整间距	]]--
	SpriteList_Adjust(relatedrecommendssprite)
	return 1
end

--@function voteOnButtonClick
--@tag-name recommendframe-btnarea-comment
--@tag-action button:OnSelect
--@brief 互动按钮，用户可以评价视屏的功能点
function voteOnButtonClick(sprite)
	ReleaseSpriteCapture(sprite)
	--[[	这里的全局量是互动模板的读取路径，在messagepannel中用到	]]--
	voteReg = registerCreate("voteReturn")
	registerSetInteger(voteReg,"voteFlag",1)
	local messagepannel = registerCreate("messagepannel")
	registerSetString(messagepannel, "loadpath","MODULE:\\vote.xml")
	registerSetString(messagepannel, "returnpath",sceneRecommend)
	registerSetString(messagepannel, "returnpathname","recommend")
	registerSetString(messagepannel, "title","您给这条记录的评价是")
	--[[  获得根节点  ]]--  
	local reg = registerCreate("recommend") 
	local root = registerGetInteger(reg, "root") 
	local MessagePannel = FindChildSprite(root, "MessagePannel") 
	if MessagePannel == 0 or MessagePannel == nil then 
		MessagePannel = CreateSprite("node", root) 
		SetSpriteProperty(MessagePannel,"name","MessagePannel") 
	end
	SetSpriteCapture(MessagePannel)
	--[[  载入  ]]--  
	local menu = CreateSprite("listitem")
 	LoadSprite(menu, 	sceneMessagePanel)
	AddChildSprite(MessagePannel, menu)
	local excelentSpriteName = FindChildSprite(menu,"excelent")
	SetSpriteFocus(excelentSpriteName)
	saveTouchFocus(excelentSpriteName)
end

--@function shareOnButtonClick
--@tag-name recommendframe-btnarea-share
--@tag-action button:OnSelect
--@brief 分享按钮，用户可以把视频分享给好友的功能点
function shareOnButtonClick(sprite)
	ReleaseSpriteCapture(sprite)
	--[[	这里的全局量是互动模板的读取路径，在messagepannel中用到	]]--
	--reg1 = registerCreate("fenxiang")
	--registerSetInteger(reg1, "flag", 1)
	shareReg = registerCreate("shareReturn")
	registerSetInteger(shareReg,"shareFlag",1)
	local messagepannel = registerCreate("messagepannel")
	registerSetString(messagepannel, "loadpath","MODULE:\\share.xml")
	registerSetString(messagepannel, "returnpath",sceneRecommend)
	registerSetString(messagepannel, "returnpathname","recommend")
	registerSetString(messagepannel, "title","推荐好友")
	--[[  获得根节点  ]]--  
	local reg = registerCreate("recommend") 
	local root = registerGetInteger(reg, "root") 
	local MessagePannel = FindChildSprite(root, "MessagePannel") 
	
	if MessagePannel == 0 or MessagePannel == nil then 
		MessagePannel = CreateSprite("node", root) 
		SetSpriteProperty(MessagePannel,"name","MessagePannel") 
	end
	SetSpriteCapture(MessagePannel)
	--[[  载入  ]]--  
	local menu = CreateSprite("listitem")
 	LoadSprite(menu, 	sceneMessagePanel)
	AddChildSprite(MessagePannel, menu)
	local testEditSprite = FindChildSprite(menu,"testEdit")
	SetSpriteFocus(testEditSprite)
	saveTouchFocus(sprite)
end

--@function replayOnSelect
--@tag-name recommendframe-btnarea-replay
--@tag-action button:OnSelect
--@brief 用户点击重播
function replayOnSelect(sprite)
	ReleaseSpriteCapture(sprite)
	local reg = registerCreate("video")
	local toSetIsReview = registerGetString(reg, "toSetIsReview")
	if toSetIsReview and toSetIsReview == "true" then
		registerSetString(reg, "IsReview","true")
	else
		registerSetString(reg, "IsReview","")
	end	
	registerSetString(reg, "toSetIsReview", "")
	--是否是重播
	registerSetString(reg, "isReplay", "true")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin ~= 0 then
		pluginInvoke(MediapalyPlugin, "Stop")
	end
	FreeScene(recommendSprite)
	local videotype = registerGetString(reg,"videoType")
	if videotype == "group" then
		Go2Scene(sceneVideoGroup)
	else
		Go2Scene(sceneVideoLiveDemand)
	end
end

--@function downloadOnSelect
--@tag-name recommendframe-btnarea-share
--@tag-action button:OnSelect
--@brief 下载按钮，转到正在下载
function downloadOnSelect(sprite)
	ReleaseSpriteCapture(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("recommend")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg2 = registerCreate("menuprograminfo_volume")
	local reg_v = registerCreate("video")
	local videotype = registerGetString(reg_v,"videoType")
	--[[  下载标志位  ]]--  
	downloadReg = registerCreate("downloadReg")
	registerSetInteger(downloadReg,"downloadFlag",1)
	WriteLogs("downloadFlag ="..registerGetInteger(downloadReg,"downloadFlag"))
	if videotype == "group" then
		FreeScene(GetCurScene())
		Go2Scene(sceneDownloadSelect)
	else 
		--[[  获取缓存中的数据  ]]--
		local volumeUrlFileName = registerGetString(reg2, "volumeUrlFileName")
		local jsondownload
		if volumeUrlFileName then
			jsondownload = jsonLoadFile(volumeUrlFileName)
		end
		if jsondownload then
			--[[  这里应该动态获取点击按钮的具体url  ]]--
			local downUrl = jsondownload.downUrl
			if downUrl == "" then
				setDialogParam("提示", "获取下载地址失败", "BT_OK", sceneRecommend, sceneRecommend)
				Go2Scene(sceneDialog)
			else				
				--[[  显示loading场景  ]]--
				enterLoading(loadarea)
				require "module.protocol.protocol_videoloading"
				RequestDownloadVideo(107, downUrl)
			end
		end
	end
	return 1
end

--@function listItemOnButtonClick
--@tag-name groupbutton in recommend-item
--@tag-action button:OnSelect
--@brief 列表按钮，跳转
function listItemOnButtonClick(sprite)
	local listitem = GetSpriteParent(sprite)
	local name = GetSpriteName(listitem)
	local url
	if name == "correlation" then
		if json.commend2 then
			url = json.commend2[SpriteListItem_GetIndex(listitem)].urlPath
		end
	elseif name == "commend2" then 
		if json.correlation then
			url = json.correlation[SpriteListItem_GetIndex(listitem)].urlPath
		end
	end
	--[[  获得根节点  ]]--  
	local reg = registerCreate("recommend")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	require "module.protocol.protocol_infovolume"
	enterLoading(loadarea)
	RequestVolume(111, url)
	local reg_v= registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg_v, "MediapalyPlugin")
	pluginInvoke(MediapalyPlugin, "Stop")
end

function OnSpriteEvent2(message, params)
	if message == 1001 then
		if overwriteflag == 1 then
			require("module.setting")
			os.remove(Cfg.GetDownloadPath()..videoData.urls[0].name..Cfg.GetVideoType())
	    local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name,1)
	    if result == -1 then
				SetTimer(2, 1000, "OnTimer")
			else
				SetTimer(1, 1000, "OnTimer")
			end
		elseif overwriteflag == 2 then
			require "module.common.DownloadUpload"
			PauseOneDownloadTask(videoData.urls[0].name, 1)
			local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name,1)
			SetTimer(1, 1000, "OnTimer")
		end
	end	
end

function OnTimer(idEvent)
	if idEvent == 1 then
		setDialogParam("提示", "已经添加到下载队列", "BT_OK", sceneRecommend, sceneRecommend, GetCurScene())
		Go2Scene(sceneDialog)
		tempDownloadReg = registerCreate("tempDownloadReg")
		registerSetInteger(tempDownloadReg,"tempDownloadFlag",1)
	end
end

--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	--[[	获取根节点	]]--
	local reg = registerCreate("recommend")
	local root = registerGetInteger(reg, "root")
	local downloadSprite = FindChildSprite(root,"recommendframe-btnarea-download")
	if HasSpriteFocus(downloadSprite) == 1 then
		KillSpriteFocus(downloadSprite)
	end
	if message == 107 then
		WriteLogs("in in in in 107")
		videoData = OnDownloadVideoDecode()
		--local downloadSprite = FindChildSprite(root,"recommendframe-btnarea-download")
		--KillSpriteFocus(downloadSprite)
		if videoData then
			exitLoading()
			if videoData.success == "true" then
				require "module.protocol.protocol_downloadinfor"
				require "module.dialog.useDialog"
				require "module.setting"
				local path = Cfg.GetDownloadPath()
				local dir = OpenDirectory(path..videoData.urls[0].name..".3gp")
				if dir then
					local reg = registerCreate("recommend")   
					local root = registerGetInteger(reg, "root")
					local spriteEvent = FindChildSprite(root, "event")
					setDialogParam("提示", "该文件已存在，是否需要覆盖下载", "BT_OK_CANCEL", sceneRecommend, sceneRecommend, spriteEvent)
					overwriteflag = 1
					Go2Scene(sceneDialog)
				else
					if videoData.urls[0].url and videoData.urls[0].url ~= "" then
						local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name)
						if result == -1 then
							local reg_r = registerCreate("recommend")   
							local root_r = registerGetInteger(reg_r, "root") 
							local spriteEvent = FindChildSprite(root_r, "event")
							setDialogParam("提示", "该任务已存在,是否需要覆盖下载?", "BT_OK_CANCEL", sceneRecommend, sceneRecommend, spriteEvent)
							overwriteflag = 2
							Go2Scene(sceneDialog)
						else
							setDialogParam("提示", "文件已经添加到下载队列", "BT_OK", sceneRecommend, sceneRecommend, GetCurScene())
							Go2Scene(sceneDialog)
							tempDownloadReg = registerCreate("tempDownloadReg")
							registerSetInteger(tempDownloadReg,"tempDownloadFlag",1)
						end
					else
						setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneRecommend, sceneRecommend, GetCurScene())
						Go2Scene(sceneDialog)
					end
				end
			else
				if videoData.feeds then
					local regv = registerCreate("video")
					local filename = registerGetString(regv, "videoDownloadFileName")
					local regp = registerCreate("productorder")
					registerSetString(regp,"fileName",filename)
					registerSetString(regp,"returntype","download")
					SetReturn(sceneRecommend,sceneOrderProduct)
					Go2Scene(sceneOrderProduct)
					FreeVideoLoadingFuncs()
				else
					setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume, GetCurScene())
					Go2Scene(sceneDialog)
				end
			end
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneRecommend, sceneRecommend, GetCurScene())
			Go2Scene(sceneDialog)
		end
	end
	if message == 111 then
		local volumeData = OnVolumeDecode() 
		if volumeData then
			exitLoading()
			local recommendSprite = GetCurScene()
			FreeScene(recommendSprite)
			GoAndFreeScene(scenePrograminfo_volume)
			local productHandle = FindScene(sceneProduct)
			if productHandle == 0 then
				SetReturn(sceneHome,scenePrograminfo_volume)
			else
				SetReturn(sceneProduct,scenePrograminfo_volume)
			end
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneRecommend, sceneRecommend, GetCurScene())
			Go2Scene(sceneDialog)
		end
	elseif MSG_SMS_ID == message then			
		DealMsgContent(sceneRecommend, sceneRecommend)
	elseif message > 32768 and message ~= MSG_SMS_ID + 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneRecommend, sceneRecommend, nil)
		Go2Scene(sceneDialog)		
	end
	return 1
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	require("module.common.commonMsg")
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_MINIMIZED then
		local shareSprite = FindChildSprite(GetCurScene(), "recommendframe-btnarea-share")
		if shareSprite ~= 0 then
			ReleaseSpriteCapture(shareSprite)
		end
		local addrlistSprite = FindChildSprite(GetCurScene(), "addrlist") 
		if addrlistSprite ~= 0 then
			ReleaseSpriteCapture(addrlistSprite)
		end
		elseif message == MSG_DEACTIVATE then
		if localflag and localflag == 1 then
			localflag = nil
		else
			local reg = registerCreate("video")
			local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
			pluginInvoke(MediapalyPlugin, "Stop")
		end
	elseif message == MSG_RETURN then
		local reg = registerCreate("video")
		local toSetIsReview = registerGetString(reg, "toSetIsReview")
		if toSetIsReview and toSetIsReview == "true" then
			registerSetString(reg, "IsReview","true")
		else
			registerSetString(reg, "IsReview","")
		end	
		registerSetString(reg, "toSetIsReview", "")
		FreeScene(GetCurScene())
		localflag = 1
	elseif message == MSG_ACTIVATE then
		local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
		registerSetString(SceneReg,"SceneName","recommend")
		--[[  设置互动节目标题  ]]--
		local reg = registerCreate("recommend")   
		local rootSprite=registerGetInteger(reg, "root")
		local regvideo = registerCreate("video")
		local videoName1Sprite=FindChildSprite(rootSprite,"videoName1")
		local videoName2Sprite=FindChildSprite(rootSprite,"videoName2")
		SetSpriteProperty(videoName1Sprite, "text",registerGetString(regvideo,"videoName"))
		SetSpriteProperty(videoName2Sprite, "text",registerGetString(regvideo,"videoName"))
	end
end

function listItemKeyUp(sprite, keyCode)
	require "module.keyCode.keyCode"
	local regvideo = registerCreate("video")
	local videotype =  registerGetString(regvideo, "videoType")
	WriteLogs("in LISTITEMKEYUP")
	local reg = registerCreate("recommend")
	registerSetInteger(reg, "lastFocus",sprite)
	registerSetInteger(reg, "lastFocusFlag",1)
	------------------ksw----------------------------------
	local ToMesReg = registerCreate("ToMesReg")
	registerSetInteger(ToMesReg,"ToMesFocus",sprite)
	---------------------------------------------------------
	
	--------------------------------------------ksw------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	--------------------------------------------ksw-----------------------------------------------
	if GetSpriteName(sprite) and GetSpriteName(sprite)=="recommendframe-btnarea-share" then
		local mesCnlRtnReg =registerCreate("mesCnlRtn")
		registerSetInteger(mesCnlRtnReg,"mesCnlRtnFocus",sprite)
	end
---------------------------------------------------------------------------------------------------	
	
	local root = registerGetInteger(reg, "root")
	local VoteSprite = FindChildSprite(root,"recommendframe-btnarea-comment")
	if keyCode == ApKeyCode_Enter then
		
		return 0
	end
	if keyCode == ApKeyCode_F2 then
		WriteLogs("in F2")
		voteReg = registerCreate("voteReturn")
		voteFlag = registerGetInteger(voteReg,"voteFlag")
		if VoteFlag and VoteFlag == 1 then
			SetSpriteFocus(VoteSprite)
			saveTouchFocus(VoteSprite)
			registerSetInteger(VoteReg,"VoteFlag",0)
		end
	end
	--获取根节点
	
	--找到连个list的节点
	local relatedrecommendsList = FindChildSprite(root,"recommendframe-relatedrecommends")
	local relatedvideosList = FindChildSprite(root,"recommendframe-relatedvideos")	

	--获取sprite所在的item节点
	listItemButtonSprite= GetParentSprite(sprite)
	-- 通过Item获取index
	local index = SpriteListItem_GetIndex(listItemButtonSprite)
	--第二个列表的的项数
	relatedvideosListItemCount = SpriteList_GetListItemCount(relatedvideosList)
	WriteLogs("relatedvideosListItemCount="..relatedvideosListItemCount)
	
	--获取当前list的项数
	ListItemCount = SpriteList_GetListItemCount(GetParentSprite(listItemButtonSprite))
	WriteLogs("ListItemCount"..ListItemCount)
	--第一个列表的项数
	recommendListItemCount = SpriteList_GetListItemCount(relatedrecommendsList)
	--获取item的父节点，加以限制
	limitSprite = GetParentSprite(listItemButtonSprite)
	limitSpriteName = GetSpriteName(limitSprite)
	--向下
	if keyCode == ApKeyCode_F1 and LoadingFlag() then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)	
	end
	if keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	if keyCode == ApKeyCode_Down and json and json.commend2 and json.commend2[0] then
		if index < ListItemCount-1 then
			local listSprite=SpriteList_GetListItem(GetParentSprite(listItemButtonSprite),index+1) --the node is list
			if IsSpriteVisible(listSprite) == 0 then
				for i=index+2,ListItemCount-1 do
					local listSprite2=SpriteList_GetListItem(GetParentSprite(listItemButtonSprite),i)
					if IsSpriteVisible(listSprite2) == 1 then
						FocusSprite = FindChildSprite(listSprite2,"groupbutton")
						SetSpriteFocus(FocusSprite)
						saveTouchFocus(FocusSprite)
						break
					end
				end
			else
				FocusSprite = FindChildSprite(listSprite,"groupbutton")
				SetSpriteFocus(FocusSprite)
				saveTouchFocus(FocusSprite)
			end
		end
	end
	if keyCode == ApKeyCode_Up then
		if index >= 1 then 
			listSprite=SpriteList_GetListItem(GetParentSprite(listItemButtonSprite),index-1) --the node is list
			FocusSprite = FindChildSprite(listSprite,"groupbutton")
			SetSpriteFocus(FocusSprite)
			saveTouchFocus(FocusSprite)
		end
		if index ==0 and GetSpriteName(sprite)=="groupbutton" and limitSpriteName == "recommendframe-relatedrecommends"  then
			if videotype ~= "live" then
				local replayButtonSprite = FindChildSprite(root,"recommendframe-btnarea-replay")
				if IsSpriteEnable(replayButtonSprite) == 1 then
					SetSpriteFocus(replayButtonSprite)
					saveTouchFocus(replayButtonSprite)
				end
			else
				local shareButtonSprite = FindChildSprite(root,"recommendframe-btnarea-share")
				if IsSpriteEnable(shareButtonSprite) == 1 then
					SetSpriteFocus(shareButtonSprite)
					saveTouchFocus(shareButtonSprite)
				else
					local commentButtonSprite = FindChildSprite(root,"recommendframe-btnarea-comment")
					if IsSpriteEnable(commentButtonSprite) == 1 then
						SetSpriteFocus(commentButtonSprite)
						saveTouchFocus(commentButtonSprite)
					end
				end
			end
		end
		if index ==0 and GetSpriteName(sprite)=="groupbutton" and limitSpriteName ~= "recommendframe-relatedrecommends"  then
			local listSprite=SpriteList_GetListItem(relatedrecommendsList,recommendListItemCount-1)
			FocusSprite = FindChildSprite(listSprite,"groupbutton")
			SetSpriteFocus(FocusSprite)
			saveTouchFocus(FocusSprite)
		end
	end
	topSprite = GetSpriteName(sprite)
	if topSprite == "recommendframe-btnarea-replay" and keyCode == ApKeyCode_Right then
		local shareButtonSprite = FindChildSprite(root,"recommendframe-btnarea-share")
		if IsSpriteEnable(shareButtonSprite) == 1 then
			SetSpriteFocus(shareButtonSprite)
			saveTouchFocus(shareButtonSprite)
		else
			local commentButtonSprite = FindChildSprite(root,"recommendframe-btnarea-comment")
			if IsSpriteEnable(commentButtonSprite) == 1 then
				SetSpriteFocus(commentButtonSprite)
				saveTouchFocus(commentButtonSprite)
			else
				local downloadButtonSprite = FindChildSprite(root,"recommendframe-btnarea-download")
				if IsSpriteEnable(downloadButtonSprite) == 1 then
					SetSpriteFocus(downloadButtonSprite)
					saveTouchFocus(downloadButtonSprite)
				end
			end
		end
	end
	if topSprite == "recommendframe-btnarea-share" then
		if keyCode == ApKeyCode_Right then
			local commentButtonSprite = FindChildSprite(root,"recommendframe-btnarea-comment")
			if IsSpriteEnable(commentButtonSprite) == 1 then
				SetSpriteFocus(commentButtonSprite)
				saveTouchFocus(commentButtonSprite)
			else
				local downloadButtonSprite = FindChildSprite(root,"recommendframe-btnarea-download")
				if IsSpriteEnable(downloadButtonSprite) == 1 then
					SetSpriteFocus(downloadButtonSprite)
					saveTouchFocus(downloadButtonSprite)
				end
			end
		end
		if keyCode == ApKeyCode_Left then
			if videotype ~= "live" then
				local replayButtonSprite = FindChildSprite(root,"recommendframe-btnarea-replay")
				if IsSpriteEnable(replayButtonSprite) then
					SetSpriteFocus(replayButtonSprite)
					saveTouchFocus(replayButtonSprite)
				end
			end
		end
	end
	local videotype =  registerGetString(regvideo, "videoType")
	if topSprite == "recommendframe-btnarea-comment" then
		if keyCode == ApKeyCode_Right then
			if videotype ~= "live" then
				local downloadButtonSprite = FindChildSprite(root,"recommendframe-btnarea-download")
				if IsSpriteEnable(downloadButtonSprite) == 1 then
					SetSpriteFocus(downloadButtonSprite)
					saveTouchFocus(downloadButtonSprite)
				end
			end
		end
		if keyCode == ApKeyCode_Left then
			local shareButtonSprite = FindChildSprite(root,"recommendframe-btnarea-share")
			if IsSpriteEnable(shareButtonSprite) == 1 then
				SetSpriteFocus(shareButtonSprite)
				saveTouchFocus(shareButtonSprite)
			else
				if videotype ~= "live" then
					local replayButtonSprite = FindChildSprite(root,"recommendframe-btnarea-replay")
					if IsSpriteEnable(replayButtonSprite) then
						SetSpriteFocus(replayButtonSprite)
						saveTouchFocus(replayButtonSprite)
					end
				end
			end
		end
	end
	if topSprite == "recommendframe-btnarea-download" and keyCode == ApKeyCode_Left then
		local commentButtonSprite = FindChildSprite(root,"recommendframe-btnarea-comment")
		if IsSpriteEnable(commentButtonSprite) == 1 then
			SetSpriteFocus(commentButtonSprite)
			saveTouchFocus(commentButtonSprite)
		else
			local shareButtonSprite = FindChildSprite(root,"recommendframe-btnarea-share")
			if IsSpriteEnable(shareButtonSprite) == 1 then
				SetSpriteFocus(shareButtonSprite)
				saveTouchFocus(shareButtonSprite)
			else
				if videotype ~= "live" then
					local replayButtonSprite = FindChildSprite(root,"recommendframe-btnarea-replay")
					if IsSpriteEnable(replayButtonSprite) then
						SetSpriteFocus(replayButtonSprite)
						saveTouchFocus(replayButtonSprite)
					end
				end
			end
		end
	end
	--local ReturnFocus = sprite
	--recommendReg = registerCreate("recommendReg")
	--registerSetInteger(recommendReg,"ReturnFocusFlag",ReturnFocus)
end
