
function RequestSysTime(protocolNumber)
	require "module.setting"
	local sysTimeUrl = Cfg.GetServer()..Cfg.GetPortal().."/data/clt/v2/sysDate.jsp"
	local reg = registerCreate("sysTime")
	local fileName = GetLocalFilename(sysTimeUrl)
	WriteLogs("SysTimeCacheFileName = "..fileName)
	registerSetString(reg, "sysTimeFileName", fileName)
	--[[  ����httppipe�������ȡ��������  ]]--
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, sysTimeUrl, 0, fileName, observer, protocolNumber, 0, 1)
end

function OnSysDataDecode()
	local reg = registerCreate("sysTime")
	local fileName = registerGetString(reg, "sysTimeFileName")
	if fileName ~= nil and fileName ~= "" then
		return jsonLoadFile(fileName)
	end
	return nil
end