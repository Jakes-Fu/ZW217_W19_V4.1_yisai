﻿--@module	uploadingInfor
--@note	用于正在上传界面的UI显示
--@author	shenyi
--@date	2010/06/03
require("module.common.SceneUtils")
require "module.common.commonScroll"
require("module.keyCode.keyCode")
uploadingInfor_UploadHeight = 72
uploadingInfor_PausedHeight = 48
uploadingInfor_NormalHeight = 25
uploadingInfor_ItemWidth = 222
uploadingInfor_FirButtonPosX = 168
uploadingInfor_FirButtonPosY = 2
uploadingInfor_FirButtonWidth = 33
uploadingInfor_FirButtonHeight = 19
uploadingInfor_ProgressWidth = 109

status={2,2,0,1,0,1,2,1,0,1}
textlist={"记录新中国的48个瞬间","喜洋洋与灰太郎之牛气冲天","全球高科技武器大集合","自然界最凶残动物排行榜","喜洋洋与灰太郎之牛气冲天","世界奇人怪人大聚会","全球高科技武器大集合","自然界最凶残动物排行榜","记录新中国的48个瞬间","自然界最凶残动物排行榜" }
--uploadcount = 7
--totalheight = uploadcount*25+47
--curIndex = 0
prevSelectSprite = nil
itemCount = nil
uploadTime = {}
entercount = 1

task={}

--上传文件类型
UPLOAD_FILE_TYPE = "3gp"

--界面上上传状态更新的时间间隔
UPLOADING_SHOW_STATUS_INTERVAL = 1200 -- ms

UPLOADING_TIMER_ID = 1;

--上个时间片的上传大小
preTimerSize = {}
--初次进入上传大小
initTimerSize = {}
totalTime = {}
initFinish = {}
uploadingIndex=0
IdleIndex=0
hasUploadingFlag=0

--@tag-action	body:BuildChildrenFinished
--@brief	创建正在上传
function bodyBuildChildrenFinished(sprite)

	local reg = registerCreate("uploading")
	registerSetInteger(reg, "root", sprite)	
		
	--LoadQuickLauncherBar(sprite)
	local reg1 = registerCreate("System")
	upload = registerGetInteger(reg1,"Upload")	
	if upload == 0 then
		upload = pluginCreate("Upload")
	end
	
	local reg = registerCreate("uploadinfor")
	
	SetTimer( 2, 1, "FirstOnTimer")
		
	return 1
	
end

function FirstOnTimer()
	itemCount = updateTaskTable()	
	if itemCount > 0 then
		
		for i=1,itemCount do
			preTimerSize[i] = task[i-1].size/(1024*1024)
			initTimerSize[i] = task[i-1].size/(1024*1024)
			if task[i-1].size < task[i-1].maxsize then
				initFinish[i] = 1
			end
		end
		WriteLogs("bodyBuildChildrenFinished")
		WriteLogs("initTimerSize---"..initTimerSize[1])
		WriteLogs("preTimerSize---"..preTimerSize[1])
		
		totalheight = itemCount*25+47
		local reg = registerCreate("uploading")
		registerSetInteger(reg,"curIndex",-1)
		local sprite = registerGetInteger(reg, "root")			
		
		CreateUploadingInforList(sprite)
		SetTimer( UPLOADING_TIMER_ID, 100, "StatusOnTimer")
		--setUploadingInforData()
	elseif itemCount==0 then
		local reg = registerCreate("uploading")
		itemfocus=FindChildSprite(registerGetInteger(reg, "root"),"empty")
		SetSpriteFocus(itemfocus)
		saveTouchFocus(itemfocus)
	end

	return 1
	
end

--@function	CreateuploadList
--@brief	创建上传列表
function CreateUploadingInforList(sprite)
	local reg = registerCreate("uploading")
	local curIndex = registerGetInteger(reg,"curIndex")
	local spriteList = FindChildSprite(sprite, "uploading-list")
	for i=1,itemCount do 
		if task[i-1].status == "Uploading" then
			if totalTime[i] ~= nil then
				totalTime[i] = totalTime[i] + 1
			else
				totalTime[i] = 1
			end
			curIndex = i-1
		end	
	end
	if curIndex == nil or curIndex == -1 then
		curIndex = 0
	end
	registerSetInteger(reg,"curIndex",curIndex)
	local xmlNode=xmlLoadFile("MODULE:\\uploadingInforList.xml")
	for i=1,itemCount do
		local uploadSprite = CreateSprite("listitem")
		ret = LoadSpriteFromNode(uploadSprite, xmlNode)
		local spriteSel1 = FindChildSprite(uploadSprite,"select1")
		local spriteSel2 = FindChildSprite(uploadSprite,"select2")
		local spriteUnSel = FindChildSprite(uploadSprite,"unselect")

			--WriteLogs("111111111111111")
			SetSpriteVisible(spriteSel1, 0)
			SetSpriteEnable(spriteSel1, 0)
			SetSpriteVisible(spriteSel2, 0)
			SetSpriteEnable(spriteSel2, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)
			SetSpriteRect(uploadSprite, 0, 0, uploadingInfor_ItemWidth, uploadingInfor_NormalHeight)
			if task[i-1].status == "Uploading"  then
				uploadingIndex=i-1
			elseif task[i-1].status == "Idle" or task[i-1].status == "Seeking" then
				IdleIndex=i-1
			end
		local spriteText = FindChildSprite(uploadSprite,"item-text")
		local spriteText1 = FindChildSprite(uploadSprite,"item-text1")
		local spriteText2 = FindChildSprite(uploadSprite,"item-text2")
		--WriteLogs("textlist[i]"..textlist[i])
				
		SetSpriteProperty(spriteText,"text",task[i-1].title)
		SetSpriteProperty(spriteText1,"text",task[i-1].title)
		SetSpriteProperty(spriteText2,"text",task[i-1].title)
		
		local spriteImage = FindChildSprite(uploadSprite,"image-select")
		
		--WriteLogs("spriteImage"..spriteImage)
		if task[i-1].status == "Idle" or task[i-1].status == "Seeking" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])				
		elseif task[i-1].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
		elseif task[i-1].status == "Uploading" then
			SetSpriteProperty(spriteImage,"src",imagelist[3])
		elseif task[i-1].status == "Failed" then
			SetSpriteProperty(spriteImage,"src",imagelist[5])			
		end			
		
		AddChildSprite(spriteList, uploadSprite)
		SpriteList_AddListItem(spriteList, uploadSprite)
	end
	xmlRelease(xmlNode)
	local uploadingIndex = 0
	for i=1,itemCount do 
		if task[i-1].status == "Uploading" then
			uploadingIndex = i-1
			if totalTime[i] ~= nil then
				totalTime[i] = totalTime[i] + 1
			else
				totalTime[i] = 1
			end
		end	
	end	
	--curIndex = 0
	UpdateSelectItemData()
	SpriteList_Adjust(spriteList)
	uploadlist=spriteList
	local itemCount=SpriteList_GetListItemCount(uploadlist)
	local extendIndex
	if not uploadingIndex then
		extendIndex=IdleIndex
	else
		extendIndex=uploadingIndex
		hasUploadingFlag=1
	end
	local spriteItem = SpriteList_GetListItem(spriteList,extendIndex)
	registerSetInteger(reg,"curIndex",extendIndex)
	
	local itemfocus= FindChildSprite(spriteItem,"unselect")
	local itemfocus = FindChildSprite(itemfocus,"item-button1")
	SetSpriteFocus(itemfocus)
	saveTouchFocus(itemfocus)
	CreateScrollBar(sprite,"uploading-list",(itemCount-1)*uploadingInfor_NormalHeight+uploadingInfor_PausedHeight,76)
	ScrollBarAdjust(0,3,0)
	uploadButtonOnKeyUp(itemfocus,ApKeyCode_Enter)
end

--@function	setUploadSelectData
--@brief	设置正在上传数据
imagelist = {"file:///image/Uploading/ico_3.png","file:///image/Uploading/ico_2.png","file:///image/Uploading/ico_scgl.png","file:///image/Uploading/ico_4.png","file:///image/Uploading/ico_5.png"}

function setUploadingInforData()
	WriteLogs("setUploadingInforData")
	local reg = registerCreate("uploading")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite,"uploading-list")
	WriteLogs("spriteList"..spriteList)
	
	for i = 1,itemCount do
		spriteItem = SpriteList_GetListItem(spriteList, i-1)
		WriteLogs("spriteItem"..spriteItem)
		
		local spriteSel1 = FindChildSprite(spriteItem,"select1")
		local spriteSel2 = FindChildSprite(spriteItem,"select2")
		local spriteUnSel = FindChildSprite(spriteItem,"unselect")
		
		local spriteText = FindChildSprite(spriteItem,"item-text")
		local spriteText1 = FindChildSprite(spriteItem,"item-text1")
		local spriteText2 = FindChildSprite(spriteItem,"item-text2")
		--WriteLogs("textlist[i]"..textlist[i])
		
		
		SetSpriteProperty(spriteText,"text",task[i-1].title)
		SetSpriteProperty(spriteText1,"text",task[i-1].title)
		SetSpriteProperty(spriteText2,"text",task[i-1].title)
		
		local spriteImage = FindChildSprite(spriteItem,"image-select")
		
		--WriteLogs("spriteImage"..spriteImage)
		if task[i-1].status == "Idle" or task[i-1].status == "Seeking" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])				
		elseif task[i-1].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
		elseif task[i-1].status == "Uploading" then
			SetSpriteProperty(spriteImage,"src",imagelist[3])
		elseif task[i-1].status == "Failed" then
			SetSpriteProperty(spriteImage,"src",imagelist[5])			
		end	
	
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteSel2, 0)
		SetSpriteEnable(spriteSel2, 0)
		SetSpriteVisible(spriteUnSel, 1)			
		SetSpriteEnable(spriteUnSel, 1)
		SetSpriteRect(spriteItem, 0, 0, uploadingInfor_ItemWidth, uploadingInfor_NormalHeight)			
	
	end
	SpriteList_Adjust(spriteList)
end

function iuploadButtonOnSelect(sprite)
 	SetReturn( sceneUploadingInfo, sceneUpload)
	FreeScene(GetCurScene())	
	Go2Scene(sceneUpload )
end

--@function	itemButtonOnSelect
--@tag-name	item-button
--@tag-action	button:OnSelect
--@brief	用于响应各列表项按钮
function itemButtonOnSelect(sprite)	
	--WriteLogs("1111111111")
	--WriteLogs("prevSelectSprite  "..prevSelectSprite)
	--[[
	if prevSelectSprite ~= nil then
		WriteLogs("itemButtonOnSelect "..prevSelectSprite)
		local spriteSel11 = FindChildSprite(prevSelectSprite,"select1")
		local spriteSel12 = FindChildSprite(prevSelectSprite,"select2")
		local spriteUnSel1 = FindChildSprite(prevSelectSprite,"unselect")
		SetSpriteVisible(spriteSel11, 0)
		SetSpriteEnable(spriteSel11, 0)
		SetSpriteVisible(spriteSel12, 0)
		SetSpriteEnable(spriteSel12, 0)		
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(prevSelectSprite, 0, 0, uploadingInfor_ItemWidth, uploadingInfor_NormalHeight)
	end
	]]--
	--WriteLogs("aaaaaaaaaa")
	
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "uploading-list")
	for i=0,(SpriteList_GetListItemCount(spriteList)-1) do
		local toUnselItem= SpriteList_GetListItem(spriteList,i)
		local spriteSel11 = FindChildSprite(toUnselItem,"select1")
		local spriteSel12 = FindChildSprite(toUnselItem,"select2")
		local spriteUnSel1 = FindChildSprite(toUnselItem,"unselect")
		SetSpriteVisible(spriteSel11, 0)
		SetSpriteEnable(spriteSel11, 0)
		SetSpriteVisible(spriteSel12, 0)
		SetSpriteEnable(spriteSel12, 0)		
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(toUnselItem, 0, 0, uploadingInfor_ItemWidth, uploadingInfor_NormalHeight)
		local spriteImage = FindChildSprite(toUnselItem,"image-select")
		if task[i].status == "Idle" or task[i-1].status == "Seeking" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])				
		elseif task[i].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
		elseif task[i].status == "Uploading" then
			SetSpriteProperty(spriteImage,"src",imagelist[3])
		elseif task[i].status == "Failed" then
			SetSpriteProperty(spriteImage,"src",imagelist[5])			
		end	
	end
	
	local spriteParent = GetSpriteParent(sprite)
	local spriteupload = GetSpriteParent(spriteParent)
	local spriteSel21 = FindChildSprite(spriteupload,"select1")
	local spriteSel22 = FindChildSprite(spriteupload,"select2")
	local spriteUnSel2 = FindChildSprite(spriteupload,"unselect")
		
	local index = SpriteListItem_GetIndex(spriteupload)
	--WriteLogs("select idnex "..index)
	if task[index].status == "Idle" or task[index].status == "Seeking" or task[index].status == "Paused" or task[index].status == "Failed" then
		local spriteImage = FindChildSprite(spriteupload,"image-select1")
		local spritePercent = FindChildSprite(spriteupload,"percent-text")
		WriteLogs("spriteImage"..spriteImage)
		WriteLogs("spritePercent"..spritePercent)
		--WriteLogs("status[index]"..status[index])
		
		if task[index].status == "Idle" or task[index].status == "Seeking" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])
			SetSpriteProperty(spritePercent, "text","")					
		elseif task[index].status == "Paused" then
			SetSpriteProperty(spriteImage,"src",imagelist[2])
			SetSpriteProperty(spritePercent, "text","")
		elseif task[index].status == "Failed" then
			SetSpriteProperty(spriteImage,"src",imagelist[4])	
			SetSpriteProperty(spritePercent, "text","")
		end		
		SetSpriteVisible(spriteSel21, 1)
		SetSpriteEnable(spriteSel21, 1)
		SetSpriteVisible(spriteSel22, 0)
		SetSpriteEnable(spriteSel22, 0)
		SetSpriteVisible(spriteUnSel2, 0)			
		SetSpriteEnable(spriteUnSel2, 0)			
		SetSpriteRect(spriteupload, 0, 0, uploadingInfor_ItemWidth, uploadingInfor_PausedHeight)
		
	elseif task[index].status == "uploading" or task[index].status == "Seeking" then
		SetSpriteVisible(spriteSel21, 0)
		SetSpriteEnable(spriteSel21, 0)
		SetSpriteVisible(spriteSel22, 1)
		SetSpriteEnable(spriteSel22, 1)
		SetSpriteVisible(spriteUnSel2, 0)			
		SetSpriteEnable(spriteUnSel2, 0)
		SetSpriteRect(spriteupload, 0, 0, uploadingInfor_ItemWidth, uploadingInfor_UploadHeight)
	end	
	local reg = registerCreate("uploading")
	registerSetInteger(reg,"curIndex",index)	
	UpdateSelectItemData()
	
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "uploading-list")
	WriteLogs("spriteList"..spriteList)
	SpriteList_Adjust(spriteList)
	prevSelectSprite = spriteupload
	
	local index1 = SpriteListItem_GetIndex(prevSelectSprite)+1
	local index2 = SpriteListItem_GetIndex(spriteupload)+1
	if status[index1] == 0 or status[index1] == 1 then
		totalheight = totalheight - 24
	elseif status[index1] == 2 then
		totalheight = totalheight - uploadingInfor_PausedHeight
	end
	if status[index2] == 0 or status[index2] == 1 then
		totalheight = totalheight + 24
	elseif status[index2] == 2 then
		totalheight = totalheight + uploadingInfor_PausedHeight
	end
	
	local spriteImage = FindChildSprite(sprite,"scrollbar-image")
	local spriteScroll = FindChildSprite(sprite,"scroll")
	local spriteSplider = FindChildSprite(sprite,"splider-bar")
	if totalheight <= 223 then
		SetSpriteVisible(spriteImage,0)
		SetSpriteVisible(spriteSplider,0)
		SetSpriteEnable(spriteScroll,0)
		SetSpriteEnable(spriteSplider,0)
	else 
		SetSpriteVisible(spriteImage,1)
		SetSpriteVisible(spriteSplider,1)
		SetSpriteEnable(spriteScroll,1)
		SetSpriteEnable(spriteSplider,1)
	end
end

function operButtonOnSelect(sprite)
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local index = SpriteListItem_GetIndex(spriteItem)
	local reg = registerCreate("uploading")
	registerSetInteger(reg,"curIndex", index)
	if task[index].status == "Paused" then
		local itemCount = updateTaskTable()
		if itemCount > 0 then
			pluginInvoke(upload, "Resume", task[index].id)
		end
	--elseif text == "暂停" then
	elseif task[index].status == "Idle" then
		local itemCount = updateTaskTable()
		if itemCount > 0 then
			pluginInvoke(upload, "Pause", task[index].id)
		end
	end
end

function deleteButtonOnSelect(sprite)
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local index = SpriteListItem_GetIndex(spriteItem)
	
	local itemCount = updateTaskTable()
	local root = GetRootSprite(sprite)
	local spriteEvent = FindChildSprite(root, "event")
	local reg = registerCreate("uploadinfor")
	registerSetInteger(reg,"delindex",index)
	registerSetInteger(reg,"deletebutton",sprite)
	require "module.dialog.useDialog"	
	require "module.common.registerScene"
	setDialogParam("上传管理", "       是否要删除上传任务", "BT_OK_CANCEL",sceneUploadingInfo, sceneUploadingInfo,spriteEvent)
	Go2Scene(sceneDialog)	
end

function pauseButtonOnSelect(sprite)
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local index = SpriteListItem_GetIndex(spriteItem)
	local reg = registerCreate("uploading")
	registerSetInteger(reg,"curIndex", index)
	WriteLogs("pauseButtonOnSelect index "..index)
	local itemCount = updateTaskTable()
	if itemCount > 0 then
		pluginInvoke(upload, "Pause", task[index].id)
	end

end

function deleteButtonOnSelect1(sprite)
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local index = SpriteListItem_GetIndex(spriteItem)
	local reg_u = registerCreate("uploading")
	registerSetInteger(reg_u,"curIndex", index)
	local itemCount = updateTaskTable()
	local root = GetRootSprite(sprite)
	local spriteEvent = FindChildSprite(root, "event")
	local reg = registerCreate("uploadinfor")
	registerSetInteger(reg,"delindex",index)
	registerSetInteger(reg,"deletebutton",sprite)
	require "module.dialog.useDialog"	
	require "module.common.registerScene"
	setDialogParam("上传管理", "       是否要删除上传任务", "BT_OK_CANCEL",sceneUploadingInfo, sceneUploadingInfo,spriteEvent)	
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	registerSetString(SceneReg,"SceneName","uploadingFile") --dw
	Go2Scene(sceneDialog)
end

function UpdateSelectItemData()
	WriteLogs("按钮切换  --dw")
	local reg = registerCreate("uploading")
	local index = registerGetInteger(reg,"curIndex")
	isChanged = registerGetInteger(reg, "isChanged")
	WriteLogs("curIndex ============================ " .. index)
	if index and index ~= -1 then
		local spriteRoot = registerGetInteger(reg, "root")
		local spriteList = FindChildSprite(spriteRoot,"uploading-list")
		for i=1,itemCount do
			local spriteItem = SpriteList_GetListItem(spriteList, i-1)
			local spriteImage = FindChildSprite(spriteItem,"image-select")
			if task[i-1].status == "Idle" or task[i-1].status == "Seeking" then
				SetSpriteProperty(spriteImage,"src",imagelist[1])
			elseif task[i-1].status == "Paused" then
				SetSpriteProperty(spriteImage,"src",imagelist[2])
			elseif task[i-1].status == "Uploading" then
				SetSpriteProperty(spriteImage,"src",imagelist[3])
			elseif task[i-1].status == "Failed" then	
				SetSpriteProperty(spriteImage,"src",imagelist[5])	
			end
		end	
	local spriteItem = SpriteList_GetListItem(spriteList, index)
	local x,y = GetSpriteRect(spriteItem)
	local spriteSel1 = FindChildSprite(spriteItem,"select1")
	local spriteSel2 = FindChildSprite(spriteItem,"select2")
	local spriteUnSel = FindChildSprite(spriteItem,"unselect")
	if task[index].status == "Idle" or task[index].status == "Seeking" or task[index].status == "Paused" or task[index].status == "Failed" then
		if IsSpriteVisible(spriteSel1) == 0 then
			SetSpriteVisible(spriteSel1, 1)
			SetSpriteEnable(spriteSel1, 1)
			SetSpriteVisible(spriteSel2, 0)
			SetSpriteEnable(spriteSel2, 0)
			SetSpriteVisible(spriteUnSel, 0)
			SetSpriteEnable(spriteUnSel, 0)
			SetSpriteRect(spriteItem, x, y, 222, 48)
			if task[index].status == "Idle" then
				SetSpriteFocus(FindChildSprite(spriteSel1,"operbutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"operbutton"))
			elseif task[index].status == "Seeking" then
				SetSpriteFocus(FindChildSprite(spriteSel1,"operbutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"operbutton"))
			elseif task[index].status == "Paused" then
				SetSpriteFocus(FindChildSprite(spriteSel1,"operbutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"operbutton"))
			elseif task[index].status == "Failed" then	
				SetSpriteFocus(FindChildSprite(spriteSel1,"deletebutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"deletebutton"))
			end
		end
		local spriteImage = FindChildSprite(spriteItem,"image-select1")
		local spritePercent = FindChildSprite(spriteItem,"percent-text")
		local spriteImg = FindChildSprite(spriteItem, "oper-img")
		local spriteImg1 = FindChildSprite(spriteItem, "oper-img1")
		
		if task[index].status == "Idle" or task[index].status == "Seeking" then
			SetSpriteProperty(spriteImage,"src",imagelist[1])
			SetSpriteProperty(spritePercent, "text","")				
			SetSpriteProperty(spriteImg, "src", "file:///image/download/zt2.png")
			SetSpriteProperty(spriteImg1, "src", "file:///image/download/zt1.png")
		elseif task[index].status == "Paused" or task[index].status == "Failed" then
			if task[index].status == "Paused" then
				SetSpriteProperty(spriteImage,"src",imagelist[2])
			elseif task[index].status == "Failed" then			
				SetSpriteProperty(spriteImage,"src",imagelist[4])
				local spriteButton = FindChildSprite(spriteItem,"operbutton")
				local spriteDel = FindChildSprite(spriteItem,"deletebutton")
				SetSpriteVisible(spriteButton,0)				
				SetSpriteEnable(spriteButton,0)			
				SetSpriteRect(spriteDel,uploadingInfor_FirButtonPosX,uploadingInfor_FirButtonPosY,uploadingInfor_FirButtonWidth,uploadingInfor_FirButtonHeight)	
			end
			local maxsize = string.format("%.2f",task[index].maxsize/(1024*1024))
			local size = string.format("%.2f",task[index].size/(1024*1024))		
			local per = nil
			if maxsize == 0 then
				per = 0
			else
				per = size*100/maxsize
				if per > 99.9999 then
					per = 0
				end
			end
			percent = string.format("%.2f",per)
			if tonumber(percent) >= 0 and tonumber(percent) <= 100 then
				SetSpriteProperty(spritePercent, "text","已上传: "..percent.."%")
			else
				SetSpriteProperty(spritePercent, "text","")
			end
			SetSpriteProperty(spriteImg, "src", "file:///image/download/upload2.png")
			SetSpriteProperty(spriteImg1, "src", "file:///image/download/upload1.png")
		end
		
	elseif task[index].status == "Uploading" then
		if IsSpriteVisible(spriteSel2) == 0 then
			SetSpriteVisible(spriteSel2, 1)
			SetSpriteEnable(spriteSel2, 1)
			SetSpriteVisible(spriteSel1, 0)
			SetSpriteEnable(spriteSel1, 0)
			SetSpriteVisible(spriteUnSel, 0)			
			SetSpriteEnable(spriteUnSel, 0)			
			SetSpriteRect(spriteItem, x, y, 222, 72)
			SetSpriteFocus(FindChildSprite(spriteSel2,"pausebutton"))
			saveTouchFocus(FindChildSprite(spriteSel2,"pausebutton"))
		end
		if task[index].maxsize > 0 and task[index].leavesize > 0 then
			local spriteSize = FindChildSprite(spriteItem,"upload-size")
			local spriteSpeed = FindChildSprite(spriteItem, "speed")
			local spriteCurPercent = FindChildSprite(spriteItem,"curpercent")
			local spriteForeground = FindChildSprite(spriteItem,"foreground")
			local maxsize = string.format("%.2f",task[index].maxsize/(1024*1024))
			local size = string.format("%.2f",task[index].size/(1024*1024))		
			percent = string.format("%.2f",size*100/maxsize)
			
			local speed = 0
			local speed1 = 0
			local speed2 = 0
			--if uploadTime[index+1] > 0 then
				WriteLogs("preTimerSize  "..preTimerSize[index+1])
				WriteLogs("task[index].size  "..task[index].size/(1024*1024))				
				speed1 = (task[index].size/(1024*1024) - preTimerSize[index+1])/(UPLOADING_SHOW_STATUS_INTERVAL/1000)
				--WriteLogs("totalTime---"..totalTime[index+1])
				WriteLogs("speed1---"..speed1)
				if totalTime[index+1] == 0 then
					speed2 = 0
				else
					speed2 = (task[index].size/(1024*1024) - initTimerSize[index+1])/(totalTime[index+1]*UPLOADING_SHOW_STATUS_INTERVAL/1000)
				end
				WriteLogs("speed2---"..speed2)
				--preTimerSize[index+1] = task[index].size/(1024*1024)
				speed = 0.2*speed1 + 0.8*speed2
				WriteLogs("speed---"..speed)
			--end
			if speed < 0 then
				speed = 0
			end
			local showspeed = string.format("%d",speed*1024)
			SetSpriteProperty(spriteSpeed, "text",""..showspeed.."KB/S")	
			
			--109 是进度条长度，这里用来计算进度条的百分比
			local width = (tonumber(percent))*uploadingInfor_ProgressWidth/100
			SetSpriteProperty(spriteCurPercent, "text",""..percent.."%")
			SetSpriteProperty(spriteSize,"text",""..size.."MB / "..maxsize.."MB")
			x,y,w,h =  GetSpriteRect(spriteForeground)
			SetSpriteRect(spriteForeground,x,y,width,h)
		end
	end
	SpriteList_Adjust(spriteList)
	for i=1,itemCount do
		preTimerSize[i] = task[i-1].size/(1024*1024)
		if initFinish[i] ~= 1 then
			initTimerSize[i] = task[i-1].size/(1024*1024)
			if task[i-1].size < task[i-1].maxsize then
				initFinish[i] = 1
				end
			end
		end
	end
end

function StatusOnTimer()
	local reg = registerCreate("uploading")
	local curIndex = registerGetInteger(reg,"curIndex")
	local itemCount = updateTaskTable()
	for i=1,itemCount do 
		if task[i-1].status == "Uploading" then
			if totalTime[i] ~= nil then
				totalTime[i] = totalTime[i] + 1
			else
				totalTime[i] = 1
			end
		end	
	end
	if itemCount > 0 then
		WriteLogs("Count = " .. itemCount)
		UpdateSelectItemData()
		for idx = 0, itemCount - 1 do
			WriteLogs("idx "..idx)
			WriteLogs("Task [" .. idx .. "]")
			 WriteLogs("\t" .. "id     : " .. task[idx].id)
			WriteLogs("\t" .. "remote : " .. task[idx].remote)
			 WriteLogs("\t" .. "local  : " .. task[idx].localfile)
			 WriteLogs("\t" .. "title  : " .. task[idx].title)
			 WriteLogs("\t" .. "maxsize: " .. task[idx].maxsize)
			 WriteLogs("\t" .. "leavesize   : " .. task[idx].leavesize)
			WriteLogs("\t" .. "status : " .. task[idx].status)
		end
		SetTimer( UPLOADING_TIMER_ID, UPLOADING_SHOW_STATUS_INTERVAL, "StatusOnTimer")
	end
end

--
--取得上传队列中的个数
--然后取得每一个上传的状态
--然后保存到全局的task中
g_task_info = {}

function updateTaskTable()
    require "module.debug.printdbg"
	
	local itemCount = pluginInvoke(upload, "Count")
	local curCount = itemCount
	local finish = 0
	for idx = 0, itemCount - 1 do
		task[idx] = {}
		local result, id, remote, remoteparam, localfile, title, desc, type, maxsize, leavesize, status = pluginInvoke(upload, "GetItem", idx)

		task[idx].id = id
		task[idx].remote = remote
		task[idx].remoteparam = remoteparam
		task[idx].localfile = localfile
		task[idx].title = title
		task[idx].desc = desc
		task[idx].type = type
		task[idx].maxsize = maxsize
		task[idx].leavesize = leavesize
		task[idx].size = maxsize - leavesize
						
		if status == 0 then		task[idx].status = "Idle"
		elseif status == 1 then	task[idx].status = "LoadFailed"
		elseif status == 2 then	task[idx].status = "Seeking"
		elseif status == 3 then	task[idx].status = "Uploading"
		elseif status == 4 then	task[idx].status = "Paused"
		elseif status == 5 then	task[idx].status = "Finished"
		elseif status == 6 then	task[idx].status = "Failed"
		else   task[idx].status = "Unknown"
		end		
		
	end

	for removeidx = 0, itemCount - 1 do
		if task[removeidx].status == "Finished" then
			WriteLogs("removeidx"..removeidx.."  finished")
			pluginInvoke(upload, "Remove", task[removeidx].id)
			curCount = curCount - 1
			SaveUploadHistoryList(task[removeidx].localfile,task[removeidx].title)
			finish = 1
		end
	end
	WriteLogs("finish  "..finish)

	itemCount = pluginInvoke(upload, "Count")
	if finish == 1 then
		SetTimer(1,1000,"FreeOnTimer")
	end
	return	itemCount
end

function FreeOnTimer()
	WriteLogs("FreeScene Go2Scene(sceneUploadingInfo)")
	local labelSprite = GetCurScene()
	FreeScene(labelSprite)
	Go2Scene(sceneUploadingInfo)
end

function buttonLocalFileSelect()
	--SetReturn(sceneUploadingInfo,sceneUploadHistory)	
	local Curscene = GetCurScene()
	FreeScene(Curscene)
	Go2Scene(sceneUploadHistory)
end

function SaveUploadHistoryList(playurl,videoName)
    require ("module.setting");
	local regUploadList = registerCreate("uploadHistoryList")
	local filename = Cfg.GetTempPath( "uploadhist.xml" );
	registerLoad(regUploadList, filename)
	local count = registerGetInteger(regUploadList, "count")
	if count ~=nil then
		count =count +1
	else
		count = 1
	end

	for i=1, count do
		if registerGetString(regUploadList, "playurl" ..i) == playurl then
			return 1
		end
	end
	registerSetString(regUploadList, "playurl" ..count, playurl)
	registerSetString(regUploadList, "name" ..count, videoName)
	registerSetInteger(regUploadList, "count", count)
	registerSave(regUploadList, filename)
	registerRelease("uploadHistoryList")
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	require("module.common.commonMsg")
	--[[  返回事件  ]]--
	if message == MSG_RETURN then
		FreeScene(GetCurScene())
		WriteLogs("*******************")
	WriteLogs("bodyOnSpriteEvent-----------------------start----message="..message)
	--WriteLogs("message-----------message-----message-------message----message="..MSG_SMS)
	elseif message == MSG_SMS then
		WriteLogs("bodyOnSpriteEvent-----------------------1")
		requestMsgContent()
	WriteLogs("bodyOnSpriteEvent-----------------------3")
	end
	return 1
end

function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if MSG_SMS_ID == message then			
		DealMsgContent(sceneUploadingInfo, sceneUploadingInfo)
	end
	return 1
end

--对话框响应
function OnSpriteEvent_uploadingInfor(message, params)
	if message == 1001 then	
	WriteLogs("delete***************************---------------------------------------------------")	
		local itemCount = updateTaskTable()
		if itemCount > 0 then
			local reg = registerCreate("uploadinfor")
			local index = registerGetInteger(reg,"delindex")				
			pluginInvoke(upload, "Remove", task[index].id)
		end
		local labelSprite = GetCurScene()
		FreeScene(labelSprite)	
		Go2Scene(sceneUploadingInfo)
	elseif message == 1002 then
-- reg = registerCreate("uploadinfor")
	--	local delete = registerGetInteger(reg,"deletebutton")	
	--	SetSpriteFocus(delete)
	end
end
-- brief 列表为empty情况下事件
--author dw

function emptyKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	WriteLogs("empty:"..keyCode)
	require("module.keyCode.keyCode")
	local name = GetSpriteName(sprite)
	if	keyCode==ApKeyCode_Enter or keyCode==ApKeyCode_Down  or keyCode==ApKeyCode_Up  or  keyCode==ApKeyCode_Left  then return 0
	elseif  keyCode==ApKeyCode_Right then buttonLocalFileSelect(sprite)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
-- brief 正在上传列表
--author dw
function uploadButtonOnKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	WriteLogs("键盘事件： ")
	local name = GetSpriteName(sprite)
	local itemCount=SpriteList_GetListItemCount(uploadlist)
	local item=GetSpriteParent(GetSpriteParent(sprite))
	local index=SpriteListItem_GetIndex(item)
	local spriteSel1 = FindChildSprite(item,"select1")
	local spriteSel2 = FindChildSprite(item,"select2")
	local spriteUnSel = FindChildSprite(item,"unselect")	
	local list_x, list_y2, list_w, list_h = GetSpriteRect(uploadlist)
	local _, list_y1 = GetSpriteRect(item)
	local list_y = list_y1+list_y2
	local reg = registerCreate("uploading")
	registerSetInteger(reg,"curIndex",index)
	WriteLogs("-----------------------------------------------:"..index)
	--local itemCount=updateTaskTable()
	local i=1
	if	keyCode==ApKeyCode_Enter then
		WriteLogs("回车事件： ")
		if GetSpriteName(GetSpriteParent(sprite))=="unselect" then	
			local x, y, w, h = GetSpriteRect(item)
			local spriteRoot = GetRootSprite(sprite)
			local spriteList = FindChildSprite(spriteRoot, "uploading-list")
			for i=0,(SpriteList_GetListItemCount(spriteList)-1) do
				local toUnselItem= SpriteList_GetListItem(spriteList,i)
				local spriteSel11 = FindChildSprite(toUnselItem,"select1")
				local spriteSel12 = FindChildSprite(toUnselItem,"select2")
				local spriteUnSel1 = FindChildSprite(toUnselItem,"unselect")
				SetSpriteVisible(spriteSel11, 0)
				SetSpriteEnable(spriteSel11, 0)
				SetSpriteVisible(spriteSel12, 0)
				SetSpriteEnable(spriteSel12, 0)		
				SetSpriteVisible(spriteUnSel1, 1)			
				SetSpriteEnable(spriteUnSel1, 1)
				SetSpriteRect(toUnselItem, 0, 0, uploadingInfor_ItemWidth, uploadingInfor_NormalHeight)
				local spriteImage = FindChildSprite(toUnselItem,"image-select")
				if  task[i].status == "Seeking" then
					SetSpriteProperty(spriteImage,"src",imagelist[1])				
				elseif task[i].status == "Paused" then
					SetSpriteProperty(spriteImage,"src",imagelist[2])
				elseif task[i].status == "Uploading" or task[i].status == "Idle"  then
					SetSpriteProperty(spriteImage,"src",imagelist[3])
				elseif task[i].status == "Failed" then
					SetSpriteProperty(spriteImage,"src",imagelist[5])
				end	
			end
			
			if  task[index].status == "Paused" or task[index].status == "Seeking"  then
				WriteLogs("初始项目")
				SetSpriteVisible(spriteSel1, 1)
				SetSpriteEnable(spriteSel1, 1)
				SetSpriteVisible(spriteSel2, 0)
				SetSpriteEnable(spriteSel2, 0)
				SetSpriteVisible(spriteUnSel, 0)			
				SetSpriteEnable(spriteUnSel, 0)			
				SetSpriteRect(item, x, y, 222, 48)
				SetSpriteFocus(FindChildSprite(spriteSel1,"operbutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"operbutton"))
			elseif  task[index].status == "Failed"  then 
				WriteLogs("失败")
				SetSpriteVisible(spriteSel1, 1)
				SetSpriteEnable(spriteSel1, 1)
				SetSpriteVisible(spriteSel2, 0)
				SetSpriteEnable(spriteSel2, 0)
				SetSpriteVisible(spriteUnSel, 0)			
				SetSpriteEnable(spriteUnSel, 0)			
				SetSpriteRect(item, x, y, 222, 48)
				SetSpriteFocus(FindChildSprite(spriteSel1,"deletebutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"deletebutton"))
			elseif  task[index].status == "Uploading" then
				SetSpriteVisible(spriteSel2, 1)
				SetSpriteEnable(spriteSel2, 1)
				SetSpriteVisible(spriteSel1, 0)
				SetSpriteEnable(spriteSel1, 0)
				SetSpriteVisible(spriteUnSel, 0)			
				SetSpriteEnable(spriteUnSel, 0)			
				SetSpriteRect(item, x, y, 222, 72)
				SetSpriteFocus(FindChildSprite(spriteSel2,"pausebutton"))
				saveTouchFocus(FindChildSprite(spriteSel2,"pausebutton"))
			elseif task[index].status == "Idle" then
				WriteLogs("@@@@@@@@@@@@@@@@hasUploadingFlag=="..hasUploadingFlag)
				SetSpriteVisible(spriteSel1, 1)
				SetSpriteEnable(spriteSel1, 1)
				SetSpriteVisible(spriteSel2, 0)
				SetSpriteEnable(spriteSel2, 0)
				SetSpriteVisible(spriteUnSel, 0)			
				SetSpriteEnable(spriteUnSel, 0)			
				SetSpriteRect(item, x, y, 222, 48)
				SetSpriteFocus(FindChildSprite(spriteSel1,"operbutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"operbutton"))
			end
			SpriteList_Adjust(uploadlist)
			if list_y >165 then
				if task[index].status == "Uploading" then
					SetSpriteRect(uploadlist,list_x, list_y2-uploadingInfor_NormalHeight-uploadingInfor_NormalHeight,list_w, list_h)
				else
					if list_y>195 then
						SetSpriteRect(uploadlist,list_x, list_y2-uploadingInfor_NormalHeight,list_w, list_h)
					end
				end
				---------------------------modified 10.27-----------------
				ChangeScrollPositon(sprite,"down")
				----------------------------------------------------------
			end	
		elseif name=="operbutton" then
			if task[index].status == "Paused"  then
				local x, y, w, h = GetSpriteRect(item)
				local flagStatus = false
				for i=1,itemCount do 
					if task[i-1].status == "Uploading" then
						flagStatus = true
					end	
				end
				--[[
				if flagStatus == false then
					SetSpriteVisible(spriteSel2, 1)
					SetSpriteEnable(spriteSel2, 1)
					SetSpriteVisible(spriteSel1, 0)
					SetSpriteEnable(spriteSel1, 0)
					SetSpriteVisible(spriteUnSel, 0)			
					SetSpriteEnable(spriteUnSel, 0)
					SetSpriteRect(item, x, y, 222,72)
					SetSpriteFocus(FindChildSprite(spriteSel2,"pausebutton"))
					saveTouchFocus(FindChildSprite(spriteSel2,"pausebutton"))
					SpriteList_Adjust(uploadlist)
				end
				--]]
				if list_y >165 then
					if flagStatus == false then
						SetSpriteRect(uploadlist,list_x, list_y2-uploadingInfor_NormalHeight,list_w, list_h)
						---------------------------modified 10.27-----------------
						ChangeScrollPositon(sprite,"down")
						----------------------------------------------------------
					end	
				end
			end
			operButtonOnSelect(sprite)
		elseif name=="deletebutton" then 
			deleteButtonOnSelect(sprite)
		elseif name=="pausebutton" then 
			local x, y, w, h = GetSpriteRect(item)	
			SetSpriteVisible(spriteSel1, 1)
			SetSpriteEnable(spriteSel1, 1)
			SetSpriteVisible(spriteSel2, 0)
			SetSpriteEnable(spriteSel2, 0)
			SetSpriteVisible(spriteUnSel, 0)			
			SetSpriteEnable(spriteUnSel, 0)			
			SetSpriteRect(item, x, y, 222,48)	
			SetSpriteFocus(FindChildSprite(spriteSel1,"operbutton"))
			saveTouchFocus(FindChildSprite(spriteSel1,"operbutton"))
			pauseButtonOnSelect(sprite)
			SpriteList_Adjust(uploadlist)
		elseif name=="deletebutton1" then 
			deleteButtonOnSelect1(sprite)
		end	      
		UpdateSelectItemData()
	elseif keyCode==ApKeyCode_Down  and index<=itemCount-1 then
		local nextListItem = SpriteList_GetListItem(uploadlist, index+1)	
		if index==itemCount-1 and (name=="deletebutton" or name=="deletebutton1") then return 0 end
		if GetSpriteName(GetSpriteParent(sprite))=="unselect" then		
			SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"))
			saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"))
		else
			if name=="operbutton" then
				SetSpriteFocus(FindChildSprite(spriteSel1,"deletebutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"deletebutton"))	
			elseif name=="pausebutton" then
				SetSpriteFocus(FindChildSprite(spriteSel2,"deletebutton1"))
				saveTouchFocus(FindChildSprite(spriteSel2,"deletebutton1"))	
			elseif name=="deletebutton"  or name=="deletebutton1" then
				SetSpriteVisible(spriteSel2, 0)
				SetSpriteEnable(spriteSel2, 0)
				SetSpriteVisible(spriteSel1, 0)
				SetSpriteEnable(spriteSel1, 0)
				SetSpriteVisible(spriteUnSel, 1)			
				SetSpriteEnable(spriteUnSel, 1)		
				local x, y, w, h = GetSpriteRect(item)		
				SetSpriteRect(item, x, y, 222, 25)	
				--SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"))
				--saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"))
				uploadButtonOnKeyUp(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"),ApKeyCode_Enter)
				SpriteList_Adjust(uploadlist)
			end
		end
		if list_y >195 then
			SetSpriteRect(uploadlist,list_x, list_y2-uploadingInfor_NormalHeight,list_w, list_h)
			---------------------------modified 10.27-----------------
			ChangeScrollPositon(sprite,"down")
			----------------------------------------------------------
		end
	elseif keyCode==ApKeyCode_Up  then
			WriteLogs("index = " .. index .. " name = " .. name .. " status = " ..task[index].status)
			if index==0 and name=="operbutton" then return 0 
			elseif index==0 and name=="deletebutton" and task[index].status ~= "Failed" then --edit
			SetSpriteFocus(FindChildSprite(spriteSel1,"operbutton")) 
			saveTouchFocus(FindChildSprite(spriteSel1,"operbutton"))
			return 0
			elseif index ==0 and name =="deletebutton" and task[index].status == "Failed" then return 0 --add
			elseif index==0 and name=="deletebutton1" then  
			SetSpriteFocus(FindChildSprite(spriteSel2,"pausebutton"))
			saveTouchFocus(FindChildSprite(spriteSel2,"pausebutton"))
			return 0
			elseif index==0 then 
			return 0
			end
		if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
			local nextListItem = SpriteList_GetListItem(uploadlist, index-1)			
			SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"))
			saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"))
		else
			if name=="deletebutton" and task[index].status ~= "Failed"   then
				SetSpriteFocus(FindChildSprite(spriteSel1,"operbutton"))
				saveTouchFocus(FindChildSprite(spriteSel1,"operbutton"))
			elseif name=="deletebutton1" then
				SetSpriteFocus(FindChildSprite(spriteSel2,"pausebutton"))
				saveTouchFocus(FindChildSprite(spriteSel2,"pausebutton"))
			elseif task[index].status == "Failed" or name=="operbutton" or name=="pausebutton" then																	--删除按钮		
				local nextListItem = SpriteList_GetListItem(uploadlist, index-1)	
				SetSpriteVisible(spriteSel2, 0)
				SetSpriteEnable(spriteSel2, 0)
				SetSpriteVisible(spriteSel1, 0)
				SetSpriteEnable(spriteSel1, 0)
				SetSpriteVisible(spriteUnSel, 1)			
				SetSpriteEnable(spriteUnSel, 1)
				local x, y, w, h = GetSpriteRect(item)		
				SetSpriteRect(item, x, y, 222, 25)	
				--SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"))
				--saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"))
				uploadButtonOnKeyUp(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button1"),ApKeyCode_Enter)
				SpriteList_Adjust(uploadlist)
			end						
		end
		if list_y <= 10 then
			if task[index].status == "Uploading" then
				SetSpriteRect(uploadlist,list_x, list_y2+uploadingInfor_NormalHeight+uploadingInfor_NormalHeight,list_w, list_h)
			else
				SetSpriteRect(uploadlist,list_x, list_y2+uploadingInfor_NormalHeight,list_w, list_h)
			end
			SpriteScrollBar_Adjust(uploadlist)
			---------------------------modified 10.27-----------------
			ChangeScrollPositon(sprite,"up")
			----------------------------------------------------------
		end
	elseif keyCode == ApKeyCode_Left then
		--[[
		if name=="operbutton"  or name=="pausebutton"then
			SetSpriteVisible(spriteSel2, 0)
			SetSpriteEnable(spriteSel2, 0)
			SetSpriteVisible(spriteSel1, 0)
			SetSpriteEnable(spriteSel1, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)
			local x, y, w, h = GetSpriteRect(item)		
			SetSpriteRect(item, x, y, 222, 25)	
			SetSpriteFocus(FindChildSprite(FindChildSprite(item,"unselect"),"item-button1"))
			saveTouchFocus(FindChildSprite(FindChildSprite(item,"unselect"),"item-button1"))
			SpriteList_Adjust(uploadlist)
		elseif name=="item-button1" then
			return 0
		end
		]]--
	elseif keyCode == ApKeyCode_Right then
		buttonLocalFileSelect()
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end	

--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	WriteLogs("liuchaobing test spriteitem name is "..GetSpriteName(spriteitem))
	WriteLogs("liuchaobing test spriteitem index is "..CurIndex)
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,3,0)
	else
		ScrollBarAdjust(CurIndex + 1,3,1)
	end
end

function itemButtonOnMouseDown(sprite)
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	uploadButtonOnKeyUp(sprite,ApKeyCode_Enter)
end

