--@author xf_pan
--@date	2010/06/16
--@brief get partiners

require "module.common.io"
local parFileName = "partiners.txt"
function GetPartiners()
	local f = fileRead("MODULE:\\channelid.ini")
	if f then
		return f
	else
		return ""
	end
end
