﻿require("module.loading.useLoading")


keyQuickLauncherBar = "QuickLauncherBar";
	SPRITENAME_SYSMENU = "sysmenu";
	SPRITENAME_BOTTOMMENU = "bottommenu";
function menuButtonOnSelect(sprite)
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	
	local LoadingReg=registerCreate("LoadingFlag")
	local Loading_String=registerGetString(LoadingReg,"loadingString")
	
	if Loading_String=="enter" then
		WriteLogs("进入Loading 状态")
		
	return
	end
	hideBottomSprite(rootSprite);
	
			local flagReg=registerCreate("flagnum")
			registerSetInteger(flagReg,"flagnum",0)
			
			local flags=registerCreate("flags")
		registerSetInteger(flags, "flagtool",0)
		
	
	--if hideMenuSprite(rootSprite) == 0 then
		WriteLogs("爆破？？？----21")
		require "module.protocol.protocol_video"
		OnMenuButton()
		menuSprite = CreateSprite("node", rootSprite);
		SetSpriteName(menuSprite, SPRITENAME_SYSMENU);
		LoadSprite(menuSprite, "MODULE:\\sysmenu.xml");
		SetSpriteCapture(rootSprite);
		WriteLogs("爆破？？？----21")
	--end
end

function hideBottomSprite(rootSprite)
	local bottomSprite = FindChildSprite(rootSprite, SPRITENAME_BOTTOMMENU);
	if bottomSprite ~= 0 then
		RemoveChildSprite(rootSprite, bottomSprite, 1);
		ReleaseSpriteCapture(rootSprite);
		return	1;
	end
	return	0;
end

function hideMenuSprite(rootSprite)
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	local menuSprite = FindChildSprite(rootSprite, SPRITENAME_SYSMENU);
	if menuSprite ~= 0 then
		RemoveChildSprite(rootSprite, menuSprite, 1);
		ReleaseSpriteCapture(rootSprite);
		return	1;
	end
	return	0;
end

function returnButtonOnSelect(sprite)
	WriteLogs("zgh:menuOpen_returnButtonOnSelect")
	local LoadingReg=registerCreate("LoadingFlag")
	registerSetString(LoadingReg,"loadingString","None")
	if hidePopupSprites() == 1 then
		return;
	end
	require "module.common.SceneUtils"
	require "module.common.registerScene"
	local curScene = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle");
	local SceneName = registerGetString(regHandle, string.format("%d", curScene))
--	WriteLogs("------------------------------:"..GetSpriteName(homeSprite))
	WriteLogs("SceneName:"..SceneName)
	if SceneName == sceneHome then
		WriteLogs("zgh:if")
		require "module.dialog.useDialog"
		local	reg = registerCreate(keyQuickLauncherBar);
		local	rootSprite = registerGetInteger(reg, "rootSprite");
		local spriteEvent = FindChildSprite(rootSprite,"event")		
		local dlgImg = {}
		dlgImg.OK_N_IMG = "file:///image/dialog/ok.png"
		dlgImg.OK_F_IMG = "file:///image/dialog/ok_alt.png"	
		setDialogParam("退出", "您确认要退出吗？", "BT_OK_CANCEL",sceneHome ,sceneHome,spriteEvent,nil,dlgImg)
		Go2Scene(sceneDialog)
		
		return 1
	
	end

--取消阴影
--	SetNoShadow()
	require "module.protocol.protocol_video"
	OnReturnButton()


	--找数据ReturnTable仓库
 	local regReturn = registerCreate(keyQuickLauncherBar);
 	--得到ReturnTable中"PageName"的总数,就是找到最近的页面
 	local count = registerGetInteger(regReturn, "Count");
 	--得到ReturnTable中最近的页面的名字
	local LastPageName = registerGetString(regReturn, "PageName"..count)
	local CurScene = GetCurScene()
	--如果存在，返回那个页面
	if LastPageName ~= "" and LastPageName ~= nil then	
		--由页面控制free
		local	reg = registerCreate(keyQuickLauncherBar);
		local	rootSprite = registerGetInteger(reg, "rootSprite")
		local   rootScene = GetCurScene()
		----------------------add by yaoxiangyin-------------------解决渠道版通过菜单进排行或搜索结果界面再返回后失焦点问题
		if LastPageName==sceneGuide then
			if SceneName==scenePaihang or SceneName==sceneSearch then
				local regKey = registerCreate("SCMngr")
				registerSetInteger(regKey,LastPageName,0)
			end
		end
		-----------------------------------------------------------
		require "module.common.commonMsg"
		--发给当前场景
		SendSpriteEvent(rootScene, MSG_RETURN)
		
		--以下处理当前场景和目标场景相同的情况
		while 1 do
			LastPageName = registerGetString(regReturn, "PageName"..count)
			if LastPageName ~= SceneName then
				if LastPageName == sceneVideoGroup or LastPageName == sceneVideoLiveDemand or LastPageName == sceneVideoLiveDemand_NB or LastPageName == sceneVideolocal then
					if SceneName ~= sceneRecommend then
						LastPageName = registerGetString(regReturn, "PageName"..count-1)	
						count = count - 1						
					else
						Go2Scene(LastPageName)
						break
					end					
				else
					if nil == LastPageName or "" == LastPageName then 
						Go2Scene(sceneHome) 
					else
						Go2Scene(LastPageName)
					end
					break
				end
			else
				LastPageName = registerGetString(regReturn, "PageName"..count-1)
				count = count - 1
			end
		end			
		
		registerSetString(regReturn, "CurPage", LastPageName)
		if count >= 1 then
			registerRemove(regReturn, "PageName"..count)
			count = count - 1	
		end
	else
		GoAndFreeScene(sceneHome)
		registerSetString(regReturn, "CurPage", sceneHome)
		for i=1, count do
			registerRemove(regReturn, "PageName"..i)
		end
		count = 0
	end	
	registerSetInteger(regReturn, "Count", count)	
	local regVideo = registerCreate("video")
	registerSetString(regVideo, "isDownloading","")	
end

function hidePopupSprites()
	local	reg = registerCreate(keyQuickLauncherBar)
	local	rootSprite = registerGetInteger(reg, "rootSprite")
	
	if hideMenuSprite(rootSprite) == 1 then	return	1;	end
	if hideBottomSprite(rootSprite) == 1 then	return	1;end

	return	0;
end
