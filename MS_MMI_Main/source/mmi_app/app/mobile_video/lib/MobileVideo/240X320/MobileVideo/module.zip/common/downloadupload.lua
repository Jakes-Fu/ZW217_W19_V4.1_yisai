﻿--@module DownloadUpload
--@note 下载上传相关
--@author chenzhongjie
--@date 2010/07/05
--[[  暂停上传  ]]--
function PauseUploadTask()
	local reg = registerCreate("System")
	upload = registerGetInteger(reg,"Upload")	
	if upload == 0 then
		upload = pluginCreate("Upload")
	end
	local taskId = {}
	local itemCount = pluginInvoke(upload, "Count")
	for idx = 0, itemCount - 1 do
		local result, id, remote, remoteparam, localfile, title, desc, type, maxsize, leavesize, status = pluginInvoke(upload, "GetItem", idx)
		if status == 3 then
			uploadingId = id
			pluginInvoke(upload, "Pause", uploadingId)
			WriteLogs("uploadingId"..uploadingId.."is paused")
			break
		end
	end	
end

--[[  开始上传  ]]--
function StartUploadTask()
	local reg = registerCreate("System")
	upload = registerGetInteger(reg,"Upload")	
	if upload == 0 then
		upload = pluginCreate("Upload")
	end
	if uploadingId then
		pluginInvoke(upload, "Resume", uploadingId)
		WriteLogs("uploadingId"..uploadingId.."is resumed")
	end	
end

--[[  暂停指定下载任务  ]]--
--[[  isDelete为true 则删除临时文件，否则不删除临时文件 ]]--
function PauseOneDownloadTask(name, isDelete)
	GetDownloadStauts()
	local itemCount = GetDownloadCount()
	for idx = 0, itemCount - 1 do
		if task[idx].title == "temp_"..name then
			pluginInvoke(download, "Remove", task[idx].id)
			if isDelete and isDelete == "true" then
				local filename = task[idx].localfile
				os.remove (filename)
			end
		end
	end
end

--[[  暂停所有下载  ]]--
function PauseDownloadTask()
	task={}
	WriteLogs("PauseAllDownloadTask")
	nDownloadingTask = -1
	local reg = registerCreate("System")
	download = registerGetInteger(reg,"Download")	
	if download == 0 then
		download = pluginCreate("Download")
	end
	local itemCount = pluginInvoke(download, "Count")
	for idx = 0, itemCount - 1 do
		task[idx] = {}
		local result, id, remote, localfile, title, maxsize, size, status = pluginInvoke(download, "GetItem", idx)
		task[idx].id = id
		task[idx].remote = remote
		task[idx].localfile = localfile
		task[idx].title = title
		task[idx].maxsize = maxsize
		task[idx].size = size
		if status == 0 then		task[idx].status = "Idle"
		elseif status == 1 then	task[idx].status = "NotEnoughSpace"
		elseif status == 2 then	task[idx].status = "Downloading"
		elseif status == 3 then	task[idx].status = "Paused"
		elseif status == 4 then	task[idx].status = "Finished"
		elseif status == 5 then	task[idx].status = "Failed"
		else   task[idx].status = "Unknown"
		end		
	end
	for i = 0, itemCount - 1 do
		if task[i].status == "Downloading" then
			local nDownloadingTask = i
			local reg_downloading = registerCreate("downloading")
			registerSetInteger(reg_downloading,"DownloadingNum", nDownloadingTask)
		end
	end
	for j = 0, itemCount - 1 do
		if task[j].status ~= "Failed" then
			pluginInvoke(download, "Pause", task[j].id)
		end
	end
end

--[[  开始下载  ]]--
function StartDownloadTask()
	GetDownloadStauts()
	local reg_downloading = registerCreate("downloading")
	local nDownloadingTask = registerGetInteger(reg_downloading,"DownloadingNum")
	if nDownloadingTask >= 0  and task then
		pluginInvoke(download, "Resume", task[nDownloadingTask].id)
	end
end

--[[  获取下载状态  ]]--
function GetDownloadStauts()
	task={}
	nDownloadingTask = -1
	local reg = registerCreate("System")
	download = registerGetInteger(reg,"Download")	
	if download == 0 then
		download = pluginCreate("Download")
	end
	local itemCount = pluginInvoke(download, "Count")
	for idx = 0, itemCount - 1 do
		task[idx] = {}
		local result, id, remote, localfile, title, maxsize, size, status = pluginInvoke(download, "GetItem", idx)
		task[idx].id = id
		task[idx].remote = remote
		task[idx].localfile = localfile
		task[idx].title = title
		task[idx].maxsize = maxsize
		task[idx].size = size
		if status == 0 then		task[idx].status = "Idle"
		elseif status == 1 then	task[idx].status = "NotEnoughSpace"
		elseif status == 2 then	task[idx].status = "Downloading"
		elseif status == 3 then	task[idx].status = "Paused"
		elseif status == 4 then	task[idx].status = "Finished"
		elseif status == 5 then	task[idx].status = "Failed"
		else   task[idx].status = "Unknown"
		end		
	end
	local reg_downloading = registerCreate("downloading")
end

--[[  获取下载任务个数  ]]--
function GetDownloadCount()
	local reg = registerCreate("System")
	download = registerGetInteger(reg,"Download")	
	if download == 0 then
		download = pluginCreate("Download")
	end
	local itemCount = pluginInvoke(download, "Count")
	return itemCount
end

--[[  执行下载逻辑  ]]--
function DownloadProc(videoData,sceneName)
	require "module.protocol.protocol_downloadinfor"
	local spaceh, spacel = GetLocalSpace()
	space = spaceh*4294967296 + spacel
	if space > 1024 then
		require "module.setting"
		local downloadPathCfg = Cfg.GetDownloadPathCfg()
		if videoData and videoData.success == "true" then
			if downloadPathCfg == "phone" then			
				local folder = GetDefaultFolder(WDFIDL_MYVIDIO)
				require "module.protocol.protocol_downloadinfor"
				require("module.dialog.useDialog")
				require("module.setting")
				if folder and folder ~= nil then
					local path = Cfg.GetDownloadPath()
					Download2Dir(folder,sceneName,1)
				else
					local path = Cfg.GetDownloadPath()
					Download2Dir(path,sceneName)
				end
			else
				local path = Cfg.GetDownloadPath()
				Download2Dir(path,sceneName)
			end
		else
			if videoData and videoData.feeds or videoData.once then
				local regv = registerCreate("video")
				local filename = registerGetString(regv, "videoDownloadFileName")
				local regp = registerCreate("productorder")
				registerSetString(regp,"fileName",filename)
				registerSetString(regp,"returntype","download")
				SetReturn(scenePrograminfo_volume,sceneOrderProduct)
				FreeVideoLoadingFuncs()
				GoAndFreeScene(sceneOrderProduct)
			else
				setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneName, sceneName, nil)
				Go2Scene(sceneDialog)
			end
		end
	else
		require("module.dialog.useDialog")
		setDialogParam("提示", "磁盘剩余空间容量不足", "BT_OK", sceneName, sceneName, nil)
		Go2Scene(sceneDialog)
	end
end

--[[  下载到指定的路径  ]]--
function Download2Dir(path, sceneName, isMyVideo)
	require "module.protocol.protocol_downloadinfor"
	if videoData and videoData.urls and videoData.urls[0] and videoData.urls[0].name and sceneName == GetSceneName() then
		require "module.common.io"
		local dir = fileExist(path..videoData.urls[0].name..Cfg.GetVideoType())
		local root = FindScene(sceneName)
		local spriteEvent = FindChildSprite(root, "event")
		--[[  spriteEventForReturn只有在订购界面存在，当订购触发下载任务时，需要返回到详情  ]]--
		local spriteEventForReturn = FindChildSprite(root, "eventForReturn")
		local dlgImg = {
			OK_N_IMG = "file:///image/dialog/yes1.png",
			OK_F_IMG = "file:///image/dialog/yes2.png",
			CANCEL_N_IMG = "file:///image/dialog/no1.png",
			CANCEL_F_IMG = "file:///image/dialog/no2.png"
		}
		if dir and dir ~= nil and sceneName == GetSceneName() then
			setDialogParam("提示", "该文件已存在,是否覆盖?", "BT_OK_CANCEL", sceneName, sceneName, spriteEvent, nil, dlgImg)
			local reg = registerCreate("Download")
			registerSetString(reg,"DownloadOverWrite", path..videoData.urls[0].name..Cfg.GetVideoType())
			overwriteflag = 1
			Go2Scene(sceneDialog)
		else
			if videoData.urls[0].url and videoData.urls[0].url ~= "" and sceneName == GetSceneName() then
				local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name, isMyVideo)
				if result == -1 then
					setDialogParam("提示", "该文件已存在,是否覆盖?", "BT_OK_CANCEL", sceneName, sceneName, spriteEvent, nil, dlgImg)
					overwriteflag = 2
					Go2Scene(sceneDialog)
				elseif result == -2 then
					setDialogParam("提示", "未找到TF卡", "BT_OK", sceneName, sceneName, spriteEventForReturn == 0 and nil or spriteEventForReturn)
					Go2Scene(sceneDialog)
				else
					setDialogParam("提示", "文件已添加到下载队列", "BT_OK", sceneName, sceneName, spriteEventForReturn == 0 and nil or spriteEventForReturn)
					Go2Scene(sceneDialog)
				end
			else
				setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneName, sceneName, spriteEventForReturn == 0 and nil or spriteEventForReturn)
				Go2Scene(sceneDialog)
			end
		end
	else
		setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneName, sceneName)
		Go2Scene(sceneDialog)	
	end
end