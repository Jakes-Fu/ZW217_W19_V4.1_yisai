
--@author  zhouzhicheng
--@brief   RME 程序的运行入口
--

function Main()
	require "module.common.registerScene"
	require "module.common.SceneUtils"
	require "module.setting"
	WriteLogs("*******************************************")
	WriteLogs("*");
	WriteLogs("*   RME is going to run");
	WriteLogs("*   copyright @WonderTek.com");
	WriteLogs("*");
	WriteLogs("*******************************************")
	--配置信息存放在 rmeclient.xml中
	--在内存中是常驻在 REG_SETTING 中
	--或者可以通过便捷函数，直接获取
	--local cfg = Setting();
	Cfg.Load()
	
	WriteLogs("*******************************************")
	WriteLogs("");
	WriteLogs("MAX_LOGIN_TIMES :"..Cfg.GetMaxLoginTimes())
	WriteLogs("LOGIN_TIMES :"..Cfg.GetLoginTimes())
	WriteLogs("UUID :"..Cfg.GetUUID())
	WriteLogs("SERVER:"..Cfg.GetServer())
	WriteLogs("PORTAL:"..Cfg.GetPortal())
	WriteLogs("PORTAL_URL:"..Cfg.GetPortalURL())
	WriteLogs("RMEStart:"..Cfg.GetWelcome())
	WriteLogs("")
	WriteLogs("*******************************************")
	local themeMode = Cfg.GetTheme()
	if themeMode == "blue" then
		ChangeSkin(0, 0, 0)
	elseif themeMode == "purple" then
		ChangeSkin(70, 0, 0)
	elseif themeMode == "pink" then
		ChangeSkin(107, 0, 0)
	elseif themeMode == "black" then
		ChangeSkin(255, 255, 255)
	end
	
	local curS = GetCurScene()
	local welcomeS = CreateSprite()
	LoadSprite( welcomeS, Cfg.GetWelcome() )
	SetSpriteProperty(welcomeS,"name",Cfg.GetWelcome())
	SetCurScene( welcomeS )
	local regHandle = registerCreate("SCMngr")
	registerSetString(regHandle, "MODULE:\\welcome.xml", string.format("%d", welcomeS))
	local regHandle_r = registerCreate("SCMngr_handle")
	registerSetString(regHandle_r, string.format("%d", welcomeS), "MODULE:\\welcome.xml")
	FreeSprite( curS )
end


Main()
