﻿--
require "module.common.registerScene"
require "module.common.SceneUtils"
require "module.keyCode.keyCode"

product_MediaPlayerRect = {0,30,240,180}  --播放器窗口尺寸
product_StartPorgressRect = {0,22,0,6}	  --缓存刷新进度条初始区域
product_MiddlePorgressRect = {0,22,120,6} --缓存刷新进度条中段区域
product_EndPorgressRect = {0,22,240,6}	  --缓存刷新进度条结束区域

product_arrowAbleRect = {0,1,14,29}
product_arrowDisableRect = {0,0,14,29}

product_nSelSizeX = 62	--导航栏目选中时的尺寸宽度
product_nSelSizeY = 33	--导航栏目选中时的尺寸高度
product_nSizeX = 32		--导航栏目非选中时的尺寸宽度
product_nSizeY = 23		--导航栏目非选中时的尺寸高度
product_space = 3		--导航栏目之间间隔
product_ptX = product_nSizeX + product_space --导航栏目起始X坐标计算基准
product_middleStartY = 3  --导航栏目中间项起始Y坐标
product_otherStartY = 10  --导航栏目其它项起始Y坐标

product_SelOffX,product_SelOffY = 0,0 --导航区域大图片相对起始坐标
product_NorOffX,product_NorOffY = 0,0  --导航区域小图片相对起始坐标

ptImg = {}
ptImg[0] = {product_ptX * 2 , product_middleStartY}           							 --导航栏目中间项起始坐标
ptImg[1] = {product_ptX, product_otherStartY}			   							 --导航栏目中间偏左项起始坐标
ptImg[2] = {product_ptX * 2 + product_nSelSizeX + product_space, product_otherStartY} --导航栏目中间偏右项起始坐标
ptImg[3] = {0, product_otherStartY}								 					 --导航栏目最左项起始坐标
ptImg[4] = {product_ptX * 3 + product_nSelSizeX + product_space, product_otherStartY} --导航栏目最右项起始坐标


function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("product")
	registerSetInteger(reg, "root", sprite)
	
	local regSystem = registerCreate("System")
	http = registerGetInteger(regSystem, "comHttpPipe")
	
	require("module.protocol.protocol_channel")
	--获取当前时间
	require ("module.protocol.protocol_systime")
	RequestSysTime(113)
	
	SetTimer(1, 5, "OnTimerChannel")
	local loadarea = FindChildSprite(sprite,"loadarea")
	require("module.loading.useLoading")
	return 1
end

function OnTimerChannel(IDEvent)
	require("module.protocol.protocol_channel")
	jsonChannel = LoadJsonChannelNetworkData()
	ReleaseChannelNetworkData()
	changeChannelDataList()
	SetTimer(1, 5, "OnTimerEvent")
end

function OnTimerEvent(IDEvent)
	local reg = registerCreate("product")
	local sprite = registerGetInteger(reg, "root")
	
	if IDEvent == 1 then
		createChannelList(sprite)
		SetTimer(2, 50, "OnTimerEvent")
	elseif IDEvent == 2 then
		if jsonChannel.programList then
			createVideoList(sprite)
		else
			local defaultBtn=FindChildSprite(sprite,"defaultBtn")
			SetSpriteFocus(defaultBtn)
			saveTouchFocus(defaultBtn)
		end
		if ( jsonChannel and jsonChannel.imgListNavi ) then
			setPathSpriteText(jsonChannel.path,jsonChannel.imgListNavi[0].channelName)
		end
		exitLoading()
		doNotReload = nil
	end
end

--
function OnPluginEvent_product(message, Param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if message == 101 then
		local jsonChannelTemp = ChannelNetworkData()
		if jsonChannelTemp then
			exitLoading()
			jsonChannel = LoadJsonChannelNetworkData()
			ReleaseChannelNetworkData()

			deleteChannelList()
			deleteVideoSpriteList()
			
			changeChannelDataList()
			local reg = registerCreate("product")
			local sprite = registerGetInteger(reg, "root")
			createChannelList(sprite)
			if jsonChannel.programList then
				createVideoList(sprite)
			else
				local defaultBtn=FindChildSprite(sprite,"defaultBtn")
				SetSpriteFocus(defaultBtn)
				saveTouchFocus(defaultBtn)
			end
			setPathSpriteText(jsonChannel.path,jsonChannel.imgListNavi[0].channelName)
		end
	elseif message == 102 then
		require("module.protocol.protocol_infovolume")
		local json = OnVolumeDecode()
		exitLoading()
		if json ~= nil and json ~= "" then			
			local sceneInfo = "MODULE:\\menuprograminfo_volume.xml"
			SetReturn("MODULE:\\product.xml", sceneInfo)
			GoAndFreeScene(sceneInfo)
		end	
	elseif message == 103 then
		RequestPlay(sceneProduct)
	elseif message == 104 then
		require("module.dialog.useDialog")
		reslut, desc = OnPipeAddMyFav()
		exitLoading()
		setDialogParam("提示", desc, "BT_OK", sceneProduct, sceneProduct, GetCurScene())
		Go2Scene(sceneDialog)
	elseif message == 105 then
		require("module.protocol.protocol_infolabel")
		local json = OnLabelDecode()
		exitLoading()
		if json ~= nil and json ~= "" then
			SetReturn(sceneProduct,scenePrograminfo_label)
			Go2Scene(scenePrograminfo_label)
		end
	elseif message == 106 then
		require("module.protocol.protocol_infolist")
		local json = OnListDecode()
		exitLoading()
		if json ~= nil and json ~= "" then
			SetReturn(sceneProduct,scenePrograminfo_list)
			Go2Scene(scenePrograminfo_list)
		end
	elseif message == 107 then
		RequestPlay(sceneProduct)
	elseif message == 108 then
		require("module.protocol.protocol_magazine")
		local json = MagazineNetworkData()
		exitLoading()
		if json ~= nil and json ~= "" then
			SetReturn(sceneProduct,sceneMagazine)
			Go2Scene(sceneMagazine)
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "服务器返回数据错误", "BT_OK", sceneProduct, sceneProduct, nil)
			Go2Scene(sceneDialog)
		end
	elseif message == 984 then
		exitLoading()
		require("module.protocol.protocol_magazine")
		require("module.dialog.useDialog")
		setDialogParam("提示", "下载成功,请在收件箱中查看", "BT_OK", sceneProduct, sceneProduct, nil)
		Go2Scene(sceneDialog)
		if magazineItemIndex and magazineItemIndex ~= "" then
			WriteMagazien2MessageBox(magazineItemIndex)
		end
		if magazineItemName and magazineItemName ~= "" then
			Makefolder("MODULE:\\videoexpress\\"..magazineItemName)
			local src = "MODULE:\\videoexpress\\"..magazineItemName..".zip"
			local target = "MODULE:\\videoexpress\\"..magazineItemName.."\\"
			local unzip = BeginUnzip(src, target)
			if not unzip then
				WriteLogs("bad ZPKG file")
			else
				while GoToUnzipNextFile(unzip) do
					ProcessUnzip(unzip)
				end
				EndUnzip(unzip)
			end
		end
		os.remove("MODULE:\\videoexpress\\"..magazineItemName..".zip")
	elseif message == 111 then
		--isloading = 1;
		local jsonChannelTemp = ChannelNetworkData()
		if jsonChannelTemp then
			exitLoading()
			jsonChannel = LoadJsonChannelNetworkData()
			ReleaseChannelNetworkData()
			
			deleteChannelList()
			deleteVideoSpriteList()
			changeChannelDataList()
			local reg = registerCreate("product")
			local sprite = registerGetInteger(reg, "root")
			createChannelList(sprite)
			createVideoList(sprite)
			
			setPathSpriteText(jsonChannel.path,jsonChannel.imgListNavi[0].channelName)
		end
	elseif message == 112 then
		SetTimer(1,1500,"bookDelay")
	elseif message == 114 then
		RequestPlay(sceneProduct)
		local reg_vi = registerCreate("video")
		registerSetInteger(reg_vi, "isLive", 1)
	elseif MSG_SMS_ID == message then			
		DealMsgContent(sceneProduct, sceneProduct)
	elseif message > 32768 then 
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneProduct, sceneProduct, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function bodyOnSpriteEvent_product(message, params)
	require("module.common.commonMsg")
	require "module.videoexpress-common"
	if message == MSG_ADD_FAV then --add my fav
		--[[
		local reg = registerCreate("product")
		local root = registerGetInteger(reg, "root")
		local spriteEvent = FindChildSprite(root,"addFavConfirm")
		if spriteEvent ==0 then
			WriteLogs("product.lua line257 spriteEvent is 0")
		end	
		WriteLogs("---------------------------Go2Scene(sceneDialog) begin-----------------------------------------")
		require "module.dialog.useDialog"
		setDialogParam("确认收藏", "您确认要收藏该栏目吗？", "BT_OK_CANCEL", sceneProduct, sceneProduct,spriteEvent)
		WriteLogs("product.lua line262")
		Go2Scene(sceneDialog)
		WriteLogs("---------------------------Go2Scene(sceneDialog) end-----------------------------------------")
		WriteLogs("---------------------------SetSpriteFocus myfav yyyyy-----------------------------------------")
		local yaoReg = registerCreate("yaoxiangyin")
		SetSpriteFocus(registerGetInteger(yaoReg,"fav")) --add by yaoxiangyin
		WriteLogs("result:"..HasSpriteFocus(registerGetInteger(yaoReg,"fav")))
		WriteLogs("ok_Button=="..FindChildSprite(root,"ok-button_dilog"))
		WriteLogs("ok_Button=="..registerGetInteger(yaoReg,"fav"))
		WriteLogs("---------------------------SetSpriteFocus myfav end-----------------------------------------")
		]]--
--[[--------------------------------------add by yaoxiangyin 2010-09-25 ----------------------------------------]]--		
		require("module.protocol.protocol_addmyfav")
		local reg = registerCreate("product")
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
		local curChannel = jsonChannel.imgListNavi[0]
		local urlPath1 = curChannel.urlPath
		urlPath1 = string.gsub(urlPath1,"&","|")
		RequestAddMyfav(104, 0, curChannel.channelId, curChannel.contentId, urlPath1, curChannel.channelType)
------------------------------------------------------------------------------------------------------------------------		
	elseif message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_RETURN then
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		if MediapalyPlugin ~= 0 then
			pluginInvoke(MediapalyPlugin, "Stop")
			pluginInvoke(MediapalyPlugin, "Show" , 0)
		end
		FreeScene(GetCurScene())
	elseif message == MSG_ACTIVATE then
		--if jsonChannel and jsonChannel.imgListNavi[0].channelType == "3" and jsonChannel.programList then
		--	require("module.productLive")
		--	local index = GetCurLiveVideoIndex()
		--	require "module.protocol.protocol_videoloading"
		--	local regVideo = registerCreate("video")
		--	registerSetString(regVideo, "startTime", jsonChannel.programList[index].startTime)
		--	registerSetString(regVideo, "endTime", jsonChannel.programList[index].endTime)
		--	local reg_g = registerCreate("product")
		--	local urlpath = registerGetString(reg_g,"channelURL")
		--	RequestVideo(114, jsonChannel.programList[index].playUrl, urlpath, jsonChannel.programList[index].contentName ,"live")
		--end
		local reg_r = registerCreate("recommend")   
		registerSetInteger(reg_r, "isDownloadDisable", 0)
		if jsonChannel and jsonChannel.imgListNavi then
			if jsonChannel.imgListNavi[0].haveData == "true" then
				local reg = registerCreate("product")
				local root=registerGetInteger(reg,"root")
				local defaultSprite
				if jsonChannel.imgListNavi[0].channelType == "1" then 	--点播节目
					defaultSprite=FindChildSprite(root,"item-button-0")
					if defaultSprite~=0 then
						saveTouchFocus(defaultSprite)
					else
						saveTouchFocus(FindChildSprite(root,"defaultButton"))
					end
				elseif jsonChannel.imgListNavi[0].channelType == "2" then --[[  直播节目  ]]-- 
					--判断比较复杂
				end
			end
		end
	elseif message == MSG_RELOAD then
		WriteLogs("message == MSG_RELOAD")
		require("module.protocol.protocol_channel")
		local jsonChannelTemp = ChannelNetworkData()
		if jsonChannelTemp then
			local reg = registerCreate("product")
			sprite = registerGetInteger(reg, "root")
			SetSpriteCapture(sprite)
			ReleaseSpriteCapture(sprite)
			SetTimer(1, 1, "OnTimerReload")
		end
	end
end

function addFavSpriteEvent(message, params)
	if message == 1001 then
		require("module.protocol.protocol_addmyfav")
		local reg = registerCreate("product")
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
		local curChannel = jsonChannel.imgListNavi[0]
		local urlPath1 = curChannel.urlPath
		urlPath1 = string.gsub(urlPath1,"&","|")
		RequestAddMyfav(104, 0, curChannel.channelId, curChannel.contentId, urlPath1, curChannel.channelType)
	elseif message == 1002 then
	
	end
end

function OnTimerReload()
	if doNotReload and doNotReload == 1 then doNotReload = nil return end
	local reg = registerCreate("product")
	sprite = registerGetInteger(reg, "root")
	hideMenu("sysmenu")
	hideMenu("bottommenu")
	jsonChannel = LoadJsonChannelNetworkData()
	ReleaseChannelNetworkData()
	WriteLogs("deleteChannelList")			
	deleteChannelList()
	deleteVideoSpriteList()			
	changeChannelDataList()	
	SetTimer(1, 5, "OnTimerEvent")
end

function bookconfirm(message, params)
	if message == 1001 then
		local reg = registerCreate("product")
		local root = registerGetInteger(reg, "root")
		local remindurl = registerGetString(reg,"remindurl")
		require("module.protocol.protocol_infovolume")
		RequestVolume(112, remindurl)
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
	elseif message == 1002 then
		--[[  donothing  ]]--
	end
end

function setPathSpriteText(text,text2)
	if text and text ~= 0 then
		local reg = registerCreate("product")
		local sprite = registerGetInteger(reg, "root")
		local spritelabel = FindChildSprite(sprite, "product-path")
		SetSpriteProperty(spritelabel, "text", text)
		
		local spritename = FindChildSprite(sprite, "product-channel-name")
		SetSpriteProperty(spritename, "text", text2)
		local channellist = FindChildSprite(sprite, "product-programgroup-list")
		
		local channelpage = FindChildSprite(sprite,"product-channel-page")
		--local itemcount = SpriteList_GetListItemCount(channellist)
		local itemcount = 0
		if jsonChannel and jsonChannel.programList then
			itemcount = table.maxn(jsonChannel.programList) + 1 
		end
		totalcount = math.ceil((itemcount)/SpriteList_GetLineCount(channellist))
		if jsonChannel.programList then
			if jsonChannel.imgListNavi[0].channelType ~= "2" and jsonChannel.imgListNavi[0].channelType ~= "3" then
				SetSpriteProperty(channelpage,"text","第1页/共"..totalcount.."页")
			else
				SetSpriteProperty(channelpage,"text","第1页/共1页")
			end
		else
			SetSpriteProperty(channelpage,"text","第0页/共0页")
		end
	end
end


function createVideoList(sprite)
	if jsonChannel and jsonChannel.imgListNavi then
		if jsonChannel.imgListNavi[0].haveData == "true" then
			require("module.productDemand")
			if jsonChannel.imgListNavi[0].channelType == "1" then 	--点播节目
			local reg=registerCreate("FlagNum")
			registerSetInteger(reg,"flag",1)
			  WriteLogs("点播: CreateDemandVideoList() ")
			  if jsonChannel.programList and jsonChannel.programList[0].category == "5" then
			  	setChannelLabel(sprite)
			  	createLabelVideoList(sprite)
			  else
					setChannelLabel(sprite)
					createDemandVideoList(sprite)
				end
				local leftArrow = FindChildSprite(sprite,"leftArrow")
				local rightArrow = FindChildSprite(sprite,"rightArrow")
				SetSpriteEnable(leftArrow,1)
				SetSpriteVisible(leftArrow,1)
				SetSpriteEnable(rightArrow,1)
				SetSpriteVisible(rightArrow,1)
			elseif jsonChannel.imgListNavi[0].channelType == "2" then --[[  直播节目  ]]--
			local reg=registerCreate("FlagNum")
			registerSetInteger(reg,"flag",2)
			  WriteLogs("Live: CreateLiveVideoList()")
				require("module.productLive")
				setChannelDay(sprite)
				setChannelInfoDisable(sprite)
				createLiveVideoList(sprite)
			elseif jsonChannel.imgListNavi[0].channelType == "3" then --[[  直播节目与直播回看  ]]--
			  WriteLogs("直播节目与直播回看")
			  local reg = registerCreate("product")
				local root = registerGetInteger(reg, "root")
				local channellist = FindChildSprite(root,"product-channel-name")
				local channelpage = FindChildSprite(root,"product-channel-page")
				local channelicon = FindChildSprite(root,"icon-sel")
				SetSpriteProperty(channellist,"visible",0)
				SetSpriteProperty(channelpage,"visible",0)
				SetSpriteProperty(channelicon,"visible",0)
				require("module.productLive")
				setChannelDay(sprite)
				createLiveAllVideoList(sprite)
				local leftArrow = FindChildSprite(sprite,"leftArrow")
				local rightArrow = FindChildSprite(sprite,"rightArrow")
				SetSpriteEnable(leftArrow,0)
				SetSpriteVisible(leftArrow,0)
				SetSpriteEnable(rightArrow,0)
				SetSpriteVisible(rightArrow,0)
			elseif jsonChannel.imgListNavi[0].channelType == "4" then --[[  混播节目  ]]--
				require("module.productLive")
				setChannelInfoDisable(sprite)
				createLiveVideoList(sprite)
			elseif jsonChannel.imgListNavi[0].channelType == "5" then --[[  视频杂志  ]]--
				createMagzineList(sprite)
			end
		end
	end
	local reg = registerCreate("product")
	local root = registerGetInteger(reg, "root")
	local LeftArrow_n = FindChildSprite(root ,"leftbutton_normal")
	local l,t,w,h = GetSpriteRect(LeftArrow_n)
	if w == 14 then
		createArrows(root,"btgdLeftAble.png","btgdLeftDisable.png","btgdRightAble.png","btgdRightDisable.png")
	else
		createArrows(root,"gd_left.png","gd_left2.png","gd_right.png","gd_right2.png")
	end
end

function createArrows(root,left,leftdisable,right,rightdiable)
	local LeftArrow_n = FindChildSprite(root ,"leftbutton_normal")
	local LeftArrow_f = FindChildSprite(root ,"leftbutton_focus")
	local RightArrow_n = FindChildSprite(root ,"rightbutton_normal")
	local RightArrow_f = FindChildSprite(root ,"rightbutton_focus")
	SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..leftdisable)
	SetSpriteProperty(LeftArrow_f,"src","file://image//common//"..leftdisable)
	local programgrouplist = FindChildSprite(root,"product-programgroup-list")
	local startitem = SpriteList_GetStartItem(programgrouplist)
	local totalitem = SpriteList_GetListItemCount(programgrouplist)
	if startitem >= 6 then
		SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..left)
		SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..left)
	else
		SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..leftdisable)
		SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..leftdisable)
	end
	if totalitem - 6*math.floor(startitem/6) >= 6 then
		SetSpriteProperty(RightArrow_n,"src","file://image//common//"..right)
		SetSpriteProperty(RightArrow_f,"src","file://image//common//"..right)
	else
		SetSpriteProperty(RightArrow_n,"src","file://image//common//"..rightdiable)
		SetSpriteProperty(RightArrow_f,"src","file://image//common//"..rightdiable)
	end
end

function resetVideoItem(spriteList, start, start)
	if jsonChannel and jsonChannel.imgListNavi then
		if jsonChannel.imgListNavi[0].haveData == "true" then
			if jsonChannel.imgListNavi[0].channelType == "1" then 		--点播节目
				resetDemandVideoItem(spriteList, start, start)
			elseif jsonChannel.imgListNavi[0].channelType == "2" then --直播节目
				resetLiveVideoItem(spriteList, start, start)
			elseif jsonChannel.imgListNavi[0].channelType == "3" then --直播节目与直播回看
				resetLiveVideoItem(spriteList, start, start)
			elseif jsonChannel.imgListNavi[0].channelType == "4" then --混播节目
				resetLiveVideoItem(spriteList, start, start)
			end
		end
	end
end
---------------------------------------------------
--Network Data  Change Channel
function changeChannelDataList()
	if jsonChannel and jsonChannel.imgListNavi then
--		0 1 2 3 4 5 
--		排成 5 3 1 0 2 4 5 3 1 0 2 4
--		得到这个表的索引	
		local valueMax = table.maxn(jsonChannel.imgListNavi);
		local imgListNaviCount = table.maxn(jsonChannel.imgListNavi) + 1
		local nBegin = (valueMax % 2) ~= 0 and valueMax or valueMax - 1
		local nCount = 0
		local nIndex = nBegin
		local array = {}
--		奇数
		for nIndex = nBegin, 1, -2 do
			array[nCount] = nIndex
			nCount = nCount + 1
		end
--		偶数
		for nIndex = 0, valueMax, 2 do
			array[nCount] = nIndex
			nCount = nCount + 1
		end
				
		nIndex = 0
        local arrMax = (valueMax + 1) * 2 - 1
		for nCount = nCount, arrMax do
			array[nCount] = array[nIndex]
			nIndex = nIndex + 1
		end

		local nFindIndex = 0
		for i=0, table.maxn(jsonChannel.imgListNavi) do
			local haveData = jsonChannel.imgListNavi[i].haveData
			if string.match(haveData, "true") then
				nFindIndex = i
			end
		end
		for i=0, #array do
			if array[i] == nFindIndex then 
				nFindIndex = i
				break
			end
		end
		nFindIndex = (nFindIndex < imgListNaviCount / 2) and (nFindIndex + imgListNaviCount) or nFindIndex;
--		构建数据数组
		local newImgList = {}
		nIndex2 = 0
		nIndex = 1
		newImgList[nIndex2] = jsonChannel.imgListNavi[array[nFindIndex]]
		nIndex2 = nIndex2 + 1
		while nIndex < 4 and #newImgList < valueMax do
    	if (nFindIndex - nIndex) >= 0 then
				newImgList[nIndex2] = jsonChannel.imgListNavi[array[nFindIndex - nIndex]]
			  nIndex2  = nIndex2 + 1
      end
      if ( (nFindIndex + nIndex) < imgListNaviCount * 2) then
			  newImgList[nIndex2] = jsonChannel.imgListNavi[array[nFindIndex + nIndex]]
			  nIndex2 = nIndex2 + 1
      end
      nIndex = nIndex + 1
		end
		jsonChannel.imgListNavi = newImgList
	end
end

function DisplayButton(spriteLeftImage, spriteRightImage, start, step, total, isRing, spriteLeftImage_f, spriteRightImage_f)
	local ButtonLeft = GetSpriteParent(GetSpriteParent(spriteLeftImage))
	local ButtonRight = GetSpriteParent(GetSpriteParent(spriteRightImage))
	if isRing then --环状
		if spriteLeftImage and spriteLeftImage ~= 0 then
			if step < total then
				--SetSpriteVisible(spriteLeftImage, 1)
				SetSpriteProperty(spriteLeftImage, "src", "file://image//common//btgdLeftAble.png")
				SetSpriteProperty(spriteLeftImage_f, "src", "file://image//common//btgdLeftAble.png")
				SetSpriteRect(spriteLeftImage_f, product_arrowAbleRect[1],product_arrowAbleRect[2],product_arrowAbleRect[3],		       	  product_arrowAbleRect[4])
				SetSpriteEnable(ButtonLeft, 1)
			else
				--SetSpriteVisible(spriteLeftImage, 0)
				SetSpriteProperty(spriteLeftImage, "src", "file://image//common//btgdLeftDisable.png")
				SetSpriteProperty(spriteLeftImage_f, "src", "file://image//common//btgdLeftDisable.png")
				SetSpriteRect(spriteLeftImage_f, product_arrowDisableRect[1],product_arrowDisableRect[2],product_arrowDisableRect[3],		           product_arrowDisableRect[4])
				SetSpriteEnable(ButtonLeft, 0)
			end
		end
		if spriteRightImage and spriteRightImage ~= 0 then
			if step < total then
				--SetSpriteVisible(spriteRightImage, 1)
				SetSpriteProperty(spriteRightImage, "src", "file://image//common//btgdRightAble.png")
				SetSpriteProperty(spriteRightImage_f, "src", "file://image//common//btgdRightAble.png")
				SetSpriteRect(spriteRightImage_f, product_arrowAbleRect[1],product_arrowAbleRect[2],product_arrowAbleRect[3],		       		product_arrowAbleRect[4])
				SetSpriteEnable(ButtonRight, 1)
			else
				--SetSpriteVisible(spriteRightImage, 0)
				SetSpriteProperty(spriteRightImage, "src", "file://image//common//btgdRightDisable.png")
				SetSpriteProperty(spriteRightImage_f, "src", "file://image//common//btgdRightDisable.png")
				SetSpriteRect(spriteRightImage_f, product_arrowDisableRect[1],product_arrowDisableRect[2],product_arrowDisableRect[3],		           product_arrowDisableRect[4])
				SetSpriteEnable(ButtonRight, 0)
			end
		end
	else
		if spriteLeftImage and spriteLeftImage ~= 0 then
			if start >= step then
				--SetSpriteVisible(spriteLeftImage, 1)
				SetSpriteProperty(spriteLeftImage, "src", "file://image//common//btgdLeftAble.png")
				SetSpriteProperty(spriteLeftImage_f, "src", "file://image//common//btgdLeftAble.png")
				SetSpriteRect(spriteLeftImage_f, product_arrowAbleRect[1],product_arrowAbleRect[2],product_arrowAbleRect[3],		       		product_arrowAbleRect[4])
				SetSpriteEnable(ButtonLeft, 1)
			else
				--SetSpriteVisible(spriteLeftImage, 0)
				SetSpriteProperty(spriteLeftImage, "src", "file://image//common//btgdLeftDisable.png")
				SetSpriteProperty(spriteLeftImage_f, "src", "file://image//common//btgdLeftDisable.png")
				SetSpriteRect(spriteLeftImage_f, product_arrowDisableRect[1],product_arrowDisableRect[2],product_arrowDisableRect[3],		           product_arrowDisableRect[4])
				SetSpriteEnable(ButtonLeft, 0)
			end
		end
		if spriteRightImage and spriteRightImage ~= 0 then
			if start + step < total then
				--SetSpriteVisible(spriteRightImage, 1)
				SetSpriteProperty(spriteRightImage, "src", "file://image//common//btgdRightAble.png")
				SetSpriteProperty(spriteRightImage_f, "src", "file://image//common//btgdRightAble.png")
				SetSpriteRect(spriteRightImage_f, product_arrowAbleRect[1],product_arrowAbleRect[2],product_arrowAbleRect[3],		       		product_arrowAbleRect[4])
				SetSpriteEnable(ButtonRight, 1)
			else
				--SetSpriteVisible(spriteRightImage, 0)
				SetSpriteProperty(spriteRightImage, "src", "file://image//common//btgdRightDisable.png")
				SetSpriteProperty(spriteRightImage_f, "src", "file://image//common//btgdRightDisable.png")
				SetSpriteRect(spriteRightImage_f, product_arrowDisableRect[1],product_arrowDisableRect[2],product_arrowDisableRect[3],		           product_arrowDisableRect[4])
				SetSpriteEnable(ButtonRight, 0)
			end
		end
	end
end

function createChannelList(sprite)
	local spriteList = FindChildSprite(sprite, "product-channel-list")
	if 4 ~= 6 then
		ptImg[0] = {product_ptX * 2 , product_middleStartY}
		ptImg[1] = {product_ptX, product_otherStartY}																						--导航栏目中间偏左项起始坐标
		ptImg[2] = {product_ptX * 2 + product_nSelSizeX + product_space, product_otherStartY}		--导航栏目中间偏右项起始坐标
		ptImg[3] = {0, product_otherStartY}								 					 --导航栏目最左项起始坐标
		ptImg[4] = {product_ptX * 3 + product_nSelSizeX + product_space, product_otherStartY}		--导航栏目最右项起始坐标
	else
		ptImg[0] = {product_ptX * 3 , product_middleStartY}																			--导航栏目中间项起始坐标
		ptImg[1] = {product_ptX * 2 , product_otherStartY}																			--导航栏目中间偏右项起始坐标
		ptImg[2] = {product_ptX * 3 + product_nSelSizeX + product_space, product_otherStartY}		
		ptImg[3] = {product_ptX * 1, product_otherStartY}																				
		ptImg[4] = {product_ptX * 4 + product_nSelSizeX + product_space, product_otherStartY}	
		ptImg[5] = {0 , product_otherStartY}																										--导航栏目最左项起始坐标
		ptImg[6] = {product_ptX * 5 + product_nSelSizeX + product_space, product_otherStartY}						--导航栏目最右项起始坐标
	end
	if jsonChannel and jsonChannel.imgListNavi then
		local nMax = math.min(#jsonChannel.imgListNavi, 4)
		local xmlNode=xmlLoadFile("MODULE:\\productListItem.xml")
		for i=0, nMax do
			local productChannelSprite = CreateSprite("listitem")
			LoadSpriteFromNode(productChannelSprite, xmlNode)
			
			local spriteButton = FindChildSprite(productChannelSprite, "buttonChangeName")
			local spriteImageNormal = FindChildSprite(productChannelSprite, "buttonNormalImg")
			local spriteImageForcus = FindChildSprite(productChannelSprite, "buttonFocusImg")
			local buttonNormalBgImg = FindChildSprite(productChannelSprite, "buttonNormalBgImg")
			local buttonFocusBgImg = FindChildSprite(productChannelSprite, "buttonFocusBgImg")
			SetSpriteProperty(spriteButton, "name", string.format("channel-button-%d", i))
			
			WriteLogs("Product channel name => "..jsonChannel.imgListNavi[i].channelName);
			
			--选中状态
			if 0 == i then
				SetSpriteRect(productChannelSprite, ptImg[i][1], ptImg[i][2], product_nSelSizeX, product_nSelSizeY)
				SetSpriteRect(spriteButton, 0, 0, product_nSelSizeX, product_nSelSizeY)
				SetSpriteRect(buttonNormalBgImg, 0, 0, product_nSelSizeX , product_nSelSizeX );
				SetSpriteRect(buttonFocusBgImg, 0, 1, product_nSelSizeX , product_nSelSizeX );
--[[----------------------------------修改人：yaoxiangyin 修改时间：2010.09.08----------------------------------------------------]]--				
				--SetSpriteFocus(spriteButton)
-----------------------------------------------------------------------------------------------				
				SetSpriteProperty(buttonNormalBgImg, "src", "file:///image/product/lanmu_sel_bg.png" )
				SetSpriteProperty(buttonFocusBgImg, "src", "file:///image/product/lanmu_sel_bg.png" )
				
				if jsonChannel.imgListNavi[i].bigImg then
					SetSpriteProperty(spriteImageNormal, "src", jsonChannel.imgListNavi[i].bigImg)
					SetSpriteRect(spriteImageNormal, product_SelOffX, product_SelOffY, product_nSelSizeX  ,  product_nSelSizeY   )
					SetSpriteProperty(spriteImageForcus, "src", jsonChannel.imgListNavi[i].bigImg)
					SetSpriteRect(spriteImageForcus, product_SelOffX, product_SelOffY +1, product_nSelSizeX  , product_nSelSizeY  )
				end
			else --非选中状态
				SetSpriteRect(productChannelSprite, ptImg[i][1], ptImg[i][2], product_nSizeX, product_nSizeY)
				SetSpriteRect(spriteButton, 0, 0, product_nSizeX, product_nSizeY)
				SetSpriteRect(buttonNormalBgImg, 0, 0, product_nSizeX , product_nSizeY );
				SetSpriteRect(buttonFocusBgImg, 0, 1, product_nSizeX , product_nSizeY );
				SetSpriteProperty(buttonNormalBgImg, "src", "file:///image/product/lanmu_bg.png" )
				SetSpriteProperty(buttonFocusBgImg, "src", "file:///image/product/lanmu_bg.png" )
				if jsonChannel.imgListNavi[i].smallImg then
					SetSpriteProperty(spriteImageNormal, "src", jsonChannel.imgListNavi[i].smallImg)
					SetSpriteRect(spriteImageNormal, product_NorOffX, product_NorOffY, product_nSizeX, product_nSizeY  )
					
					SetSpriteProperty(spriteImageForcus, "src", jsonChannel.imgListNavi[i].smallImg)
					SetSpriteRect(spriteImageForcus, product_NorOffX, product_NorOffY +1, product_nSizeX  , product_nSizeY )
				end
			end
			AddChildSprite(spriteList, productChannelSprite)
			SpriteList_AddListItem(spriteList, productChannelSprite)
		end
		xmlRelease(xmlNode)
		local start = SpriteList_GetStartItem(spriteList)
		local listItemCount = table.maxn(jsonChannel.imgListNavi) + 1
		local itemPerPage = SpriteList_GetItemPerPage(spriteList)
		
		local spriteLeftImage = FindChildSprite(sprite, "product-channel-left-arrow-image")
		local spriteRightImage = FindChildSprite(sprite, "product-channel-right-arrow-image")
		local spriteLeftImage_f = FindChildSprite(sprite, "product-channel-left-arrow-image-f")
		local spriteRightImage_f = FindChildSprite(sprite, "product-channel-right-arrow-image-f")
		DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount, 1, spriteLeftImage_f, spriteRightImage_f)
	end
end

function deleteChannelList()
	local reg = registerCreate("product")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "product-channel-list")
	
	SpriteList_ClearListItem(spriteList, 1, 1)
end

function deleteVideoSpriteList()
	local reg = registerCreate("product")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "product-programgroup-list")
	SpriteList_ClearListItem(spriteList, 1, 1)
	local spriteList = FindChildSprite(sprite, "product-programgroup-list-live")
	SpriteList_ClearListItem(spriteList, 1, 1)
	local scroll = FindChildSprite(sprite, "List-Scroll")
	if scroll ~= 0 then
		RemoveChildSprite(GetSpriteParent(scroll), scroll)
		FreeSprite(scroll)
	end
end

function channelListButtonOnSelect(spriteButton)
    if doNotReload == 1 then return end
	doNotReload = 1
	local spriteParent = GetSpriteParent(spriteButton)
	local spriteList = FindChildSprite(spriteParent, "product-channel-list")
	
	-----------------------------------------------------------------
	local qkLhBar=registerCreate("QkLHBAR")
	SenceSprite=registerGetInteger(qkLhBar,"qKLunchText")	
	local sprite_child=FindChildSprite(SenceSprite,"quicklauncherbar")
	-----------------------------------------------------------------
	
	if spriteList and spriteList ~= 0 and GetSpriteName(spriteList) == "product-channel-list" then
		if	jsonChannel.imgListNavi then
			if GetSpriteName(spriteButton) == "product-channel-left-arrow" and 5 <= table.maxn(jsonChannel.imgListNavi) then
				RequestChannel(101, jsonChannel.imgListNavi[1].urlPath)
				local reg = registerCreate("product")
				local root = registerGetInteger(reg, "root")
				local loadarea = FindChildSprite(root ,"loadarea")
				enterLoading(loadarea)
				
				-------------------------------------------------------
				if jsonChannel.imgListNavi[1].channelType == "1" then 
					SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按*或#键可进行翻页")
				elseif jsonChannel.imgListNavi[1].channelType == "2"  or  jsonChannel.imgListNavi[1].channelType == "3" then 
					SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按1,3,7,9键可切换节目单")
				end
				------------------add by liuchaobing----------------
				
			elseif GetSpriteName(spriteButton) == "product-channel-right-arrow" and 5 <= table.maxn(jsonChannel.imgListNavi) then
				RequestChannel(101, jsonChannel.imgListNavi[2].urlPath)
				local reg = registerCreate("product")
				local root = registerGetInteger(reg, "root")
				local loadarea = FindChildSprite(root ,"loadarea")
				enterLoading(loadarea)
				
				------------------add by liuchaobing----------------
				if jsonChannel.imgListNavi[2].channelType == "1" then 
					SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按*或#键可进行翻页")
				elseif jsonChannel.imgListNavi[2].channelType == "2"  or  jsonChannel.imgListNavi[2].channelType == "3" then 
					SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按1,3,7,9键可切换节目单")
				end
				-------------------------------------------------------
				
			end
		end
	end
end

function channelListiItemOnSelect(sprite)
	if jsonChannel.imgListNavi then
		local spriteListItem = GetSpriteParent(sprite)
		local spriteList = GetSpriteParent(spriteListItem)
		local index = SpriteListItem_GetIndex(spriteListItem)
		if index ~= 0 then
			local reg = registerCreate("product")
			local root = registerGetInteger(reg, "root")
			local loadarea = FindChildSprite(root ,"loadarea")
			enterLoading(loadarea)
			RequestChannel(101, jsonChannel.imgListNavi[index].urlPath)
			
			-- sava urlPath
			require("module.menuprograminfo")
			SetProgramInfoUrlPath(jsonChannel.imgListNavi[index].urlPath)
		end
		-----------------------------add by liuchaobing--------------------
		local qkLhBar=registerCreate("QkLHBAR")
		SenceSprite=registerGetInteger(qkLhBar,"qKLunchText")	
		local sprite_child=FindChildSprite(SenceSprite,"quicklauncherbar")
		if jsonChannel.imgListNavi[index].channelType == "1" then 
			SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按*或#键可进行翻页")
		elseif jsonChannel.imgListNavi[index].channelType == "2"  or  jsonChannel.imgListNavi[index].channelType == "3" then 
			SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按1,3,7,9键可切换节目单")
		end
		----------------------------------------------------------
	end
	ReleaseSpriteCapture(sprite)
end

function listUpButtonOnSelect(sprite)
	local filter = GetSpriteRect(sprite)
	--[[  -2不需要写进模板  ]]--
	if filter == -2 then
		UpButtonOnSelect(sprite,"btgdLeftAble.png","btgdLeftDisable.png","btgdRightAble.png","btgdRightDisable.png")
	else
		UpButtonOnSelect(sprite,"gd_left.png","gd_left2.png","gd_right.png","gd_right2.png")
	end
end

function UpButtonOnSelect(sprite,left,leftdisable,right,rightdiable)
	local parentSprite = GetSpriteParent(sprite)
	if parentSprite then
		spriteList = FindChildSprite(parentSprite, "product-programgroup-list")
		if spriteList ~= 0 then
			local itemPerPage = SpriteList_GetItemPerPage(spriteList)
			local start = SpriteList_GetStartItem(spriteList)
			local itemCount = SpriteList_GetListItemCount(spriteList)
			start = start - itemPerPage
			if start >=0 then
				SpriteList_SetStartItem(spriteList, start)
				resetVideoItem(spriteList, start, start)
			end
			local first = FindChildSprite(spriteList,"video-sprite-"..start)
			local productDemandItemButton = FindChildSprite(first,"productDemandItemButton")
			local productLabelItemButton = FindChildSprite(first,"productLabelItemButton")
			local firstsprite = 0
			if IsSpriteVisible(productDemandItemButton) then
			firstsprite = FindChildSprite(productDemandItemButton,"item-button-"..start)
			else
				firstsprite = FindChildSprite(productLabelItemButton,"item-button-"..start)
			end
			SetSpriteFocus(firstsprite)
			saveTouchFocus(firstsprite)
			SetSpriteProperty(FindChildSprite(firstsprite,"boardImage"),"src","file:///image/product/jiaodian_bg.PNG")
----------------------------------------------------------------------------------------------------------		
			local reg = registerCreate("product")
			local root = registerGetInteger(reg, "root")
			local LeftArrow_n = FindChildSprite(root ,"leftbutton_normal")
			local LeftArrow_f = FindChildSprite(root ,"leftbutton_focus")
			local RightArrow_n = FindChildSprite(root ,"rightbutton_normal")
			local RightArrow_f = FindChildSprite(root ,"rightbutton_focus")
			if start <= 0 then				
				SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..leftdisable)
				SetSpriteProperty(LeftArrow_f,"src","file://image//common//"..leftdisable)
				if itemCount <= itemPerPage then
					SetSpriteProperty(RightArrow_n,"src","file://image//common//"..rightdiable)
					SetSpriteProperty(RightArrow_f,"src","file://image//common//"..rightdiable)
				else
					SetSpriteProperty(RightArrow_n,"src","file://image//common//"..right)
					SetSpriteProperty(RightArrow_f,"src","file://image//common//"..right)
				end
				local channellist = FindChildSprite(root,"product-programgroup-list")
				local channelpage = FindChildSprite(root,"product-channel-page")
				SetSpriteProperty(channelpage,"text","第1页/共"..totalcount.."页")
			else
				SetSpriteProperty(RightArrow_n,"src","file://image//common//"..right)
				SetSpriteProperty(RightArrow_f,"src","file://image//common//"..right)
				SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..left)
				SetSpriteProperty(LeftArrow_f,"src","file://image//common//"..left)
				local channellist = FindChildSprite(root,"product-programgroup-list")
				local channelpage = FindChildSprite(root,"product-channel-page")
				SetSpriteProperty(channelpage,"text","第"..1+start/SpriteList_GetLineCount(channellist).."页/共"..totalcount.."页")
			end
		end
	end
	return	1
end

function listDownButtonOnSelect(sprite)
	local filter = GetSpriteRect(sprite)
	--[[  295不需要写进模板  ]]--
	if filter == 295 then
		DownButtonOnSelect(sprite,"btgdLeftAble.png","btgdLeftDisable.png","btgdRightAble.png","btgdRightDisable.png")
	else
		DownButtonOnSelect(sprite,"gd_left.png","gd_left2.png","gd_right.png","gd_right2.png")
	end
end

function DownButtonOnSelect(sprite,left,leftdisable,right,rightdiable)
	local parentSprite = GetSpriteParent(sprite)
	if parentSprite then
		spriteList = FindChildSprite(parentSprite, "product-programgroup-list")
		if spriteList ~= 0 then
			local itemPerPage = SpriteList_GetItemPerPage(spriteList)
			local start = SpriteList_GetStartItem(spriteList)
			local itemCount = SpriteList_GetListItemCount(spriteList)
			start = start + itemPerPage
			if start < itemCount then
				SpriteList_SetStartItem(spriteList, start)
				resetVideoItem(spriteList, start, start)
			end
			local first = FindChildSprite(spriteList,"video-sprite-"..start)
			local productDemandItemButton = FindChildSprite(first,"productDemandItemButton")
			local productLabelItemButton = FindChildSprite(first,"productLabelItemButton")
			local firstsprite = 0
			if IsSpriteVisible(productDemandItemButton) then
				firstsprite = FindChildSprite(productDemandItemButton,"item-button-"..start)
			else
				firstsprite = FindChildSprite(productLabelItemButton,"item-button-"..start)
			end
			SetSpriteFocus(firstsprite)
			saveTouchFocus(firstsprite)
			SetSpriteProperty(FindChildSprite(firstsprite,"boardImage"),"src","file:///image/product/jiaodian_bg.PNG")
----------------------------------------------------------------------------------------------------------	
			local reg = registerCreate("product")
			local root = registerGetInteger(reg, "root")
			local LeftArrow_n = FindChildSprite(root ,"leftbutton_normal")
			local LeftArrow_f = FindChildSprite(root ,"leftbutton_focus")
			local RightArrow_n = FindChildSprite(root ,"rightbutton_normal")
			local RightArrow_f = FindChildSprite(root ,"rightbutton_focus")
			if itemCount - start <= itemPerPage then
				if itemCount <= itemPerPage then
					SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..leftdisable)
					SetSpriteProperty(LeftArrow_f,"src","file://image//common//"..leftdisable)
				else
					SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..left)
					SetSpriteProperty(LeftArrow_f,"src","file://image//common//"..left)
				end
				SetSpriteProperty(RightArrow_n,"src","file://image//common//"..rightdiable)
				SetSpriteProperty(RightArrow_f,"src","file://image//common//"..rightdiable)
				local channellist = FindChildSprite(root,"product-programgroup-list")
				local channelpage = FindChildSprite(root,"product-channel-page")
				SetSpriteProperty(channelpage,"text","第"..totalcount.."页/共"..totalcount.."页")
			else
				SetSpriteProperty(LeftArrow_n,"src","file://image//common//"..left)
				SetSpriteProperty(LeftArrow_f,"src","file://image//common//"..left)
				SetSpriteProperty(RightArrow_n,"src","file://image//common//"..right)
				SetSpriteProperty(RightArrow_f,"src","file://image//common//"..right)
				local channellist = FindChildSprite(root,"product-programgroup-list")
				local channelpage = FindChildSprite(root,"product-channel-page")
				SetSpriteProperty(channelpage,"text","第"..1+start/SpriteList_GetLineCount(channellist).."页/共"..totalcount.."页")
			end
		end
	end
	return	1
end

function bookDelay()
	require("module.protocol.protocol_infovolume")
	local remindjson = OnVolumeDecode()
	exitLoading()
	require("module.dialog.useDialog")
	if remindjson and remindjson.desc and remindjson.success then
		setDialogParam("提示", remindjson.desc, "BT_OK", sceneProduct, sceneProduct, GetCurScene())
		Go2Scene(sceneDialog)
		if remindjson.success == "true" then
			local reg = registerCreate("product")
			local remindprogram = registerGetInteger(reg,"remindprogram")
			local remindprogramId = registerGetInteger(reg,"remindprogramId")
	 		SetSpriteVisible(remindprogram, 1)
	 		
	 		local temp = registerCreate("temp")
		 	registerLoad(temp, "MODULE:\\..\\temp\\booking.xml")
	 		registerSetString(temp,remindprogramId,"1")
	 		registerSave(temp,"MODULE:\\..\\temp\\booking.xml")
	 		registerRelease("temp")
 		end
	else
		setDialogParam("提示", "无法获取网络数据，预约失败", "BT_OK", sceneProduct, sceneProduct, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

--[[-----------------------------------修改人：yaoxiangyin 修改时间：2010.09.17-----------------------------------------------------]]--
function defaultBtnKeyUp(sprite,keyCode)
	WriteLogs("-----------------------defaultBtnKeyUp   begin----------------------")
	local regProductLive = registerCreate("productlive")
	registerSetInteger(regProductLive,"lastFocusSprite",sprite)
	registerSetInteger(regProductLive,"lastFocusFlag",1)
	-------------------------------------------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	local spriteRoot=GetRootSprite(sprite)
	changeDayList(sprite, keyCode)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode == ApKeyCode_Right then
		WriteLogs("---------------------ApKeyCode_Right------------------------")		
		local spriteLR=FindChildSprite(spriteRoot,"product-channel-right-arrow")
		channelListButtonOnSelect(spriteLR)
	elseif keyCode == ApKeyCode_Left then
		WriteLogs("---------------------ApKeyCode_Left------------------------")
		local spriteLR=FindChildSprite(spriteRoot,"product-channel-left-arrow")
		channelListButtonOnSelect(spriteLR)
	elseif keyCode == ApKeyCode_F1 then
		WriteLogs("---------------------ApKeyCode_F1------------------------")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		WriteLogs("---------------------ApKeyCode_F2------------------------")
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	WriteLogs("-----------------------defaultBtnKeyUp   end----------------------")
end

--begin [、Jone]
--用来处理日期切换(前天、昨天、今天、明天)
function changeDayList(sprite, keyCode)

	local spr = registerGetInteger(registerCreate("product"), "root", sprite)

	--WriteLogs("productLive.lua-->listKeyUp_Live-->keyCode:"..keyCode)
	if keyCode==ApKeyCode_Char1 then 
		WriteLogs("---------------------ApKeyCode_Char1------------------------")
		sprite1=FindChildSprite(spr,"beforeYesterday")
		productLiveChannelDaySelect(sprite1)
	end
	if keyCode==ApKeyCode_Char3 then 
		WriteLogs("---------------------ApKeyCode_Char3------------------------")
		sprite1=FindChildSprite(spr,"yesterday")
		productLiveChannelDaySelect(sprite1)
	end
	if keyCode==ApKeyCode_Char7 then 
		WriteLogs("---------------------ApKeyCode_Char7------------------------")
		sprite1=FindChildSprite(spr,"today")
		productLiveChannelDaySelect(sprite1)
	end  
	if keyCode==ApKeyCode_Char9 then 
		WriteLogs("---------------------ApKeyCode_Char9------------------------")
		sprite1=FindChildSprite(spr,"tomorrow")
		productLiveChannelDaySelect(sprite1)
  end  
end

function productLiveChannelDaySelect(sprite)
	local DaySelect = GetSpriteName(sprite)
	local reg = registerCreate("product")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root ,"loadarea")
  if jsonChannel.imgListNavi and #jsonChannel.imgListNavi >= 0 and jsonChannel.imgListNavi[0] then
  	if DaySelect == "beforeYesterday" then
   		if jsonChannel.imgListNavi[0].beforeYesterdayUrl then
   			require ("module.protocol.protocol_channel")
   			RequestChannel(111, jsonChannel.imgListNavi[0].beforeYesterdayUrl)
				enterLoading(loadarea)
   		end
   	end
   	if DaySelect == "yesterday" then
   		if jsonChannel.imgListNavi[0].beforeYesterdayUrl then
   			require ("module.protocol.protocol_channel")
   			RequestChannel(111, jsonChannel.imgListNavi[0].yesterdayUrl)
				enterLoading(loadarea)
   		end
   	end
   	if DaySelect == "today" then
   		if jsonChannel.imgListNavi[0].beforeYesterdayUrl then
   			require ("module.protocol.protocol_channel")
			WriteLogs("productLiveChannelDaySelect:jsonChannel.imgListNavi[0].todayUrl=="..jsonChannel.imgListNavi[0].todayUrl)
   			RequestChannel(111, jsonChannel.imgListNavi[0].todayUrl)
				enterLoading(loadarea)
   		end
   	end
   	if DaySelect == "tomorrow" then
   		if jsonChannel.imgListNavi[0].beforeYesterdayUrl then
   			require ("module.protocol.protocol_channel")
   			RequestChannel(111, jsonChannel.imgListNavi[0].tomorrowUrl)
				enterLoading(loadarea)
   		end
   	end
  end
end
--------------------------------------------------------------------------------------------------------------------------------