﻿--RequestVideo请求播放函数
--protocolNumbers 	----监听号
--palyurl			----视频请求地址，本地播放器为视频名称
--pathurl 			----视频详情请求地址,本地播放为任意字符串
--videoName			----视频节目名称
--videoType			----播放类型 "local"--本地播放 流媒体播放为任意字符串
--外部调整页面调用
function RequestVideo(protocolNumber, playurl, pathurl, videoName, videoType)
	local reg = registerCreate("video")
	if videoType == "local" then
		local local_url = playurl
		for i=1, table.maxn(local_url.url) do
			registerSetString(reg, "localUrl" ..i, local_url.url[i])
		end
		registerSetInteger(reg, "videoCount", table.maxn(local_url.url))
		registerSetInteger(reg, "curVideo", local_url.urlItem)
		registerSetString(reg, "videoName", videoName)
		registerSetString(reg, "videoType", videoType)
	else
		local fileName = GetLocalFilename(playurl)
		local reg = registerCreate("video")
		registerSetString(reg, "videoFileName", fileName)
		registerSetString(reg, "videoType", videoType)
		registerSetString(reg, "playurl", playurl)
		registerSetString(reg, "pathurl", pathurl)
		registerSetString(reg, "videoName", videoName)
		local observer = pluginGetObserver()
		pluginInvoke(http, "AppendCommand", 0, playurl, 0, fileName, observer, protocolNumber, 0,1)
	end
end

--播放器页面调用
function OnVideoDecode()
	local reg = registerCreate("video")
	videoType = registerGetString(reg, "videoType")
	videoName = registerGetString(reg, "videoName")
	if videoTypeList and ( videoType == videoTypeList[1] ) then
	else
		local reg = registerCreate("video")
		local fileName = registerGetString(reg, "videoFileName")
		playurl = registerGetString(reg, "playurl")
		pathurl = registerGetString(reg, "pathurl")
		local json = jsonLoadFile(fileName)
		if fileName ~= nil and fileName ~= "" then
			return jsonLoadFile(fileName)
		end
	end
	return nil
end

--请将该方法放在用户点击底部菜单栏时，“返回”按钮处理函数中调用
function OnReturnButton()
	local reg = registerCreate("video")
	require "module.common.registerScene"
	local volumeSprite = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle");
	local SceneName = registerGetString(regHandle, string.format("%d", volumeSprite))

	if  SceneName == sceneVideoGroup or SceneName == sceneVideoLiveDemand or SceneName == sceneVideoLiveDemand_NB or SceneName == sceneVideolocal then
		reg = registerCreate("video")  
		local sprite=registerGetInteger(reg, "root")
		local statuslabel = FindChildSprite(sprite, "player-status1")													--状态信息，用于显示播放器状态
		local statuslabe2 = FindChildSprite(sprite, "player-status2")													--状态信息
		local statusSMS   = FindChildSprite(sprite, "sms-Status")															--短信状态信息
		local smsStatusImage = FindChildSprite(sprite, "sms-Status-image")	
		SetSpriteVisible(statuslabel, 1)
		SetSpriteVisible(statuslabe2, 1)	
		SetSpriteProperty(statusSMS, "text", "")
		SetSpriteVisible(smsStatusImage, 0)	
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Show" , 0)
			pluginInvoke(MediapalyPlugin, "Stop")
		end
	end
end

--请将该方法放在用户点击底部菜单栏时，除“返回”外的其它处理函数中
function OnMenuButton()
	local reg = registerCreate("video")
	require "module.common.registerScene"
	local volumeSprite = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle")
	local SceneName = registerGetString(regHandle, string.format("%d", volumeSprite))

	if  SceneName == sceneVideoGroup or SceneName == sceneVideoLiveDemand or SceneName == sceneVideoLiveDemand_NB or SceneName == sceneVideolocal then
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Show" , 0)
			pluginInvoke(MediapalyPlugin, "Pause")
		end
	elseif SceneName == scenePrograminfo_volume or SceneName == sceneProduct then
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Stop")
		end
	end
end

--记录已播放器节目
function SaveHistoryVideoList(IsReview)
	local purl = playurl
	local i,j = string.find(purl,"?contentId=")
	local k = nil
	if j then
		k = string.find(purl,"&",j+1)
	else
		--[[  playurl上没有contentId，一般不会出这个错  ]]--
		return
	end
	local contentId = nil
	if k then
		contentId = string.sub(playurl,j+1,k-1)
	else
		contentId = string.sub(playurl,j+1,string.len(playurl))
	end
	local regVideoList = registerCreate("historyVideoList")
	registerLoad(regVideoList, "MODULE:\\..\\temp\\history.xml")
	local count = registerGetInteger(regVideoList, "count")
	if count and count ~= 0 then
		--[[ 清空旧版本历史记录格式 ]]--
		--registerClear(regVideoList) --clear方法有问题 慎用
		registerRelease("historyVideoList")
		regVideoList = registerCreate("historyVideoList")
	end
	local historyContent = registerGetString(regVideoList, "historyContent")
	local _,isIn = string.find(historyContent,contentId)
	if isIn and isIn ~= 0 then
		registerRelease("historyVideoList")
		return
	else
		local historyItemCount = registerGetInteger(regVideoList, "historyItemCount")
		local m_date=os.date("*t", os.time())
		local m_datestr = m_date.year .."-" ..m_date.month .."-" ..m_date.day
		if IsReview == nil then
			registerSetString(regVideoList,"history"..historyItemCount+1,"{"..contentId.."},".."{"..playurl.."},".."{"..pathurl.."},".."{"..m_datestr.."},".."{"..videoName.."},".."{"..videoType.."},".."{}")
		else
			registerSetString(regVideoList,"history"..historyItemCount+1,"{"..contentId.."},".."{"..playurl.."},".."{"..pathurl.."},".."{"..m_datestr.."},".."{"..videoName.."},".."{"..videoType.."},".."{"..IsReview.."}")
		end
		registerSetInteger(regVideoList,"historyItemCount",historyItemCount+1)
		local str = registerGetString(regVideoList,"historyContent")
		registerSetString(regVideoList,"historyContent",str..contentId..",")
		registerSave(regVideoList, "MODULE:\\..\\temp\\history.xml")
		registerRelease("historyVideoList")
	end
end

function SaveLiveTable(LiveTable)
	g_LiveTalbe = {}
	if LiveTable then
		g_LiveTalbe = LiveTable
		for i = 1, #LiveTable do
			WriteLogs("contentName"..i.."-->"..LiveTable[i].contentName)
			WriteLogs("startTime-->"..LiveTable[i].startTime)
			WriteLogs("endTime-->"..LiveTable[i].endTime)
		end
	end
end

function GetLiveTable()
	local reg_Livelist = registerCreate("LiveList")
	local listIndex    = registerGetInteger(reg_Livelist, "listIndex")
	local listCount    = registerGetInteger(reg_Livelist, "listCount")
	if listIndex <= listCount then
		local name         = registerGetString(reg_Livelist, "contentName"..listIndex)
		local startTime    = registerGetString(reg_Livelist, "startTime"..listIndex)
		local endTime      = registerGetString(reg_Livelist, "endTime"..listIndex)
		listIndex = listIndex + 1
		registerSetInteger(reg_Livelist, "listIndex", listIndex)
		return name, startTime, endTime
	else
		return ""
	end
end