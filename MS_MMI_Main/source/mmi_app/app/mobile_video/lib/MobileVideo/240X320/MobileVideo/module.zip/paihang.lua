﻿--@module	paihang
--@note	排行界面UI
--@author	shenyi
--@date	2010/05/27

require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.protocol.protocol_videoloading"
require "module.Loading.useLoading"
require "module.common.ascertainTargetScene"
require "module.protocol.protocol_topten"
require "module.keyCode.keyCode"

paihang_FirMenuRect = {9,0,43,30}
paihang_SecMenuRect = {52,0,43,30}
paihang_ThrMenuRect = {95,0,43,30}
paihang_ForMenuRect = {145,0,43,30}
paihang_FifMenuRect = {188,0,43,30}
paihang_ButtonRect = {0,0,50,30}
paihang_TextRect1 = {7,6,46,30}
paihang_TextRect2 = {7,5,46,30}
paihang_SelectHeight = 48
paihang_NormalHeight = 25
paihang_ItemWidth = 222
paihang_WholeStarWidth = 16
paihang_HalfStarWidth = 12
paihang_StarHeight = 12

lefturl = nil
righturl = nil
urlarray = {}
listcount = 0
navicount = 0
--totalheight = 0
--@function	bodyBuildChildrenFinished
--@tag-action	body:BuildChildrenFinished
--@brief	创建列表
function bodyBuildChildrenFinished(sprite)
	SetSpriteFocus(FindChildSprite(sprite,"tempButton"))
	saveTouchFocus(FindChildSprite(sprite,"tempButton"))
	WriteLogs(" 默认焦点："..HasSpriteFocus(FindChildSprite(sprite,"tempButton")))
	WriteLogs("paihang bodyBuildChildrenFinished")
	local reg = registerCreate("paihang")
	registerSetInteger(reg, "root", sprite)
	http = pluginCreate("HttpPipe")
	local topTenData = TopTenNetworkData()
	if topTenData then
		jsondata = topTenData
		if jsondata then 
			createPaihangData(jsondata)
			if navicount > 0 then
				createMenuList()
				setMenuListData()
			end
			if listcount > 0 then
				createPaihangList()
				setPaihangListData()
			end
		end
	end
	--[[if totalheight < 311 then
		local spriteImage = FindChildSprite(sprite,"scrollbar-image")
		local spriteScroll = FindChildSprite(sprite,"scroll")
		local spriteSplider = FindChildSprite(sprite,"splider-bar")
		SetSpriteVisible(spriteImage,0)
		SetSpriteVisible(spriteSplider,0)
		SetSpriteEnable(spriteScroll,0)
		SetSpriteEnable(spriteSplider,0)
	end--]]

	--LoadQuickLauncherBar(sprite)

	--curstart_index = 0
	return 1
end

--@function	createPaihangList
--@brief	创建排行项目列表
function createPaihangList()
	local reg = registerCreate("paihang")
	local sprite = registerGetInteger(reg, "root")	
	local strImgPaihang = {"file:///image/paihang/one.png","file:///image/paihang/two.png", 
			"file:///image/paihang/three.png","file:///image/paihang/four.png",
			"file:///image/paihang/ico_five.png","file:///image/paihang/ico_six.png",
			"file:///image/paihang/ico_seven.png","file:///image/paihang/ico_eight.png",
			"file:///image/paihang/ico_nine.png","file:///image/paihang/ico_ten.png"}
		
	local spriteList = FindChildSprite(sprite, "paihang-list")
	SpriteList_ClearListItem(spriteList, 1,1)
	if listcount == 0 then  return end
	local xmlNode=xmlLoadFile("MODULE:\\paihanglistitem.xml")
	for i=1, listcount do		
		local paihangSprite = CreateSprite("listitem")
		LoadSpriteFromNode(paihangSprite, xmlNode)	
		local spriteImage = FindChildSprite(paihangSprite, "paixu-image")
		local spriteImage1 = FindChildSprite(paihangSprite, "paixu-image1")
		if i <= 10 then
			SetSpriteProperty(spriteImage, "src", strImgPaihang[i])
			SetSpriteProperty(spriteImage1, "src", strImgPaihang[i])
		end
		local spriteUnselect = FindChildSprite(paihangSprite, "unselect")
		local spriteSelect = FindChildSprite(paihangSprite, "select")				
		
		if i == 1 then
			SetSpriteVisible(spriteSelect,0)
			SetSpriteEnable(spriteSelect,0)
			SetSpriteVisible(spriteUnselect,1)
			SetSpriteEnable(spriteUnselect,1)	
			SetSpriteRect(paihangSprite,0,0,paihang_ItemWidth,paihang_NormalHeight)	
			prevSelectSprite = paihangSprite			
		else		
			SetSpriteVisible(spriteSelect,0)
			SetSpriteEnable(spriteSelect,0)
			SetSpriteVisible(spriteUnselect,1)
			SetSpriteEnable(spriteUnselect,1)	
			SetSpriteRect(paihangSprite,0,0,paihang_ItemWidth,paihang_NormalHeight)	
		end
				
		if i == listcount then 
			local spriteFengge = FindChildSprite(paihangSprite, "fengge-image")
			local spriteFengge1 = FindChildSprite(paihangSprite, "fengge-image1")		
			SetSpriteVisible(spriteFengge,0)
			SetSpriteVisible(spriteFengge1,0)
		end
				
		AddChildSprite(spriteList, paihangSprite)
		SpriteList_AddListItem(spriteList, paihangSprite)
	end	
	xmlRelease(xmlNode)
	SpriteList_Adjust(spriteList)
	pHList=spriteList
	SetSpriteFocus(FindChildSprite(SpriteList_GetListItem(spriteList, 0),"item-button"))
	saveTouchFocus(FindChildSprite(SpriteList_GetListItem(spriteList, 0),"item-button"))
	
	--totalheight = 25*listcount + 23
	--[[  统一滚动条创建  ]]--
	require "module.common.commonScroll"
	CreateScrollBar(sprite,"paihang-list",(listcount-1)*paihang_NormalHeight+paihang_SelectHeight,76.4)		
	ScrollBarAdjust(0,4,0)	
end


--@function	createMenuList
--@brief	创建顶端菜单列表
--menuText={"动漫榜","原创榜","榜中榜","影视榜","财经榜"}
function createMenuList()
	local reg = registerCreate("paihang")
	local sprite = registerGetInteger(reg, "root")	
	local spriteList = FindChildSprite(sprite, "top-list")
	local xmlNode=xmlLoadFile("MODULE:\\paihangtopitem.xml")
	for i=1,5 do
		local menuSprite = CreateSprite("listitem")
		LoadSpriteFromNode(menuSprite, xmlNode)
		local spriteTxt = FindChildSprite(menuSprite, "menu-text")
		--SetSpriteProperty(spriteTxt, "text", menuText[i])
	
		if i == 1 then
			SetSpriteRect(menuSprite,paihang_FirMenuRect[1],paihang_FirMenuRect[2],paihang_FirMenuRect[3],paihang_FirMenuRect[4])			
		elseif i == 2 then
			SetSpriteRect(menuSprite,paihang_SecMenuRect[1],paihang_SecMenuRect[2],paihang_SecMenuRect[3],paihang_SecMenuRect[4])	
		elseif i == 3 then
			local spriteButton = FindChildSprite(menuSprite, "menu-button")
			local spriteTxt1 = FindChildSprite(menuSprite, "menu-text1")
			SetSpriteProperty(spriteTxt, "color", "#226688")
			SetSpriteProperty(spriteTxt, "v-align", "center")
			SetSpriteRect(spriteTxt,paihang_TextRect1[1],paihang_TextRect1[2],paihang_TextRect1[3],paihang_TextRect1[4])
			SetSpriteProperty(spriteTxt1, "color", "#226688")
			SetSpriteProperty(spriteTxt1, "v-align", "center")
			SetSpriteRect(spriteTxt1,paihang_TextRect2[1],paihang_TextRect2[2],paihang_TextRect2[3],paihang_TextRect2[4])
			SetSpriteRect(menuSprite,paihang_ThrMenuRect[1],paihang_ThrMenuRect[2],paihang_ThrMenuRect[3],paihang_ThrMenuRect[4])	
			SetSpriteRect(spriteButton,paihang_ButtonRect[1],paihang_ButtonRect[2],paihang_ButtonRect[3],paihang_ButtonRect[4])
		elseif i == 4 then
			SetSpriteRect(menuSprite,paihang_ForMenuRect[1],paihang_ForMenuRect[2],paihang_ForMenuRect[3],paihang_ForMenuRect[4])
		elseif i == 5 then
			SetSpriteRect(menuSprite,paihang_FifMenuRect[1],paihang_FifMenuRect[2],paihang_FifMenuRect[3],paihang_FifMenuRect[4])	
		end
		
		--SetSpriteRect(menuSprite, 10+45*(i-1), 0, 45, 30)
		AddChildSprite(spriteList, menuSprite)
		SpriteList_AddListItem(spriteList, menuSprite)
		local spriteItem = SpriteList_GetListItem(spriteList, 2)
		SetSpriteFocus(FindChildSprite(spriteItem,"menu-button"))
		saveTouchFocus(FindChildSprite(spriteItem,"menu-button"))
	end	
	xmlRelease(xmlNode)
end


relation = {2,1,3,0,4}
--设置顶部菜单显示文字
function setMenuListData()
	local reg = registerCreate("paihang")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "top-list")
	local nMax = math.min(#jsondata.imgListNavi, 4)
	
	for i=0, nMax do
		spriteItem = SpriteList_GetListItem(spriteList, relation[i+1])
		local spriteTxt = FindChildSprite(spriteItem, "menu-text")
		SetSpriteProperty(spriteTxt, "text", NaviDataArray[i].naviName)
		if i == 0 then
			local spriteTxt1 = FindChildSprite(spriteItem, "menu-text1")
			SetSpriteProperty(spriteTxt1, "text", NaviDataArray[i].naviName)
		end
	end
	local spriteLeft = FindChildSprite(sprite,"leftButton")	
	if jsondata.imgListNavi == nil or table.maxn(jsondata.imgListNavi) < 1 then
		SetSpriteEnable(spriteLeft,0)
	else
		SetSpriteEnable(spriteLeft,1)
	end
	local spriteRight = FindChildSprite(sprite,"rightButton")	
	if jsondata.imgListNavi == nil or table.maxn(jsondata.imgListNavi) < 2 then
		SetSpriteEnable(spriteRight,0)
	else
		SetSpriteEnable(spriteRight,1)
	end	
end

--设置排行列表各项数据
function setPaihangListData()
	local reg = registerCreate("paihang")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "paihang-list")
	for i = 1,listcount do
		spriteItem = SpriteList_GetListItem(spriteList, i-1)
		
		local spritePlay = FindChildSprite(spriteItem, "playbutton")
		local spriteDetail = FindChildSprite(spriteItem, "detailbutton")
		local spriteGoto = FindChildSprite(spriteItem, "gotobutton")
		WriteLogs("programDataArray"..i.." category"..programDataArray[i-1].category)
		WriteLogs("spritePlay---"..spritePlay)
		WriteLogs("spriteGoto---"..spriteGoto)
		local category = tonumber(programDataArray[i-1].category)
		if  category == 5 then
			WriteLogs("category==5")
			SetSpriteVisible(spritePlay,0)
			SetSpriteEnable(spritePlay,0)
			SetSpriteVisible(spriteDetail,0)
			SetSpriteEnable(spriteDetail,0)
			SetSpriteVisible(spriteGoto,1)
			SetSpriteEnable(spriteGoto,1)			
		else
			SetSpriteVisible(spritePlay,1)
			SetSpriteEnable(spritePlay,1)
			SetSpriteVisible(spriteDetail,1)
			SetSpriteEnable(spriteDetail,1)
			SetSpriteVisible(spriteGoto,0)
			SetSpriteEnable(spriteGoto,0)				
		end
		
		--设置显示文字
		local spriteTxt = FindChildSprite(spriteItem, "item-text")
		local spriteTxt1 = FindChildSprite(spriteItem, "item-text1")
		SetSpriteProperty(spriteTxt, "text", programDataArray[i-1].contentName)	
		SetSpriteProperty(spriteTxt1, "text", programDataArray[i-1].contentName)		
		
		--显示播放次数
		local spriteCount = FindChildSprite(spriteItem,"play-count")
		local spriteCount1 = FindChildSprite(spriteItem,"play-count1")		
		SetSpriteProperty(spriteCount,"text",programDataArray[i-1].playCount)
		SetSpriteProperty(spriteCount1,"text",programDataArray[i-1].playCount)	
	
		--显示星级
		local starlevel = FindChildSprite(spriteItem , "starlevel")
		local star = (programDataArray[i-1].starLevel)/2
		local width1 = math.floor(star)*paihang_WholeStarWidth
		local width2 = (star - math.floor(star))*paihang_HalfStarWidth
		SetSpriteRect(starlevel,0,0,width1+width2,paihang_StarHeight)
	end
end

function clearList()
	local reg = registerCreate("paihang")
	local sprite = registerGetInteger(reg, "root")	
	local topList = FindChildSprite(sprite, "top-list")	
	local spriteList = FindChildSprite(sprite, "paihang-list")
	SpriteList_ClearListItem(topList, 1,1)	
	SpriteList_ClearListItem(spriteList, 1,1)	
end


--@function	paihangButtonOnSelect
--@tag-name	paihangButton
--@tag-action	button:OnSelect
--@brief	用于响应排行列表按键事件
function paihangButtonOnSelect(sprite)
	--[[
	if prevSelectSprite ~= nil then
		WriteLogs("itemButtonOnSelect "..prevSelectSprite)
		local spriteSel1 = FindChildSprite(prevSelectSprite,"select")
		local spriteUnSel1 = FindChildSprite(prevSelectSprite,"unselect")		
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)	
		SetSpriteRect(prevSelectSprite, 0,0, paihang_ItemWidth, paihang_NormalHeight)
	end
	]]--
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "paihang-list")
	
	for i=0,(SpriteList_GetListItemCount(spriteList)-1) do
		local initItem=SpriteList_GetListItem(spriteList,i)
		local spriteSel1 = FindChildSprite(initItem,"select")
		local spriteUnSel1 = FindChildSprite(initItem,"unselect")		
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)	
		SetSpriteRect(initItem, 0,0, paihang_ItemWidth, paihang_NormalHeight)
	end
	local spriteParent = GetSpriteParent(sprite)
	local spritePaihang = GetSpriteParent(spriteParent)
	local spriteSel2 = FindChildSprite(spritePaihang,"select")
	local spriteUnSel2 = FindChildSprite(spritePaihang,"unselect")

	SetSpriteVisible(spriteUnSel2, 0)
	SetSpriteEnable(spriteUnSel2, 0)
	SetSpriteVisible(spriteSel2, 1)			
	SetSpriteEnable(spriteSel2, 1)
	SetSpriteRect(spritePaihang, 0,0, paihang_ItemWidth, paihang_SelectHeight)
	local buttonPlay = FindChildSprite(spriteSel2, "playbutton")
	SetSpriteFocus(buttonPlay)
	saveTouchFocus(buttonPlay)
	SpriteList_Adjust(spriteList)
	prevSelectSprite = spritePaihang
	-- select = SpriteListItem_GetIndex(spritePaihang) + 1
	-- WriteLogs(select)
end

function gotoButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("paihang")
	local root = GetRootSprite(sprite)
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	WriteLogs("gotoButtonOnSelect")
	local spriteParent = GetSpriteParent(sprite)
	local spritePaihang = GetSpriteParent(spriteParent)
	local index = SpriteListItem_GetIndex(spritePaihang)
	local formType = tonumber(programDataArray[index].formType)
	local displayType = tonumber(programDataArray[index].displayType)
	local urlpath = programDataArray[index].urlPath
	SceneName, pfnRequest, pfnDecode = AscertainTargetScene(5,formType,displayType)
	pfnRequest(102,urlpath)		
end

function detailButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("paihang")
	local root = GetRootSprite(sprite)
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	
	local spriteParent = GetSpriteParent(sprite)
	local spritePaihang = GetSpriteParent(spriteParent)
	local index = SpriteListItem_GetIndex(spritePaihang)
	local urlpath = programDataArray[index].urlPath	
	require "module.protocol.protocol_infovolume"
	RequestVolume(103,urlpath)
end

function playButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("paihang")
	local root = GetRootSprite(sprite)
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	--[[  这里应该动态获取点击按钮的具体url  ]]--
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local num = SpriteListItem_GetIndex(spriteItem)
	local urlpath = programDataArray[num].urlPath
	local playUrl = programDataArray[num].playUrl
	local name = programDataArray[num].contentName
	WriteLogs("urlpath "..urlpath)
	WriteLogs("playUrl "..playUrl)
	RequestVideo(104, playUrl, urlpath, name, "demand")
	--[[ 不需要响应这个请求，只是为了拿到详情中的下载地址 ]]--
	require "module.protocol.protocol_infovolume"
	RequestVolume(999,urlpath)
	return 1
end

function leftButtonOnSelect()	
	if jsondata.imgListNavi and table.maxn(jsondata.imgListNavi) >= 1 then
		--[[  获得根节点  ]]--  
		local reg = registerCreate("paihang")
		local sprite = registerGetInteger(reg, "root")	
		local loadarea = FindChildSprite(sprite, "loadarea")
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		RequestTopTen(101,jsondata.imgListNavi[1].urlPath)	
	end	
end

function rightButtonOnSelect()
	if jsondata.imgListNavi and table.maxn(jsondata.imgListNavi) >= 2 then
		--[[  获得根节点  ]]--  
		local reg = registerCreate("paihang")
		local sprite = registerGetInteger(reg, "root")	
		local loadarea = FindChildSprite(sprite, "loadarea")
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		RequestTopTen(101,jsondata.imgListNavi[2].urlPath)	
	end
end


--@function	menuButtonOnSelect
--@tag-name	menu-button
--@tag-action	button:OnSelect
--@brief	用于响应顶端菜单按键事件
relation2 = {3,1,0,2,4}
function menuButtonOnSelect(sprite)
    WriteLogs("menuButtonOnSelect")
	local spriteItem = GetSpriteParent(sprite)
	local index2 = SpriteListItem_GetIndex(spriteItem)	
	local index = relation2[index2+1]
	if jsondata.imgListNavi[index].urlPath then
		--[[  获得根节点  ]]--  
		local reg = registerCreate("paihang")
		local root = GetRootSprite(sprite)
		local loadarea = FindChildSprite(root, "loadarea")
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)

		RequestTopTen(101,jsondata.imgListNavi[index].urlPath)
	end
end

function OnPluginEventPh(message, param)
	require "module.videoexpress-common"
	WriteLogs("bodyOnPluginEvent")
	if message == 101 then
		WriteLogs("paihang")
		exitLoading()
		local topTenData = LoadJsonTopTenNetworkData()
		if topTenData then
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			Go2Scene(scenePaihang)
		end
		-- local reg = registerCreate("paihang")
		-- local sprite = registerGetInteger(reg,"root")
				
		-- local jsondata = jsonToTable(TopTenNetworkData())
		-- createPaihangData(jsondata)
		-- --createMenuList()
		-- clearList()
		-- if navicount > 0 then
			-- createMenuList()
			-- setMenuListData()
		-- end
		-- if listcount > 0 then
			-- createPaihangList()
			-- setPaihangListData()
			-- resetFirstItem()
		-- end
	elseif message == 102 then
		local detailData = pfnDecode()
		WriteLogs("detail decode end")
		exitLoading()
		if detailData then
			exitLoading()		
			SetReturn(scenePaihang,SceneName)
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			Go2Scene(SceneName)
		else
		--[[  出错提示  ]]--
		end			
	elseif message == 103 then
		require "module.protocol.protocol_infovolume"
		local volumeData = OnVolumeDecode()
		WriteLogs("volume decode end")
		if volumeData then
			exitLoading()		
			SetReturn(scenePaihang,scenePrograminfo_volume)
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			GoAndFreeScene(scenePrograminfo_volume)
		else
		--[[  出错提示  ]]--
		end	
	elseif message == 104 then
		RequestPlay(scenePaihang)
	elseif MSG_SMS_ID == message then
		DealMsgContent(scenePaihang, scenePaihang)
	end
end

---------------------------------------------------
---------------------------------------------------
--Network Data  Change Channel
function changeChannelList(jsonChannelGroup)
	if jsonChannelGroup.imgListNavi then
--		0 1 2 3 4 5 
--		排成 5 3 1 0 2 4 5 3 1 0 2 4
--		得到这个表的索引	
		local valueMax = table.maxn(jsonChannelGroup.imgListNavi);
		local imgListNaviCount = table.maxn(jsonChannelGroup.imgListNavi) + 1
		WriteLogs(string.format("valueMax [%d]", valueMax))
		local nBegin = (valueMax % 2) ~= 0 and valueMax or valueMax - 1
		local nCount = 0
		local nIndex = nBegin
		local array = {}
--		奇数
		for nIndex = nBegin, 1, -2 do
			array[nCount] = nIndex
			nCount = nCount + 1
		end
--		偶数
		for nIndex = 0, valueMax, 2 do
			array[nCount] = nIndex
			nCount = nCount + 1
		end
				
		nIndex = 0
        local arrMax = (valueMax + 1) * 2 - 1
		for nCount = nCount, arrMax do
			array[nCount] = array[nIndex]
			nIndex = nIndex + 1
		end
----debug Info
--		for i = 0, table.maxn(array) do
--			WriteLogs(string.format("%d,", array[i]))
--		end

		local nFindIndex = 0
		for i=0, table.maxn(jsonChannelGroup.imgListNavi) do
			local haveData = jsonChannelGroup.imgListNavi[i].haveData
			if string.match(haveData, "true") then
				nFindIndex = i
			end
		end
		WriteLogs(string.format("1.nFindIndex [%d]", nFindIndex))
		for i=0, #array do
			WriteLogs(string.format("nValue [%d]", array[i]))
			if array[i] == nFindIndex then 
				nFindIndex = i
				break
			end
		end
		
		nFindIndex = (nFindIndex < imgListNaviCount / 2) and (nFindIndex + imgListNaviCount) or nFindIndex;
--		构建数据数组
		local newImgList = {}
		nIndex2 = 0
		nIndex = 1
		newImgList[nIndex2] = jsonChannelGroup.imgListNavi[array[nFindIndex]]
		nIndex2 = nIndex2 + 1
		WriteLogs("11111111#newImgList---"..#newImgList)
		while nIndex < 4 and #newImgList < valueMax do
			if (nFindIndex - nIndex) >= 0 then
				newImgList[nIndex2] = jsonChannelGroup.imgListNavi[array[nFindIndex - nIndex]]
				nIndex2  = nIndex2 + 1
			end
			if array[nFindIndex - nIndex] ~= array[nFindIndex + nIndex] then
				if ( (nFindIndex + nIndex) < imgListNaviCount * 2) then
				  newImgList[nIndex2] = jsonChannelGroup.imgListNavi[array[nFindIndex + nIndex]]
				  nIndex2 = nIndex2 + 1
				end
			end
			nIndex = nIndex + 1
			WriteLogs("222222222#newImgList---"..#newImgList)
		end
		jsonChannelGroup.imgListNavi = newImgList		
				
	end
end

--@function RequestPaihang
--@brief 协议请求
function RequestPaihang(url,tag)
	WriteLogs(string.format("1. RequestGuide URL [%s]", url))
	
	fileName = GetLocalFilename(url)
	WriteLogs("fileName"..fileName)
	local reg = registerCreate("paihang")
	registerSetString(reg, "paihangUrlFileName", fileName)
	local observer = pluginGetObserver()	
	WriteLogs("pluginInvoke")
	pluginInvoke(http, "AppendCommand", 0, url, 0, fileName, observer, 101, 0,1)
	
end



--@function createPaihangData
--@brief 协议解析,顶部菜单信息存入NaviDataArray中，列表项内容存入programDataArray中
function createPaihangData(json)
	
	--local json = jsonLoadFile(fileName)
	
	changeChannelList(json)
	
	NaviDataArray = {}

	if json.imgListNavi then
		navicount = table.maxn(json.imgListNavi) + 1
		WriteLogs("naviCount"..navicount)
		--for i=0, table.maxn(json.imgListNavi) do			
		for i=0,table.maxn(json.imgListNavi) do
			local name = nil
			local id = nil

			if json.imgListNavi[i].topId then
				id = json.imgListNavi[i].topId
			elseif json.imgListNavi[i].channelName then
				id = json.imgListNavi[i].channelId
			end		
			
			if json.imgListNavi[i].topName then
				name = json.imgListNavi[i].topName
			elseif json.imgListNavi[i].channelName then
				name = json.imgListNavi[i].channelName
			end
			
			NaviDataArray[i] = {
						naviName	=	name,
						navilId		=	id,
						channelType =   json.imgListNavi[i].channelType,
						urlPath		=	json.imgListNavi[i].urlPath,
						}
		
		end
	end
	
	
	programDataArray = {}
	
	if json.programList then
		listcount = table.maxn(json.programList)+1
		--超过十个，只显示前十个
		if listcount > 10 then
			listcount = 10
		end
		for i=0, table.maxn(json.programList) do
			programDataArray[i] = {
					contentId	=	json.programList[i].contentId,
					contentName =	json.programList[i].contentName,
					starLevel	=	json.programList[i].starLevel,
					category	=	json.programList[i].category,
					formType	=	json.programList[i].formType,
					displayType	=	json.programList[i].displayType,
					type		=	json.programList[i].type,
					playUrl		=	json.programList[i].playUrl,
					urlPath		=	json.programList[i].urlPath,
					playCount 	=	json.programList[i].hits,
					}
		end
	end
	
end

function bodyOnSpriteEventPh(message, params)
	require "module.common.commonMsg"
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
end

--@function menuButtonOnKeyUp
--@tag-name menu-button
--@tag-action button:OnKeyUp
--brief 响应顶端菜单按键事件
function menuButtonOnKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	if keyCode == ApKeyCode_Left and LoadingFlag() then
		leftButtonOnSelect()
	elseif keyCode == ApKeyCode_Right and LoadingFlag() then
		rightButtonOnSelect()
	elseif keyCode == ApKeyCode_Down then
		local root = GetRootSprite(sprite)
		local paihangList = FindChildSprite(root, "paihang-list")
		local playButton = FindChildSprite(paihangList, "item-button")
		if playButton ~= nil then
			SetSpriteFocus(playButton)
			saveTouchFocus(playButton)
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--@brief 响应列表播放按钮键盘事件
--@auther  dw
function playButtonOnKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	WriteLogs("%%%%%%%%%%%%%%%%%%%%%%%: "..keyCode)
	local  name=GetSpriteName(sprite)
	local itemCount=SpriteList_GetListItemCount(pHList)
	local item=GetSpriteParent(GetSpriteParent(sprite))
	local index=SpriteListItem_GetIndex(item)
	local spriteSel = FindChildSprite(item,"select")
	local spriteUnSel = FindChildSprite(item,"unselect")
	local list_x, list_y2, list_w, list_h = GetSpriteRect(pHList)
	local _, list_y1 = GetSpriteRect(item)
	local list_y = list_y1+list_y2
	
	WriteLogs("头结点："..GetSpriteName(GetSpriteParent(sprite)))
	if keyCode==ApKeyCode_Enter then
		if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
				local i=1
				SetSpriteVisible(spriteSel, 1)
				SetSpriteEnable(spriteSel, 1)
				SetSpriteVisible(spriteUnSel, 0)			
				SetSpriteEnable(spriteUnSel, 0)	
				local x, y, w, h = GetSpriteRect(item)
				SetSpriteRect(item, x, y, 222, 48)
				SetSpriteFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton"))
				saveTouchFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton"))
				WriteLogs("焦点成功:"..HasSpriteFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton")))
				for j=index,itemCount-1 do
					
					spriteItem = SpriteList_GetListItem(pHList, index+i)
					i=i+1
					local x, y, w, h = GetSpriteRect(spriteItem)			
					SetSpriteRect(spriteItem,x,y+26,w,h)
				end
		elseif GetSpriteName(GetSpriteParent(sprite))=="select" then
				if GetSpriteName(sprite)=="playbutton" then playButtonOnSelect(sprite)
				elseif GetSpriteName(sprite)=="detailbutton" then detailButtonOnSelect(sprite)
				elseif GetSpriteName(sprite)=="gotobutton" then gotoButtonOnSelect(sprite)
				end
		end
						if list_y >= 195 then
							SpriteScrollBar_Adjust(pHList)
							SetSpriteRect(pHList,list_x, list_y2-26,list_w, list_h)	
							ChangeScrollPositon(sprite,"down")
						end
						SpriteList_Adjust(pHList)
	elseif keyCode==ApKeyCode_Down and index<=itemCount-1 then
		
		if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
					if index==itemCount-1 then return 0 end
					local nextListItem = SpriteList_GetListItem(pHList, index+1)			
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))	
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
		elseif	GetSpriteName(GetSpriteParent(sprite))=="select" then
					if index==itemCount-1 and name=="detailbutton" then return 0 end
					local i=1
					if name=="playbutton" then
						WriteLogs("+++++++++++++++++++++++++++++++++++++++++++++++++")
						SetSpriteFocus(FindChildSprite(spriteSel,"detailbutton"))
						saveTouchFocus(FindChildSprite(spriteSel,"detailbutton"))
					elseif name=="detailbutton" or "gotobutton" then
						WriteLogs("-------------------------------------------------")
						local nextListItem = SpriteList_GetListItem(pHList, index+1)
						WriteLogs("下焦点："..SpriteListItem_GetIndex(nextListItem))
						SetSpriteVisible(spriteSel, 0)
						SetSpriteEnable(spriteSel, 0)
						SetSpriteVisible(spriteUnSel, 1)			
						SetSpriteEnable(spriteUnSel, 1)		
						local x, y, w, h = GetSpriteRect(item)							
						SetSpriteRect(item, x, y, 222, 25)
						local spriteSelNext = FindChildSprite(nextListItem,"select")
						local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
						SetSpriteVisible(spriteSelNext, 0)
						SetSpriteEnable(spriteSelNext, 0)
						SetSpriteVisible(spriteUnSelNext, 1)			
						SetSpriteEnable(spriteUnSelNext, 1)		
						SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
						saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					--[[	for j=index,itemCount-1 do
							
							spriteItem = SpriteList_GetListItem(pHList, index+i)
							i=i+1
							local x, y, w, h = GetSpriteRect(spriteItem)			
							SetSpriteRect(spriteItem,x,y-26,w,h)
						end]]---
					end
		end
						if list_y >= 195 then
							SpriteScrollBar_Adjust(pHList)
							SetSpriteRect(pHList,list_x, list_y2-26,list_w, list_h)
							ChangeScrollPositon(sprite,"down")
						end
						SpriteList_Adjust(pHList)
	elseif 	keyCode==ApKeyCode_Up then
			WriteLogs("上移动 ")
					if index==0 and name=="detailbutton"  then 
					SetSpriteFocus(FindChildSprite(spriteSel,"playbutton")) 
					saveTouchFocus(FindChildSprite(spriteSel,"playbutton"))
					return 0
					elseif index==0 and name=="playbutton" then return 0
					elseif index==0 then return 0
					
					end
					local i=1
					
					local nextListItem = SpriteList_GetListItem(pHList, index-1)
			if 		GetSpriteName(GetSpriteParent(sprite))=="unselect" then
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))	
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
			elseif	GetSpriteName(GetSpriteParent(sprite))=="select" then
					WriteLogs("上焦点："..SpriteListItem_GetIndex(nextListItem))
					if name=="detailbutton" then
						SetSpriteFocus(FindChildSprite(spriteSel,"playbutton"))
						saveTouchFocus(FindChildSprite(spriteSel,"playbutton"))
					elseif  name=="playbutton" or "gotobutton" then
						SetSpriteVisible(spriteSel, 0)
						SetSpriteEnable(spriteSel, 0)
						SetSpriteVisible(spriteUnSel, 1)			
						SetSpriteEnable(spriteUnSel, 1)		
						local x, y, w, h = GetSpriteRect(item)							
						SetSpriteRect(item, x, y, 222, 25)
						local spriteSelNext = FindChildSprite(nextListItem,"select")
						local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
						SetSpriteVisible(spriteSelNext, 0)
						SetSpriteEnable(spriteSelNext, 0)
						SetSpriteVisible(spriteUnSelNext, 1)			
						SetSpriteEnable(spriteUnSelNext, 1)		
						SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
						saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					--[[	for j=index,itemCount-1 do
							spriteItem = SpriteList_GetListItem(pHList, index+i)
							i=i+1
							local x, y, w, h = GetSpriteRect(spriteItem)			
							SetSpriteRect(spriteItem,x,y-26,w,h)
						end]]--
					end
					
			end
				if list_y <= 10 then
				SpriteScrollBar_Adjust(pHList)
				SetSpriteRect(pHList,list_x, list_y2+26,list_w, list_h)
				ChangeScrollPositon(sprite,"up")
				end
				SpriteList_Adjust(pHList)
	elseif keyCode == ApKeyCode_Left and LoadingFlag() then
		leftButtonOnSelect()
	elseif keyCode == ApKeyCode_Right and LoadingFlag() then
		rightButtonOnSelect()
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

function tempButtonKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require "module.keyCode.keyCode"
	if keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	WriteLogs("liuchaobing test spriteitem name is "..GetSpriteName(spriteitem))
	WriteLogs("liuchaobing test spriteitem index is "..CurIndex)
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,4,0)
	else
		ScrollBarAdjust(CurIndex + 1,4,1)
	end
end