--
require "module.common.SceneUtils"
function subjectButtonOnSelect(spriteButton)
	local subjectSpriteRoot = GetSpriteParent(spriteButton)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
	if subjectSpriteRoot and subjectSpriteRoot ~= 0 then
		local subjectList = FindChildSprite(subjectSpriteRoot, "subject-list")
		local spriteLeftButton = FindChildSprite(subjectSpriteRoot, "subject-left-button")
		local spriteRightButton = FindChildSprite(subjectSpriteRoot, "subject-right-button")
		
		if subjectList and subjectList ~= 0 then
			local listItemCount = SpriteList_GetListItemCount(subjectList)
			local itemPerPage = SpriteList_GetItemPerPage(subjectList)
			
			--���Խ��з�ҳ����
			if itemPerPage < listItemCount then
				local start = SpriteList_GetStartItem(subjectList)
--[[------------------------------------------------------------------------------------------------]]--
				local startItem
				local startButton
--------------------------------------------------------------------------------------------------------
				local spriteLeftImage = FindChildSprite(spriteLeftButton, "subject-left-enable-image")
				local spriteRightImage = FindChildSprite(spriteRightButton, "subject-right-enable-image")
						
				if spriteButton == spriteLeftButton then
--					WriteLogs("spriteButton == spriteLeftButton")
					registerSetNumber(pageIndexReg,"subjectPageIndex",(registerGetInteger(pageIndexReg, "subjectPageIndex")-1))
					start = start - itemPerPage
					if start >=0 then
-------------------------------------------------------------------------------------------------------------
						startItem=SpriteList_GetListItem(subjectList,start)
						startButton=FindChildSprite(startItem,"subject-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
						registerSetInteger(homeLastFoucsReg,"lastSubjectFocusSprite",startButton)
--------------------------------------------------------------------------------------------------------------						
						SpriteList_SetStartItem(subjectList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end
				elseif spriteButton == spriteRightButton then
					registerSetNumber(pageIndexReg,"subjectPageIndex",(registerGetInteger(pageIndexReg, "subjectPageIndex")+1))
					start = start + itemPerPage
					if start < listItemCount then
-----------------------------------------------------------------------------------------------------------						
						startItem=SpriteList_GetListItem(subjectList,start)
						startButton=FindChildSprite(startItem,"subject-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
						registerSetInteger(homeLastFoucsReg,"lastSubjectFocusSprite",startButton)
--------------------------------------------------------------------------------------------------------------						
						SpriteList_SetStartItem(subjectList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end	
				end
			end
		end
	end
end

function channelButtonOnSelect(spriteButton)
	local channelSpriteRoot = GetSpriteParent(spriteButton)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
	if channelSpriteRoot and channelSpriteRoot ~= 0 then
		local channelList = FindChildSprite(channelSpriteRoot, "channel-list")
		local spriteLeftButton = FindChildSprite(channelSpriteRoot, "channel-left-button")
		local spriteRightButton = FindChildSprite(channelSpriteRoot, "channel-right-button")
	
		if channelList and channelList ~= 0 then
			local listItemCount = SpriteList_GetListItemCount(channelList)
			local itemPerPage = SpriteList_GetItemPerPage(channelList)
			
			--���Խ��з�ҳ����
			if itemPerPage < listItemCount then
				local start = SpriteList_GetStartItem(channelList)
--[[------------------------------------------------------------------------------------------------]]--
				local startItem
				local startButton
--------------------------------------------------------------------------------------------------------				
				local spriteLeftImage = FindChildSprite(spriteLeftButton, "channel-left-enable-image")
				local spriteRightImage = FindChildSprite(spriteRightButton, "channel-right-enable-image")
						
				if spriteButton == spriteLeftButton then
--					WriteLogs("spriteButton == spriteLeftButton")
					registerSetNumber(pageIndexReg,"channelPageIndex",(registerGetInteger(pageIndexReg, "channelPageIndex")-1))
					start = start - itemPerPage
					if start >=0 then
-------------------------------------------------------------------------------------------------------------
						startItem=SpriteList_GetListItem(channelList,start)
						startButton=FindChildSprite(startItem,"channel-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
						registerSetInteger(homeLastFoucsReg,"lastChannelFocusSprite",startButton)
--------------------------------------------------------------------------------------------------------------	
						SpriteList_SetStartItem(channelList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end
				elseif spriteButton == spriteRightButton then
					registerSetNumber(pageIndexReg,"channelPageIndex",(registerGetInteger(pageIndexReg, "channelPageIndex")+1))
					start = start + itemPerPage
					if start < listItemCount then
-----------------------------------------------------------------------------------------------------------						
						startItem=SpriteList_GetListItem(channelList,start)
						startButton=FindChildSprite(startItem,"channel-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
						registerSetInteger(homeLastFoucsReg,"lastChannelFocusSprite",startButton)
--------------------------------------------------------------------------------------------------------------
						SpriteList_SetStartItem(channelList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end	
				end
			end
		end
	end
end

function pairButtonOnSelect(spriteButton)
	local pairSpriteRoot = GetSpriteParent(spriteButton)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
	if pairSpriteRoot and pairSpriteRoot ~= 0 then
		local pairList = FindChildSprite(pairSpriteRoot, "pair-list")
		local spriteLeftButton = FindChildSprite(pairSpriteRoot, "pair-left-button")
		local spriteRightButton = FindChildSprite(pairSpriteRoot, "pair-right-button")
	
		if pairList and pairList ~= 0 then
			local listItemCount = SpriteList_GetListItemCount(pairList)
			local itemPerPage = SpriteList_GetItemPerPage(pairList)
			
			--���Խ��з�ҳ����
			if itemPerPage < listItemCount then
				local start = SpriteList_GetStartItem(pairList)
--[[------------------------------------------------------------------------------------------------]]--
				local startItem
				local startButton
--------------------------------------------------------------------------------------------------------				
				local spriteLeftImage = FindChildSprite(spriteLeftButton, "pair-left-enable-image")
				local spriteRightImage = FindChildSprite(spriteRightButton, "pair-right-enable-image")
						
				if spriteButton == spriteLeftButton then
--					WriteLogs("spriteButton == spriteLeftButton")
					registerSetNumber(pageIndexReg,"pairPageIndex",(registerGetInteger(pageIndexReg, "pairPageIndex")-1))
					start = start - itemPerPage
					if start >=0 then
-------------------------------------------------------------------------------------------------------------
						startItem=SpriteList_GetListItem(pairList,start)
						startButton=FindChildSprite(startItem,"pair-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
						registerSetInteger(homeLastFoucsReg,"lastPairFocusSprite",startButton)
--------------------------------------------------------------------------------------------------------------
						SpriteList_SetStartItem(pairList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end
				elseif spriteButton == spriteRightButton then
					registerSetNumber(pageIndexReg,"pairPageIndex",(registerGetInteger(pageIndexReg, "pairPageIndex")+1))
					start = start + itemPerPage
					if start < listItemCount then
-----------------------------------------------------------------------------------------------------------						
						startItem=SpriteList_GetListItem(pairList,start)
						startButton=FindChildSprite(startItem,"pair-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
						registerSetInteger(homeLastFoucsReg,"lastPairFocusSprite",startButton)
--------------------------------------------------------------------------------------------------------------
						SpriteList_SetStartItem(pairList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end	
				end
			end
		end
	end
end

function OnSelectFromSubjectButton(sprite)
	local spriteListItem = GetSpriteParent(sprite)
	local index = SpriteListItem_GetIndex(spriteListItem)
	if homeData.subject and index <= #homeData.subject and homeData.subject[index] then
		RequestObject(homeData.subject[index])
	end
end

function OnSelectFromChannelButton(sprite)
	local spriteListItem = GetSpriteParent(sprite)
	local index = SpriteListItem_GetIndex(spriteListItem)
	if homeData.specialChannel and index <= #homeData.specialChannel and homeData.specialChannel[index] then
		RequestObject(homeData.specialChannel[index])
	end
end

function OnSelectFromPairButton(sprite)
	local spriteListItem = GetSpriteParent(sprite)
	local index = SpriteListItem_GetIndex(spriteListItem)	
	if homeData.channel and index <= #homeData.channel and homeData.channel[index] then
		RequestObject(homeData.channel[index])
	end
end

function editTextOnTextChanged(sprite)
	text = GetSpriteText(sprite)
	if text then
		local reg = registerCreate("home")
		local spriteRoot = registerGetInteger(reg, "root")	
		local spriteEditLabel = FindChildSprite(spriteRoot, "edit-text")
		SetSpriteProperty(spriteEditLabel, "text", text)
	end
	ReleaseSpriteCapture(sprite)
	local rootSprite = GetRootSprite(sprite)
  	local sendSprite = FindChildSprite(rootSprite,"scapegoat")
  	SetSpriteFocus(sendSprite)
end

function searchKeywordButtonOnSelect(sprite)
	local spriteName = GetSpriteName(sprite)
	if spriteName == "moreButton" then
		if homeData.moreKeyUrl then
			require("module.protocol.protocol_menusearch")
			RequestMenuSearch(105, homeData.moreKeyUrl)
			loadAnimation()
		end
		return
	else 
		local spriteListItem = GetSpriteParent(sprite)
		local nIndex = SpriteListItem_GetIndex(spriteListItem)
		if homeData.keyword[nIndex].searchUrl then
			RequestSearchResult(106, 1, homeData.searchUrl, homeData.keyword[nIndex].value)
			loadAnimation()
		end
	end
	require "module.searchInfo"
	SaveSearchReqSortType("time")
end

function searchButtonOnSelect(sprite)
	local reg = registerCreate("home")
	local spriteRoot = registerGetInteger(reg, "root")	
	local spriteEditLabel = FindChildSprite(spriteRoot, "edit-text")
	local text = GetSpriteText(spriteEditLabel)
	if nil == text or "" == text then
		if homeData.moreKeyUrl then
			require("module.protocol.protocol_menusearch")
			RequestMenuSearch(105, homeData.moreKeyUrl)
			loadAnimation()
		end
	else
		RequestSearchResult(106, 1, homeData.searchUrl, text)
		loadAnimation()
	end
	require "module.searchInfo"
	SaveSearchReqSortType("time")
end



testFlag = 0
function progressHitTest(sprite,x,y)		
	if y > 215 or (y < 124 and y > 86) then 
		return 0
	end
	moveNum = moveNum + 1
	WriteLogs("move---move")
	if testFlag == 1 then
		
		local parent = GetRootSprite(sprite)
		channellistSprite = FindChildSprite(parent, "channel-list")
		local l, t, w, h = GetSpriteRect(channellistSprite)
		local name = GetSpriteName(sprite)
		local channelNum = string.sub(name,16,17)
		local Num = tonumber(channelNum)
		if Num ~= nil then					--�㵽��ť��	
--			CurDownIndex = SpriteListItem_GetIndex(sprite)	
--			if DownIndex ~= CurDownIndex then			--�ƶ��������Ƶ���ť��
--				return
--			end
			local x = GetX(sprite, channellistSprite,x)
			local XX = x + l
			if g_l < 0 then		
				if XX - g_x <= 0 then
					SetSpriteRect(channellistSprite, XX , t, w, h)
					--SetSpriteRect(channellistSprite, g_l - (g_x - x) , t, w, h)
				else
					SetSpriteRect(channellistSprite, XX , t, w, h)
					--SetSpriteRect(channellistSprite, g_l + (x - g_x) , t, w, h)
				end			
			else 
				SetSpriteRect(channellistSprite, XX - g_x , t, w, h)
			end
		else							--�㵽�հ״�
			if g_l < 0 then		
				if x - g_x <= 0 then
					SetSpriteRect(channellistSprite, g_l - (g_x - x) , t, w, h)
				else
					SetSpriteRect(channellistSprite, g_l + (x - g_x) , t, w, h)
				end			
			else 
				SetSpriteRect(channellistSprite, x - g_x , t, w, h)
			end
		end
		
	end
	return 0
end

function progressOnMouseDown(sprite,x,y)	
	if y > 215 or (y < 124 and y > 86) then  
		return 0
	end
	
	moveNum = 0
	WriteLogs("down---down")
	local parent = GetRootSprite(sprite)
	channellistSprite = FindChildSprite(parent, "channel-list")
	local l, t, w, h = GetSpriteRect(channellistSprite)
	g_x = GetX(sprite, channellistSprite,x)
	

	local name = GetSpriteName(sprite)
	local channelNum = string.sub(name,16,17)
	local Num = tonumber(channelNum)
	if Num ~= nil then					--�㵽��ť��
		DownIndex = SpriteListItem_GetIndex(sprite)		
	end	
	g_l = l	
	testFlag = 1
	return 0
end

function progressOnMouseUp(sprite,x,y)
	if y > 215 or (y < 124 and y > 86) then 
		return 0
	end
	WriteLogs("up---up")
	local name = GetSpriteName(sprite)
	local channelNum = string.sub(name,16,17)
	local Num = tonumber(channelNum)
	if Num == nil then						--�㵽�հ״�		
		if x - g_x < 0 then					--�յ���������
			if channellistSprite then
				--26��һ��Ƶ�����ȵ�һ��
				local Mod = (g_x - x)%206
				local result = math.floor((g_x - x)/206)
				WriteLogs("Mod----->"..Mod)
				WriteLogs("result----->"..result)
				local reg_home = registerCreate("home")
				local col = registerGetInteger(reg_home, "col")
				if (result+1)*206 - g_l < col * 51 then	--���Ĳ���
					if Mod < 103 then
						SetSpriteRect(channellistSprite, g_l-result*206,0,206,86)
					else
						SetSpriteRect(channellistSprite, g_l-(result+1)*206,0,206,86)
					end
				else					--����̫��
					SetSpriteRect(channellistSprite, g_l-result*206,0,206,86)
				end
			end		
		else  							--�յ�������Ҳ�
			if channellistSprite then
				--26��һ��Ƶ�����ȵ�һ��
				local Mod = (x - g_x)%206
				local result = math.floor((x - g_x)/206)
				WriteLogs("Mod----->"..Mod)
				WriteLogs("result----->"..result)
				if (g_l + result*206) < 0 then
					if Mod < 103  then
						SetSpriteRect(channellistSprite, g_l + result*206,0,206,86)
					elseif Mod > 103 then
						SetSpriteRect(channellistSprite, g_l + (result+1)*206,0,206,86)				
					end
				else
					SetSpriteRect(channellistSprite, 0,0,206,86)
				end
			end
		end
	else		
--		CurDownIndex = SpriteListItem_GetIndex(sprite)	
--		if DownIndex ~= CurDownIndex then			--�ƶ��������Ƶ���ť��
--			return
--		end						--���ڰ�ť��
		local x = GetX(sprite, channellistSprite,x)
		local l, t, w, h = GetSpriteRect(channellistSprite)
		local x = x + l
		if l - g_l < 0 then					--�յ���������
			if channellistSprite then
				--26��һ��Ƶ�����ȵ�һ��
				local Mod = (g_l - l)%206
				local result = math.floor((g_l - l)/206)
				WriteLogs("Mod----->"..Mod)
				WriteLogs("result----->"..result)
				local reg_home = registerCreate("home")
				local col = registerGetInteger(reg_home, "col")
				if (result+1)*206 - g_l < col * 51 then	--���Ĳ���
					if Mod < 103 then
						SetSpriteRect(channellistSprite, g_l-result*206,0,206,86)
					else
						SetSpriteRect(channellistSprite, g_l-(result+1)*206,0,206,86)
					end
				else					--����̫��
					SetSpriteRect(channellistSprite, g_l-result*206,0,206,86)
				end
			end		
		else  							--�յ�������Ҳ�
			if channellistSprite then
				--26��һ��Ƶ�����ȵ�һ��
--				local Mod = (x - g_x)%206
--				local result = math.floor((x - g_x)/206)
				local Mod = (l - g_l)%206
				local result = math.floor((l - g_l)/206)
				WriteLogs("Mod----->"..Mod)
				WriteLogs("result----->"..result)
				if (g_l + result*206) < 0 then
					if Mod < 103  then
						SetSpriteRect(channellistSprite, g_l + result*206,0,206,86)
					elseif Mod > 103 then
						SetSpriteRect(channellistSprite, g_l + (result+1)*206,0,206,86)				
					end
				else
					SetSpriteRect(channellistSprite, 0,0,206,86)
				end
			end
		end
	end
	testFlag = 0
	return 0
end

function GetX(sprite,spriteList,x)
	local itemCount = SpriteList_GetListItemCount(channellistSprite)
	local name = GetSpriteName(sprite)
	local channelNum = string.sub(name,16,17)
	local Num = tonumber(channelNum)
	if Num ~= nil then
		Downindex = SpriteListItem_GetIndex(sprite)		
		if Num >= math.ceil(itemCount/2) then
			local Mod = (Num - math.ceil(itemCount/2)) % 4
			--g_x = Mod * 51 + x
			return Mod * 51 + x
		else
			local Mod = Num % 4
			--g_x = Mod * 51 + x
			return Mod * 51 + x
		end
	else
		--g_x = x
	--	WriteLogs("xxxxxxxxxxxxxxxxxx"..x)
		return x
	end
end
