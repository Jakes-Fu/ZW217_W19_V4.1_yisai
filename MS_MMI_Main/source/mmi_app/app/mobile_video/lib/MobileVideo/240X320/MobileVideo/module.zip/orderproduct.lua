---@module orderproduct
--@note 产品订购
--@author Abigale
--@date 2010/06/02

require "module.Loading.useLoading"
require "module.common.registerScene"
require "module.common.SceneUtils"
require "module.common.ascertainTargetScene"
require "module.dialog.useDialog"
require "module.keyCode.keyCode"

function bodyBuildChildrenFinished(sprite)
	--[[	设置根节点	]]--
	local reg = registerCreate("productorder")
	registerSetInteger(reg, "root", sprite)
	createProductOrderData(sprite)
	local orderProductFlagReg=registerCreate("orderProductFlagReg")
		registerSetString(orderProductFlagReg,"OrderProduct","duwei")
		duwei_Flag=registerGetString(orderProductFlagReg,"OrderProduct")
		WriteLogs("CCCCCCCCCCCCCCCCCCC     :"..duwei_Flag)
	return 1
end

--@@data come from download or play 获取产品订购页面数据
function OnProductOrderDecode()
	local reg = registerCreate("productorder")
	local myorderfileName = registerGetString(reg, "fileName")
	return jsonLoadFile(myorderfileName)
end

--@@show the orderproduct menu 展示产品订购页面数据
function createProductOrderData(sprite)
	ProductOrderArray = {}
	ProductOrderArray = OnProductOrderDecode()
	local spriteproductname = FindChildSprite(sprite, "productname")
	local spriteName = FindChildSprite(sprite, "product-name")
	local spriteIntroduce = FindChildSprite(sprite, "product-introduce")
	
	local spriteFeed1 = FindChildSprite(sprite, "fee1")
	local spriteFeed2 = FindChildSprite(sprite, "fee2")
	local spriteFeed3 = FindChildSprite(sprite, "fee3")
	
	orderProductButtonArray={
								FindChildSprite(sprite, "product-orderfee1"),FindChildSprite(sprite, "product-orderfee2"),
								FindChildSprite(sprite, "product-orderfee3")
							}
	local spriteFeedArray = {spriteFeed1, spriteFeed2, spriteFeed3}
	if ProductOrderArray.feeds ~= nil then
		n = table.maxn(ProductOrderArray.feeds)
		for i=0 ,n do
			SetSpriteProperty(spriteproductname, "text", ProductOrderArray.feeds[i].name)
			SetSpriteProperty(spriteName, "text",  ProductOrderArray.feeds[i].name)
			SetSpriteProperty(spriteIntroduce, "text", ProductOrderArray.feeds[i].desc)
			SetSpriteProperty(spriteFeedArray[i+1], "text", ProductOrderArray.feeds[i].price)
		end
	end		
	if ProductOrderArray.once then
		SetSpriteProperty(spriteproductname, "text",  ProductOrderArray.once[0].name)
		SetSpriteProperty(spriteName, "text",  ProductOrderArray.once[0].name)
		SetSpriteProperty(spriteIntroduce, "text", ProductOrderArray.once[0].desc)
		SetSpriteProperty(spriteFeedArray[3], "text", ProductOrderArray.once[0].price)
	end
	
	---------------------第1个资费按钮是否显示----------------------------
	local spriteButton1 = FindChildSprite(sprite, "product-orderfee1")
	local text1 = GetSpriteText(spriteFeed1)
	if text1 == ""  then
		SetSpriteVisible(spriteButton1, 0)
		SetSpriteEnable(spriteButton1, 0)
	end
	---------------------第1个资费按钮是否显示----------------------------
	---------------------第2个资费按钮是否显示----------------------------
	local spriteButton2 = FindChildSprite(sprite, "product-orderfee2")
	
	local text2 = GetSpriteText(spriteFeed2)
	if text2 == ""  then
		SetSpriteVisible(spriteButton2, 0)
		SetSpriteEnable(spriteButton2, 0)
	end
	---------------------第2个资费按钮是否显示----------------------------
	---------------------第3个资费按钮是否显示----------------------------
	local spriteButton3 = FindChildSprite(sprite, "product-orderfee3")
	local text3 = GetSpriteText(spriteFeed3)
	if text3 == ""  then
		SetSpriteVisible(spriteButton3, 0)
		SetSpriteEnable(spriteButton3, 0)
	end
	---------------------第3个资费按钮是否显示----------------------------
	--[[	默认选中按次	]]--
	if text2 ~= "" then
		local feesprite = FindChildSprite(sprite,"product-orderfee2")
		SetSpriteFocus(feesprite)
		saveTouchFocus(feesprite)
	elseif text1 ~= "" then
		local feesprite = FindChildSprite(sprite,"product-orderfee1")
		SetSpriteFocus(feesprite)
		saveTouchFocus(feesprite)
	elseif text3 ~= "" then
		local feesprite = FindChildSprite(sprite,"product-orderfee3")
		SetSpriteFocus(feesprite)
		saveTouchFocus(feesprite)
	end
end

-- 资费单选按钮
function orderfeeOnButtonClick(sprite)
	local	selectImg = FindChildSprite(sprite, "focusimg")	
	local	name=GetSpriteName(sprite)
	local	n = string.sub(name,17,17)
	local	n = math.floor(n)
	local spriteRoot = GetRootSprite(sprite)
	local spriteproductname = FindChildSprite(spriteRoot, "productname")
	local spriteName = FindChildSprite(spriteRoot, "product-name")
	local spriteIntroduce = FindChildSprite(spriteRoot, "product-introduce")
	if  IsSpriteVisible( selectImg ) == 1 then		
		if 3 == n then
		  if ProductOrderArray and ProductOrderArray.once then
				SetSpriteProperty(spriteproductname, "text",  ProductOrderArray.once[0].name)
				SetSpriteProperty(spriteName, "text",  ProductOrderArray.once[0].name)
				SetSpriteProperty(spriteIntroduce, "text", ProductOrderArray.once[0].desc)
				url = ProductOrderArray.once[0].url	
			else
			  
			end
		else
		  if ProductOrderArray and ProductOrderArray.feeds then
				SetSpriteProperty(spriteproductname, "text",  ProductOrderArray.feeds[n-1].name)
				SetSpriteProperty(spriteName, "text",  ProductOrderArray.feeds[n-1].name)
				SetSpriteProperty(spriteIntroduce, "text", ProductOrderArray.feeds[n-1].desc)
				url = ProductOrderArray.feeds[n-1].url
			else
			
			end
		end
		local reg = registerCreate("productorder")
		if url ~= nil and url ~= "" then
			registerSetString(reg, "productorderUrlFileName-pre", url)
		end
	end
end

--订购按钮
function orderbuttonOnSelect(sprite)
	saveTouchFocus(sprite)
	local reg = registerCreate("productorder")
	local url = registerGetString(reg, "productorderUrlFileName-pre")
	RequestOrderProduct(url,2002)
end

--@@deleiver http request 发送网络请求
function RequestOrderProduct(url,tag)
	loadAnimation()
	fileName = GetLocalFilename(url)
	local reg = registerCreate("productorder")
	registerSetString(reg, "productorderUrlFileName", fileName)
	
	local observer = pluginGetObserver()
	local regSystem = registerCreate("System")
	local http	= pluginCreate("HttpPipe")
	pluginInvoke(http, "AppendCommand", 0, url, 0, fileName, observer, tag, 0,1)
end

function OnSpriteEvent2(message, params)
	if message == 1001 then
		WriteLogs("-----------------do OnSpriteEvent2-----------------")
		if overwriteflag == 1 then
			require("module.setting")
			os.remove(Cfg.GetDownloadPath()..videoData.urls[0].name..Cfg.GetVideoType())
	    local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name,1)
	    if result == -1 then
				SetTimer(2, 1000, "OnTimer")
			else
				SetTimer(1, 1000, "OnTimer")
			end
		elseif overwriteflag == 2 then
			require "module.common.DownloadUpload"
			PauseOneDownloadTask(videoData.urls[0].name, 1)
			local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name,1)
			SetTimer(1, 1000, "OnTimer")
		end
	end	
end

function OnTimer(idEvent)
	if idEvent == 1 then
		setDialogParam("提示", "已经添加到下载队列", "BT_OK", sceneOrderProduct, sceneOrderProduct, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

--@@response http 网络请求回应
function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	if message == 2002 then
		exitLoading()
		local reg = registerCreate("productorder")
		local sprite = registerGetInteger(reg,"root")
		ResponseOrderProductDecode()
		JsonDataShow()
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneOrderProduct, sceneOrderProduct)
	elseif message > 32768 then
		exitLoading()
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneOrderProduct, sceneOrderProduct, GetCurScene())
		Go2Scene(sceneDialog)	
	end
end

--@@获取订购返回数据
function ResponseOrderProductDecode()
	local reg = registerCreate("productorder")
	local filename = registerGetString(reg, "productorderUrlFileName")
	json = jsonLoadFile(filename)
	return json
end

function JsonDataShow()
	videoData = ResponseOrderProductDecode()
	--[[ 弹出提示对话框 ]]--
	if videoData and videoData.success and videoData.success == "true" then
		local reg = registerCreate("productorder")
		local returntype = registerGetString(reg,"returntype")
		if returntype == "play" then 
			local spriteRoot = GetCurScene()
			local dialogsprite = FindChildSprite(spriteRoot, "dialogInterface")
			setDialogParam("提示", "订购成功", "BT_OK", sceneOrderProduct,sceneOrderProduct, dialogsprite, nil, nil, "", "")
			Go2Scene(sceneDialog)
			--SetTimer(1,3000,"Autojump")
		elseif returntype == "download" then
			require "module.common.DownloadUpload"
			DownloadProc(videoData,sceneOrderProduct)
		end
	elseif videoData and videoData.success and videoData.success == "true_identifyerror" then
		--[[ 不让其跳转到播放页面 ]]--
		local reg = registerCreate("QuickLauncherBar")
		local count = registerGetInteger(reg, "Count")
		registerSetInteger(reg, "Count", count-1)
		if videoData.desc and videoData.desc ~= "" then
			setDialogParam("提示", videoData.desc, "BT_NULL", sceneOrderProduct, sceneOrderProduct,nil)
		else
			setDialogParam("提示", "订购成功，次月生效", "BT_NULL", sceneOrderProduct, sceneOrderProduct,nil)
		end
		Go2Scene(sceneDialog)
	else
		local spriteRoot = GetCurScene()
		local dialogsprite2 = FindChildSprite(spriteRoot, "dialogInterface2")
		setDialogParam("提示", "订购失败，请稍后再试", "BT_OK", sceneOrderProduct, sceneOrderProduct,dialogsprite2)	
		Go2Scene(sceneDialog)  
	end
end
--dw
function Falsetojump()
	local dialog = GetCurScene()
	FreeScene(dialog)
	Go2Scene(sceneOrderProduct)
end

function DialogSpriteEvent(message,params)
	if 1001 == message then
		--[[
		local reg = registerCreate("productorder")
		local filename = registerGetString(reg, "productorderUrlFileName")
		local reg_v = registerCreate("video")
		registerSetString(reg_v, "videoFileName", fileName)
		local videotype = registerGetString(reg_v, "videoType")
		if videotype == "group" then
			Go2Scene(sceneVideoGroup)
		else
			Go2Scene(sceneVideoLiveDemand)
		end
		]]--
		WriteLogs("-----------------do DialogSpriteEvent-----------------")
		CancelTimer(1)
		local reg = registerCreate("productorder")
		local filename = registerGetString(reg, "productorderUrlFileName")
		local reg_v = registerCreate("video")
		registerSetString(reg_v, "videoFileName", fileName)
		local videotype = registerGetString(reg_v, "videoType")
		local reg = registerCreate("video")
		local filename = registerGetString(reg, "videoFileNameDelete")
		local filePath = string.gsub(filename, "MODULE:\\", GetModuleFolder())
		WriteLogs("order product cache file："..filePath)
		os.remove(filePath)
		if videotype == "group" then
			Go2Scene(sceneVideoGroup)
		else
			Go2Scene(sceneVideoLiveDemand)
		end
	elseif 1002 == message then
		
	end
end

function DialogSpriteEvent2(message,params)
	if 1001 == message then
		WriteLogs("-----------------do DialogSpriteEvent2-----------------")
	end
end

function Autojump()
	local curScene = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle")
	local SceneName = registerGetString(regHandle, string.format("%d", curScene))
	if SceneName == sceneDialog then
		local reg = registerCreate("productorder")
		local filename = registerGetString(reg, "productorderUrlFileName")
		local reg_v = registerCreate("video")
		registerSetString(reg_v, "videoFileName", fileName)
		local videotype = registerGetString(reg_v, "videoType")
		removeMenu(GetCurScene())
		local dialog = GetCurScene()
		local backSceneNode  = FindChildSprite(dialog, "back-scene")
		local backgroundScene = FindScene(sceneOrderProduct)
		if backSceneNode and backSceneNode ~= 0 and backgroundScene and backgroundScene ~= 0 then
			RemoveChildSprite(backSceneNode, backgroundScene)
		end
		FreeScene(dialog)
		local reg = registerCreate("video")
		local filename = registerGetString(reg, "videoFileNameDelete")
		local filePath = string.gsub(filename, "MODULE:\\", GetDefaultFolder(WDFIDL_MODULE))
		WriteLogs("order product cache file："..filePath)
		os.remove(filePath)
		if videotype == "group" then
			Go2Scene(sceneVideoGroup)
		else
			Go2Scene(sceneVideoLiveDemand)
		end
	end
end

function loadAnimation()
	local reg = registerCreate("productorder")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	require("module.loading.useLoading")
	enterLoading(loadarea)
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
end

function OnSpriteEventForReturn(message, params)
	if message == 1001 then
		WriteLogs("-----------------do OnSpriteEventForReturn-----------------")
		FreeScene(GetCurScene())
		Go2Scene(scenePrograminfo_volume)
	end
end

------------------添加键盘按钮事件------------------------
function clickOrderProduct(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	WriteLogs("clickOrderProduct start")
	local temp
	local result
	for i=1,table.getn(orderProductButtonArray) do
		if GetSpriteName(sprite) == GetSpriteName(orderProductButtonArray[i]) then
			temp = i
			break
		end
	end
	WriteLogs("-------------temp----------"..temp)
	if 	keyCode == ApKeyCode_Left or keyCode == ApKeyCode_Up then
		if temp ~= 1 then
			result = IsSpriteVisible(orderProductButtonArray[temp-1])
			for i = 1, table.getn(orderProductButtonArray) do
				if result == 1 then
					break
				else
					temp = temp - 1
				end
				if temp == 0 then return end
				result = IsSpriteVisible(orderProductButtonArray[temp-1])
			end
			SetSpriteFocus(orderProductButtonArray[temp-1])
			saveTouchFocus(orderProductButtonArray[temp-1])
		end
	elseif keyCode == ApKeyCode_Right or keyCode == ApKeyCode_Down then
		if temp ~= table.getn(orderProductButtonArray) then
			result = IsSpriteVisible(orderProductButtonArray[temp+1])
			for i = 1, table.getn(orderProductButtonArray) do
				if result == 1 then
					break
				else
					temp = temp + 1
				end
				if temp == table.getn(orderProductButtonArray) then return end
				result = IsSpriteVisible(orderProductButtonArray[temp+1])
			end
			SetSpriteFocus(orderProductButtonArray[temp+1])
			saveTouchFocus(orderProductButtonArray[temp+1])
		end
	elseif keyCode == ApKeyCode_Enter then
		orderbuttonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		WriteLogs("zhg:f2")
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end