﻿-- author xf_pan
-- date	 2010/06/02

--require "module.protocol.protocol_infovolume"
--require "module.protocol.protocol_navigation"
--require "module.protocol.protocol_infolabel"
--require "module.protocol.protocol_infolist"
--require "module.protocol.protocol_channel"
--require "module.common.registerScene"


---------------------------------------------------
--enum TVideoCategoryType
--{
	local EVideoCategory_Null	= 0
	local EVideoCategory_Video	= 1		-- 视频
	local EVideoCategory_Audio	= 2		-- 音频
	local EVideoCategory_Image	= 3		-- 图像
    local EVideoCategory_Complex= 4		-- 复合
	local EVideoCategory_Contant= 5		-- 内容集
--}
---------------------------------------------------
--enum TVideoFormType
--{
	local EVideoForm_Null	= 0
	local EVideoForm_Pack	= 1		-- 打包类型
	local EVideoForm_Subject= 2		-- 专题类型
	local EVideoForm_Drama	= 3		-- 剧集类型
	local EVideoForm_Other	= 4		-- other
--}
---------------------------------------------------
--enum TVideodisplayType
--{
	local EVideoDisplay_Null		= 0
	local EVideoDisplay_TelePlay	= 1		-- 电视剧
	local EVideoDisplay_New			= 2		-- 新闻
	local EVideoDisplay_PinShu		= 3		-- 评书
	local EVideoDisplay_Cartoon		= 4		-- 动画
	local EVideoDisplay_SubjectLive	= 5		-- 专题直播
    local EVideoDisplay_Other		= 6		-- 其它
--}
---------------------------------------------------
--enum ESceneType
--{
    local EScene_Type_Sigle				= 0		--单集详情
    local EScene_Type_ImgAndText		= 1		--图文混排
    local EScene_Type_2Level_Navigation	= 2		--二级导航
    local EScene_Type_Tag				= 3		--标签式详情
    local EScene_Type_List				= 4		--列表式详情
    local EScene_Type_Count				= 5		--
--}
---------------------------------------------------


--param Category 	内容类别
--param FormType	内容集类型
--param DisplayType	显示类型
--return 
--value1	场景名
--value2	request函数指针
--value2	Decode函数指针
function AscertainTargetScene(Category,  FormType,  DisplayType)

	-- WriteLogs("Category: " .. Category)
	-- WriteLogs("FormType: " .. FormType)
	-- WriteLogs("DisplayType: " .. DisplayType)
	local TypeScene = -1
	
	-- Category
	if	Category == EVideoCategory_Video or Category == EVideoCategory_Audio or Category == EVideoCategory_Image then
		TypeScene = EScene_Type_Sigle
	elseif Category == EScene_Type_ImgAndText then
		TypeScene = EScene_Type_ImgAndText
	elseif Category == EVideoCategory_Contant then
		
		-- FormType
		if FormType == EVideoForm_Pack then
			TypeScene = EScene_Type_Tag
		elseif FormType == EVideoForm_Subject then
			TypeScene = EScene_Type_List
		elseif FormType == EVideoForm_Drama then
			TypeScene = EScene_Type_2Level_Navigation		
		elseif FormType == EVideoForm_Other then
		
			-- DisplayType
			if DisplayType == EVideoDisplay_Other then
				TypeScene = EScene_Type_List
			else
				TypeScene = EScene_Type_Tag
			end -- end DisplayType			
		end -- end FormType		
	end	 -- end Category			
	
	require "module.common.registerScene"
	if TypeScene == EScene_Type_Sigle then  -- 单集详情
		require "module.protocol.protocol_infovolume"
		return scenePrograminfo_volume, RequestVolume, OnVolumeDecode
	elseif TypeScene == EScene_Type_ImgAndText then	--图文混排
		return nil
	elseif TypeScene == EScene_Type_2Level_Navigation then	--二级导航
		require "module.protocol.protocol_channel"
		return sceneProduct, RequestChannel, OnChannelDecode
	elseif TypeScene == EScene_Type_Tag then	--标签式详情
		require "module.protocol.protocol_infolabel"
		return scenePrograminfo_label, Requestlabel, OnLabelDecode
	elseif TypeScene == EScene_Type_List then	--列表式详情
		require "module.protocol.protocol_infolist"
		return scenePrograminfo_list, RequestList, OnListDecode
	end
end

