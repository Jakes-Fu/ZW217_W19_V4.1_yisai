﻿--@module dialog
--@note 对话框
--@author xf_pan
--@date 2010/05/30

require "module.dialog.useDialog"
require"module.keyCode.keyCode"
SCENE_DIALOG 		= "dialog"
SCENE_DIALOG_ROOT	= "root"
SHOW_FLAG 			= "show-flag"

function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate(SCENE_DIALOG)
	registerSetInteger(reg, SCENE_DIALOG_ROOT, sprite)
	registerSetInteger(reg, SHOW_FLAG, 1)
	
	-- global
	require "module.common.SceneUtils"
	dialogTitle, message, dialogType, backSceneName, background, observer,backSceneMenu , OK_N_IMG, OK_F_IMG, CANCEL_N_IMG, CANCEL_F_IMG, leftText, rightText = getDialogParam()
	clearDialogParam()
	backScene	= FindScene(backSceneName)
	resultMessage	= 1000
	createDialog()

	local backSceneSprite	= FindChildSprite(sprite, "back-scene")
	local dialogRootSprite	= FindChildSprite(sprite, "dialog")
	local backgroundScene	= FindScene(background)
	if backgroundScene ~= nil and backgroundScene ~= "" then
		WriteLogs(backgroundScene)
		AddChildSprite(backSceneSprite, backgroundScene)
	end
	SetSpriteCapture(dialogRootSprite)
	local reg = registerCreate(SCENE_DIALOG)
	local root = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	local HideSprite = FindChildSprite(root,"empBtn")
	local orderProductFlagReg=registerCreate("orderProductFlagReg")
	local duwei_Flag=registerGetString(orderProductFlagReg,"OrderProduct")
	WriteLogs("RRRRRRRRRRRRRRRRRRRRRRR::::    "..duwei_Flag)
	if duwei_Flag=="duwei" then
		registerSetString(orderProductFlagReg,"OrderProduct","duwei_flag")
		if	HasSpriteFocus(HideSprite) ==1 then
			KillSpriteFocus(HideSprite)
		end
		return 1
	else 
	
	WriteLogs("buttonName="..GetSpriteName(HideSprite))
	SetSpriteFocus(HideSprite)
	end
	return 1
end

--@function	createDialog
--@brief	创建对话框元素
function createDialog()
	--[[	获取根节点	]]--
	local reg = registerCreate(SCENE_DIALOG)
	local root = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	
	local titleSprite	= FindChildSprite(root, "dialog-title")
	local title2Sprite	= FindChildSprite(root, "dialog-title2")
	local bodySprite	= FindChildSprite(root, "dialog-body")
	local areaSprite	= FindChildSprite(root, "dialog-area")
	local messageSprite	= FindChildSprite(root, "dialog-message")
	local okSprite		= FindChildSprite(root, "ok-button")
	local cancelSprite	= FindChildSprite(root, "cancel-button")
	
	local okbtnImgN	= FindChildSprite(root, "okbtnImgN")
	local okbtnImgF	= FindChildSprite(root, "okbtnImgF")
	local cancelbtnImgN	= FindChildSprite(root, "cancelbtnImgN")
	local cancelbtnImgF	= FindChildSprite(root, "cancelbtnImgF")
	

	SetSpriteProperty( okbtnImgN,"text", leftText );
	SetSpriteProperty( okbtnImgF,"text", leftText );
	SetSpriteProperty( cancelbtnImgN,"text", rightText );
	SetSpriteProperty( cancelbtnImgF,"text", rightText );
	
	-- title
	if dialogTitle ~= "" then
		SetSpriteProperty(titleSprite, "text", dialogTitle)
		SetSpriteProperty(title2Sprite, "text", dialogTitle)
	else
		SetSpriteProperty(titleSprite, "text", "提示")
		SetSpriteProperty(title2Sprite, "text", "提示")
	end
	
	local labelHeight, buttonOffset, lableOffset	= 20, 25 , 10
	
	local body_x,   body_y, 	body_w,   body_h 	= GetSpriteRect(bodySprite)
	local message_x,message_y,message_w,message_h 	= GetSpriteRect(messageSprite)
	local area_x,   area_y, 	area_w,   area_h 	= GetSpriteRect(areaSprite)
	local ok_x, 	  ok_y, 	ok_w, 	  ok_h 		= GetSpriteRect(okSprite)
	local cancel_x, cancel_y, cancel_w, cancel_h 	= GetSpriteRect(cancelSprite)
	
	-- message is empty
	if message == "" then
		body_h = body_h - labelHeight
		body_y = body_y + labelHeight
		area_h = area_h - labelHeight
		ok_y   = ok_y   - labelHeight + 5
		cancel_y = cancel_y - labelHeight + 5
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
		SetSpriteRect(areaSprite, area_x, area_y, area_w, area_h)
		SetSpriteRect(okSprite, ok_x, ok_y, ok_w, ok_h)
		SetSpriteRect(cancelSprite, cancel_x, cancel_y, cancel_w, cancel_h)
	else
		SetSpriteProperty(messageSprite, "text", message)
	end
	
	-- button type
	if dialogType == "BT_NULL" then
		body_h = body_h - labelHeight
		body_y = body_y + labelHeight
		area_h = area_h - labelHeight
		message_y = message_y + lableOffset
		SetSpriteRect(okSprite,area_x, area_y, area_w, area_h+46)
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
		SetSpriteRect(areaSprite, area_x, area_y, area_w, area_h)
		SetSpriteRect(messageSprite,message_x,message_y,message_w,message_h)
		SetSpriteVisible(okSprite, 0)
		SetSpriteVisible(cancelSprite, 0)
		SetSpriteEnable(okSprite, 1)
		SetSpriteFocus(okSprite)
		SetSpriteEnable(cancelSprite, 0)
	elseif dialogType == "BT_OK" then
		SetSpriteVisible(cancelSprite, 0)
		SetSpriteEnable(cancelSprite, 0)
--		ok_x = ok_x + buttonOffset
--		SetSpriteRect(okSprite, ok_x, ok_y, ok_w, ok_h)
	end
	
end

function dialogBodyOnTick(sprite)

	local reg 	   = registerCreate(SCENE_DIALOG)
	local root	   = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	local showFlag = registerGetInteger(reg, SHOW_FLAG)	
	
	local length = 20
	if 1 == showFlag then
		local bodySprite	= FindChildSprite(root, "dialog-body")		
		local body_x, body_y, body_w, body_h = GetSpriteRect(bodySprite)
		
		if body_y <= 196 then
			body_y = 196
			registerSetInteger(reg, SHOW_FLAG, 0)
		else
			body_y = body_y - length
		end
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
	elseif 2 == showFlag then
		local bodySprite = FindChildSprite(root, "dialog-body")		
		local body_x, body_y, body_w, body_h = GetSpriteRect(bodySprite)
		
		local dialog = GetCurScene()
		if body_y >= 340 then
			registerSetInteger(reg, SHOW_FLAG, 0)
			skipToScene()
			SendSpriteEvent(observer, resultMessage)
			FreeDialog(dialog)		
		else
			body_y = body_y + length
			SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
		end		
	end
	
	return 1
end

function okButtonOnSelect(sprite)
	WriteLogs("okButtonOnSelect function")
	local reg = registerCreate(SCENE_DIALOG)
	local root = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	setDialogReturnParam("ok")	
	resultMessage = 1001
	-- 刷新背景的情况下可以加动画
	--registerSetInteger(reg, SHOW_FLAG, 2)
	local bodySprite	= FindChildSprite(root, "dialog-body")
	local body_x, body_y, body_w, body_h = GetSpriteRect(bodySprite)
	body_y = 340
	SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
	local dialog = GetCurScene()
	skipToScene()
	ReleaseSpriteCapture(sprite)
	FreeDialog(dialog)
	SendSpriteEvent(observer, resultMessage)
	---------------------------------------------
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	local curScene=registerGetString(SceneReg,"SceneName")
	-------------------------------------------
	if curScene~=nil and curScene=="history" then	
		local his_Reg=registerCreate("sc_Reg")
		local Button = registerGetInteger(his_Reg,"sprite_flag")
		SetSpriteFocus(Button)
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
		
	elseif curScene~=nil and curScene=="search-result" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="favorite" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="LocalFile" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="uploadingFile" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="uploadHistoryFile" then
		registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	elseif curScene~=nil and curScene=="menuSetingScene" then
		WriteLogs("menuSetting")
	    registerSetString(SceneReg,"SceneName","None")  ---将仓库初始化为None
		return
	end
	
	----------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	local ToDigFocus = registerGetInteger(ToDigReg,"ToDigFocus")
	if ToDigFocus then
		SetSpriteFocus(ToDigFocus)
	end
end

function cancelButtonOnSelect(sprite)
	local reg = registerCreate(SCENE_DIALOG)
	setDialogReturnParam("cancel")
	resultMessage = 1002
	
	-- 刷新背景的情况下可以加动画
	--registerSetInteger(reg, SHOW_FLAG, 2)
end

function skipToScene()
	local programInfoSprite = CreateSprite()
	if backSceneName ~= nil and backSceneName ~= "" then
		if  backSceneMenu == 1  then -- 不需要菜单
			Go2Scene(backSceneName,1)
		else
			Go2Scene(backSceneName)
		end	
	end
end

function FreeDialog(dialog)
	local backSceneNode = FindChildSprite(dialog, "back-scene")
	RemoveChildSprite(dialog, backSceneNode)
	FreeScene(dialog)
end

function empBtnOnKeyUp(sprite,keyCode)
		require"module.keyCode.keyCode"
		if keyCode == ApKeyCode_F2 or keyCode == ApKeyCode_Enter or keyCode == ApKeyCode_Up then
			local reg = registerCreate(SCENE_DIALOG)
			local root = registerGetInteger(reg, SCENE_DIALOG_ROOT)
			local okSprite		= FindChildSprite(root, "ok-button")
			okButtonOnSelect(okSprite)
			WriteLogs("call okButtonOnSelect")
		end
	
	
end

function okButtonOnkeyUp(sprite,keyCode)
		WriteLogs("#############33 my yaoxiangyin okButtonOnkeyUp############")
		if keyCode == ApKeyCode_F2 or keyCode == ApKeyCode_Enter or keyCode == ApKeyCode_Up then
			okButtonOnSelect(sprite)
		end
		return 0
end