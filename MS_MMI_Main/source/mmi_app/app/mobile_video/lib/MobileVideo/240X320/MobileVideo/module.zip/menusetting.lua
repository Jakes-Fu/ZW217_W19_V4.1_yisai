﻿--@module 	menuSetting
--@note 		设置页面
--@author 	chengzhongjie
--@date 		2010/05/25
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.setting"
require "module.keyCode.keyCode"

isVisibleLogin = 0
isVisibleDown = 0
isKeyboardVersion = 1

--下载路径 0为手机 1为TF卡
path = 0
page = 0
cardFlag = 0

--页面上次选中Button
local LastButtonSprite = nil
--页面上次选中Button的附属标签项
local LastButtonSeclabel = nil




function bodyBuildChildrenFinished(sprite)
	local downloadPathCfg = Cfg.GetDownloadPathCfg()
	local loginPage = Cfg.GetEntryPage()
	local isChannelVer = Cfg.IsChannelVersion()
	
	RootSprite = GetRootSprite(sprite)
	if downloadPathCfg == "phone" then
		local curSprite = FindChildSprite(RootSprite,"mobile")
		local CurImageSprite = FindChildSprite(curSprite,"normalImage")
		local otherSprite = FindChildSprite(RootSprite,"card")
		local OtherImageSprite = FindChildSprite(otherSprite,"normalImage")
		SetSpriteProperty(OtherImageSprite,"src","file:///image/Setting/dg_dx2.png")
		SetSpriteProperty(CurImageSprite,"src","file:///image/Setting/dg_dx1.png")
		path = 0
	else
		local curSprite = FindChildSprite(RootSprite,"card")
		local CurImageSprite = FindChildSprite(curSprite,"normalImage")
		local otherSprite = FindChildSprite(RootSprite,"mobile")
		local OtherImageSprite = FindChildSprite(otherSprite,"normalImage")
		SetSpriteProperty(OtherImageSprite,"src","file:///image/Setting/dg_dx2.png")
		SetSpriteProperty(CurImageSprite,"src","file:///image/Setting/dg_dx1.png")
		path = 1
	end
	
	if ( isChannelVer ) then
		if loginPage == "home" then
			local curSprite = FindChildSprite(RootSprite,"welcome")
			local otherSprite = FindChildSprite(RootSprite,"main")
			local CurImageSprite = FindChildSprite(curSprite,"normalImage")
			local OtherImageSprite = FindChildSprite(otherSprite,"normalImage")
			SetSpriteProperty(OtherImageSprite,"src","file:///image/Setting/dg_dx2.png")
			SetSpriteProperty(CurImageSprite,"src","file:///image/Setting/dg_dx1.png")
			page = 0
		else
			local curSprite = FindChildSprite(RootSprite,"main")
			local CurImageSprite = FindChildSprite(curSprite,"normalImage")
			local otherSprite = FindChildSprite(RootSprite,"welcome")
			local OtherImageSprite = FindChildSprite(otherSprite,"normalImage")
			SetSpriteProperty(OtherImageSprite,"src","file:///image/Setting/dg_dx2.png")
			SetSpriteProperty(CurImageSprite,"src","file:///image/Setting/dg_dx1.png")
			page = 1
		end
	else
		local curSprite = FindChildSprite(RootSprite,"welcome")
		local otherSprite = FindChildSprite(RootSprite,"main")
		if loginPage == "home" then
			local CurImageSprite = FindChildSprite(curSprite,"normalImage")
			local OtherImageSprite = FindChildSprite(otherSprite,"normalImage")
			SetSpriteEnable(curSprite,0)
			SetSpriteEnable(otherSprite,0)
			SetSpriteActive(curSprite,0)
			SetSpriteActive(otherSprite,0)
			SetSpriteProperty(OtherImageSprite,"src","file:///image/Setting/dg_dx2.png")
			SetSpriteProperty(CurImageSprite,"src","file:///image/Setting/dg_dx1_dis.png")
			page = 0
		else
			local curSprite = FindChildSprite(RootSprite,"main")
			local CurImageSprite = FindChildSprite(curSprite,"normalImage")
			SetSpriteEnable(curSprite,0)
			SetSpriteEnable(otherSprite,0)
			SetSpriteActive(curSprite,0)
			SetSpriteActive(otherSprite,0)
			local otherSprite = FindChildSprite(RootSprite,"welcome")
			local OtherImageSprite = FindChildSprite(otherSprite,"normalImage")
			SetSpriteProperty(OtherImageSprite,"src","file:///image/Setting/dg_dx2.png")
			SetSpriteProperty(CurImageSprite,"src","file:///image/Setting/dg_dx1_dis.png")
			page = 1
		end	
	end
	if (isKeyboardVersion) then
		local focusSprite = FindChildSprite(RootSprite,"ok")
		SetSpriteFocus(focusSprite)
		saveTouchFocus(focusSprite)
	end
	return 1
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_USER + 99 then
		FreeScene(GetCurScene())
	elseif message == MSG_SMS then
		requestMsgContent()
	end
end

--@function 		LogButtonSelect
--@tag-name 		main、first
--@tag-action 	botton:OnSelect
--@brief 				用于控制单选按钮逻辑
function LogButtonSelect(sprite)
	RootSprite = GetRootSprite(sprite)
	local name = GetSpriteName(sprite)
	local curSprite = FindChildSprite(RootSprite,name)
	if name == "main" then
		otherSprite = FindChildSprite(RootSprite,"welcome")
		page = 1
	else
		otherSprite = FindChildSprite(RootSprite,"main")
		page = 0
	end
	local CurImageSprite = FindChildSprite(curSprite,"normalImage")
	local OtherImageSprite = FindChildSprite(otherSprite,"normalImage")
	SetSpriteProperty(OtherImageSprite,"src","file:///image/Setting/dg_dx2.png")
	SetSpriteProperty(CurImageSprite,"src","file:///image/Setting/dg_dx1.png")
	return 1
end

--@function 		DownButtonSelect
--@tag-name 		mobile、card
--@tag-action 	botton:OnSelect
--@brief 				用于控制单选按钮逻辑
function DownButtonSelect(sprite)
	RootSprite = GetRootSprite(sprite)
	local name = GetSpriteName(sprite)
	local curSprite = FindChildSprite(RootSprite,name)
	if name == "card" then
		otherSprite = FindChildSprite(RootSprite,"mobile")
		path = 1
	else
		otherSprite = FindChildSprite(RootSprite,"card")
		path = 0
	end
	local CurImageSprite = FindChildSprite(curSprite,"normalImage")
	local OtherImageSprite = FindChildSprite(otherSprite,"normalImage")
	SetSpriteProperty(OtherImageSprite,"src","file:///image/Setting/dg_dx2.png")
	SetSpriteProperty(CurImageSprite,"src","file:///image/Setting/dg_dx1.png")
	return 1
end

--@function 		SettingdownOnselect
--@tag-name 		Settingdownload
--@tag-action 	botton:OnSelect
--@brief 				用于控制最下面2个单选按钮是否显示
function SettingdownOnselect(sprite)
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	RootSprite = GetRootSprite(sprite)
	local buttonNormal2 = FindChildSprite(sprite,"buttonNormal2")	
	--将图片设置成焦点样式
	SetSpriteProperty(buttonNormal2,"src","file:///image/common/yjt.png")
	local buttonNormal1 = FindChildSprite(RootSprite,"buttonNormal1")
	SetSpriteProperty(buttonNormal1,"src","file:///image/common/yjt.png")
	
	local buttonGroup = FindChildSprite(RootSprite,"DownloadButtonGroup")
	if isVisibleDown == 0 then
		SetSpriteVisible(buttonGroup, 0)
		SetSpriteEnable(FindChildSprite(RootSprite,"mobile"),0)
		SetSpriteEnable(FindChildSprite(RootSprite,"card"),0)
		isVisibleDown=1
	else
		SetSpriteVisible(buttonGroup, 1)
		SetSpriteEnable(FindChildSprite(RootSprite,"mobile"),1)
		SetSpriteEnable(FindChildSprite(RootSprite,"card"),1)
		isVisibleDown=0
	end
end

--@function 		SettingloginOnselect
--@tag-name 		Settinglogin
--@tag-action 	botton:OnSelect
--@brief 				用于控制登陆设置下的2个单选按钮是否显示
function SettingloginOnselect(sprite)
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	RootSprite = GetRootSprite(sprite)
	--找到当前按钮下的buttonNormal2节点
	local buttonNormal1 = FindChildSprite(sprite,"buttonNormal1")
	SetSpriteProperty(buttonNormal1,"src","file:///image/common/yjt.png")
	local buttonNormal2 = FindChildSprite(RootSprite,"buttonNormal2")
	SetSpriteProperty(buttonNormal2,"src","file:///image/common/yjt.png")
	
	local buttonGroup = FindChildSprite(RootSprite,"button-1")
	local CurSpriteName = GetSpriteName(sprite)
	if isVisibleLogin == 0 then
		SetSpriteProperty(buttonGroup, "rect","600,40,0,0")
		local buttonGroup2 = FindChildSprite(RootSprite,"button-2")
		SetSpriteProperty(buttonGroup2,"rect","0,30,240,88")
		isVisibleLogin=1
		SetSpriteEnable(FindChildSprite(RootSprite,"main"),0)
		SetSpriteEnable(FindChildSprite(RootSprite,"welcome"),0)
	else
		SetSpriteVisible(buttonGroup, 1)
		SetSpriteProperty(buttonGroup,"rect","0,0,240,88")
		local buttonGroup2 = FindChildSprite(RootSprite,"button-2")
		SetSpriteProperty(buttonGroup2,"rect","0,80,240,88")
		isVisibleLogin=0
		SetSpriteEnable(FindChildSprite(RootSprite,"main"),1)
		SetSpriteEnable(FindChildSprite(RootSprite,"welcome"),1)
	end
end

function OnSpriteEvent_Setting(message, params)
	WriteLogs("menuSetting ok_cancel message"..message)	
	if message == 1001 then
        Go2Scene(sceneHome)
	elseif message == 1002 then
		Go2Scene(sceneHome)
	end	
end

function okButtonOnSelect(sprite)
	WriteLogs("menuSetting.ok selected!")
	require "module.dialog.useDialog"
	require "module.common.registerScene"
	require "module.common.SceneUtils"
  
	local root = GetRootSprite(sprite)
	local spriteEvent = FindChildSprite(root, "event")
	local folder = GetModuleFolder()
	local configPath = folder.."config.xml"
	if path == 0 then
		Cfg.SetDownloadPathCfg( "phone", true )
	elseif path == 1 then
		local FlashCardName = GetFlashCardName()
		if FlashCardName and FlashCardName ~= "" then
			local spaceh, spacel = GetDiskFreeSpaceEx(FlashCardName)
			WriteLogs("danny spaceh = "..spaceh)
			WriteLogs("danny spacel = "..spacel)
			if spaceh == 0 and spacel == 0 then
				local spriteEvent = FindChildSprite(RootSprite,"event")
				setDialogParam("设置", "找不到存储卡", "BT_OK",sceneSetting, sceneSetting,spriteEvent)
				Go2Scene(sceneDialog)
				Cfg.SetDownloadPathCfg( "phone", true )
				return 1
			else
				Cfg.SetDownloadPathCfg("card", true)
			end
		else
			local spriteEvent = FindChildSprite(RootSprite,"event")
			setDialogParam("设置", "找不到存储卡", "BT_OK",sceneSetting, sceneSetting,spriteEvent)
			Go2Scene(sceneDialog)
			Cfg.SetDownloadPathCfg( "phone", true )
			return 1
		end 
	end
	if page == 1 then
		Cfg.SetEntryPage("welcomeNew", true )
	elseif page == 0 then
		Cfg.SetEntryPage("home", true)
	end
	setDialogParam("保存配置", "修改配置成功", "BT_OK", sceneSetting, sceneSetting, spriteEvent)
	Go2Scene(sceneDialog)
end

function cancelButtonOnSelect(sprite)
	WriteLogs("menuSetting.Cancel  selected!")
	ReturnProc()
end

function OnSpriteEvent(message, params)
	SetTimer(1,20,"ReturnProc")
end

function ReturnProc()
 	local reg = registerCreate("QuickLauncherBar");
 	--得到ReturnTable中"PageName"的总数,就是找到最近的页面
 	local count = registerGetInteger(reg, "Count");
 	--得到ReturnTable中最近的页面的名字
	local LastPageName = registerGetString(reg, "PageName"..count)
	local CurScene = GetCurScene()
	--如果存在，返回那个页面
	if LastPageName ~= "" and LastPageName ~= nil then
		if LastPageName ~= sceneVideoGroup and LastPageName ~= sceneVideoLiveDemand and LastPageName ~= sceneVideoLiveDemand_NB and LastPageName ~= sceneVideolocal then
			FreeScene(CurScene)
			Go2Scene(LastPageName)
			registerSetString(reg, "CurPage", LastPageName)
		else
			registerRemove(reg, "PageName"..count)
			count = count - 1
			local LastPageName1 = registerGetString(reg, "PageName"..count)
			FreeScene(CurScene)
			Go2Scene(LastPageName1)
			registerSetString(reg, "CurPage", LastPageName1)
		end
	else
		FreeScene(CurScene)
		Go2Scene(sceneHome)
		registerSetString(reg, "CurPage", sceneHome)
	end
	if count >= 1 then
		registerRemove(reg, "PageName"..count)
		count = count - 1
	end
	registerSetInteger(reg, "Count", count)
end

function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if MSG_SMS_ID == message then
		DealMsgContent(sceneSetting, sceneSetting)
	end
	return 1
end

function OnTimerDialog()
	require "module.dialog.useDialog"	
	require "module.common.registerScene"
	require "module.common.SceneUtils"	
	cardFlag = 1
	local RootSprite = GetCurScene()
	WriteLogs("***************--------------------------******************",RootSprite)
	local spriteEvent = FindChildSprite(RootSprite,"event")
	setDialogParam("设置", "找不到存储卡", "BT_OK",sceneHome, sceneSetting,spriteEvent)	
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	registerSetString(SceneReg,"SceneName","menuSetingScene")
	Go2Scene(sceneDialog)
end
--键盘事件


function ButtonKeyUp(sprite, keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local RootSprite = GetRootSprite(sprite)
	local name = GetSpriteName(sprite)
	local CurbuttonSprite = nil
	WriteLogs("Key event begin !")
	WriteLogs("Key event is "..keyCode)
	local Bg_x,Bg_y,Bg_w,Bg_h = GetSpriteRect(FindChildSprite(RootSprite,"QuickLauncherBar"))
	WriteLogs("Bg_w==="..Bg_w)
	WriteLogs("Current button Sprite is "..name)
	if keyCode == ApKeyCode_Up and name then
		if name == "cancel" or name == "ok" then 
			if IsSpriteEnable(FindChildSprite(RootSprite, "card")) ==1 then
				changeFocus(sprite,"cardCacheFocus","normalcardlabel")
			else
				changeFocus(sprite,"SettingdownloadCacheFocus","normalSettingdownloadlabel")
			end
		elseif name == "cardCacheFocus" or name == "card" then 
			if IsSpriteEnable(FindChildSprite(RootSprite, "mobile")) ==1  then
				changeFocus(sprite,"mobileCacheFocus","normalmobilelabel")
			else
				changeFocus(sprite,"SettingdownloadCacheFocus","normalSettingdownloadlabel")
			end
		elseif name == "mobileCacheFocus" or name == "mobile" then 
			changeFocus(sprite,"SettingdownloadCacheFocus","normalSettingdownloadlabel")
		elseif name == "welcomeCacheFocus" or name == "welcome" then 
			if IsSpriteEnable(FindChildSprite(RootSprite, "main")) ==1 and Bg_w == 240 and Bg_w<Bg_h then
				changeFocus(sprite,"mainCacheFocus","normalmainlabel")
			else
				changeFocus(sprite,"SettingloginCacheFocus","normalSettingloginlabel")
			end
		elseif name == "main" or name == "mainCacheFocus" then 
			changeFocus(sprite,"SettingloginCacheFocus","normalSettingloginlabel")
		end
	elseif keyCode == ApKeyCode_Down then
		if name == "Settinglogin" or name == "SettingloginCacheFocus" then 
			if IsSpriteEnable(FindChildSprite(RootSprite, "main")) ==1 then
				changeFocus(sprite,"mainCacheFocus","normalmainlabel")
			else
				changeFocus(sprite,"SettingdownloadCacheFocus","normalSettingdownloadlabel")
			end
		elseif name == "main" or name == "mainCacheFocus" then 
			if IsSpriteEnable(FindChildSprite(RootSprite, "welcome")) ==1 and Bg_w == 240 and Bg_w<Bg_h then
				changeFocus(sprite,"welcomeCacheFocus","normalwelcomelabel")
			else
				changeFocus(sprite,"SettingdownloadCacheFocus","normalSettingdownloadlabel")
			end
		elseif name == "welcomeCacheFocus" or name == "welcome" then 
			changeFocus(sprite,"SettingdownloadCacheFocus","normalSettingdownloadlabel")
		elseif name == "SettingdownloadCacheFocus" or name == "Settingdownload" then 
			if IsSpriteEnable(FindChildSprite(RootSprite, "mobile")) ==1 then
				changeFocus(sprite,"mobileCacheFocus","normalmobilelabel")
			else
				CurbuttonSprite = FindChildSprite(RootSprite, "ok")
				SetSpriteFocus(CurbuttonSprite)
				saveTouchFocus(CurbuttonSprite)
				if LastButtonSeclabel ~= nil then
					SetSpriteProperty(LastButtonSeclabel,"color","#000000")
				end
			end
		elseif name == "mobileCacheFocus" or name == "mobile" then 
			if IsSpriteEnable(FindChildSprite(RootSprite, "card")) ==1 then
				changeFocus(sprite,"cardCacheFocus","normalcardlabel")
			else
				CurbuttonSprite = FindChildSprite(RootSprite, "ok")
				SetSpriteFocus(CurbuttonSprite)
				saveTouchFocus(CurbuttonSprite)
				if LastButtonSeclabel ~= nil then
					SetSpriteProperty(LastButtonSeclabel,"color","#000000")
				end
			end
		elseif name == "card" or name == "cardCacheFocus" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "ok")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
			if LastButtonSeclabel ~= nil then
				SetSpriteProperty(LastButtonSeclabel,"color","#000000")
			end
			LastButtonSeclabel = nil
		end
	elseif keyCode == ApKeyCode_Left then
		if name == "cancel" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "ok")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
		elseif name == "cardCacheFocus" or name == "card"  then
			if Bg_w == 320 and Bg_w>Bg_h then
				changeFocus(sprite,"mobileCacheFocus","normalmobilelabel")
			end
		elseif name == "welcomeCacheFocus" or name == "welcome" then
			if Bg_w == 320 and Bg_w>Bg_h then
				changeFocus(sprite,"mainCacheFocus","normalmainlabel")
			end
		end
	elseif keyCode == ApKeyCode_Right then
		if name == "ok" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "cancel")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
		elseif name == "mobileCacheFocus" or name == "mobile" then 
			if Bg_w == 320 and Bg_w>Bg_h then
				changeFocus(sprite,"cardCacheFocus","normalcardlabel")
			end
		elseif name == "main" or name == "mainCacheFocus" then
			if Bg_w == 320 and Bg_w>Bg_h then
				changeFocus(sprite,"welcomeCacheFocus","normalwelcomelabel")
			end
		end

	elseif keyCode == ApKeyCode_Enter then
		--SetSpriteFocus(sprite)
		if name == "cancel" then 
			cancelButtonOnSelect(sprite)	
		elseif name == "ok" then 
			okButtonOnSelect(sprite)
		elseif name == "cardCacheFocus" or name == "card" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "card")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
			DownButtonSelect(CurbuttonSprite)
			--SetSpriteProperty(FindChildSprite(RootSprite, "normalcardlabel"),"color","#FF0000")
		elseif name == "mobileCacheFocus" or name == "mobile" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "mobile")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
			DownButtonSelect(CurbuttonSprite)
			--SetSpriteProperty(FindChildSprite(RootSprite, "normalmobilelabel"),"color","#FF0000")
		elseif name == "welcomeCacheFocus" or name == "welcome" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "welcome")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
			LogButtonSelect(CurbuttonSprite)
			--SetSpriteProperty(FindChildSprite(RootSprite, "normalwelcomelabel"),"color","#FF0000")
		elseif name == "mainCacheFocus" or name == "main" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "main")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
			LogButtonSelect(CurbuttonSprite)
			--SetSpriteProperty(FindChildSprite(RootSprite, "normalmainlabel"),"color","#FF0000")
		elseif name == "SettingdownloadCacheFocus" or name == "Settingdownload" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "Settingdownload")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
			SettingdownOnselect(CurbuttonSprite)
			--SetSpriteProperty(FindChildSprite(RootSprite, "normalmainlabel"),"color","#FF0000")
		elseif name == "SettingloginCacheFocus" or name == "Settinglogin" then 
			CurbuttonSprite = FindChildSprite(RootSprite, "Settinglogin")
			SetSpriteFocus(CurbuttonSprite)
			saveTouchFocus(CurbuttonSprite)
			SettingloginOnselect(CurbuttonSprite)
			--SetSpriteProperty(FindChildSprite(RootSprite, "normalmainlabel"),"color","#FF0000")
		end	
		if LastButtonSeclabel ~= nil then
			SetSpriteProperty(LastButtonSeclabel,"color","#000000")
		end
		--WriteLogs("GetSpriteName(CurbuttonSprite)................."..GetSpriteName(CurbuttonSprite))
		if CurbuttonSprite ~= nil then
			local buttonFocusLabel = FindChildSprite(RootSprite, "focus"..GetSpriteName(CurbuttonSprite).."label")
			if buttonFocusLabel ~= 0 then
				SetSpriteProperty(buttonFocusLabel,"color","#FF0000")
				LastButtonSeclabel = buttonFocusLabel
			end	
		end		
	elseif keyCode == ApKeyCode_Cancel or keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		
	elseif keyCode == ApKeyCode_F1 then
			local homeLastFoucsReg= registerCreate("homeLastFoucs")
			registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
			require("module.sysmenu")
			require("module.menuopen")
			SysGetSeceSprite(sprite)
			menuButtonOnSelect(sprite)
	else
		WriteLogs("Other Key event !")
	end	
	--WriteLogs("The Label has focus or not **** "..HasSpriteFocus(CurbuttonSprite).."****")
	WriteLogs("Key event has done !")	
	return 1
end
function changeFocus(sprite,ButtonName,LabelName)
	local RootSprite = GetRootSprite(sprite)
	CurbuttonSprite = FindChildSprite(RootSprite, ButtonName)
	SetSpriteProperty(FindChildSprite(RootSprite, LabelName),"color","#FF0000")
	WriteLogs(LabelName.." is changed !")
	if CurbuttonSprite then
		SetSpriteFocus(CurbuttonSprite)
		saveTouchFocus(CurbuttonSprite)
	end
	if LastButtonSeclabel ~= nil and LastButtonSeclabel ~= FindChildSprite(RootSprite, LabelName) then
		SetSpriteProperty(LastButtonSeclabel,"color","#000000")
		WriteLogs(GetSpriteName(LastButtonSeclabel).." is recovery !")
	end
	LastButtonSeclabel = FindChildSprite(RootSprite, LabelName)
end
