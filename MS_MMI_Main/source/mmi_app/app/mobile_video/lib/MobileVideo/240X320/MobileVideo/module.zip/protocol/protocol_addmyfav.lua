--@author xf_pan 
--@date 2010/06/15
require ("module.setting")

function RequestAddMyfav(protocolNumber,addType, channelId, contentId, urlPath, channelType)
	
	local requestUrl
	if addType == 0 then -- add channel		
		requestUrl = string.format("%s/msp/collect.msp?nodeId=%s&contentId=&urlPath=%s&channelType=%s", Cfg.GetPortalURL(), channelId, urlPath, channelType)
	elseif addType == 1 then -- add content
		requestUrl = string.format("%s/msp/collect.msp?nodeId=%s&contentId=%s&urlPath=%s", Cfg.GetPortalURL(), channelId, contentId, urlPath)
	end
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	
	local addMyFavFileName = GetLocalFilename(requestUrl)
	local reg = registerCreate("product_addMyFav")
	local fileName = registerSetString(reg, "product_addMyFav_FileName", addMyFavFileName)
		
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, requestUrl, 0, addMyFavFileName, observer, protocolNumber, 0, 1)

end

function OnPipeAddMyFav()

	local reg = registerCreate("product_addMyFav")
	local fileName = registerGetString(reg, "product_addMyFav_FileName")
	local json =  jsonLoadFile(fileName)
	
	return json.success, json.desc
end

