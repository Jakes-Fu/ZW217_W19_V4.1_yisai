--author xf_pan
--date	2010/06/01
-- request search result
function SetSearchUrl(url)
	if url then
		local regSearch = registerCreate("searchScene")
		registerSetString(regSearch, "search_url", url)
	end
end
function GetSearchUrl()
	local regSearch = registerCreate("searchScene")
	return  registerGetString(regSearch, "search_url")
end

function SetSearchUrlByTime(url)
	if url == nil then
		url = ""
	end
	WriteLogs("SetSearchUrlByTime url = "..url);
	local regSearch = registerCreate("searchScene")
	return  registerSetString(regSearch, "search_url_time", url)
end

function GetSearchUrlByTime()
	local regSearch = registerCreate("searchScene")
	local su = registerGetString(regSearch, "search_url_time")
	if ( su == nil or su == "" ) then
		return GetSearchUrl()
	else
		return su
	end
end

function SetSearchUrlByHot(url)
	if url == nil then
		url = ""
	end
	WriteLogs("SetSearchUrlByHot url = "..url)
	local regSearch = registerCreate("searchScene")
	return  registerSetString(regSearch, "search_url_hot", url)
end

function GetSearchUrlByHot()
	local regSearch = registerCreate("searchScene")
	local su = registerGetString(regSearch, "search_url_hot")
	if ( su == nil or su == "" ) then
		return GetSearchUrl()
	else
		return su
	end
end

function RequestSearchResult(protocolNumber, method, searchUrl, postdata0 ,postdata1 ,isAdvanced)
	if ( postdata0 == nil ) then
		postdata0 = ""
	end
	if ( postdata1 == nil ) then
		postdata1 = ""
	end
	local regSystem = registerCreate("System")
	http = registerGetInteger(regSystem, "comHttpPipe")
	local fileName = GetLocalFilename(searchUrl)
	local reg = registerCreate("search_result")
	registerSetString(reg, "searchResultFileName", fileName)
	WriteLogs("searchResult cachefile:  "..fileName)
	require "module.searchInfo"
	SaveSearchReqVal( postdata0 ) 
	
	--[[ 转化为请求参数类型 ]]--
	local postdata = ""
	if postdata1 ~= "" then
		postdata = string.format("s=%s&k=%s", postdata1, postdata0)
	else
		postdata = string.format("k=%s", postdata0)
	end
	if isAdvanced ~= nil then
		local reg_a = registerCreate("advancedsearch")
		local combobox1text = registerGetString(reg_a, "combobox1text")
		local combobox2text = registerGetString(reg_a, "combobox2text")
		if combobox1text == "按分类" then
			postdata = postdata.."&filterType=02"
			if combobox2text and combobox2text ~= "" then
				local reg_m = registerCreate("advancedsearch")
				postdata = postdata.."&filterContent="..registerGetString(reg_m,combobox2text)
			else
				postdata = postdata.."&filterContent="
			end
		elseif combobox1text == "按品牌" then
			postdata = postdata.."&filterType=03"
			if combobox2text and combobox2text ~= "" then
				local reg_m = registerCreate("advancedsearch")
				postdata = postdata.."&filterContent="..registerGetString(reg_m,combobox2text)
			else
				postdata = postdata.."&filterContent="
			end
		end
	end
	WriteLogs("postdata:"..postdata)
	local observer = pluginGetObserver()
	if method == 1 then
		pluginInvoke(http, "AppendCommand", 1, searchUrl, postdata, fileName, observer, protocolNumber, 0, 1)
	elseif method == 0 then
		pluginInvoke(http, "AppendCommand", 0, searchUrl, 0, fileName, observer, protocolNumber, 0 , 1)
	end
end

function OnSearchResultDecode()
	local reg = registerCreate("search_result")
	local fileName = registerGetString(reg, "searchResultFileName")
	if fileName ~= nil and fileName ~= "" then
		return jsonLoadFile(fileName)
	end
	return nil
end