﻿
--推荐短信解析

szPhoneNum			= 	"10086"
szSM1 				=	"SM1"
szAy				=	"Ay"
szHoff				=	"Hoff"
szCmain				=	"Cmain"
szTsmsListenerID	=	"TsmsListenerID"
szNonRecommend		=	"NonRecommend"
szSemicolon			=	";"

ERR_NORMAL								= 0x0
ERR_NULL_POINT							= 0x01
ERR_N0_SM1_STRING						= 0x02
ERR_NO_AY_STRING						= 0x03
ERR_NO_HOFF_STRING						= 0x04
ERR_NO_CMAIN_STRING						= 0x05
ERR_NO_TSMSLISTENERID_STRING			= 0x06
ERR_NO_TSMSLISTENERID_VALUE				= 0x07		
ERR_N0_NONRECOMMEND_STRING				= 0x08
ERR_NO_TSMSLISTENERID_VALUE_NOT_DIGIT	= 0x09
ERR_NO_TSMSLISTENERID_EQUAL_STRING		= 0x0a
ERR_NO_BEGIN							= 0x0b
ERR_NO_END								= 0x0c
ERR_UNDEFINED							= 0XFF

EPARSE_WAITFOR_EQUAL					= 0x0
EPARSE_BEGIN							= 0x01
EPARSE_WAIT_MIDDLE						= 0x02
EPARSE_MIDDLE							= 0x03
EPARSE_WAIT_END							= 0x04
EPARSE_END								= 0x05
EPARSE_NUM								= 0x06
EPARSE_NUMDONE							= 0x07
EPARSE_ERR								= 0x08
	
--检测是否为推荐短信
function Check_PhoneNumber(SMSMail)
	if nil == string.find(SMSMail, szPhoneNum) then
		return true
	end
	return true
end

--解析推荐短信内容
--@msgContent为短信内容
--@返回值为msgID
function SMS_ParseMessageID(msgContent)
	if nil == msgContent and "" == msgContent then
		return false
	end
	WriteLogs("----------------***********msgContent="..msgContent)
	local TsmsListenerIDValue
	local msgContentLen = string.len(msgContent)
	
	local SM1Start, SM1End = string.find(msgContent, szSM1)	
	if nil ~= SM1Start then
		
	end
	
	if nil ~= string.find(msgContent, szAy) then
	
	end
	
	if nil ~= string.find(msgContent, szHoff) then
	
	end
	
	if nil ~= string.find(msgContent, szCmain) then
	
	end
	
	--解析msgID
	local TsmsListenerIDStart, TsmsListenerIDEnd = string.find(msgContent, szTsmsListenerID)
	if nil ~= TsmsListenerIDStart then
		local EqualStart, EqualEnd = string.find(msgContent, "=")
		if nil ~= EqualStart then
			local leaveMsgContent = string.sub(msgContent, EqualEnd+1, msgContentLen)
			local TsmsListenerIDValueStart, TsmsListenerIDValueEnd = string.find(leaveMsgContent, szSemicolon) 
			--msgID的值
			TsmsListenerIDValue = string.sub(leaveMsgContent, 1, TsmsListenerIDValueStart-1)
		end
	end
	
	if nil ~= string.find(msgContent, szNonRecommend) then
	
	end
	WriteLogs("--------------------------********TsmsListenerIDValue="..TsmsListenerIDValue)
	return TsmsListenerIDValue
end

