﻿--@module 	SystemMenu
--@note 		底部菜单
--@author 	chengzhongjie
--@date 		2010/05/25
--@brief 		用于显示弹出菜单
SPRITENAME_SYSMENU = "sysmenu";
keyQuickLauncherBar = "QuickLauncherBar";
SPRITENAME_BOTTOMMENU = "bottommenu";
require "module.sysmenu"
function helpButtonOnSelect(sprite)
	local reg = registerCreate("help")
	registerSetString(reg,"kind","help")
	local regInfo = registerCreate(keyQuickLauncherBar)
	SenceSprite=registerGetInteger(regInfo,"rootSprite")
	 regInfor = registerCreate("sysSprite")
	 local SenceSpriteRoot=registerGetInteger(reg,"rootSprite")
	hideMenuSprite();
	--hidePopupSprites()
	WriteLogs("helpButtonOnSelect");
	require "module.common.SceneUtils"
	local sprite_child=FindChildSprite(SenceSprite,"quicklauncherbar")
	WriteLogs("-------hello---------"..GetSpriteName(FindChildSprite(sprite_child,"menu-title")))
	SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按#号返回页面顶部")
	SetReturn1(sceneHelp)
	Go2Scene(sceneHelp)	
	--SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","欢迎使用手机视频业务")
end

function introButtonOnSelect(sprite)
	local reg = registerCreate("help")
	registerSetString(reg,"kind","intro")
	local regInfo = registerCreate(keyQuickLauncherBar)
	SenceSprite=registerGetInteger(regInfo,"rootSprite")
	 regInfor = registerCreate("sysSprite")
	 local SenceSpriteRoot=registerGetInteger(reg,"rootSprite")
	hideMenuSprite();
	--hidePopupSprites()
	WriteLogs("introButtonOnSelect");
	require "module.common.SceneUtils"
	--	local sprite_child=FindChildSprite(SenceSprite,"quicklauncherbar")
--	WriteLogs("-------hello---------"..GetSpriteName(FindChildSprite(sprite_child,"menu-title")))
--	SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按#号返回页面顶部")
	SetReturn1("MODULE:\\help.xml")
	Go2Scene("MODULE:\\help.xml")	
	
end

function aboutButtonOnSelect(sprite)
	local reg = registerCreate("help")
	registerSetString(reg,"kind","about")
	local regInfo = registerCreate(keyQuickLauncherBar)
	SenceSprite=registerGetInteger(regInfo,"rootSprite")
	regInfor = registerCreate("sysSprite")
	local SenceSpriteRoot=registerGetInteger(reg,"rootSprite")
	hideMenuSprite();
	--hidePopupSprites()
	WriteLogs("aboutButtonOnSelect");
	require "module.common.SceneUtils"
	--	local sprite_child=FindChildSprite(SenceSprite,"quicklauncherbar")
--	WriteLogs("-------hello---------"..GetSpriteName(FindChildSprite(sprite_child,"menu-title")))
--	SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按#号返回页面顶部")
	SetReturn1(sceneHelp)
	Go2Scene(sceneHelp)	
	
end



function hidePopupSprites()
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	
	if hideMenuSprite(rootSprite) == 1 then	return	1;	end
	if hideBottomSprite(rootSprite) == 1 then	return	1;end
end

function sysHelpKeyUp(sprite,keyCode)
	
	servicereg=registerCreate("helpButtonSprite")
	registerSetInteger(servicereg,"helpButton",FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"help"))


	local reg=registerCreate("PassLeft")
	 registerSetInteger(reg,"spritePassLeft",sprite)
	WriteLogs("-------------------++++++++++++++++++++++++++++:"..keyCode)
	item=GetParentSprite(sprite)
	local menuList=GetParentSprite(GetParentSprite(sprite))
	itemCount = SpriteList_GetListItemCount(menuList)
	WriteLogs("______name:"..GetSpriteName(menuList))
	index = SpriteListItem_GetIndex(item)
	WriteLogs(".....index:"..index)
	local list={"help","ywjs","about"}
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
		local lastFocus=registerGetInteger(homeLastFoucsReg,"lastFocusSprite")
	if keyCode==10 and index <=itemCount-1 then
		if index==(itemCount-1) then 
		
		return 0
		else
		listitem=SpriteList_GetListItem(menuList, index+1)
		WriteLogs("---------"..SpriteListItem_GetIndex(listitem))
		cursprite=FindChildSprite(listitem,list[index+2])
		SetSpriteFocus(cursprite)
		result=HasSpriteFocus(cursprite)
		WriteLogs("result:"..result)
		
		end
	
		elseif keyCode ==1 then
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			require("module.menuopen")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
			
		elseif keyCode == 2  then
			require("module.menuopen")
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
		
		
	elseif keyCode==7  then
			flag=1
			local flagReg=registerCreate("flagnum")
			registerSetInteger(flagReg,"flagnum",flag)
			local regInfor=registerCreate("passSprite")
			local senceSprite=registerGetInteger(regInfor,"CurSprite")
			WriteLogs("=-=-=-=-2013=-012=3012=30"..GetSpriteName(senceSprite))
			SetSpriteFocus(senceSprite)
			
			local reg=registerCreate("popS")
			popSprite=registerGetInteger(reg,"pop")
			ShowPopupMenu(popSprite,0)
			--SetSpriteVisible(GetParentSprite(GetParentSprite(sprite)),0)
			--SetSpriteEnable(GetParentSprite(GetParentSprite(sprite)),0)
	--[[elseif keyCode==3 then
			if index==0 then helpButtonOnSelect(sprite)
			elseif index==1 then introButtonOnSelect(sprite)
			elseif index==2 then aboutButtonOnSelect(sprite)
			end]]--
		
	elseif keyCode==9 and index>=1 then
		if index==0 then return 0
		else 
		listitem=SpriteList_GetListItem(menuList, index-1)
		WriteLogs("---------"..SpriteListItem_GetIndex(listitem))
		cursprite=FindChildSprite(listitem,list[index])
		SetSpriteFocus(cursprite)
		
		end
	end
		return 0
end
function ShowPopupMenu(popSprite, show)
	if show == 0 then
		SetSpriteVisible(popSprite, 0);
		SetSpriteEnable(popSprite, 0);
		childPopSprite = FindChildSpriteByClass(popSprite, "list");
		if childPopSprite ~= 0 then
			SpriteList_SetCurItem(childPopSprite, -1);
		end
	else
		SetSpriteVisible(popSprite, 1);
		SetSpriteEnable(popSprite, 1);
	end
end

