﻿--@module 	SystemMenu
--@note 		底部菜单
--@author 	chengzhongjie
--@date 		2010/05/25
--@brief 		用于显示弹出菜单
require "module.sysmenu"
function mymagazineOnSelect(sprite)
	hideMenuSprite();
	WriteLogs("mymagazineOnSelect");
end

function friendvideoOnSelect(sprite)
	hideMenuSprite();
	WriteLogs("friendvideoOnSelect");
end

