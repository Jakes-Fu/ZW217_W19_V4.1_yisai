
function RequestBulletin(protocolNumber, searchUrl)
	local reg = registerCreate("bulletin")
	local fileName = GetLocalFilename(searchUrl)
	registerSetString(reg, "bulletinFileName", fileName)
	--[[  ����httppipe�������ȡ��������  ]]--
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, searchUrl, 0, fileName, observer, protocolNumber, 0, 0)
end

function OnBulletinDecode()
	local reg = registerCreate("bulletin")
	local fileName = registerGetString(reg, "bulletinFileName")
	if fileName ~= nil and fileName ~= "" then
		return jsonLoadFile(fileName)
	end
	return nil
end
