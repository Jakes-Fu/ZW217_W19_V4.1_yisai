﻿-- @author xf_pan 2010/07/15 4:52
-- @brief sava group info

function SaveGroupFileName(fileName)
	local reg = registerCreate("video_groupinfo")
	registerRemove(reg, "video_groupUrlFileName")
	registerSetString(reg, "video_groupUrlFileName", fileName)
end

function GetGroupFileName()
	local reg = registerCreate("video_groupinfo")
	return registerGetString(reg, "video_groupUrlFileName")
end