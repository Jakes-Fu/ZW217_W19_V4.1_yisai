﻿--@author xf_pan
--@date  2010/06/15

local USER_MSG		= 1000
MSG_ADD_FAV	= USER_MSG + 100 -- 添加收藏消息
MSG_RETURN	= USER_MSG + 99  -- 返回消息
MSG_RELOAD	= USER_MSG + 98  -- 返回消息