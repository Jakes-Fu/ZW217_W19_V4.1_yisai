﻿--@auther:lijicheng
--@用于lua文件操作

--判断目录是否存在，这是一种临时解决方案，效率不会很高，此外还会有副作用，可能会在该目录下留下一个空文件
--最好的方式是引擎提供。
function dirExist(path)
	if path ~= nil then
		return fileExist(path.."\\__check__.txt");
	end
	return nil;
end

--用于判断文件是否存在
function fileExist(pathName)
	--test create file
	local path = fileConvert(pathName)
	local file = io.open(path, "rb")
	if file then
		file:close()
	end
	return file
end

--用于创建文件
function fileCreate(pathName)
	local path = fileConvert(pathName)
	local file = io.open(path, "wb")
	if file then
		file:close()
	end
	return file
end

--用于删除文件
function fileRemove(pathName)
	local path = fileConvert(pathName)
	if fileExist(path) then
		return os.remove(path)
	end
	return true
end

--用于移动文件
function fileRename(src, dest)
	local lsrc = fileConvert(src)
	local ldest = fileConvert(dest)
	if fileExist(lsrc) then
		return os.rename(lsrc, ldest)
	end
	return false
end

--读取全部文件到一个字符串
function fileRead(pathName)
	local path = fileConvert(pathName)
	local file = io.open(path, "rb")
	if file then
		local fContent =  file:read("*all")
		file:close()
		return fContent
	end
	return nil
end

--写一个字符串到文件
function fileWrite(pathName, fContent)
	local path = fileConvert(pathName)
	local file = io.open(path, "w+")
	if file then
		local ret =  file:write(fContent)
		file:close()
		return ret
	end
	return nil
end

--读取文件分行成表
function fileReadToTable(pathName)
	local fContent = {}
	local path = fileConvert(pathName)
	local file = io.open(path, "r")
	local row = 1
	if file then
		while true do
			local line = file:read("*l")
			if line == nil or line == "" then break end
			fContent[row] = line
			WriteLogs("io.lua : fileReadToTable :"..row..tostring(line))
			row = row + 1
		end
		file:close()
		return fContent
	end
	return nil
end

--把相对路径转成绝对路径
function fileConvert(pathName)
	if "MODULE:\\" == pathName.match(pathName, "MODULE:\\") then
		local modulePath = GetModuleFolder()
		pathName = string.gsub(pathName, "MODULE:\\", modulePath)
	end
	return pathName
end

--获取文件的大小（byte）
function fileLen(fileName)
	local fh = assert(io.open(fileName, "rb")) 
	local len = assert(fh:seek("end")) 
	fh:close()
	return len
end

--获取文件的扩展名
function fileExt(fileName)
	local ext = ""

	-- if fileName ~= nil then
	   -- ext = string.gsub(fileName, "(%w+).(%w+)","%2");
	-- end

	--直接使用 string.gsub 不支持中文。只能够用蠢办法，不过考虑到后缀名长度比较短，而且使用不频繁，可以使用
	local slen = string.len(fileName);
	for i=slen,0, -1 do
		if string.char(string.byte(fileName,i)) =="." then
			ext = string.sub(fileName,i+1,slen);
			break;
		end
	end

	return ext;
end

--删除文件夹和文件夹下所有文件

function deleteDir(path)
	local dir = OpenDirectory(path.."*.*")	
	if dir then
		for n = 0, table.maxn(dir) do
			local deletePath = string.gsub(path,"MODULE:\\",GetModuleFolder())
			WriteLogs("删除文件："..deletePath..dir[n].filename)
			os.remove(deletePath..dir[n].filename)
		end
	end
	Deletefolder(path)
end