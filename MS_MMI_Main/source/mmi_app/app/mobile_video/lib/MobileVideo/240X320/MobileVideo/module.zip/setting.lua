﻿----------------------------------------------------------------
--
--@author = zhouzhicheng
--@brief  = function list:
--					Cfg.Load()
--					Cfg.Save()
--					Cfg.GetUUID()
--					Cfg.SetUUID( newUUID, saveAuto )
--					Cfg.GetMaxLoginTimes()
--					Cfg.GetServer()
--					Cfg.GetPortal()
--					Cfg.AddLoginTimes()
--					Cfg.GetWelcome()
--					Cfg.GetPortalURL()				//取得一个带有服务器地址+portal地址的url
--					Cfg.CheckLogTimesLimits()
--					Cfg.GetDownloadPathCfg()
--					Cfg.GetPhoneDownloadPath()
--					Cfg.GetFileter()					//取得本地文件过滤条件 返回表结构
--					Cfg.GetVideoType()
--					Cfg.GetPhoneNum()
--					Cfg.SavePhoneNum()
--					Cfg.SaveLastLoginDate()
--					Cfg.GetLastLoginDate()
--					Cfg.GetHelpText
----------------------------------------------------------------

Cfg = {};

Cfg.self = { 
						--这里存放注册键值
						KEY = { 
						SETTING = "_REG_SETTING_",
						RMEAPP  = "_REG_RMEAPP_" ,
						HELP    = "_REG_HELP_",
						LASTLOGINDATE = "_REG_LASTLOGINDATE_",
						--视频服务的地址
						SERVER = "SERVER",
						
						---------------------
						--服务器上的portal路径 ，这个是在 setting.xml 中
						PORTAL = "PORTAL",
						
						---------------------
						--这是 client_initialise协议的中的参数，用来唯一标识一个客户端
						UUID = "UUID",
						
						CHANNEL_ID_FILE = "CHANNEL_ID_FILE",
						---------------------
						PHONE_NUM = "PHONE_NUM",
						---------------------
						--下面两个参数是用来记录登陆次数的
						LOGIN_TIMES = "LOGIN_TIMES",
						MAX_LOGIN_TIMES = "MAX_LOGIN_TIMES",

						---------------------
						--RME业务的首页面，一般情况下是 module\welcome.xml
						RMESTART = "RMEStart",
						
						---------------------
						--下载路径  eg. {APP_PATH}\download\ , {FLASH_PATH}\download\
						DOWNLOAD_PATH_CFG = "DOWNLOAD_PATH_CFG",
						
						---------------------
						--用户登陆进来的首页是什么  eg. home , welcomeNew
						ENTRY_PAGE = "ENTRY_PAGE",
						
						---------------------
						--当前平台允许的视频，eg. {*.3gp},{*.dat}
						FILTER = "FILTER",
						
						---------------------
						--当前播放器支持的视频格式，eg. .cmtv
						VIDEO_TYPE = "VIDEO_TYPE",
						
						---------------------
						--帮助中需要的相关信息
						--只提供 Get 函数
						HELP_INFO_PATH= "HELP_INFO_PATH",
						THEME = "THEME",
						},
					
				--这里存放所有相关的默认值
				DEFAULT = {
						MAX_LOGIN_TIMES = 6,
						LOGIN_TIMES = 0,
						},
						
				--这里存放和RME相关的所有配置文件名，
				CFGFILE = {
						SETTING = "MODULE:\\setting.xml",
						RMEAPP="MODULE:\\rmeclient.xml",
						HELP = "MODULE:\\help_config.xml",
						},
				}

function Cfg.AddLoginTimes(saveAuto)
	local k = registerCreate( Cfg.self.KEY.RMEAPP )
	local lt = Cfg.GetLoginTimes(k)
	lt = lt + 1;
	WriteLogs("lt=>"..lt)
	registerSetInteger( k , Cfg.self.KEY.LOGIN_TIMES,lt)
	if saveAuto ~= nil and saveAuto == true then
		Cfg.Save()
	end 
	return lt,lt-1
end

function Cfg.IsChannelVersion( )
	local keySetting = registerCreate( Cfg.self.KEY.SETTING )
	local channelid = Cfg.GetChannelID( keySetting )
	WriteLogs("channelid = "..channelid)
	if channelid ~= "" and string.len(channelid)>10 and channelid ~= "100020.wondertek.00" then
		return true
	else
		return false
	end
end

function Cfg.GetChannelID( k )
	require ("module.common.partiners")
	local idf = registerGetString( k, Cfg.self.KEY.CHANNEL_ID_FILE )
	if idf ==  nil or idf == "" then
		return ""
	else
		local p = fileRead( idf )
		if ( p == nil ) then
			return ""
		else
			return p
		end
	end	
end

--加载 setting.xml内容
function Cfg._loadSetting()
	WriteLogs("dbg: setting -> load "..Cfg.self.CFGFILE.SETTING)
	local data={ server= nil, portal=nil , channelid_file =nil}
	local nodeTree = xmlLoadFile( Cfg.self.CFGFILE.SETTING )
	if nodeTree ~= 0 then
		local nodeRoot = xmlFindElement(nodeTree, nodeTree, "root")
		if nodeRoot ~= 0 then
			local nodeClient = xmlFindElement(nodeTree, nodeRoot, "server")
			if nodeClient ~= 0 then
				data.server = xmlElementGetAttr(nodeClient, "url")
				data.portal = xmlElementGetAttr(nodeClient, "portal")
			end
			local nodeChannel = xmlFindElement(nodeTree, nodeRoot, "channel-id-file")
			if nodeClient ~= 0 then
				data.channelid_file = xmlElementGetAttr(nodeChannel, "value")
			else
				data.channelid_file = ""
			end
		end
	end
	xmlRelease(nodeTree)
	local keySetting = registerCreate( Cfg.self.KEY.SETTING )
	registerSetString( keySetting, Cfg.self.KEY.SERVER, data.server )
	registerSetString( keySetting, Cfg.self.KEY.PORTAL, data.portal )
	registerSetString( keySetting, Cfg.self.KEY.CHANNEL_ID_FILE, data.channelid_file )
end

function Cfg._loadHelpCfg()
	local key = registerCreate( Cfg.self.KEY.HELP )
	registerLoad( key , Cfg.self.CFGFILE.HELP )
end

--加载 rmeclient.xml内容
function Cfg._loadRMEClientCfg()
	WriteLogs("dbg: setting -> load "..Cfg.self.CFGFILE.RMEAPP )
	local key = registerCreate( Cfg.self.KEY.RMEAPP )
	registerLoad( key, Cfg.self.CFGFILE.RMEAPP )
	WriteLogs("EnterPage :"..Cfg.GetEntryPage())
end

--setting.xml 是引擎一层的，所以应用业务层不能够修改
--业务应用层的数据在 rmeclient中，需要根据业务情况保存
function Cfg.Save()
	WriteLogs("dbg: setting -> save rmeclient.xml")
	local keyRME = registerCreate( Cfg.self.KEY.RMEAPP )
	registerSave( keyRME, Cfg.self.CFGFILE.RMEAPP )
end


function Cfg.GetLoginTimes(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	return registerGetInteger( k , Cfg.self.KEY.LOGIN_TIMES )
end

function Cfg.GetMaxLoginTimes(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	return registerGetInteger( k , Cfg.self.KEY.MAX_LOGIN_TIMES )
end

--提供一个便捷函数，检查登陆次数是否满足要求
function Cfg.CheckLogTimesLimits()
	local k = registerCreate( Cfg.self.KEY.RMEAPP )
	local lt = Cfg.GetLoginTimes( k )
	local mlt = Cfg.GetMaxLoginTimes( k )
	if lt ~= nil and mlt ~= nil and lt < mlt then
		return true
	else
		return false
	end
end

function Cfg.GetUUID(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	return registerGetString( k , Cfg.self.KEY.UUID )
end

function Cfg.GetPortal(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.SETTING )
	end
	return registerGetString( k , Cfg.self.KEY.PORTAL )
end

function Cfg.GetServer(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.SETTING )
	end
	return registerGetString( k , Cfg.self.KEY.SERVER )
end

--这是一个快捷函数
function Cfg.GetPortalURL(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.SETTING )
	end
	local s = registerGetString( k , Cfg.self.KEY.SERVER )
	local p = registerGetString( k , Cfg.self.KEY.PORTAL )
	return s..p
end

-- 这里k一定要是 self.KEY.RMEAPP 的值
function Cfg.SetUUID (uuid,saveAuto,k)
	if k == nil then
		k = registerCreate(Cfg.self.KEY.RMEAPP)
	end
	registerSetString(k,Cfg.self.KEY.UUID,uuid)
	if saveAuto ~= nil and saveAuto == true then
		Cfg.Save()
	end
end

--保存主题模式
function Cfg.SaveTheme(color,k)
	if k == nil then
		k = registerCreate(Cfg.self.KEY.RMEAPP)
	end
	registerSetString(k,Cfg.self.KEY.THEME,color)
	Cfg.Save()
end

--获取主题模式
function Cfg.GetTheme(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	return registerGetString(k, Cfg.self.KEY.THEME )
end
 
--取得RME程序的主入口
function Cfg.GetWelcome(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	return registerGetString( k, Cfg.self.KEY.RMESTART )
end

function Cfg.GetPhoneDownloadPath( f )
	local pp =  GetDefaultFolder(WDFIDL_DOWNLOAD)
	if ( f ~= nil and f ~= "" ) then
		pp = pp..f
	end
	return pp
end

function Cfg.GetDownloadPathCfg(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	return registerGetString( k, Cfg.self.KEY.DOWNLOAD_PATH_CFG);
end

--获取业务层的临时目录路径
--该路径末尾一定带有 \ 结尾的
function Cfg.GetTempPath(f)
	local tp =  "MODULE:\\..\\temp\\"
	if ( f ~= nil and f ~= "" ) then
		tp = tp.. f
	end
	return tp
end

--取得下载路径
function Cfg.GetDownloadPath( k )
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	local dlpcfg =  Cfg.GetDownloadPathCfg( k )
	local dp = nil
	if ( dlpcfg == "card" ) then
		local FlashCardName = GetFlashCardName()
		if FlashCardName and FlashCardName ~= "" then
			dp =  GetFlashCardName().."\\"
		else
			dp = nil
		end
	else
		dp = Cfg.GetPhoneDownloadPath()
	end
	if dp == nil then
		return Cfg.GetPhoneDownloadPath()
	else
		return dp
	end
end

--保存下载路径
function Cfg.SetDownloadPathCfg( newpath , saveAuto , k )
	if k == nil then
		k = registerCreate(Cfg.self.KEY.RMEAPP)
	end
	registerSetString( k, Cfg.self.KEY.DOWNLOAD_PATH_CFG, newpath )
	if saveAuto ~= nil and saveAuto == true then
		Cfg.Save()
	end 
end

function Cfg.GetEntryPage( k )
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	return registerGetString( k, Cfg.self.KEY.ENTRY_PAGE )
end

function Cfg.SetEntryPage( page , saveAuto , k  )
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	registerSetString( k, Cfg.self.KEY.ENTRY_PAGE, page )
	if saveAuto ~= nil and saveAuto == true then
		Cfg.Save()
	end 
end

function Cfg.GetPhoneNum(k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	return registerGetString( k, Cfg.self.KEY.PHONE_NUM )
end

function Cfg.SavePhoneNum(pn,saveAuto,k)
	if k == nil then
		k = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	WriteLogs("SavePhoneNum = "..pn)
	registerSetString( k, Cfg.self.KEY.PHONE_NUM, pn )
	if saveAuto ~= nil and saveAuto == true then
		Cfg.Save()
	end 
end

function  Cfg._checkValid()
	local keyRME = registerCreate( Cfg.self.KEY.RMEAPP )
	local max_login_times = Cfg.GetMaxLoginTimes(keyRME)
	local login_times = Cfg.GetLoginTimes(keyRME)
	local download_path_cfg = Cfg.GetDownloadPathCfg( keyRME )
	--最大访问请求的次数，默认值
	if (max_login_times == nil or max_login_times == "" ) then
		max_login_times = Cfg.self.DEFAULT.MAX_LOGIN_TIMES
	elseif ( type( max_login_times ) == "string" ) then
		max_login_times = tonumber( max_login_times )
	end
	
	if ( max_login_times < 0 ) then
		max_login_times = Cfg.self.DEFAULT.MAX_LOGIN_TIMES
	end
	
	--login_times
	if (login_times == nil or login_times == "" ) then
		login_times=  Cfg.self.DEFAULT.LOGIN_TIMES
	elseif( type( login_times ) == "string") then
		 login_times = tonumber( login_times )
	end
	if ( login_times < 0 ) then
		login_times  = Cfg.self.DEFAULT.LOGIN_TIMES
	end
	
	--检查下载目录
	if (download_path_cfg == nil or download_path_cfg =="") then
		 download_path_cfg = "phone"
	end

	--save 变更后的数据
	registerSetString( keyRME , Cfg.self.KEY.MAX_LOGIN_TIMES, max_login_times )
	registerSetString( keyRME , Cfg.self.KEY.LOGIN_TIMES, login_times )
	registerSetString( keyRME , Cfg.self.KEY.DOWNLOAD_PATH_CFG, download_path_cfg )
	Cfg.Save()
 end

--加载配置文件
function  Cfg.Load()
	 Cfg._loadSetting()
	 Cfg._loadRMEClientCfg()
	 Cfg._loadHelpCfg()
	 Cfg._checkValid()
end

function CreateRequestURL(url)
	return Cfg.GetServer()..url;
end

---------------------------------------------------
--Cfg.Load()已经确保一定在所有所有函数启动前能够被正确调用
--获取过滤条件表
function Cfg.GetFileter(k)
	if key == nil then
		key = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	local FILTER = registerGetString( key , Cfg.self.KEY.FILTER )
	local start = 0
	local filtertable = {}
	while start do
		keystring,start = __FindValue(FILTER,start)
		if start then
			table.insert(filtertable,keystring)
		end
	end
	return filtertable
end

function __FindValue(keystring,start)
	local i = string.find(keystring,"{",start)
	if i then 
		j = string.find(keystring,"}",i+1)
		return string.sub(keystring,i+1,j-1),j+1
	else
		return nil
	end
end

function Cfg.GetVideoType( k )
	if key == nil then
		key = registerCreate( Cfg.self.KEY.RMEAPP )
	end
	local VIDEO_TYPE = registerGetString( key , Cfg.self.KEY.VIDEO_TYPE )
	return VIDEO_TYPE
end

function Cfg.__GetHelpPath__( k )
	if (k) then
		k = registerCreate( Cfg.self.KEY.HELP )
	end
	local help_dir = registerGetString( k, Cfg.self.KEY.HELP_INFO_PATH )
	WriteLogs("__GetHelpPath__ ==> "..help_dir)
	return help_dir
end

function Cfg.GetHelpText(indexText)
	require "module.common.io"
	local app_path = GetDefaultFolder(WDFIDL_MODULE)
	local key = registerCreate( Cfg.self.KEY.HELP )
	local help_dir = Cfg.__GetHelpPath__(key)
	local help_text_file= registerGetString( key, indexText )
	local hf = app_path..help_dir..help_text_file
	WriteLogs("help_text_file "..hf)
	local ts =  fileRead(  hf )
	if ( indexText == "HELP_ABOUT") then
		require("module.ver")
		ts = string.format( ts, G_CLIENT_INFO)
	end
	return ts
end

function Cfg.SaveLastLoginDate(LastLoginDate)
	local rmekey = registerCreate(Cfg.self.KEY.RMEAPP)
	registerSetString(rmekey,Cfg.self.KEY.LASTLOGINDATE,LastLoginDate)
	Cfg.Save()
end

function Cfg.GetLastLoginDate()
	local rmekey = registerCreate(Cfg.self.KEY.RMEAPP)
	local LastLoginDate = registerGetString(rmekey,Cfg.self.KEY.LASTLOGINDATE)
	return LastLoginDate
end
