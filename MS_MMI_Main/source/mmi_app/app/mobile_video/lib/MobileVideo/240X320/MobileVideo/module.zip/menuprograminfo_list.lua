﻿--@module menuprograminfo_list
--@note 列表详情
--@author cuiyizhou
--@date 2010/05/28
require "module.Loading.useLoading"
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.protocol.protocol_videoloading"
require "module.keyCode.keyCode"
playurl = {}
name = {}

function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("menuprograminfo_list")   
	registerSetInteger(reg, "root", sprite)
	local reg = registerCreate("menuprograminfo_list")
	local fileName = registerGetString(reg, "listUrlFileName")
	json = jsonLoadFile(fileName)
	loadJsonData()
	--[[  创建列表元素  ]]-- 
	createSubjectList(sprite)
	--[[  根据json中数据判断是否需要显示上一节目或者下一节目]]--
	if json.prevId then
	else
		local backbtn = FindChildSprite(sprite,"button-backprogram")
		SetSpriteVisible(backbtn ,0)
		SetSpriteEnable(backbtn ,0)
	end
	if json.nextId then
	else
		local nextbtn = FindChildSprite(sprite,"button-nextprogram")
		SetSpriteVisible(nextbtn ,0)
		SetSpriteEnable(nextbtn ,0)
	end
	return 1
end

--@function createSubjectList
--@brief 创建列表元素
function createSubjectList(sprite)
	local spriteList = FindChildSprite(sprite, "subject-list")
	--[[  创建列表元素，此处应该使用网络数据  ]]--
	if json.subIds ~= nil then
		count = table.maxn(json.subIds)
		SpriteList_LoadListItem(spriteList, "MODULE:\\menuprograminfo_listItem.xml", count+1)
		for i=0, count do
			local menuprograminfoSprite = SpriteList_GetListItem(spriteList,i)
			--[[  设置item区域大小  ]]--
			SetSpriteRect(menuprograminfoSprite, 0, 0, 205, 25)
			--[[  设置列表设置列表上的文字内容  ]]--
			local spritetextN = FindChildSprite(menuprograminfoSprite, "subjectButtontextN")
			SetSpriteProperty(spritetextN, "text", json.subIds[i].subName)
			local spritetextF = FindChildSprite(menuprograminfoSprite, "subjectButtontextF")
			SetSpriteProperty(spritetextF, "text", json.subIds[i].subName)
--[[---------------------------------修改人：yaoxiangyin 修改时间：2010.08.30-----------------------------------------]]--			
			local subjectButtonSprite=FindChildSprite(menuprograminfoSprite,"subject-list-1")
			SetSpriteProperty(subjectButtonSprite, "name",string.format("subject-list-%d",i))
			SetSpriteProperty(subjectButtonSprite, "OnKeyUp","menulistButtonSubjectKeyUp")
---------------------------------------------------------------------------------------------------------
		end
		--[[  自动调整item之间间隔  ]]--
		SpriteList_Adjust(spriteList)
		--[[  创建滚动条  ]]--
		require "module.common.commonScroll"
		CreateScrollBar(sprite,"subject-list",25*(count+1),61)
--[[---------------------------------修改人：yaoxiangyin 修改时间：2010.08.30-----------------------------------------]]--	
		SetSpriteFocus(FindChildSprite(spriteList,"subject-list-0"))
-----------------------------------------------------------------------------------------------------------------------------		
	else
		count = 0
	end
end

--@function backButtonOnSelect
--@tag-name button-backprogram
--@tag-action button:OnSelect 
--@brief 上一节目
function backButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_list")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	if nil ~= json then
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		require "module.menuprograminfo"
		--[[  这里应该动态获取点击按钮的具体url  ]]--
		if json.prevId[0].category == "1" then
			local volumeurl = json.prevId[0].urlPath
			require "module.protocol.protocol_infovolume"
			RequestVolume(109, volumeurl)
			--[[ sava urlPath ]]--
			SetProgramInfoUrlPath(volumeurl)
		elseif json.prevId[0].category == "5" then
			if json.prevId[0].displayType == "5" then
				local listurl = json.prevId[0].urlPath
				require "module.protocol.protocol_infolist"
				RequestList(112, listurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(listurl)
			elseif json.prevId[0].displayType == "1" then
				local labelurl = json.prevId[0].urlPath
				require "module.protocol.protocol_infolabel"
				Requestlabel(111, labelurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(labelurl)
			end
		end
	end
end

--@function nextButtonOnSelect
--@tag-name button-nextprogram
--@tag-action button:OnSelect 
--@brief 下一节目
function nextButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_list")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	if nil ~= json then
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		require "module.menuprograminfo"
		--[[  这里应该动态获取点击按钮的具体url  ]]--
		if json.nextId[0].category == "1" then
			local volumeurl = json.nextId[0].urlPath
			require "module.protocol.protocol_infovolume"
			RequestVolume(109, volumeurl)
			--[[ sava urlPath ]]--
			SetProgramInfoUrlPath(volumeurl)
		elseif json.nextId[0].category == "5" then
			if json.nextId[0].displayType == "5" then
				local listurl = json.nextId[0].urlPath
				require "module.protocol.protocol_infolist"
				RequestList(112, listurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(listurl)
			elseif json.nextId[0].displayType == "1" then
				local labelurl = json.nextId[0].urlPath
				require "module.protocol.protocol_infolabel"
				Requestlabel(111, labelurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(labelurl)
			end
		end
	end
end

--@function	loadJsonData
--@brief	从缓存中读取数据，完成数据回填，在bodyBuildChildrenFinished中调用
function loadJsonData()
	--[[  获取根节点 ]]--
	local reg = registerCreate("menuprograminfo_list")   
	local root = registerGetInteger(reg, "root")
	if json then
		--[[  数据回填 ]]--
		local sprite = FindChildSprite(root , "info-content-caption")
		SetSpriteProperty(sprite,"text",json.path)
		local starlevel = FindChildSprite(root , "starlevel")
		local width1 = math.floor(json.starLevel)*8
		local width2 = (json.starLevel - math.floor(json.starLevel))*12
		SetSpriteRect(starlevel,0,0,width1+width2,12)
		local contentName1 = FindChildSprite(root , "item-video-caption1")
		SetSpriteProperty(contentName1,"text",json.contentName)
		local contentName2 = FindChildSprite(root , "item-video-caption2")
		SetSpriteProperty(contentName2,"text",json.contentName)
		local content = FindChildSprite(root , "item-video-caption3")
		SetSpriteProperty(content,"text","歌手："..json.singer)
	
		--[[  设置海报图片内容  ]]--  
		postpic = FindChildSprite(root, "item-video-caption-postpic")
		SetSpriteProperty(postpic, "src", json.img)
		if json.subIds then
			count = table.maxn(json.subIds)+1
			for i = 0,count-1 do
				playurl[i] = json.subIds[i].playUrl
				name[i] = json.subIds[i].subName
			end
		end
	end
end

--@function VolumeItemOnSelect
--@tag-name subject-list-button
--@tag-action button:OnSelect
--@brief 选择内容完成跳转
function VolumeItemOnSelect(sprite)
	SetSpriteFocus(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_list")   
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root ,"loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	local reg_g = registerCreate("group")
	registerSetString(reg_g, "scenename","menuprograminfo_list")
	
	local spriteItem = GetSpriteParent(sprite)
	local index = SpriteListItem_GetIndex(spriteItem)
	-- sava current item
	local regVideo = registerCreate("video")
	registerSetInteger(regVideo, "groupCurItem", index)

	require("module.menuprograminfo")
	require "module.protocol.protocol_videoloading"
	RequestVideo(101, json.subIds[index].playUrl, GetProgramInfoUrlPath(), json.contentName ,"group")
end

--@function OnSpriteEvent
--@tag-name body
--@tag-action sprite:OnSpriteEvent 
--@brief 响应消息
function OnSpriteEvent(message, params)
	require("module.common.commonMsg")
	require "module.videoexpress-common"
	--[[  收藏事件  ]]--
	if message == MSG_ADD_FAV then --add my fav
		require("module.protocol.protocol_addmyfav")
		require("module.menuprograminfo")
		local reg = registerCreate("product")
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
		local urlPath = GetProgramInfoUrlPath()
		WriteLogs("addfavorite urlPath---"..urlPath)
		urlPath = string.gsub(urlPath,"&","|")
		WriteLogs("gsub urlPath---"..urlPath)
		
		local playUrl = json.subIds[0].playUrl
		WriteLogs("playUrl---"..playUrl)
		local pos = string.find(playUrl,"nodeId",0)
		if pos then
			local nodeId = string.sub(playUrl,pos+7)
			WriteLogs("nodeId---"..nodeId)			
			RequestAddMyfav(110, 1, nodeId, json.contentId, urlPath)
		end
	end
	--[[  返回事件  ]]--
	if message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
	if message == MSG_SMS then
		requestMsgContent()
	end
	return 1
end

--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	if message == 101 then
		exitLoading()
		RequestPlay(scenePrograminfo_list)
	elseif message == 104 then
		exitLoading()
		RequestPlay(scenePrograminfo_list)
	elseif message == 109 then
		local volumeData = OnVolumeDecode()
		FreeVolumeFuncs()
		if volumeData then
			exitLoading()
			local volumeSprite = GetCurScene()
			FreeScene(volumeSprite)
			Go2Scene(scenePrograminfo_volume)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_list, scenePrograminfo_list, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeVolumeFuncs()
	elseif message == 110 then
		require("module.dialog.useDialog")		
		reslut, desc = OnPipeAddMyFav()
		exitLoading()
		setDialogParam("提示", desc, "BT_OK", scenePrograminfo_list, scenePrograminfo_list, GetCurScene())
		Go2Scene(sceneDialog)
	elseif message == 111 then
		local labelData = OnLabelDecode() 
		if labelData then
			exitLoading()
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			Go2Scene(scenePrograminfo_label)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_list, scenePrograminfo_list, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeLabelFuncs()
	elseif message == 112 then
		local listData = OnListDecode() 
		if listData then
			exitLoading()
			local listSprite = GetCurScene()
			FreeScene(listSprite)
			Go2Scene(scenePrograminfo_list)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_list, scenePrograminfo_list, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeListFuncs()
	elseif message > 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", scenePrograminfo_list, scenePrograminfo_list, GetCurScene())
		Go2Scene(sceneDialog)
	elseif MSG_SMS_ID == message then
		DealMsgContent(scenePrograminfo_list, scenePrograminfo_list)
	end
	return 1
end


local subjectFirstNum=0

--[[------------------------------------修改人：yaoxiangyin 修改时间：2010.08.30------------------------------------------]]--
function menulistButtonSubjectKeyUp(sprite,keyCode)
	local menulistReg = registerCreate("menuprograminfo_list")
	registerSetInteger(menulistReg,"menulistFocusSprite",sprite)
	registerSetNumber(menulistReg,"lastFocusFlag",1)
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	local subjectList={}  --存放列表项中的Button名
	local spriteList =FindChildSprite(GetRootSprite(sprite),"subject-list") --subject-list节点
	local spriteNextButton=FindChildSprite(GetRootSprite(spriteList),"button-nextprogram")     --下一页按钮
	local spriteBackButton=FindChildSprite(GetRootSprite(spriteList), "button-backprogram")    --上一页按钮
	
	local subjectName = GetSpriteName(sprite)
	local subjectFocusNum
	
	
	local itemCount=SpriteList_GetListItemCount(spriteList)
	for j=0,itemCount-1 do
		subjectList[j]="subject-list-"..j
	end
	
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if subjectList[i]==subjectName then
	    subjectFocusNum=i
	  end
	end
	
	local menuprograminfoSprite=FindChildSprite(GetRootSprite(sprite),"menuprograminfo")   --menuprograminfo节点
	
	if keyCode== ApKeyCode_Down then
		if subjectList[subjectFocusNum+1]~=nil then
			SetSpriteFocus(FindChildSprite(spriteList,subjectList[subjectFocusNum+1]))
			if subjectFocusNum==subjectFirstNum+5 then
				subjectFirstNum=subjectFirstNum+1
				for j=0,itemCount-1 do
					local item=SpriteList_GetListItem(spriteList,j)
					item_x,item_y,item_width,item_height=GetSpriteRect(item)
					SetSpriteRect(item,item_x,item_y-25,item_width,item_height)
				end
			end
		end
	elseif keyCode== ApKeyCode_Up then
		if subjectList[subjectFocusNum-1]~=nil then
			SetSpriteFocus(FindChildSprite(spriteList,subjectList[subjectFocusNum-1]))
			if subjectFocusNum==subjectFirstNum then
				subjectFirstNum=subjectFirstNum-1
				for j=0,itemCount-1 do
					local item=SpriteList_GetListItem(spriteList,j)
					item_x,item_y,item_width,item_height=GetSpriteRect(item)
					SetSpriteRect(item,item_x,item_y+25,item_width,item_height)
				end
			end
		else
			SetSpriteFocus(spriteBackButton)
		end
	elseif keyCode== ApKeyCode_Enter then
		VolumeItemOnSelect(sprite)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

function menulistButtonProgramKeyUp(sprite,keyCode)
	local menulistReg = registerCreate("menuprograminfo_list")
	registerSetInteger(menulistReg,"menulistFocusSprite",sprite)
	registerSetNumber(menulistReg,"lastFocusFlag",1)
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	local spriteList =FindChildSprite(GetRootSprite(sprite),"subject-list") --subject-list节点
	local spriteNextButton=FindChildSprite(GetRootSprite(spriteList),"button-nextprogram")     --下一页按钮
	local spriteBackButton=FindChildSprite(GetRootSprite(spriteList), "button-backprogram")    --上一页按钮
	
	local subjectName = GetSpriteName(sprite)
	local subjectFocusNum
	
	if keyCode== ApKeyCode_Right and subjectName=="button-backprogram" then
		SetSpriteFocus(spriteNextButton)
	elseif keyCode== ApKeyCode_Left and subjectName=="button-nextprogram" then
		SetSpriteFocus(spriteBackButton)
	elseif keyCode== ApKeyCode_Down then
		SetSpriteFocus(FindChildSprite(spriteList,"subject-list-0"))
	elseif keyCode== ApKeyCode_Enter then
		if subjectName=="button-backprogram" then
			backButtonOnSelect(sprite)
		elseif subjectName=="button-nextprogram" then
			nextButtonOnSelect(sprite)
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
------------------------------------------------------------------------------------------------------------------------------