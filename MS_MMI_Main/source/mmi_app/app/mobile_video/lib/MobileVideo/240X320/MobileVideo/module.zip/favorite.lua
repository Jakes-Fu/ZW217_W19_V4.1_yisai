﻿--@module	favorite
--@note	用于收藏界面的UI显示
--@author	shenyi
--@date	2010/05/30
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.Loading.useLoading"
require "module.protocol.protocol_infovolume"
require "module.protocol.protocol_channel"
require "module.dialog.useDialog"
require "module.common.ascertainTargetScene"
require "module.keyCode.keyCode"
require "module.common.commonScroll"

favorite_SelectHeight = 48
favorite_NormalHeight = 25
favorite_ItemWidth = 222
favcount = 0
deleteCancle = 1	
--@tag-action	body:BuildChildrenFinished
--@brief	创建收藏列表
function bodyBuildChildrenFinished(sprite)
		local empty = FindChildSprite(sprite, "emptybutton")
		SetSpriteFocus(empty)
		saveTouchFocus(empty)
		local reg = registerCreate("favorite")
		registerSetInteger(reg, "root", sprite)
		http = pluginCreate("HttpPipe")
	deleteCancle=0
	return 1
end

function bodyOnSpriteEvent(message, params)
	require("module.common.commonMsg")
	require "module.videoexpress-common"
	--[[  返回事件  ]]--
	if message == MSG_RETURN then
		FreeScene(GetCurScene())
	elseif message == MSG_ACTIVATE then
		   if deleteCancle ==0 then
		if dnr and dnr == 1 then
			dnr = nil
		else
			require "module.setting"
			local FavoriteUrl = Cfg.GetServer()..Cfg.GetPortal().."/msp/collectList.msp"
			RequestFavorite(FavoriteUrl, nil)
	end
		deleteCancle = 1
		end
	elseif message == MSG_SMS then
		requestMsgContent()
	end
	return 1
end

--@function	CreatefavoriteList
--@brief	创建收藏列表
function CreatefavoriteList()
	local reg = registerCreate("favorite")
	local sprite = registerGetInteger(reg, "root")	
	local spriteList = FindChildSprite(sprite, "favorite-list")
	SpriteList_ClearListItem(spriteList, 1, 1)
	SpriteList_LoadListItem(spriteList, "MODULE:\\favoriteItemList.xml", favcount)	
	if favcount==0 then
	
		local root = GetRootSprite(sprite)
		local empty = FindChildSprite(root, "emptybutton")
		SetSpriteFocus(empty)
		saveTouchFocus(empty)
	end
	for i=1,favcount do
		local favoriteSprite	 = SpriteList_GetListItem(spriteList, i-1)		
		local spriteSel = FindChildSprite(favoriteSprite,"select")
		local spriteUnSel = FindChildSprite(favoriteSprite,"unselect")
	--[[	if i == 1 then
			SetSpriteVisible(spriteSel, 1)
			SetSpriteEnable(spriteSel, 1)
			SetSpriteVisible(spriteUnSel, 0)			
			SetSpriteEnable(spriteUnSel, 0)			
			SetSpriteRect(favoriteSprite, 0, 0, favorite_ItemWidth, favorite_SelectHeight)
			prevSelectSprite = favoriteSprite
		else]]--
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)
			SetSpriteRect(favoriteSprite, 0, 0, favorite_ItemWidth, favorite_NormalHeight)
--		end
		 spritePlay = FindChildSprite(favoriteSprite,"playbutton")
		 spriteDetail = FindChildSprite(favoriteSprite,"detailbutton")
		 spriteEnter = FindChildSprite(favoriteSprite,"enterbutton")
		if favoriteDataArray[i-1].contentId then
			--单集显示播放和详情按钮
			if favoriteDataArray[i-1].category == "1" or favoriteDataArray[i-1].category == "2" or favoriteDataArray[i-1].category == "3" then --dw
				SetSpriteVisible(spritePlay, 1)
				SetSpriteEnable(spritePlay, 1)
				SetSpriteVisible(spriteDetail, 1)			
				SetSpriteEnable(spriteDetail, 1)
				SetSpriteVisible(spriteEnter, 0)			
				SetSpriteEnable(spriteEnter, 0)
			--内容集显示详情按钮
			elseif favoriteDataArray[i-1].category == "5" then
				SetSpriteVisible(spritePlay, 0)
				SetSpriteEnable(spritePlay, 0)
				SetSpriteVisible(spriteDetail, 1)			
				SetSpriteEnable(spriteDetail, 1)
				SetSpriteVisible(spriteEnter, 0)			
				SetSpriteEnable(spriteEnter, 0)
			end
		--栏目显示进入按钮
		elseif favoriteDataArray[i-1].channelId then
			SetSpriteVisible(spritePlay, 0)
			SetSpriteEnable(spritePlay, 0)
			SetSpriteVisible(spriteDetail, 0)			
			SetSpriteEnable(spriteDetail, 0)
			SetSpriteVisible(spriteEnter, 1)			
			SetSpriteEnable(spriteEnter, 1)
		end
	end
	 SpriteList_Adjust(spriteList)
	 favorite_list = spriteList
	--WriteLogs("spriteUnsel = "..GetSpriteName(spriteUnSel))
	if favcount~=0 then
		local spriteItem = SpriteList_GetListItem(spriteList, 0)
		SetSpriteFocus(FindChildSprite(spriteItem,"item-button"))
		saveTouchFocus(FindChildSprite(spriteItem,"item-button"))
	end
	--[[  统一滚动条创建  ]]--
	CreateScrollBar(sprite,"favorite-list",(favcount-1)*favorite_NormalHeight + favorite_SelectHeight,69.1)
	ScrollBarAdjust(0,4,0)
	select = 1
end

--@function	itemButtonOnSelect
--@tag-name	item-button
--@tag-action	button:OnSelect
--@brief	用于响应各列表项按钮
function itemButtonOnSelect(sprite)
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "favorite-list")
	--[[
	if prevSelectSprite ~= nil then
		WriteLogs("favorite itemButtonOnSelect 1") 
		local spriteSel1 = FindChildSprite(prevSelectSprite,"select")
		local spriteUnSel1 = FindChildSprite(prevSelectSprite,"unselect")
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(prevSelectSprite, 0, 0, favorite_ItemWidth, favorite_NormalHeight)
		WriteLogs("favorite itemButtonOnSelect 2") 
	end
	]]--
	for i=0,(SpriteList_GetListItemCount(spriteList)-1) do
		local initSpriteItem = SpriteList_GetListItem(spriteList,i)
		local spriteSel1 = FindChildSprite(initSpriteItem,"select")
		local spriteUnSel1 = FindChildSprite(initSpriteItem,"unselect")
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(initSpriteItem, 0, 0, favorite_ItemWidth, favorite_NormalHeight)
	end
	local spriteParent = GetSpriteParent(sprite)
	local spritefavorite = GetSpriteParent(spriteParent)
	local spriteSel2 = FindChildSprite(spritefavorite,"select")
	local spriteUnSel2 = FindChildSprite(spritefavorite,"unselect")
	SetSpriteVisible(spriteUnSel2, 0)
	SetSpriteEnable(spriteUnSel2, 0)
	SetSpriteVisible(spriteSel2, 1)			
	SetSpriteEnable(spriteSel2, 1)
	SetSpriteRect(spritefavorite, 0, 0, favorite_ItemWidth, favorite_SelectHeight)
	SpriteList_Adjust(spriteList)
	prevSelectSprite = spritefavorite
	select = SpriteListItem_GetIndex(spritefavorite) + 1
	SetSpriteFocus(spriteSel2)
	saveTouchFocus(spriteSel2)
	--added by licj
	--CurIndex =SpriteList_GetCurItem(spriteList)
	--WriteLogs("curindex==="..CurIndex)
	setBtnFocus(spriteSel2)
end

function deleteButtonOnSelect(sprite)
	ReleaseSpriteCapture(sprite)
	local spriteListItem = GetSpriteParent(GetSpriteParent(sprite))
	SetSpriteEnable(spriteListItem, 0)
	local index = SpriteListItem_GetIndex(spriteListItem)
	deleteUrl = favoriteDataArray[index].delUrl
	local reg = registerCreate("favorite")
	local spriteRoot = registerGetInteger(reg, "root")	
	local spriteEvent = FindChildSprite(spriteRoot,"event")
	registerSetInteger(reg,"current",index)
	registerSetInteger(reg,"dialognum",1)
	local name = nil
	if favoriteDataArray[index].contentId then
		name = "节目"
	elseif favoriteDataArray[index].channelId then	
		name = "栏目"
	end
	setDialogParam("取消收藏", "      您确认要删除该"..name.."吗？", "BT_OK_CANCEL",sceneFavoriteList ,sceneFavoriteList,spriteEvent)
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	local curScene=registerSetString(SceneReg,"SceneName","favorite")
	Go2Scene(sceneDialog)
end

function detailButtonOnSelect(sprite)
	local spriteListItem = GetSpriteParent(GetSpriteParent(sprite))
	local index = SpriteListItem_GetIndex(spriteListItem)
	loadAnimation()
	--[[  这里应该动态获取点击按钮的具体url  ]]--
	local urlpath = favoriteDataArray[index].urlPath
	local param1 = tonumber(favoriteDataArray[index].category)
	local param2 = tonumber(favoriteDataArray[index].formType)
	local param3 = tonumber(favoriteDataArray[index].displayType)
	if param1 == 5 then
		local reg = registerCreate("download_select")
		registerSetString(reg,"filepath",favoriteDataArray[index].urlPath)	
	end
	SceneName, pfnRequest, pfnDecode = AscertainTargetScene(param1,param2,param3)
	pfnRequest(103,urlpath)					
end

--@function playButtonOnSelect
--@tag-name playButton
--@tag-action button:OnSelect
--@brief 播放按钮，用户发起播放请求，成功则播放
function playButtonOnSelect(sprite)
	loadAnimation()
	--[[  这里应该动态获取点击按钮的具体url  ]]--
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local num = SpriteListItem_GetIndex(spriteItem)

	local urlpath = favoriteDataArray[num].urlPath
	local playUrl = favoriteDataArray[num].playUrl;
	local name = favoriteDataArray[num].favoriteName

	local reg = registerCreate("favorite")
	registerSetString(reg, "urlpath", urlpath)
	registerSetString(reg, "playUrl", playUrl)
	registerSetString(reg, "name", name)	
	
	local reg1 = registerCreate("product")
	registerSetString(reg1,"playurl",playUrl)
	registerSetString(reg1,"contentid",favoriteDataArray[num].contentId)
	
	require "module.protocol.protocol_videoloading"
	RequestVideo(102, playUrl, urlpath, name, "demand")
	require "module.protocol.protocol_infovolume"
	RequestVolume(999, urlpath)		
	return 1
end

function enterButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("favorite")
	local root = GetRootSprite(sprite)
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)	
	
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	local num = SpriteListItem_GetIndex(spriteItem)
	local urlpath = favoriteDataArray[num].urlPath
	RequestChannel(107,urlpath)
end

--@function	setFavoriteListData
--@brief	设置收藏列表数据
function setFavoriteListData()
	local reg = registerCreate("favorite")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite,"favorite-list")
	for i = 1,favcount do
		spriteItem = SpriteList_GetListItem(spriteList, i-1)
		local spriteTxt = FindChildSprite(spriteItem, "item-text")
		local spriteTxt1 = FindChildSprite(spriteItem, "item-text1")
		SetSpriteProperty(spriteTxt, "text", favoriteDataArray[i-1].favoriteName)	
		SetSpriteProperty(spriteTxt1, "text", favoriteDataArray[i-1].favoriteName)	
	end
end

function OnSpriteEvent(message, params)
	require("module.common.commonMsg")
	local reg = registerCreate("favorite")
	local dlgnum = registerGetInteger(reg,"dialognum")	
	if message == 1001 then
		if dlgnum == 1 then
			loadAnimation()
			DeleteFavorite(deleteUrl,nil)
		elseif dlgnum == 2 then
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			Go2Scene(sceneFavoriteList)
		end
		deleteCancle=0
	elseif message == 1002 then
			deleteCancle = 1
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneFavoriteList, sceneFavoriteList)	
	end
end

function OnTimer()
	local reg = registerCreate("favorite")
	local spriteRoot = registerGetInteger(reg,"root")
	local spriteEvent = FindChildSprite(spriteRoot, "event")
	local success  = registerGetInteger(reg,"success")
	local index = registerGetInteger(reg,"current")
	registerSetInteger(reg,"dialognum",2)
	local name = nil
	if favoriteDataArray[index].contentId then
		name = "节目"
	elseif favoriteDataArray[index].channelId then	
		name = "栏目"
	end	
	if success == 1 then
		setDialogParam("取消收藏", "         成功删除该"..name.."!", "BT_OK", sceneFavoriteList, sceneFavoriteList, spriteEvent)
	else
		setDialogParam("取消收藏", "         删除"..name.."失败!", "BT_OK", sceneFavoriteList, sceneFavoriteList, spriteEvent)
	end
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	local curScene=registerSetString(SceneReg,"SceneName","favorite")
	Go2Scene(sceneDialog)
end

function OnPluginEvent(message, param)
  require("module.loading.useLoading")
	require "module.videoexpress-common"
	--请求收藏列表
	if message == 101 then
		exitLoading()	
		local reg = registerCreate("favorite")
		local sprite = registerGetInteger(reg,"root")
		createFavoriteData()
		CreatefavoriteList()
		setFavoriteListData()
	--跳转播放
	elseif	message == 102 then
		exitLoading()
		RequestPlay(sceneFavoriteList)
	--跳转详情
	elseif message == 103 then
		exitLoading()	
		local volumeData = pfnDecode()
		if volumeData then
			exitLoading()		
			SetReturn(sceneFavoriteList,SceneName)
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			GoAndFreeScene(SceneName)
			--Go2Scene(SceneName)
		else
		--[[  出错提示  ]]--
		end		
	--删除收藏
	elseif message == 104 then
		exitLoading()
		local json = jsonLoadFile(fileName)
		local reg = registerCreate("favorite")
		if json and json.success and json.success == "true" then
			registerSetInteger(reg,"success",1)
		else
			registerSetInteger(reg,"success",0)
		end
		SetTimer(1, 1000, "OnTimer")
	--请求详情返回以请求播放
	elseif message == 105 then
		exitLoading()
	elseif message == 106 then
		exitLoading()
		require "module.setting"
		local FavoriteUrl = Cfg.GetServer()..Cfg.GetPortal().."/msp/collectList.msp"			
	    RequestFavorite(FavoriteUrl, nil)
	--跳转栏目详情
	elseif message == 107 then
		exitLoading()	
		local json = ChannelNetworkData()
		if json then
			SetReturn(sceneFavoriteList,sceneProduct)
			GoAndFreeScene(sceneProduct)
			-- local labelSprite = GetCurScene()
			-- FreeScene(labelSprite)
			--Go2Scene(sceneProduct)
		end
	elseif message == 107 + MSG_CACHEDATA_RELOAD then
		WriteLogs("favorite message == 107 + MSG_CACHEDATA_RELOAD")
		require "module.productReload"
		ReloadProductData()
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneFavoriteList, sceneFavoriteList)	
	elseif message > 32768 then 
		exitLoading()
		dnr = 1
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneFavoriteList, sceneFavoriteList, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function  DeleteFavorite(url,tag)
	fileName = GetLocalFilename(url)
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, url, 0, fileName, observer, 104, 0, 1)
end

--@function RequestFavorite
--@brief 协议请求
function RequestFavorite(url,tag)
	fileName = GetLocalFilename(url)
	local reg = registerCreate("favorite")
	registerSetString(reg, "myfavoriteUrlFileName", fileName)
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, url, 0, fileName, observer, 101, 0, 1)
	loadAnimation()
end

--@function createPaihangData
--@brief 协议解析
function createFavoriteData()
	local json = jsonLoadFile(fileName)
	if json and json.collections then
		favoriteDataArray = {}
		favcount = table.maxn(json.collections) + 1
		for i=0, table.maxn(json.collections) do
			if json.collections[i].content ~= nil then
				local urlpath1 = json.collections[i].content.urlPath
				urlpath1 = string.gsub(urlpath1,"|","&")
				
				favoriteDataArray[i] = {
					contentId	 =	json.collections[i].content.id,
					favoriteName =	json.collections[i].content.name,
					starLevel	 =	json.collections[i].content.starLevel,
					category	 =	json.collections[i].content.category, 
					formType	 =	json.collections[i].content.formType, 
					displayType	 =	json.collections[i].content.displayType,
					type		 =	json.collections[i].content.type,
					delUrl		 =	json.collections[i].content.delUrl,
					urlPath		 =	urlpath1,
					playUrl      =  json.collections[i].content.playUrl,
					}		
			elseif json.collections[i].channel ~= nil then
				local urlpath1 = json.collections[i].channel.urlPath
				urlpath1 = string.gsub(urlpath1,"|","&")
				favoriteDataArray[i] = {
					channelId	 =	json.collections[i].channel.channelId,
					favoriteName =	json.collections[i].channel.name,
					displayType	 =	json.collections[i].channel.channelType,
					delUrl		 =	json.collections[i].channel.delUrl,
					urlPath		 =	urlpath1,
					}
			end
		end
	end
end

function loadAnimation()
	local reg = registerCreate("favorite")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	require("module.loading.useLoading")
	enterLoading(loadarea)
end

--列表每一行中内容，先定位于最左一个BUTTON
-- 四个按钮顺序：进入、播放、详情、删除
function setBtnFocus(sprite)
	local enterBtn = FindChildSprite(sprite,"enterbutton")
	local playBtn = FindChildSprite(sprite,"playbutton")
	local detailBtn = FindChildSprite(sprite,"detailbutton")
	local deleteBtn = FindChildSprite(sprite,"deletebutton")
	if IsSpriteVisible(enterBtn) ==1 then
		SetSpriteFocus(enterBtn)
		saveTouchFocus(enterBtn)
	elseif IsSpriteVisible(playBtn) ==1 then
		SetSpriteFocus(playBtn)
		saveTouchFocus(playBtn)
	elseif IsSpriteVisible(detailBtn) ==1 then
		SetSpriteFocus(detailBtn)
		saveTouchFocus(detailBtn)
	elseif IsSpriteVisible(deleteBtn) ==1 then
		SetSpriteFocus(deleteBtn)
		saveTouchFocus(deleteBtn)
	end
end

--@brief 响应列表播放按钮键盘事件
--@auther  dw
function buttonOnKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local root = GetRootSprite(sprite)
	local itemCount=SpriteList_GetListItemCount(favorite_list)
	WriteLogs("itemCount="..itemCount)
	local item=GetSpriteParent(GetSpriteParent(sprite))
	local index=SpriteListItem_GetIndex(item)
	WriteLogs("当前index"..index)
	local spriteSel = FindChildSprite(item,"select")
	local spriteUnSel = FindChildSprite(item,"unselect")
	local playSpriteButton = FindChildSprite(FindChildSprite(item,"select"), "playbutton")
	local EnterButton = FindChildSprite(FindChildSprite(item,"select"), "enterbutton")
	local detailSpriteButton = FindChildSprite(FindChildSprite(item,"select"),"detailbutton")
	local deleteSpriteButton = FindChildSprite(FindChildSprite(item,"select"),"deletebutton")
	local result = IsSpriteEnable(detailSpriteButton)
	local name = GetSpriteName(sprite)
	require("module.keyCode.keyCode")
	WriteLogs("~~~~~~~~~~~buttonOnKeyUp："..keyCode)
	local list_x, list_y2, list_w, list_h = GetSpriteRect(favorite_list)
	local _, list_y1 = GetSpriteRect(item)
	local list_y = list_y1+list_y2
	
	if	keyCode==ApKeyCode_Enter then
			WriteLogs("Enter 当前index"..index)
			if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
				local i=1
				SetSpriteVisible(spriteSel, 1)
				SetSpriteEnable(spriteSel, 1)
				SetSpriteVisible(spriteUnSel, 0)			
				SetSpriteEnable(spriteUnSel, 0)	
				local x, y, w, h = GetSpriteRect(item)
				SetSpriteRect(item, x, y, 222, 48)
				if favoriteDataArray[index].contentId then
						SetSpriteFocus(playSpriteButton)
						saveTouchFocus(playSpriteButton)
				elseif favoriteDataArray[index].channelId then
					SetSpriteFocus(EnterButton)
					saveTouchFocus(EnterButton)
				end
				for j=index,itemCount-1 do
					
					spriteItem = SpriteList_GetListItem(favorite_list, index+i)
					i=i+1
					local x, y, w, h = GetSpriteRect(spriteItem)			
					SetSpriteRect(spriteItem,x,y+favorite_NormalHeight,w,h)
				end
			elseif GetSpriteName(GetSpriteParent(sprite))=="select" then
				if GetSpriteName(sprite)=="playbutton" then playButtonOnSelect(sprite)
				elseif GetSpriteName(sprite)=="detailbutton" then detailButtonOnSelect(sprite)
				elseif GetSpriteName(sprite)=="deletebutton" then deleteButtonOnSelect(sprite)
				elseif GetSpriteName(sprite)=="enterbutton"	then enterButtonOnSelect(sprite)
				end										
			end		
			if list_y >= 195 then
				SetSpriteRect(favorite_list,list_x, list_y2-favorite_NormalHeight,list_w, list_h)
				ChangeScrollPositon(sprite,"down")
			end
			SpriteList_Adjust(favorite_list)		
	elseif keyCode == ApKeyCode_Left then
		if favoriteDataArray[index].channelId then
			if name=="deletebutton" then 
			SetSpriteFocus(EnterButton)
			saveTouchFocus(EnterButton)
			else 
			return
			end
		else	
			if name == "deletebutton" then
					if result == 0 then
							SetSpriteFocus(playSpriteButton)
							saveTouchFocus(playSpriteButton)
						else
							SetSpriteFocus(detailSpriteButton)
							saveTouchFocus(detailSpriteButton)
					end
			elseif name == "detailbutton" then
					SetSpriteFocus(playSpriteButton)
					saveTouchFocus(playSpriteButton)
			end	
		end
	elseif keyCode==ApKeyCode_Right then
			WriteLogs("右移动")
		if favoriteDataArray[index].channelId then
			if name=="enterbutton" then 
			SetSpriteFocus(deleteSpriteButton)
			saveTouchFocus(deleteSpriteButton)
			else 
				return
			end
		else
					if name == "playbutton" then
						if result == 0 then
							SetSpriteFocus(deleteSpriteButton)
							saveTouchFocus(deleteSpriteButton)
						else
							SetSpriteFocus(detailSpriteButton)
							saveTouchFocus(detailSpriteButton)
						end
					elseif name == "detailbutton" then
						SetSpriteFocus(deleteSpriteButton)
						saveTouchFocus(deleteSpriteButton)
					end
		end
	elseif keyCode==ApKeyCode_Down  and index<=itemCount-1 then
			WriteLogs("下移动")
			if index==itemCount-1 then return 0 end
				if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
					local nextListItem = SpriteList_GetListItem(favorite_list, index+1)			
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
				elseif	GetSpriteName(GetSpriteParent(sprite))=="select" then
					local i=1
					local nextListItem = SpriteList_GetListItem(favorite_list, index+1)
					
					WriteLogs("下焦点："..SpriteListItem_GetIndex(nextListItem))
					SetSpriteVisible(spriteSel, 0)
					SetSpriteEnable(spriteSel, 0)
					SetSpriteVisible(spriteUnSel, 1)			
					SetSpriteEnable(spriteUnSel, 1)		
					local x, y, w, h = GetSpriteRect(item)							
					SetSpriteRect(item, x, y, 222, 25)
					local spriteSelNext = FindChildSprite(nextListItem,"select")
					local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
					SetSpriteVisible(spriteSelNext, 0)
					SetSpriteEnable(spriteSelNext, 0)
					SetSpriteVisible(spriteUnSelNext, 1)			
					SetSpriteEnable(spriteUnSelNext, 1)		
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					for j=index,itemCount-1 do
						
						spriteItem = SpriteList_GetListItem(favorite_list, index+i)
						i=i+1
						local x, y, w, h = GetSpriteRect(spriteItem)			
						SetSpriteRect(spriteItem,x,y-favorite_NormalHeight,w,h)
					end
				end
			if list_y >= 195 then
				SpriteScrollBar_Adjust(favorite_list)
				SetSpriteRect(favorite_list,list_x, list_y2-favorite_NormalHeight,list_w, list_h)
				ChangeScrollPositon(sprite,"down")
			end	
	elseif 	keyCode==ApKeyCode_Up and index>=1 then
			WriteLogs("上移动 ")
					if index==0 then return 0 end
					local i=1
					local nextListItem = SpriteList_GetListItem(favorite_list, index-1)
			if 		GetSpriteName(GetSpriteParent(sprite))=="unselect" then
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
			elseif	GetSpriteName(GetSpriteParent(sprite))=="select" then
					WriteLogs("上焦点："..SpriteListItem_GetIndex(nextListItem))
					SetSpriteVisible(spriteSel, 0)
					SetSpriteEnable(spriteSel, 0)
					SetSpriteVisible(spriteUnSel, 1)			
					SetSpriteEnable(spriteUnSel, 1)		
					local x, y, w, h = GetSpriteRect(item)							
					SetSpriteRect(item, x, y, 222, 25)
					local spriteSelNext = FindChildSprite(nextListItem,"select")
					local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
					SetSpriteVisible(spriteSelNext, 0)
					SetSpriteEnable(spriteSelNext, 0)
					SetSpriteVisible(spriteUnSelNext, 1)			
					SetSpriteEnable(spriteUnSelNext, 1)		
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					for j=index,itemCount-1 do
						spriteItem = SpriteList_GetListItem(favorite_list, index+i)
						i=i+1
						local x, y, w, h = GetSpriteRect(spriteItem)			
						SetSpriteRect(spriteItem,x,y-favorite_NormalHeight,w,h)
					end
				
			end
			if list_y <= 10 then
				SpriteScrollBar_Adjust(favorite_list)
				SetSpriteRect(favorite_list,list_x, list_y2+favorite_NormalHeight,list_w, list_h)
				ChangeScrollPositon(sprite,"up")
				end
				
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	
	elseif keyCode == ApKeyCode_CharB then
		if itemCount ~= 0 then
			local clearButton = FindChildSprite(root, "clearButton")
			clearButtonOnSelect(clearButton)
		end
	end
end
function emptyKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	if keyCode == ApKeyCode_F1 then
        require("module.sysmenu")
        require("module.menuopen")
        local homeLastFoucsReg= registerCreate("homeLastFoucs")
        registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
        SysGetSeceSprite(sprite)
        menuButtonOnSelect(sprite)
    elseif keyCode == ApKeyCode_F2  then
        require("module.menuopen")
        returnButtonOnSelect(sprite)
    end
	return 0
end
--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	require "module.common.commonScroll"
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,4,0)
	else
		ScrollBarAdjust(CurIndex + 1,4,1)
	end
end
