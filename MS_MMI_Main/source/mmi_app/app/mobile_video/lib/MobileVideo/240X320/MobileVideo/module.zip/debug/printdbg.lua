function printData(data)
	for i, v in pairs(data) do
	    if type(v) == "table" then
	    	  printData(v)
		else --if type(v) == "string" then
			WriteLogs(string.format("[%s], [%s]", i, v))
	    end
	end
end