-- @author xf_pan
-- @date 2010/07/22
-- @brief reload guid data
function ReloadGuidData()
	require("module.common.commonMsg")
	local reg = registerCreate("guide")
	local guid = registerGetInteger(reg, "root")
	
	if guid and guid ~= 0 then
		SendSpriteEvent(guid, MSG_RELOAD)
	end
end