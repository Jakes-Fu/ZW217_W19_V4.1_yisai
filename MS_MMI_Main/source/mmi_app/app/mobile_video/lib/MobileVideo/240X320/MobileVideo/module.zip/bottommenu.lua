﻿
keyQuickLauncherBar = "QuickLauncherBar";
SPRITENAME_BOTTOMMENU = "bottommenu";

function menuBoardOnMouseUp(sprite, x, y)
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	local bottomSprite = FindChildSprite(rootSprite, SPRITENAME_BOTTOMMENU);
	if bottomSprite ~= 0 then
		ReleaseSpriteCapture(rootSprite);
		RemoveChildSprite(rootSprite, bottomSprite, 1);
	end
	---用于解决触摸点击菜单后，再次点击空白区域失焦点问题---
	local reg = registerCreate("PopMenuHide") 
	local sencePreFocus=registerGetInteger(reg,"sencePreFocus") 
	SetSpriteFocus(sencePreFocus)
	----------------------------------------------------
end

function mailBoxOnSelect(button)
	WriteLogs("mailBoxOnSelect");
	
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\receivemessage.xml")
	Go2Scene("MODULE:\\receivemessage.xml")	
end

function myOrderOnSelect(button)
	WriteLogs("myOrderOnSelect");

	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\myorder.xml")
	Go2Scene("MODULE:\\myorder.xml")	
end

function myFavOnSelect(button)
	WriteLogs("myFavOnSelect");
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\favorite.xml")
	Go2Scene("MODULE:\\favorite.xml")	
end

function addFavOnSelect(button)
	WriteLogs("addFavOnSelect");
	require("module.common.commonMsg")
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	local root = GetCurScene()
	SendSpriteEvent(root, MSG_ADD_FAV)

end

function historyOnSelect(button)
	WriteLogs("historyOnSelect");
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\history.xml")
	Go2Scene("MODULE:\\history.xml")	
end

function localFileOnSelect(button)
	WriteLogs("localFileOnSelect");
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\LocalFile.xml")
	Go2Scene("MODULE:\\LocalFile.xml")	
end

function hidePopupSprites()
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	local bottomSprite = FindChildSprite(rootSprite, SPRITENAME_BOTTOMMENU);

	if bottomSprite ~= 0 then
		ReleaseSpriteCapture(rootSprite);
		RemoveChildSprite(rootSprite, bottomSprite, 1);
	end

end


--@function 		SetReturn
--@tag-name 		无
--@tag-action		OnSelect
--@brief 				返回前需要做的事，如果该页面需要被返回，则调用这个函数
function SetReturn1(nextScenceName)
	local	regQuick = registerCreate(keyQuickLauncherBar)
	local	rootSprite = registerGetInteger(regQuick, "rootSprite")
	local   rootScene = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle")
	local SceneName = registerGetString(regHandle, string.format("%d", rootScene))
	if SceneName ~= sceneHome then
		FreeScene(rootScene)
	end
	if SceneName ~= sceneRecommend and SceneName ~= sceneDownloadSelect then
	 	reg = registerCreate(keyQuickLauncherBar)
	 	local count = registerGetInteger(reg, "Count")+1
		registerSetInteger(reg, "Count", count)
		require("module.setting");
		local CurPage = registerGetString(reg, "CurPage")
		registerSetString(reg, "PageName" .. count, CurPage)
		registerSetString(reg, "CurPage", nextScenceName)
	end
end