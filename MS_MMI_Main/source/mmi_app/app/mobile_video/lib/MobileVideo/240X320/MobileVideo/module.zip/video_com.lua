﻿EPlayerStatus_Idle		= 0 		--//正常状态，空闲
EPlayerStatus_Connecting= 1		--//正在连接网络，或者打开本地文件
EPlayerStatus_Ready		= 2			--//网络连接成功，或者本地文件打开成功，可以开始播放
EPlayerStatus_Buffering	= 3		--//网络/文件缓冲中
EPlayerStatus_Playing	= 4			--//正在播放
EPlayerStatus_Paused	= 5			--//正在暂停
EPlayerStatus_Stopped	= 6			--//播放停止，此时可以继续播放，等同于Ready
EPlayerStatus_Finished	= 7		--//播放完成，Finished与Idle相同
EPlayerStatus_Error		= 8			--//可以通过GetErrorCode/GetErrorString获得错误代码与错误文字
curStatus = 11
videoTypeList = {"local", "demand", "group", "live"}
playurl =""
pathurl =""
videoname =""
videoType =""
iffull = 0
flag = 0
curPageIsVideo = true
videoCurnum_offset = 0
function createGlobalValue()
	reg = registerCreate("video")  
	local sprite=registerGetInteger(reg, "root")
	labelStartTimeSprite = FindChildSprite(sprite, "item-playerinterface-curtime")	--当前时间
	labelEndTimeSprite = FindChildSprite(sprite, "item-playerinterface-totaltime")	--视频总时间
	huaKuaiSprite = FindChildSprite(sprite, "item-playerinterface-progressblock")		--进度游标
	local backgroundSprite = FindChildSprite(sprite, "item-playerinterface-progressbar")
	spritehighlight = FindChildSprite(sprite,"item-playerinterface-progressbarhighlight")
	spritehighred = FindChildSprite(sprite,"item-playerinterface-progressbarhighred")
	local left1, top1, width1, height1 = GetSpriteRect(backgroundSprite)
	local left2, top2, width2, height2 = GetSpriteRect(huaKuaiSprite)
	huaKuai_left = left2																														--游标的初始位置
	gWidth = width1-width2																													--进度条总长度
	FullSec = FindChildSprite(sprite, "FullSec")
	FullScreenButton = FindChildSprite(sprite, "item-playercontrols-fullscreen")
	statuslabel = FindChildSprite(sprite, "player-status1")													--状态信息，用于显示播放器状态
	statuslabe2 = FindChildSprite(sprite, "player-status2")													--状态信息
	statusSMS   = FindChildSprite(sprite, "sms-Status")															--短信状态信息
	smsStatusImage = FindChildSprite(sprite, "sms-Status-image")										--短信到来的图片
	pauseButton = FindChildSprite(sprite, "item-playercontrols-pause")							--暂停按钮
	palyButton = FindChildSprite(sprite, "item-playercontrols-play")								--播放按钮
	recommendButton = FindChildSprite(sprite, "item-playercontrols-recommend")			--互动按钮
	recommand1Button = FindChildSprite(sprite, "item-playerinterface-recommand1")		--推荐节目1
	recommand2Button = FindChildSprite(sprite, "item-playerinterface-recommand2")		--推荐节目2
--	fullButton = FindChildSprite(sprite, "FullSec")																--全屏播放器时切换
	curVolume = 0																																		--当前音量
	gTotalTime = 1
	tickTime = 0																																		--设置这个值是为了避免过于频繁的请求服务器时间
end

--显示时间
--second 秒
function setSecTime(sprite, second)
	local reg= registerCreate("video")
	if second ==nil then
		return 0
	end
	mm = second/ 60
	mm = math.floor(mm)
	if mm <10 then
		mm = "0" ..mm
	end
	ss = second % 60 
	if ss < 10 then
		ss = "0" ..ss
	end
	if videoType ~= videoTypeList[4] then
		SetSpriteProperty(sprite,"text",mm .. ":" ..ss)
	else
		if sprite == labelStartTimeSprite then
			SetSpriteProperty(sprite,"text",registerGetString(reg, "startTime"))--验收规范要求时间不变
		end
		if sprite == labelEndTimeSprite then
			SetSpriteProperty(sprite,"text",registerGetString(reg, "endTime"))
		end 
	end
end
--检测播放器状态
--UI显示播放图标，为暂停或停止状态
function UIPaly()
	SetSpriteRect(pauseButton,0,20,20,20)
	SetSpriteProperty(pauseButton ,"enable","false")
	SetSpriteRect(palyButton,0,0,20,20)
	SetSpriteProperty(palyButton ,"enable","true")
end
--UI显示暂停图标，为播放或缓冲状态
function UIPause()
	SetSpriteRect(pauseButton,0,0,20,20)
	SetSpriteProperty(pauseButton,"enable","true")
	SetSpriteRect(palyButton,0,20,20,20)
	SetSpriteProperty(palyButton,"enable","false")
end

function OnGetStatus(idEvent)
	local reg= registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin then
		local status = pluginInvoke(MediapalyPlugin, "GetStatus")
		local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
		if status == nil then
		elseif status == EPlayerStatus_Idle then	
			SetStatusText("连接中")
			UIPaly()
			WriteLogs("EPlayerStatus_Idle")
			if HasSpriteFocus(pauseButton)~=0 then
			    KillSpriteFocus(pauseButton)
			    SetSpriteFocus(palyButton)
			  end
		elseif status == EPlayerStatus_Connecting then
			SetStatusText("连接中")
			UIPause()
			WriteLogs("EPlayerStatus_Connecting")
			if HasSpriteFocus(palyButton)~=0 then
			    KillSpriteFocus(palyButton)
			    SetSpriteFocus(pauseButton)
			end
		elseif status == EPlayerStatus_Ready then
			gTotalTime = pluginInvoke(MediapalyPlugin, "GetTotalTime")
			setSecTime(labelEndTimeSprite, gTotalTime)
			if videoType ~= videoTypeList[1] then
				SetStatusText("连接中")
			end
			UIPaly()
			if curPageIsVideo and isplayed == nil then
				isplayed = 1
				pluginInvoke(MediapalyPlugin, "Play")
			end
			if HasSpriteFocus(pauseButton)~=0 then
			    KillSpriteFocus(pauseButton)
			    SetSpriteFocus(palyButton)
			end
			WriteLogs("EPlayerStatus_Ready")
		elseif status == EPlayerStatus_Buffering then
			isplayed = nil
			local curBuffer = pluginInvoke(MediapalyPlugin, "GetBufferPercent")
			if videoType ~= videoTypeList[1] then
				SetStatusText("缓冲" ..curBuffer .."%")
				if curBuffer == 0 then
					seekEnable = 0
				else
					seekEnable = 1
				end
			end
			UIPause()
			--SetSpriteEnable(pauseButton,0)
			gTotalTime = pluginInvoke(MediapalyPlugin, "GetTotalTime")
			setSecTime(labelEndTimeSprite, gTotalTime)
			if HasSpriteFocus(palyButton)~=0 then
			    KillSpriteFocus(palyButton)
			    SetSpriteFocus(pauseButton)
			end
		elseif status == EPlayerStatus_Playing then
			isplayed = nil
			gCurTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
			gTotalTime = pluginInvoke(MediapalyPlugin, "GetTotalTime")
			WriteLogs("EPlayerStatus_Playing")
			if flag ~= 1 then
				setSecTime(labelEndTimeSprite, gTotalTime)
				setSecTime(labelStartTimeSprite, gCurTime)
			end
			if gTotalTime - gCurTime < 3 and gTotalTime - gCurTime > 0 and videoType ~= videoTypeList[4] then
				SetSpriteEnable(recommendButton,0)
			else
				SetSpriteEnable(recommendButton,1)
			end
			UIPause()
			SetStatusText(videoName)
			local reg = registerCreate("video")
			registerSetString(reg,"videoName",videoName)
			if HasSpriteFocus(palyButton)~=0 then
				KillSpriteFocus(palyButton)
				SetSpriteFocus(pauseButton)
			end
		elseif status == EPlayerStatus_Paused then
			UIPaly()
			WriteLogs("EPlayerStatus_Paused")
			SetStatusText("暂停")
			if HasSpriteFocus(pauseButton)~=0 then
			    KillSpriteFocus(pauseButton)
			    SetSpriteFocus(palyButton)
			  end
		elseif status == EPlayerStatus_Stopped then
			if videoType == videoTypeList[1] then
				setSecTime(labelEndTimeSprite, 0)
				SetStatusText("播放完成")
				ResetUi()
			  if HasSpriteFocus(pauseButton)~=0 then
			    KillSpriteFocus(pauseButton)
			    SetSpriteFocus(palyButton)
			  end
			end	
			UIPaly()
			if HasSpriteFocus(pauseButton)~=0 then
			    KillSpriteFocus(pauseButton)				
			    SetSpriteFocus(palyButton)
			end
			WriteLogs("EPlayerStatus_Stopped")
		elseif status == EPlayerStatus_Finished then
			RevertStatus()	--add by yaoxiangyin
			if iffull==1 then
				FullSecOnButtonClick()
				end
			if videoType == videoTypeList[1] then
				setSecTime(labelEndTimeSprite, 0)
				SetStatusText("播放完成")
				pluginInvoke(MediapalyPlugin, "Stop")
				
				ResetUi()
			else
				require "module.common.DownloadUpload"
				pluginInvoke(MediapalyPlugin, "Stop")
				StartUploadTask()
				require ("module.common.SceneUtils")
				require ("module.common.registerScene")
				if videoType == videoTypeList[3] then
					SetReturn(sceneVideoGroup, sceneRecommend)
					GoAndFreeScene(sceneRecommend)
				else
					SetReturn(sceneVideoLiveDemand, sceneRecommend)
					GoAndFreeScene(sceneRecommend)
				end
			end	
			setSecTime(labelStartTimeSprite, 0)
			setSecTime(labelEndTimeSprite, 0)
			UIPaly()
			if HasSpriteFocus(pauseButton)~=0 then
			    KillSpriteFocus(pauseButton)				
			    SetSpriteFocus(palyButton)
			end
			WriteLogs("EPlayerStatus_Finished")
		elseif status == EPlayerStatus_Error then
			if videoType == videoTypeList[1] then
				SetStatusText("文件格式不支持")
			else
				SetStatusText("连接服务器失败")
			end
			UIPaly()
			WriteLogs("EPlayerStatus_Error")
			if HasSpriteFocus(pauseButton)~=0 then
			    KillSpriteFocus(pauseButton)
			    SetSpriteFocus(palyButton)
			  end
		end
		--播放器状态处理end
		curStatus = status
		if curTime ~= nil then
			--setSecTime(labelStartTimeSprite, curTime)
		else
			return 1
		end
		if videoType ~= videoTypeList[4] then
			if huaKuai_left ~=nil and gTotalTime ~=0 and status == EPlayerStatus_Playing and flag ~= 1 then
				local moveWidth = (gWidth / gTotalTime) * curTime
				local left2, top2, width2, height2 = GetSpriteRect(huaKuaiSprite)
				SetSpriteRect(huaKuaiSprite, huaKuai_left + moveWidth,top2, width2, height2)
				local left2, top2, width2, height2 = GetSpriteRect(spritehighlight)
				SetSpriteRect(spritehighlight, left2, top2, moveWidth, height2)
				SetSpriteRect(spritehighred, left2, top2, moveWidth, height2)
			else
				initData()
			end
		else
			if tickTime % 120 == 0 then
				--[[  直播节目时间请求，1分钟一次  ]]--
				GetSysTime()
			end	
			if huaKuai_left ~=nil and status == EPlayerStatus_Playing then
				local regLive = registerCreate("live")
				local sysTime = registerGetString(regLive, "sysTime")
				local curSysTime = 0
				if sysTime ~= "" then
					local year, month, day, hour, minute, second = ParseDate(sysTime)
					curSysTime = hour ..":" ..minute
				else
					local m_date=os.date("*t", os.time())
					curSysTime = m_date.hour ..":" ..m_date.min
				end
				local curTimeInt = getTimeFoString(curSysTime)
				WriteLogs("curTimeInt =="..curTimeInt)
				local startTimeInt = getTimeFoString(registerGetString(reg, "startTime"))
				local endTimeInt = getTimeFoString(registerGetString(reg, "endTime"))
				WriteLogs("endTimeInt =="..endTimeInt)
				if  curTimeInt ~=0 and startTimeInt ~=0 and endTimeInt ~=0 and startTimeInt <= endTimeInt and curTimeInt <= endTimeInt then
					local moveWidth =(gWidth * (curTimeInt - startTimeInt)/ (endTimeInt - startTimeInt))
					local left2, top2, width2, height2 = GetSpriteRect(huaKuaiSprite)
					SetSpriteRect(huaKuaiSprite, huaKuai_left + moveWidth,top2, width2, height2)
					local left2, top2, width2, height2 = GetSpriteRect(spritehighlight)
					SetSpriteRect(spritehighlight, left2, top2, moveWidth, height2)
					SetSpriteRect(spritehighred, left2, top2, moveWidth, height2)
				end
				if curTimeInt > endTimeInt then
					--播放下一个节目，将时间和标题改变
					require ("module.protocol.protocol_video")
					local name, startTime, endTime = GetLiveTable()
					if name ~= "" and startTime ~= "" and endTime ~= "" then
						local regVideo = registerCreate("video")
						registerSetString(regVideo, "startTime", startTime)
						registerSetString(regVideo, "endTime", endTime)
						videoName = name
						local reg = registerCreate("video")
						registerSetString(reg,"videoName",videoName)
					end
				end
			else
				initData()
			end
		end
	else
		SetStatusText("")
	end
	if curPageIsVideo then
		SetTimer(1, 500, "OnGetStatus")
	end
	tickTime = tickTime + 1
end

function getTimeFoString(stringTime)
	if stringTime and stringTime ~= "" then
		local a, b,tt, mm =string.find(stringTime, "(%d+):(%d+)")
		if tt and mm then
			return tt*60 + mm
		end
	end
	return 0
end

function liveNowTime()
	local m_date=os.date("*t", os.time())
	local hourString , minString ="", ""
	if m_date.hour	< 10 then
		hourString = "0" .. m_date.hour
	else
		hourString = m_date.hour
	end
	if m_date.min	< 10 then
		minString = "0" .. m_date.min
	else
		minString = m_date.min
	end
	return hourString ..":" ..minString
end

-- 设置状态文字
function SetStatusText(text,type)
	if type == nil then
		if statuslabel and statuslabe2 then
			SetSpriteProperty(statuslabel, "text", text)
			SetSpriteProperty(statuslabe2, "text", text)	
		end
		return 1
	elseif type == "sms" then
		SetSpriteVisible(statuslabel, 0)
		SetSpriteVisible(statuslabe2, 0)
		SetSpriteProperty(statusSMS, "text", text)
		SetSpriteVisible(smsStatusImage, 1)
		return 1
	end
end

function initData()
	local reg = registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	gTotalTime = pluginInvoke(MediapalyPlugin, "GetTotalTime")
	setSecTime(labelEndTimeSprite, gTotalTime)
end

--@function progressOnMouseUp
--@tag-name item-playerinterface-progressbar
--@tag-action image:OnMouseUp
--@brief 用于响应用户对进度条的点击时间
function progressOnMouseUp(sprite, x, y)
	--[[	先获取当前节点的父节点	]]--
	if seekEnable == 0 or IsReview == "true" then
		return
	end
	local reg = registerCreate("video")
	if videoType == videoTypeList[4] or curStatus == EPlayerStatus_Finished or curStatus == EPlayerStatus_Paused then
		return 0
	end
	
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin ~=nil then
		local	spriteParent = GetSpriteParent(sprite)
		--[[	分别寻找高亮进度条和进度快	]]--
		local spritehighlight = FindChildSprite(spriteParent,"item-playerinterface-progressbarhighlight")
		local l1,t1,w1,h1 = GetSpriteRect(spritehighlight)
		local spritehighred = FindChildSprite(spriteParent,"item-playerinterface-progressbarhighred")
		local l2,t2,w2,h2 = GetSpriteRect(spritehighred)
		SetSpriteRect(spritehighred,l2,t2,w1,h2)
		local spriteblock = FindChildSprite(spriteParent,"item-playerinterface-progressblock")
		local l,t,w,h = GetSpriteRect(spriteblock)
		local seekTime = math.floor((x-w/2)*gTotalTime/gWidth)
		if seekTime < 1 then
			seekTime=0
		else
			if seekTime > gTotalTime then
				seekTime = gTotalTime
			end
		end
		if (x + 49) > l + w then
			SetSpriteRect(spritehighred,l2,t2,x,h2)
			SetSpriteRect(spritehighlight,l1,t1,l-l1,h1)
			SetSpriteRect(spriteblock, l2+x-w,t, w, h)
		else
			if (x - 49) < l then
				SetSpriteRect(spritehighlight,l1,t1,x,h1)
				SetSpriteRect(spritehighred,l2,t2,l-l2,h2)
				if x > w then
					SetSpriteRect(spriteblock, l1+x-w,t, w, h)
				else
					SetSpriteRect(spriteblock, l1,t, w, h)
				end
			end
		end
		setSecTime(labelStartTimeSprite, seekTime)
		WriteLogs("SeekTime : ["..seekTime.."]")
		pluginInvoke(MediapalyPlugin, "Seek", seekTime)
	end
	SetTimer(1,400,"UpDelay")
	return 1
end

function UpDelay()
	flag = 0
end

function progressOnMouseDown(sprite)
	if curStatus ==	EPlayerStatus_Playing and IsReview ~= "true" then
		flag = 1
	end
end

--@function progressHitTest
--@tag-action button:OnMouseMove
--@brief 获取用户鼠标位置
function progressHitTest(sprite, x, y)
	if flag ~= 1 or seekEnable == 0 or IsReview == "true" then
		return 1
	end
	if videoType == videoTypeList[4] then
		return 0
	end
	
	local	parent = GetSpriteParent(sprite)
	local spritehighlight = FindChildSprite(parent,"item-playerinterface-progressbarhighlight")
	local l1,t1,w1,h1 = GetSpriteRect(spritehighlight)
	local spritehighred = FindChildSprite(parent,"item-playerinterface-progressbarhighred")
	local l2,t2,w2,h2 = GetSpriteRect(spritehighred)
	local spriteblock = FindChildSprite(parent,"item-playerinterface-progressblock")
	local l,t,w,h = GetSpriteRect(spriteblock)
	local seekTime = math.floor((x-w/2)*gTotalTime/gWidth)
	if seekTime < 1 then
		seekTime=0
	else
		if seekTime > gTotalTime then
			seekTime = gTotalTime
		end
	end
	
	setSecTime(labelStartTimeSprite, seekTime)
	if (x + 49) > l + w then
		SetSpriteRect(spritehighred,l2,t2,x,h2)
		SetSpriteRect(spriteblock, l2+x-w ,t, w, h)
	else
		if (x - 49) < l then
			SetSpriteRect(spritehighlight,l1,t1,x,h1)
			SetSpriteRect(spriteblock, l1+x-w <49 and 49 or (l2+x-w),t, w, h)
		end
	end
end

--[[  退出全屏处理  ]]--
function FullSecOnButtonClick(sprite)
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin then
		iffull =0
		pluginInvoke(MediapalyPlugin, "FullScreen", 0)
		ReleaseSpriteCapture(FullSec)
		SetSpriteProperty(FullSec,"enable","false")										--华为播放器
	end
		
		local reg=registerCreate("Fullselect")		
		local fullBt=registerGetInteger(reg,"FullFocus")
		SetSpriteFocus(fullBt)
		--WriteLogs("退出全屏后焦点:"..HasSpriteFocus(fullBt))
		
end

--[[  点击全屏  ]]--
function FullScreenOnButtonClick(sprite)
	WriteLogs("进入全屏")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if iffull == 0 then
		if MediapalyPlugin and curStatus==EPlayerStatus_Playing then
		iffull =1
			pluginInvoke(MediapalyPlugin, "FullScreen", 1)
			SetSpriteCapture(FullSec)
			SetSpriteProperty(FullSec,"enable","true")
			local reg=registerCreate("Fullselect")		--将全屏按钮节点写入数据仓库
			registerSetInteger(reg,"FullFocus",sprite)
		end
	end
end

--[[ 点击暂停 ]]--
function PauseOnButtonClick(sprite)
	if g_systicktime and GetTickTime() - g_systicktime < 1000 then
		return
	end
	g_systicktime = GetTickTime()
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin and curStatus==EPlayerStatus_Playing then
		WriteLogs("pauseButton")
		pluginInvoke(MediapalyPlugin, "Pause")
		UIPaly()
		SetSpriteFocus(palyButton)
	else
		WriteLogs("暂停无效")
	end
end

--[[ 点击播放器 ]]--
function  PlayOnButtonClick(sprite)
	if g_systicktime and GetTickTime() - g_systicktime < 1000 then
		return
	end
	g_systicktime = GetTickTime()
	
	reg = registerCreate("video")
	WriteLogs("当前状态当前状态当前状态当前状态当前状态："..curStatus)
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if curStatus ~= EPlayerStatus_Idle and curStatus ~= EPlayerStatus_Connecting and
		curStatus ~= EPlayerStatus_Buffering and curStatus ~= EPlayerStatus_Error and
		curStatus ~= EPlayerStatus_Stopped and curStatus ~= EPlayerStatus_Finished then
		if MediapalyPlugin then
			local reg_v = registerCreate("video")
			local isLive = registerGetInteger(reg_v, "isLive")
			WriteLogs("duweibeiju"..isLive)
			if isLive == 0 then
				pluginInvoke(MediapalyPlugin, "Play")
			else
				require ("module.protocol.protocol_video")
				local json = OnVideoDecode()
				if json and json.url then
					require("module.setting")
					if Cfg.GetVideoType() == ".3gp" then
						--[[  华为播放器  ]]--
						pluginInvoke(MediapalyPlugin, "Stop")
						SetTimer(1,500,"OpenDelay")
					else								--荣创播放器
						SetTimer(1,500,"OpenDelay")
					end
				else
					pluginInvoke(MediapalyPlugin, "Play")
				end
			end
			UIPause()
			SetSpriteFocus(pauseButton)
			saveTouchFocus(pauseButton)
		end
	else
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Open", localUrlList[videoCurnum])
			pluginInvoke(MediapalyPlugin, "Play")
			videoName = getFilename(localUrlList[videoCurnum])
			SetStatusText(videoName)
			local reg = registerCreate("video")
			registerSetString(reg,"videoName",videoName)
			ResetUi()
			playurl = localUrlList[videoCurnum]
		end
	end
end

--[[ 减音量 ]]--
function VolumeDownOnButtonClick(sprite)
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin then
		curVolume=pluginInvoke(MediapalyPlugin, "GetVolume")
		if curVolume > 24 then
			curVolume = curVolume - 25
		end
		pluginInvoke(MediapalyPlugin, "SetVolume", curVolume)
	end
	saveTouchFocus(sprite)
end

--[[ 加音量 ]]--
function VolumeUpOnButtonClick(sprite)
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin then
		curVolume=pluginInvoke(MediapalyPlugin, "GetVolume")
		curVolume = curVolume + 25
		if curVolume > 100 then
			curVolume = 100
		end
		pluginInvoke(MediapalyPlugin, "SetVolume", curVolume)
	end
	saveTouchFocus(sprite)
end

--[[ 上一个节目 ]]--
function PreVideoOnButtonClick(sprite)
	RevertStatus()	--add by yaoxiangyin
	require "module.Loading.useLoading"
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin then
		if videoCurnum > 1 then
			if videoType == videoTypeList[1] then
				pluginInvoke(MediapalyPlugin, "Stop")
				videoCurnum = videoCurnum - 1
				pluginInvoke(MediapalyPlugin, "Open", localUrlList[videoCurnum])
				videoName = getFilename(localUrlList[videoCurnum])
				SetStatusText(videoName)
				local reg = registerCreate("video")  
				registerSetString(reg,"videoName",videoName)
				ResetUi()
				playurl = localUrlList[videoCurnum]
				pluginInvoke(MediapalyPlugin, "Play")
			else
				pluginInvoke(MediapalyPlugin, "Stop")
				local root = GetCurScene()
				local loadarea = FindChildSprite(root ,"loadarea")
				enterLoading(loadarea)
				require("module.menuprograminfo")
				require "module.protocol.protocol_videoloading"
				videoCurnum = videoCurnum - 1
				videoName = json_l.contentName.." "..json_l.subIds[videoCurnum-1].subName
				local reg = registerCreate("video")  
				registerSetString(reg,"videoName",videoName)
				RequestVideo(102, json_l.subIds[videoCurnum-1].playUrl, GetProgramInfoUrlPath(), json_l.contentName ,"group")
			end
			if videoType == videoTypeList[3] then
				initData_G()
			end
			local reg_gr = registerCreate("video")
			registerSetInteger(reg_gr, "groupCurItem",videoCurnum)
			SaveHistoryVideoList()
		end
		setPreNetButtonBgImage(1)
	end
end

--[[ 下一个节目 ]]--
function NextVideoOnButtonClick(sprite)
	RevertStatus()	--add by yaoxiangyin
	require "module.Loading.useLoading"
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin then
		if videoCurnum < videoCount then
			if videoType == videoTypeList[1] then
				pluginInvoke(MediapalyPlugin, "Stop")
				videoCurnum = videoCurnum + 1
				pluginInvoke(MediapalyPlugin, "Open", localUrlList[videoCurnum])
				videoName = getFilename(localUrlList[videoCurnum])
				SetStatusText(videoName)
				local reg = registerCreate("video")  
				registerSetString(reg,"videoName",videoName)
				ResetUi()
				playurl = localUrlList[videoCurnum]
				pluginInvoke(MediapalyPlugin, "Play")
			else
				pluginInvoke(MediapalyPlugin, "Stop")
				local root = GetCurScene()
				local loadarea = FindChildSprite(root ,"loadarea")
				--[[  显示loading场景  ]]--
				enterLoading(loadarea)
				require("module.menuprograminfo")
				require "module.protocol.protocol_videoloading"
				videoCurnum = videoCurnum + 1
				videoName = json_l.contentName.." "..json_l.subIds[videoCurnum-1].subName
				local reg = registerCreate("video")
				registerSetString(reg,"videoName",videoName)
				RequestVideo(102, json_l.subIds[videoCurnum-1].playUrl, GetProgramInfoUrlPath(), json_l.contentName ,"group")
			end
			if videoType == videoTypeList[3] then
				initData_G()
			end
			local reg_gr = registerCreate("video")
			registerSetInteger(reg_gr, "groupCurItem",videoCurnum)
			SaveHistoryVideoList()
		end
		setPreNetButtonBgImage(1)
	end
end
--@function ConctrlsOnButtonClick
--@tag-name item-playercontrols下的所有button类的tag
--@tag-action button:OnSelect
--@brief 所有的播放器控制按钮逻辑
function ConctrlsOnButtonClick(sprite)
	--SetSpriteFocus(sprite)
	local reg= registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	local	spriteParent = GetSpriteParent(sprite)
	local name = GetSpriteName(sprite)
	--[[	互动界面按钮	]]--
	if name == "item-playercontrols-recommend" then
		RevertStatus()	--add by yaoxiangyin
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Show" , 0)
			pluginInvoke(MediapalyPlugin, "Pause")
			registerSetInteger(reg, "is2recommend", 1)
		end
		require ("module.common.SceneUtils")
		require ("module.common.registerScene")
		if videoType == videoTypeList[3] then
			SetReturn(sceneVideoGroup, sceneRecommend)
			GoAndFreeScene(sceneRecommend)
		else
			SetReturn(sceneVideoLiveDemand, sceneRecommend)
			GoAndFreeScene(sceneRecommend)
		end
	elseif name == "item-playercontrols-leftblock" then
		--[[	播放列表翻页	]]--
		KillSpriteFocus(sprite)
		if page >0 then
			page =page - 1
			refurbishListVideo()
		end
	elseif name == "item-playercontrols-rightblock" then
		KillSpriteFocus(sprite)
		if page <= pageMaxNum then
			page =page + 1
			refurbishListVideo()
		end
	end
	return 1
end

--推荐节目消息请求
function RequestGuide(url,tag)
	local nodeLoading = FindChildSprite(GetCurScene(), "loadingNode")
	require "module.Loading.useLoading"
	enterLoading(nodeLoading)
	require "module.protocol.protocol_infovolume"
	RequestVolume(101, url)
end

function getFilename(directory)
	local regVideo = registerCreate("video")
	local videoType = registerGetString(regVideo, "isDownloading")
	if videoType == "Downloading" then
		local t={}
		local k=0
		while true do
			k=string.find(directory,"\/",k+1)
			if k==nil then break end
			table.insert(t,k)
		end
		
		local position = t[#t]+1
		local filename = string.sub(directory,position)
		return filename
	else 
		local t={}
		local k=0
		while true do
			k=string.find(directory,"\\",k+1)
			if k==nil then break end
			table.insert(t,k)
		end
		local position = t[#t]+1
		local filename = string.sub(directory,position)
		return filename
	end
	
end

function ResetUi()
	local left2, top2, width2, height2 = GetSpriteRect(huaKuaiSprite)
	SetSpriteRect(huaKuaiSprite, huaKuai_left,top2, width2, height2)
	local left2, top2, width2, height2 = GetSpriteRect(spritehighlight)
	SetSpriteRect(spritehighlight, left2, top2, 0, height2)
	SetSpriteRect(spritehighred, left2, top2, 0, height2)
	setSecTime(labelStartTimeSprite, 0)
end

function setPreNetButtonBgImage(param)
	reg = registerCreate("video") 
	local sprite = GetCurScene()
	playerPre = FindChildSprite(sprite, "item-playercontrols-pre")
	playerPre_H = FindChildSprite(sprite, "item-playercontrols-h-pre")
	
	playerNext = FindChildSprite(sprite, "item-playercontrols-next")
	playerNext_H = FindChildSprite(sprite, "item-playercontrols-h-next")
	if videoCurnum == videoCount then
		if videoCount == 2 then
			SetSpriteRect(playerPre,0,0,20,20)
			SetSpriteProperty(playerPre ,"enable","true")
			SetSpriteRect(playerPre_H,0,20,20,20)
			SetSpriteProperty(playerPre_H ,"enable","false")
			
			SetSpriteRect(playerNext,0,20,20,20)
			SetSpriteProperty(playerNext ,"enable","false")
			SetSpriteRect(playerNext_H,0,0,20,20)
			SetSpriteProperty(playerNext_H ,"enable","true")
			local falgNextReg=registerCreate("flagNextReg")			--dw
			registerSetInteger(falgNextReg,"flagNextNum",1)
		elseif videoCount == 1 then
			SetSpriteRect(playerNext,0,20,20,20)
			SetSpriteProperty(playerNext ,"enable","false")
			SetSpriteRect(playerNext_H,0,0,20,20)
			SetSpriteProperty(playerNext_H ,"enable","true")
			local falgNextReg=registerCreate("flagNextReg")			--dw
			registerSetInteger(falgNextReg,"flagNextNum",1)
			SetSpriteRect(playerPre,0,20,20,20)
			SetSpriteProperty(playerPre ,"enable","false")
			SetSpriteRect(playerPre_H,0,0,20,20)
			SetSpriteProperty(playerPre_H ,"enable","true")  ---dw
			WriteLogs("1111111111111111111111")
			local falgReg=registerCreate("flagReg")			--dw
			registerSetInteger(falgReg,"flagNum",1)
		else		
			SetSpriteRect(playerNext,0,20,20,20)
			SetSpriteProperty(playerNext ,"enable","false")
			SetSpriteRect(playerNext_H,0,0,20,20)
			SetSpriteProperty(playerNext_H ,"enable","true")
			WriteLogs("222222222222222222222")
			------------------------------------------------------------
		local falgNextReg=registerCreate("flagNextReg")			--dw
			registerSetInteger(falgNextReg,"flagNextNum",1)
	------------------------------------------------------------------------------------------
			SetSpriteRect(playerPre,0,0,20,20)
			SetSpriteProperty(playerPre ,"enable","true")
			SetSpriteRect(playerPre_H,0,20,20,20)
			SetSpriteProperty(playerPre_H ,"enable","false")
		end
	end
	
	if videoCurnum == 1 then
		if videoCount == 2 then
			SetSpriteRect(playerPre,0,20,20,20)
			SetSpriteProperty(playerPre ,"enable","false")
			SetSpriteRect(playerPre_H,0,0,20,20)
			SetSpriteProperty(playerPre_H ,"enable","true")--dw
					
			SetSpriteRect(playerNext,0,0,20,20)
			SetSpriteProperty(playerNext ,"enable","true")
			SetSpriteRect(playerNext_H,0,20,20,20)
			SetSpriteProperty(playerNext_H ,"enable","false")
			WriteLogs("33333333333333333333")
			local falgReg=registerCreate("flagReg")			--dw
			registerSetInteger(falgReg,"flagNum",1)
		elseif videoCount == 1 then
			SetSpriteRect(playerNext,0,20,20,20)
			SetSpriteProperty(playerNext ,"enable","false")
			SetSpriteRect(playerNext_H,0,0,20,20)
			SetSpriteProperty(playerNext_H ,"enable","true")
			local falgNextReg=registerCreate("flagNextReg")			--dw
			registerSetInteger(falgNextReg,"flagNextNum",1)
			SetSpriteRect(playerPre,0,20,20,20)
			SetSpriteProperty(playerPre ,"enable","false")
			SetSpriteRect(playerPre_H,0,0,20,20)
			SetSpriteProperty(playerPre_H ,"enable","true")	
			WriteLogs("444444444444444444")
			local falgReg=registerCreate("flagReg")			--dw
			registerSetInteger(falgReg,"flagNum",1)--dw
		else
			SetSpriteRect(playerPre,0,20,20,20)
			SetSpriteProperty(playerPre ,"enable","false")
			SetSpriteRect(playerPre_H,0,0,20,20)
			SetSpriteProperty(playerPre_H ,"enable","true")
			WriteLogs("555555555555555555")
			------------------------------
			local falgReg=registerCreate("flagReg")			--dw
			registerSetInteger(falgReg,"flagNum",1)
			-------------------------------
			SetSpriteRect(playerNext,0,0,20,20)
			SetSpriteProperty(playerNext ,"enable","true")
			SetSpriteRect(playerNext_H,0,20,20,20)
			SetSpriteProperty(playerNext_H ,"enable","false")
		end
		
	end
	
	if videoCurnum >1 and videoCurnum < videoCount then
		SetSpriteRect(playerNext,0,0,20,20)
		SetSpriteProperty(playerNext ,"enable","true")
		SetSpriteRect(playerNext_H,0,20,20,20)
		SetSpriteProperty(playerNext_H ,"enable","false")
		SetSpriteRect(playerPre,0,0,20,20)
		SetSpriteProperty(playerPre ,"enable","true")
		SetSpriteRect(playerPre_H,0,20,20,20)
		SetSpriteProperty(playerPre_H ,"enable","false")
		local falgReg=registerCreate("flagReg")			--dw
			registerSetInteger(falgReg,"flagNum",0)
	end
end

function SeekUpAreaExtend(sprite)
	if flag == 1 then
		flag = 0
	end
end

function hintSMS()
	require "module.videoexpress-common"
	requestMsgContent()
end

function videoDealSMS()
	WriteLogs("cancelButtonOnSelect-start")
	local reg = registerCreate("dialog")
	setDialogReturnParam("cancel")
	resultMessage = 1002
	require "module.common.registerScene"
	-- 刷新背景的情况下可以加动画
	registerSetInteger(reg, "show-flag", 2)
	if "true" == GetMessageContentResult() then
		WriteLogs("writeMsgContent2XML")
	end
	WriteLogs("cancelButtonOnSelect-end")	
	local reg_video = registerCreate("video") 
	local smsAtPlayer = registerGetString(reg_video, "smsAtPlayer")
	SetStatusText(smsAtPlayer, "sms")
end

function RevertStatus()
	SetSpriteVisible(statuslabel, 1)
	SetSpriteVisible(statuslabe2, 1)
	SetSpriteProperty(statusSMS, "text", "")
	SetSpriteVisible(smsStatusImage, 0)
end

--时间格式20100621125251
function ParseDate(time)
	if time ~= "" then 
		local year = string.sub(time,1,4)
		local month = string.sub(time,5,6)
		local day = string.sub(time,7,8)
		local hour = string.sub(time,9,10)
		local minute = string.sub(time,11,12)
		local second = string.sub(time,13,14)
		return year, month, day, hour, minute, second
	else
		return 0
	end
end

function GetSysTime()
	require "module.protocol.protocol_systime"
	local jsonfile = OnSysDataDecode()
	if jsonfile and jsonfile.sysDate then
		local regLive = registerCreate("live")
		registerSetString(regLive, "sysTime", jsonfile.sysDate)
	end
	--获取当前时间
	require "module.protocol.protocol_systime"
	RequestSysTime(113)
	tickTime = 0	
end
	
function zeroProgress()
	setSecTime(labelStartTimeSprite, 0)
	setSecTime(labelEndTimeSprite, 0)
	local left2, top2, width2, height2 = GetSpriteRect(huaKuaiSprite)
	SetSpriteRect(huaKuaiSprite, huaKuai_left,top2, width2, height2)
	local left2, top2, width2, height2 = GetSpriteRect(spritehighlight)
	SetSpriteRect(spritehighlight, left2, top2, 0, height2)
	SetSpriteRect(spritehighred, left2, top2, 0, height2)
end

function MoveWindow_L()
    regtimer=registerCreate("timerflag")
	  timeflag=registerGetInteger(regtimer, "flag")
	  WriteLogs("dondondodn"..timeflag)
	  if timeflag==1 then
	    reg = registerCreate("video")
	    local videotype =  registerGetString(reg, "videoType")
	    local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	    if videotype==videoTypeList[1] then
	    	pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 35, 240, 160)
	    else
	    	pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 35, 240, 160)
	    end
    end
end
