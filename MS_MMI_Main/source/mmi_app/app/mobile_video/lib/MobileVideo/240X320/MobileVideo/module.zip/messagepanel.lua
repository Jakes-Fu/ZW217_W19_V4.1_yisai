﻿--@module recommend
--@note 互动及播放结束界面
--@author cuiyizhou
--@date 2010/05/25
require "module.common.SceneUtils"
require "module.common.registerScene"

flag = 0

function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("messagepannel")   
	registerSetInteger(reg, "root", sprite)
	
	--找全局变量里的name变量，赋给对话框的标题栏
	local title = registerGetString(reg, "title")
	SetSpriteProperty(FindChildSprite(sprite,"panelarea-title"),"text",title)
	SetSpriteProperty(FindChildSprite(sprite,"panelarea-title2"),"text",title)
	
	--[[  创建2个列表信息  ]]--  
	createPannelItems()

	--用于显示收藏结果和其他一些文字
	local text = registerGetString(reg, "text")
	if text ~= "" then
		SetSpriteProperty(FindChildSprite(sprite,"text"),"text",text)
	end
	return 1
end

--@function	createPannelItems
--@brief	创建提示板上的元素，在bodyBuildChildrenFinished中调用
function createPannelItems()
	--[[	获取根节点	]]--
	local reg = registerCreate("messagepannel")
	local root = registerGetInteger(reg, "root")
	
	--[[	寻找messagepannel中的list节点在其中插入其他模板的数据 	]]--
	local votesprite = FindChildSprite(root, "panelarea-items")
	--[[	创建listitem类的节点	]]--
	local voteitem = CreateSprite("listitem")
	--[[	用已有模板中数据填充该节点	]]--
	--[[	注：如果提示面板需要被很多页面用到，这里可以读取全局的值，这样可以用同		]]--
	--[[			一个页面做不同的事，但是相应按钮的事件都要写在这个lua中								]]--
	local loadpath = registerCreate("messagepannel")
	--[[	读取之前存放的路径	]]--
	local path = registerGetString(loadpath, "loadpath")
	--[[	释放全局量	]]--
	--registerRelease("messagepannel")
	LoadSprite(voteitem, path)
	SetSpriteRect(voteitem, 0,0,240,100)
	--[[	把该节点插入到场景中	]]--
	AddChildSprite(votesprite, voteitem)
	SpriteList_AddListItem(votesprite, voteitem)
	return 1
end

--@function VoteOnSelect
--@tag-name vote.xml中所有按钮的tag
--@tag-action button:OnSelect
--@brief 互动中鲜花，扔鸡蛋，返回的按钮
function VoteOnSelect(sprite)
	local spritename = GetSpriteName(sprite)
	--[[	获取根节点	]]--
	local reg = registerCreate("messagepannel")
	local root = registerGetInteger(reg, "root")
	require "module.Loading.useLoading"
	local loadarea = FindChildSprite(root ,"loadarea_m")
	enterLoading(loadarea)
	--[[	用户选择返回	]]--
	if spritename == "votereturn" then
		local pannelSprite = GetCurScene()
		local returnpath = registerGetString(reg, "returnpath")
		FreeScene(pannelSprite)
		Go2Scene(returnpath)
		--SetFocus2Latest()
		return
	end
	--[[  从json中获取投票url  ]]--
	local reg_vi = registerCreate("video")
	local videoFileName = registerGetString(reg_vi, "videoFileName")
	local json_m = jsonLoadFile(videoFileName)
	local reg_p = registerCreate("product")
	local contentId =	registerGetString(reg_p,"contentid")
	local flag_p = registerGetString(reg_p,contentId)
	if flag_p == "1" then
		require("module.dialog.useDialog")
		local returnpath = registerGetString(reg, "returnpath")
		setDialogParam("提示", "您评论过该节目", "BT_OK", returnpath,  returnpath, GetCurScene())
		--设置该分支的标志位
		pathReg = registerCreate("pathReg")
		registerSetInteger(pathReg,"pathFlag",1)
		pathFlag = registerGetInteger(pathReg,"pathFlag")
		Go2Scene(sceneDialog)
		local returnpathname = registerGetString(reg, "returnpathname")
		local reg = registerCreate(returnpathname)
		local root = registerGetInteger(reg, "root")
		local MessagePannel = FindChildSprite(root,"MessagePannel")
		RemoveChildSprite(root, MessagePannel)
		FreeSprite(MessagePannel)
		
		local myshadow = FindChildSprite(root,"myshadow")
		SetSpriteVisible(myshadow,0)
		exitLoading()
		return
	else
		--[[	用户选择鲜花	]]--
		require "module.protocol.protocol_vote"
		if spritename == "excelent" then
		--[[	隐藏当前界面 显示评论结果	]]--
			if json_m and json_m.optIds then
				if json_m.optIds[0].voteUrl then
					RequestVote(100,json_m.optIds[0].voteUrl)
				end
			else
				--[[	当无法从未订购的节目播放鉴权请求中获取投票url时，从详情中拿投票url	]]--
				local reg_v = registerCreate("menuprograminfo_volume")
				local volumeUrlFileName = registerGetString(reg_v, "volumeUrlFileName")
				local json_v = jsonLoadFile(volumeUrlFileName)
				if json_v and json_v.optIds then
					if json_v.optIds[0].voteUrl then
						RequestVote(100,json_v.optIds[0].voteUrl)
					end
				end
			end
		end
		--[[	用户选择扔鸡蛋	]]--
		if spritename == "notsatisfied" then
			--[[	隐藏当前界面 显示评论结果	]]--
			if json then
				if json.optIds[1].voteUrl then
					RequestVote(100,json.optIds[1].voteUrl)
					local result = FindChildSprite(root,"result")
				end
			else
				--[[	当无法从未订购的节目播放鉴权请求中获取投票url时，从详情中拿投票url	]]--
				local reg_v = registerCreate("menuprograminfo_volume")
				local volumeUrlFileName = registerGetString(reg_v, "volumeUrlFileName")
				local json_v = jsonLoadFile(volumeUrlFileName)
				if json_v and json_v.optIds then
					if json_v.optIds[1].voteUrl then
						RequestVote(100,json_v.optIds[1].voteUrl)
					end
				end
			end
		end
	end
end

--@function ShareOnSelect
--@tag-name share.xml中所有按钮的tag
--@tag-action button:OnSelect
--@brief 分享中发送 返回按钮
function ShareOnSelect(sprite)
	local spritename = GetSpriteName(sprite)
	--[[	获取根节点	]]--
	local reg = registerCreate("messagepannel")
	local root = registerGetInteger(reg, "root")
	SetSpriteCapture(root)
	--[[	用户选择发送	]]--
	if spritename == "send" then
		--[[	这里写发送逻辑	]]--
		local targetnumber = GetSpriteText(FindChildSprite(root,"testEdit"))
		local targetnumber1 = string.gsub(targetnumber, ",", "0")
		local targetnumber2 = string.gsub(targetnumber, ";", "0")
		local judge= tonumber(targetnumber1)
		local judge2= tonumber(targetnumber2)
		local str
		local s=0
		local flag=1
		local i = 0
		while true do
			i = string.find(targetnumber, ",", i+1)
			if i == nil then break end
			if (i-(s+1))~=11 then flag=0 break end
			s=i;
		end
		i = 0
		while true do
		  i = string.find(targetnumber, ";", i+1)
		  if i == nil then break end
		  if (i-(s+1))~=11 then flag=0 break end
		  s=i;
		end
		if (judge or judge2) and flag==1 then
			--[[  从json中获取推荐信息  ]]--
			local reg_p = registerCreate("product")			
			local contentid = registerGetString(reg_p, "contentid")
			local playurl = registerGetString(reg_p,"playurl")
			local i,j = string.find(playurl,"&nodeId=")
			if j then
				local k = string.find(playurl,"&",j+1)
			else
				require("module.dialog.useDialog")
				local returnpath = registerGetString(reg, "returnpath")
				setDialogParam("提示", "无法获取完整节目信息，推荐失败", "BT_OK", returnpath, returnpath, GetCurScene())
				Go2Scene(sceneDialog)
				return 0
			end
			local nodeid = nil
			if k then
				nodeid = string.sub(playurl,j+1,k-1)
			else
				nodeid = string.sub(playurl,j+1,string.len(playurl))
			end
			if nodeid and nodeid ~= "" then
				require "module.setting"
				require "module.protocol.protocol_share"
				RequestShare(101, Cfg.GetPortalURL().."/msp/recommend.msp?targetPhoneNumber="..targetnumber.."&contentId="..contentid.."&nodeId="..nodeid)
				local result = FindChildSprite(root,"result")
				--SetSpriteCapture(result)
				require "module.Loading.useLoading"
				local loadarea = FindChildSprite(root ,"loadarea_m")
				enterLoading(loadarea)
			else
				require("module.dialog.useDialog")
				local returnpath = registerGetString(reg, "returnpath")
				setDialogParam("提示", "无法获取完整节目信息，推荐失败", "BT_OK", returnpath, returnpath, GetCurScene())
				Go2Scene(sceneDialog)
			end
		else
			SetSpriteProperty(FindChildSprite(root,"panelarea-title"),"text","提示")
			SetSpriteProperty(FindChildSprite(root,"panelarea-title2"),"text","提示")
			local des = FindChildSprite(root,"resultdes")
			SetSpriteProperty(des,"text","非法号码输入")
			WriteLogs("非法号码输入")
			local messageReturnReg = registerCreate("messagepannel")
			local messageRoot = registerGetInteger(messageReturnReg,"root")
			messageReturn = FindChildSprite(messageRoot,"messagepanel-boardup")
			SetSpriteFocus(messageReturn)
			--"非法号码输入"的返回标志位
			desReturnFlag = 1
			local share = FindChildSprite(root,"share")
			SetSpriteRect(share,240,0,240,100)
			local result = FindChildSprite(root,"result")
			SetSpriteRect(result,0,0,240,100)
		end
	end
	--[[	用户取消	]]--
	if spritename == "cancel" or spritename == "sharereturn" then
		messageBoardOnMouseUp()
		local mesCnlRtnReg =registerCreate("mesCnlRtn")
		if registerGetInteger(mesCnlRtnReg,"mesCnlRtnFocus") then
			SetSpriteFocus(registerGetInteger(mesCnlRtnReg,"mesCnlRtnFocus"))
		end
		
	end 
	--[[	用户选择地址薄	]]--
	if spritename == "addrlist_tongxunlu" then
		OpenContactDialog("OnContactDialog", "AddressBox")
	end
end

function editOnTextChanged(sprite) 
	ReleaseSpriteCapture(sprite)	    
  local text = GetSpriteText(sprite)  
  local reg = registerCreate("messagepannel")   
  local rootSprite = registerGetInteger(reg, "root")
  SetSpriteCapture(rootSprite)
  local sendSprite = FindChildSprite(rootSprite,"scapegoat")
  SetSpriteFocus(sendSprite)
  SetSpriteProperty(FindChildSprite(GetSpriteParent(sprite),"scrolltext"),"text",text)
end

--@function OnContactDialog
--@brief 分享中地址簿按钮中的响应函数
function OnContactDialog(result, contact)
	--[[	获取根节点	]]--
	local reg = registerCreate("messagepannel")
	local root = registerGetInteger(reg, "root")
	local sprite = FindChildSprite(root , "testEdit")
	--local scrollsprite = FindChildSprite(root , "scrolltext")
	SetSpriteProperty(sprite,"text","")
	if result == 1 then
		WriteLogs("OK Pressed [" .. table.maxn(contact) .. "]")
		for n = 0, table.maxn(contact) do
			local text = GetSpriteText(sprite)
			SetSpriteProperty(sprite,"text",text..contact[n].tel..",")
		end
	else
		WriteLogs("Cancel Pressed")
	end
end

--@function OnContactDialog
--@brief textboard按钮事件
function textboardOnSelect(sprite)
	local reg = registerCreate("messagepannel")
	local spritename = GetSpriteName(sprite)
	if spritename == "whole" then
		--[[	返回上一个页面	]]--
		local pannelSprite = GetCurScene()
		local returnpath = registerGetString(reg, "returnpath")
		--返回的时候清空数据
		FreeScene(pannelSprite)
		Go2Scene(returnpath)	
	end
end

--@function SetAddrFocus
--@brief textedit事件
function SetAddrFocus(sprite)
	local parent = GetSpriteParent(sprite)
	local addrbtn = FindChildSprite(parent,"addrlist")
	--SetSpriteFocus(addrbtn)
end

--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	if message == 100 then
		exitLoading()
		json_return = OnVoteDecode()
		if json_return then
			local reg = registerCreate("messagepannel")
			local root = registerGetInteger(reg, "root")
			--[[	改变消息框中的标题文字	]]--
			local panneltitle = FindChildSprite(root, "panelarea-title")
			SetSpriteProperty(panneltitle,"text","您的评价已经成功")
			local panneltitle = FindChildSprite(root, "panelarea-title2")
			SetSpriteProperty(panneltitle,"text","您的评价已经成功")
			
			local good = FindChildSprite(root,"voteRltRight")
			local bad = FindChildSprite(root,"voteRltWrong")
			SetSpriteProperty(good,"text",json_return.voteId[0].count)
			SetSpriteProperty(bad,"text",json_return.voteId[1].count)
			
			
			local vote = FindChildSprite(root,"vote")
			SetSpriteRect(vote,240,0,240,100)
			local result = FindChildSprite(root,"result")
			SetSpriteRect(result,0,0,240,100)
			--标志位/变量
			
			local returnpathname = registerGetString(reg, "returnpathname")
			local reg_v = registerCreate(returnpathname)
			local root_v = registerGetInteger(reg_v, "root")
			local MessagePannel = FindChildSprite(root_v, "MessagePannel")
			SetSpriteCapture(MessagePannel)
			DeleteCacheFile()
			local messageReturnReg = registerCreate("messagepannel")
			local messageRoot = registerGetInteger(messageReturnReg,"root")
			messageReturn = FindChildSprite(messageRoot,"messagepanel-boardup")
			SetSpriteFocus(messageReturn)
		else
			require("module.dialog.useDialog")
			local reg = registerCreate("messagepannel")
			local returnpath = registerGetString(reg, "returnpath")
			setDialogParam("提示", "获取网络数据失败", "BT_OK", returnpath, returnpath, GetCurScene())
			Go2Scene(sceneDialog)
			local reg = registerCreate("messagepannel")
			local root = registerGetInteger(reg, "root")
			local result = FindChildSprite(root,"result")
			ReleaseSpriteCapture(result)
			
			local returnpathname = registerGetString(reg, "returnpathname")
			local reg_v = registerCreate(returnpathname)
			local root = registerGetInteger(reg_v, "root")
			local MessagePannel = FindChildSprite(root,"MessagePannel")
			RemoveChildSprite(root, MessagePannel)
			FreeSprite(MessagePannel)
		end
	elseif message == 101 then
		exitLoading()
		json_return = OnShareDecode()
		if json_return then 
			local reg = registerCreate("messagepannel")
			local root = registerGetInteger(reg, "root")
			SetSpriteProperty(FindChildSprite(root,"panelarea-title"),"text","提示")
			SetSpriteProperty(FindChildSprite(root,"panelarea-title2"),"text","提示")
			local des = FindChildSprite(root,"resultdes")
			if json_return.desc then 
				SetSpriteProperty(des,"text",json_return.desc)
				-----------------------ksw----------------------------
				local messageReturnReg = registerCreate("messagepannel")
				local messageRoot = registerGetInteger(messageReturnReg,"root")
				messageReturn = FindChildSprite(messageRoot,"messagepanel-boardup")
				SetSpriteFocus(messageReturn)
				--------------------------------------------------------------------
			end
			local share = FindChildSprite(root,"share")
			SetSpriteRect(share,240,0,240,100)
			local result = FindChildSprite(root,"result")
			SetSpriteRect(result,0,0,240,100)
			
			local returnpathname = registerGetString(reg, "returnpathname")
			local reg_v = registerCreate(returnpathname)
			local root_v = registerGetInteger(reg_v, "root")
			local MessagePannel = FindChildSprite(root_v, "MessagePannel")
			SetSpriteCapture(MessagePannel)
		else
			require("module.dialog.useDialog")
			local reg = registerCreate("messagepannel")
			local returnpath = registerGetString(reg, "returnpath")
			setDialogParam("提示", "获取网络数据失败", "BT_OK", returnpath, returnpath, GetCurScene())
			Go2Scene(sceneDialog)
			local reg = registerCreate("messagepannel")
			local root = registerGetInteger(reg, "root")
			local result = FindChildSprite(root,"result")
			ReleaseSpriteCapture(result)
		end
	elseif message > 32768 then 
		exitLoading()
		require("module.dialog.useDialog")
		local reg = registerCreate("messagepannel")
		local returnpath = registerGetString(reg, "returnpath")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", returnpath, returnpath, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function messageBoardOnMouseUp()
	local reg_m = registerCreate("messagepannel")
	local returnpathname = registerGetString(reg_m, "returnpathname")
	local reg = registerCreate(returnpathname) 
	local root = registerGetInteger(reg, "root") 
	local myshadow = FindChildSprite(root,"myshadow")
	SetSpriteVisible(myshadow,0)
	local MessagePannel = FindChildSprite(root, "MessagePannel") 
	if MessagePannel == 0 or MessagePannel == nil then 
		MessagePannel = CreateSprite("node", root) 
		SetSpriteProperty(MessagePannel,"name","MessagePannel") 
	end
	ReleaseSpriteCapture(MessagePannel)
	RemoveChildSprite(root, MessagePannel, 1)
	--local TuchReg=registerCreate("PopMenuHide")
	--local ToDigFocus = registerGetInteger(TuchReg,"sencePreFocus")
	--SetSpriteFocus(ToDigFocus)
	--SetFocus2Latest()
end
function messagepanelReturn(sprite,keyCode)
	messageBoardOnMouseUp()
	local ToMesReg = registerCreate("ToMesReg")
	local MesSpriteFocus =registerGetInteger(ToMesReg,"ToMesFocus")
	if MesSpriteFocus then
		SetSpriteFocus(MesSpriteFocus)
	end
end

function TextOnSelected()
	local reg = registerCreate("messagepannel")
	local root = registerGetInteger(reg, "root")
	local sprite = FindChildSprite(root , "scrolltext")
	SetSpriteProperty(sprite,"text","")
	local edit = FindChildSprite(root, "testEdit")
	if GetSpriteText(edit) == "好友手机号码" then
		SetSpriteProperty(edit,"text","")
	end
	local reg = registerCreate("messagepannel")   
	local rootSprite = registerGetInteger(reg, "root")
	SetSpriteCapture(rootSprite)
end

function voteOnKeyUp(sprite,keyCode)
	require "module.keyCode.keyCode"
	WriteLogs("voteOnKeyUp")
	if keyCode == ApKeyCode_Enter then
		WriteLogs("in the Killing")
		--KillSpriteFocus(sprite)
		return 0
	end
	if keyCode == ApKeyCode_F2 then
	
		messageBoardOnMouseUp()
		local ToMesReg = registerCreate("ToMesReg")
		local MesSpriteFocus =registerGetInteger(ToMesReg,"ToMesFocus")
		if MesSpriteFocus then
			SetSpriteFocus(MesSpriteFocus)
		end
	end
	local spritename = GetSpriteName(sprite)
	--[[	获取根节点	]]--
	local reg = registerCreate("messagepannel")
	local root = registerGetInteger(reg, "root")
	--[[	焦点右移动	]]--
	if spritename == "excelent" and keyCode == ApKeyCode_Right then
		local notsatSpriteName = FindChildSprite(root,"notsatisfied")
		SetSpriteFocus(notsatSpriteName)
	end
	--[[	焦点左移动	]]--
	if spritename == "notsatisfied" and keyCode == ApKeyCode_Left then
		local notsatSpriteName = FindChildSprite(root,"excelent")
		SetSpriteFocus(notsatSpriteName)
	end
end

function ShareOnKeyUp(sprite,keyCode)
	WriteLogs("in ShareOnKeyUp")
	require "module.keyCode.keyCode"
	local spritename = GetSpriteName(sprite)
	--[[	获取根节点	]]--
	local reg = registerCreate("messagepannel")
	local root = registerGetInteger(reg, "root")
		--[[	返回	]]--
	--[[	默认焦点的右移、下移和确定	]]--
	if  spritename == "testEdit" then
		WriteLogs("in testEdit")
		if keyCode == ApKeyCode_Right then
			WriteLogs("in testEdit")
			local cancelSpriteName = FindChildSprite(root,"addrlist_tongxunlu")
			WriteLogs("cancelSpriteName="..cancelSpriteName)
			SetSpriteFocus(cancelSpriteName)
		end
		if keyCode == ApKeyCode_Down then
			local addrlistSpriteName = FindChildSprite(root,"send")
			SetSpriteFocus(addrlistSpriteName)
		end
	end
	if  spritename == "addrlist_tongxunlu" then
		if keyCode == ApKeyCode_Left then
			local addrlistSpriteName = FindChildSprite(root,"testEdit")
			SetSpriteFocus(addrlistSpriteName)
		end
		if keyCode == ApKeyCode_Down then
			local cancelSpriteName = FindChildSprite(root,"cancel")
			SetSpriteFocus(cancelSpriteName)
		end
	end
	if  spritename == "send" then
		if keyCode == ApKeyCode_Right then
			local cancelSpriteName = FindChildSprite(root,"cancel")
			SetSpriteFocus(cancelSpriteName)
		end
		if keyCode == ApKeyCode_Up then
			local addrlistSpriteName = FindChildSprite(root,"testEdit")
			SetSpriteFocus(addrlistSpriteName)
		end
	end
	if  spritename == "cancel" then
		if keyCode == ApKeyCode_Left then
			local sendSpriteName = FindChildSprite(root,"send")
			SetSpriteFocus(sendSpriteName)
		end
		if keyCode == ApKeyCode_Up then
			local addrlistSpriteName = FindChildSprite(root,"addrlist_tongxunlu")
			SetSpriteFocus(addrlistSpriteName)
		end
	end
	if keyCode == ApKeyCode_Enter then
			return 0
	end
	if keyCode == ApKeyCode_F2  then
		WriteLogs("messagepanel  ShareOnKeyUp ApKeyCode_F2")
		messageBoardOnMouseUp()
		--local menuVolumeReg = registerCreate("menuprograminfo_volume")
		--SetSpriteFocus(registerGetInteger(menuVolumeReg,"lastFocus"))
		-------------------------------------------------------------
		--local recommendReg = registerCreate("recommend")
		--SetSpriteFocus(registerGetInteger(recommendReg,"lastFocus"))
		local ToMesReg = registerCreate("ToMesReg")
		local MesSpriteFocus =registerGetInteger(ToMesReg,"ToMesFocus")
		if MesSpriteFocus then
			SetSpriteFocus(MesSpriteFocus)
		end
	end
	--if desReturnFlag == 1 then		
	--end
	return 0
end
	
	

	