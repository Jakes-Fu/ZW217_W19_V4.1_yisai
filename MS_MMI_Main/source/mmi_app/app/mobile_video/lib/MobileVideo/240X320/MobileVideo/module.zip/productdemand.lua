--
productDemand_WholeStarWidth = 16
productDemand_HalfStarWidth = 6
productDemand_StarHeight = 12
productDemand_PageItemCount = 6

require "module.product"
require "module.keyCode.keyCode"
require "module.Loading.useLoading"

function setChannelLabel(sprite)
	--[[
	local spriteLabel = FindChildSprite(sprite, "product-channel-label")
	if spriteLabel and spriteLabel ~= 0 then
		SetSpriteProperty(spriteLabel, "text", jsonChannel.imgListNavi[0].desc)
		SetSpriteVisible(spriteLabel, 1)
	end
	]]--
	local spriteListItem = FindChildSprite(sprite, "product-live-channel-day")
	if spriteListItem and spriteListItem ~= 0 then
		SetSpriteVisible(spriteListItem, 0)
		SetSpriteEnable(spriteListItem, 0)
	end
end


function OnLoadListItem(spriteList, spriteItem, index)
	SetSpriteRect(spriteItem,0,0,0,0)
	SetSpriteProperty(spriteItem, "name", "video-sprite-"..index)
	local productDemandItemButton = FindChildSprite(spriteItem,"productDemandItemButton")
	local productLabelItemButton = FindChildSprite(spriteItem,"productLabelItemButton")
	if jsonChannel.programList[index].category == "5" then
		SetSpriteVisible(productDemandItemButton,0)
		SetSpriteVisible(productLabelItemButton,1)
		local ItemButtonSprite = FindChildSprite(productLabelItemButton,"list-item-button")
		SetSpriteProperty(ItemButtonSprite, "OnKeyUp","productDemandItemKeyUp")
		SetSpriteProperty(ItemButtonSprite, "name",string.format("item-button-%d",index))
		local titleSprite = FindChildSprite(productLabelItemButton, "video-title")
		SetSpriteProperty(titleSprite, "text", jsonChannel.programList[index].contentName)
		local titleSprite2 = FindChildSprite(productLabelItemButton, "video-title2")
		SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[index].contentName)
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"playbutton1"), 0)
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"list-video-caption-stars"),0)
	else
		local ItemButtonSprite = FindChildSprite(productDemandItemButton,"list-item-button")
		SetSpriteProperty(ItemButtonSprite, "OnKeyUp","productDemandItemKeyUp")
		SetSpriteProperty(ItemButtonSprite, "name",string.format("item-button-%d",index))
		local titleSprite = FindChildSprite(productDemandItemButton, "video-title")
		SetSpriteProperty(titleSprite, "text", jsonChannel.programList[index].contentName)
		local titleSprite2 = FindChildSprite(productDemandItemButton, "video-title2")
		SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[index].contentName)
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"playbutton"), 0)
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"descbutton"),0) 
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"list-video-caption-stars"),0) 
	end
	return 1
end
function createDemandVideoList(sprite)
	local spriteList = FindChildSprite(sprite, "product-programgroup-list")
	SpriteList_SetStartItem(spriteList, 0)
	local nMax = math.min(#jsonChannel.programList, 6)
	if jsonChannel.programList then
		SpriteList_LoadListItem(spriteList, "MODULE:\\product\\product_demanditem.xml", nMax, "OnLoadListItem")
	end
	resetDemandVideoItem(spriteList, 0, 0)
	if jsonChannel.programList~=nil then	
		local defaultFocus = FindChildSprite( SpriteList_GetListItem(spriteList,0) ,"item-button-0")
		SetSpriteFocus(defaultFocus)
		saveTouchFocus(defaultFocus)
	else
		local defaultFocus = FindChildSprite(GetRootSprite(spriteList),"defaultButton")
		SetSpriteFocus(defaultFocus)
		saveTouchFocus(defaultFocus)
	end
	
	SetSpriteRect(spriteList,5,4,213,163)
	SetSpriteProperty(spriteList,"line","6")
	SetSpriteProperty(spriteList,"start","0")
	SpriteList_Adjust(spriteList)
	if #jsonChannel.programList + 1 > 6 then
		SetTimer(2,1,"createDemandVideoList2")
	end
end

function OnLoadListItem2(spriteList, spriteItem, index)
	local index = index+nStart
	SetSpriteRect(spriteItem,0,0,0,0)
	SetSpriteProperty(spriteItem, "name", "video-sprite-"..index)
	local productDemandItemButton = FindChildSprite(spriteItem,"productDemandItemButton")
	local productLabelItemButton = FindChildSprite(spriteItem,"productLabelItemButton")
	if jsonChannel.programList[index].category == "5" then
		SetSpriteVisible(productDemandItemButton,0)
		SetSpriteVisible(productLabelItemButton,1)
		local ItemButtonSprite = FindChildSprite(productLabelItemButton,"list-item-button")
		SetSpriteProperty(ItemButtonSprite, "OnKeyUp","productDemandItemKeyUp")
		SetSpriteProperty(ItemButtonSprite, "name",string.format("item-button-%d",index))
		local titleSprite = FindChildSprite(productLabelItemButton, "video-title")
		SetSpriteProperty(titleSprite, "text", jsonChannel.programList[index].contentName)
		local titleSprite2 = FindChildSprite(productLabelItemButton, "video-title2")
		SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[index].contentName)
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"playbutton1"), 0)
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"list-video-caption-stars"),0)
	else
		local ItemButtonSprite = FindChildSprite(productDemandItemButton,"list-item-button")
		SetSpriteProperty(ItemButtonSprite, "OnKeyUp","productDemandItemKeyUp")
		SetSpriteProperty(ItemButtonSprite, "name",string.format("item-button-%d",index))
		local titleSprite = FindChildSprite(productDemandItemButton, "video-title")
		SetSpriteProperty(titleSprite, "text", jsonChannel.programList[index].contentName)
		local titleSprite2 = FindChildSprite(productDemandItemButton, "video-title2")
		SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[index].contentName)
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"playbutton"), 0)
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"descbutton"),0) 
		SetSpriteVisible(FindChildSprite(ItemButtonSprite,"list-video-caption-stars"),0) 
	end
	return 1
end
function createDemandVideoList2()
	WriteLogs("createDemandVideoList2 begin")
	local reg = registerCreate("product")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "product-programgroup-list")
	SpriteList_SetStartItem(spriteList, 0)
	if jsonChannel.programList then
		nStart = 6
		local nMax = #jsonChannel.programList
		SpriteList_LoadListItem(spriteList, "MODULE:\\product\\product_demanditem.xml", nMax-nStart+1, "OnLoadListItem2")
	end	
	SpriteList_Adjust(spriteList)
	local rightArrow = FindChildSprite(sprite,"rightArrow")
	SetSpriteEnable(rightArrow,1)
end

function createLabelVideoList(sprite)
	local spriteList = FindChildSprite(sprite, "product-programgroup-list")
	SpriteList_SetStartItem(spriteList, 0)
	if jsonChannel.programList then
		local nMax = #jsonChannel.programList
		local xmlNode_label=xmlLoadFile("MODULE:\\product\\product_labelitem.xml")
		local xmlNode_demand=xmlLoadFile("MODULE:\\product\\product_demanditem.xml")
		for i=0, nMax do
			local productVideoSprite = CreateSprite("listitem")
			if jsonChannel.programList[i].category == "5" then
				LoadSpriteFromNode(productVideoSprite, xmlNode_label)
			elseif jsonChannel.programList[i].category == "1" then
				LoadSpriteFromNode(productVideoSprite, xmlNode_demand)
			end
			SetSpriteProperty(productVideoSprite, "name", "video-sprite-"..i)
			
			local titleSprite = FindChildSprite(productVideoSprite, "video-title")
			SetSpriteProperty(titleSprite, "text", jsonChannel.programList[i].contentName)
			local titleSprite2 = FindChildSprite(productVideoSprite, "video-title2")
			SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[i].contentName)	
			
			AddChildSprite(spriteList, productVideoSprite)
			SpriteList_AddListItem(spriteList, productVideoSprite)
		end
		xmlRelease(xmlNode_label)
		xmlRelease(xmlNode_demand)
	end
	resetDemandVideoItem(spriteList, 0, 0)
	local first = FindChildSprite(spriteList,"video-sprite-0")
	local firstsprite = FindChildSprite(first,"list-item-button")
	SetSpriteFocus(firstsprite)
	saveTouchFocus(firstsprite)
end

function createMagzineList(sprite)
	local spriteList = FindChildSprite(sprite, "product-programgroup-list")
	SpriteList_SetStartItem(spriteList, 0)
	if jsonChannel.programList then
		local nMax = #jsonChannel.programList
		local xmlNode_magzine=xmlLoadFile("MODULE:\\product\\product_magzineitem.xml")
		for i=0, nMax do
			local productVideoSprite = CreateSprite("listitem")
			if jsonChannel.programList[i].category == "5" then
				LoadSpriteFromNode(productVideoSprite, xmlNode_magzine)
			elseif jsonChannel.programList[i].category == "1" then
				LoadSpriteFromNode(productVideoSprite, xmlNode_magzine)
			end
			SetSpriteProperty(productVideoSprite, "name", "video-sprite-"..i)
			
			local titleSprite = FindChildSprite(productVideoSprite, "video-title")
			SetSpriteProperty(titleSprite, "text", jsonChannel.programList[i].contentName)
			local titleSprite2 = FindChildSprite(productVideoSprite, "video-title2")
			SetSpriteProperty(titleSprite2, "text", jsonChannel.programList[i].contentName)	
			
			AddChildSprite(spriteList, productVideoSprite)
			SpriteList_AddListItem(spriteList, productVideoSprite)
		end
		xmlRelease(xmlNode_magzine)
	end
	resetDemandVideoItem(spriteList, 0, 0)
	local first = FindChildSprite(spriteList,"video-sprite-0")
	local firstsprite = FindChildSprite(first,"list-item-button")
	SetSpriteFocus(firstsprite)
	saveTouchFocus(firstsprite)
end

function resetDemandVideoItem(spriteList, topIndex, selectIndex)
	local top = 0
	if jsonChannel.programList then
	local nMax = math.min(#jsonChannel.programList, 6)
		for index = topIndex, topIndex + nMax do
			local productVideoSprite = SpriteList_GetListItem(spriteList, index)
			local spriteRectNode = FindChildSprite(productVideoSprite, "select-display")
			local spriteRectNode2 = FindChildSprite(productVideoSprite, "unselect-display")
			local buttonVideoItemSprite = FindChildSprite(productVideoSprite, "list-item-button")
			if index == selectIndex then
				local l,t,w,h = GetSpriteRect(spriteRectNode)
				SetSpriteRect(productVideoSprite, 0, top, w, h)
				SetSpriteRect(buttonVideoItemSprite, 0, 0, w, h)
				top = h	
				SetSpriteVisible(spriteRectNode, 1)
				SetSpriteEnable(spriteRectNode, 1)
				
				--begin [、Jone]
				--desc:此段代码用于修正当点击列表中的某项时, 移动键盘列表不能获得焦点的BUG
				local spriteToPlayBtn = FindChildSprite(spriteRectNode, "playbutton");
				SetSpriteFocus(spriteToPlayBtn)
				saveTouchFocus(spriteToPlayBtn)
				--end
				
				SetSpriteVisible(spriteRectNode2, 0)
				SetSpriteEnable(spriteRectNode2, 0)
			else
				local l,t,w,h = GetSpriteRect(spriteRectNode2)
				SetSpriteRect(productVideoSprite, 0, top, w, h)
				SetSpriteRect(buttonVideoItemSprite, 0, 0, w, h)
				top = h + top
				SetSpriteVisible(spriteRectNode, 0)
				SetSpriteEnable(spriteRectNode, 0)
				
				SetSpriteEnable(spriteRectNode2, 1)
				SetSpriteVisible(spriteRectNode2, 1)
			end
		end
		SpriteList_Adjust(spriteList)
	end
end

function videoDemandListItemButtonOnSetFocus(spriteButton, loser, leaveCount)
	local spriteItem = GetSpriteParent(spriteButton)
	local nSelectIndex = SpriteListItem_GetIndex(spriteItem)
	local spriteList = GetSpriteParent(spriteItem)
	local start = SpriteList_GetStartItem(spriteList)
	if jsonChannel.programList[nSelectIndex].starLevel then
		local starlevel = FindChildSprite(spriteButton , "starlevel")
		local width1 = math.floor(jsonChannel.programList[nSelectIndex].starLevel)*productDemand_WholeStarWidth
		local width2 = (jsonChannel.programList[nSelectIndex].starLevel - math.floor(jsonChannel.programList[nSelectIndex].starLevel))*productDemand_HalfStarWidth
		SetSpriteRect(starlevel,0,0,width1+width2,productDemand_StarHeight)
	end
	resetDemandVideoItem(spriteList, start, nSelectIndex)
end

function playButonOnSetFocus(spriteListItem, loser, leaveCount)
  WriteLogs("点播: playButonOnSetFocus selected!");
	local imgSelSprite = FindChildSprite(spriteListItem, "selectPlayButton")
	SetSpriteVisible(imgSelSprite, 1)
	SetSpriteEnable(imgSelSprite, 1)
	local imgSprite = FindChildSprite(spriteListItem, "unselectPlayButton")
	SetSpriteVisible(imgSprite, 0)
	SetSpriteEnable(imgSprite, 0)
end

function playButonOnLostFocus(spriteListItem, receiver, leaveCount)
  WriteLogs("点播: playButonOnLostFocus selected!");
	local imgSelSprite = FindChildSprite(spriteListItem, "selectPlayButton")
	SetSpriteVisible(imgSelSprite, 0)
	SetSpriteEnable(imgSelSprite, 0)
	local imgSprite = FindChildSprite(spriteListItem, "unselectPlayButton")
	SetSpriteVisible(imgSprite, 1)
	SetSpriteEnable(imgSprite, 1)
end

function descButtonOnSetFocus(spriteListItem, loser, leaveCount)
  WriteLogs("点播: descButtonOnSetFocus selected!");
	local imgSelSprite = FindChildSprite(spriteListItem, "selectDescButton")
	SetSpriteVisible(imgSelSprite, 1)
	SetSpriteEnable(imgSelSprite, 1)
	local imgSprite = FindChildSprite(spriteListItem, "unselectDescButton")
	SetSpriteVisible(imgSprite, 0)
	SetSpriteEnable(imgSprite, 0)
end

function descButtonOnLostFocus(spriteListItem, receiver, leaveCount)
  WriteLogs("点播: descButtonOnLostFocus selected!");
	local imgSelSprite = FindChildSprite(spriteListItem, "selectDescButton")
	SetSpriteVisible(imgSelSprite, 0)
	SetSpriteEnable(imgSelSprite, 0)
	local imgSprite = FindChildSprite(spriteListItem, "unselectDescButton")
	SetSpriteVisible(imgSprite, 1)
	SetSpriteEnable(imgSprite, 1)
end

function listItemDemandOnSelect(sprite)
  --<modified author=zhouzhicheng reason=需要找到真正的那个List  date=2010/06/16 15:40>
  WriteLogs("listItemDemandOnSelect")
  WriteLogs("name="..GetSpriteName(sprite))
	local spriteListItem = GetSpriteParent(sprite)
	local buttonList = GetSpriteParent(spriteListItem)
	local selectDisplay = GetSpriteParent(buttonList)
	local listItemButton = GetSpriteParent(selectDisplay)
	local demandListitem = GetSpriteParent(GetSpriteParent(listItemButton))
	local index = SpriteListItem_GetIndex( demandListitem )

	if GetSpriteName(sprite) == "playbutton" then  --播放
		require "module.protocol.protocol_videoloading"
		RequestVideo(103, jsonChannel.programList[index].playUrl, jsonChannel.programList[index].urlPath, jsonChannel.programList[index].contentName ,"demand")
		require "module.protocol.protocol_infovolume"
		RequestVolume(999, jsonChannel.programList[index].urlPath)
		local reg = registerCreate("product")
		registerSetString(reg,"playurl",jsonChannel.programList[index].playUrl)
		registerSetString(reg,"contentid",jsonChannel.programList[index].contentId)
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
	elseif GetSpriteName(sprite) == "descbutton" then
		--[[  内容集、列表式以及单集详情的判断 之后可能在此修改  ]]--
		if jsonChannel.programList[index].category == "5" and jsonChannel.programList[index].formType == "1" then 
			require("module.protocol.protocol_infolabel")
			local reg = registerCreate("download_select")
			registerSetString(reg,"filepath",jsonChannel.programList[index].urlPath)
			Requestlabel(105, jsonChannel.programList[index].urlPath)
		elseif jsonChannel.programList[index].category == "5" and jsonChannel.programList[index].formType == "2" then
			require("module.protocol.protocol_infolist")
			local reg = registerCreate("download_select")
			registerSetString(reg,"filepath",jsonChannel.programList[index].urlPath)
			WriteLogs("filepath---"..jsonChannel.programList[index].urlPath)			
			RequestList(106, jsonChannel.programList[index].urlPath)
		else
			require("module.protocol.protocol_infovolume")
			RequestVolume(102, jsonChannel.programList[index].urlPath)
		end
		
		local reg = registerCreate("product")
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
	end
	local reg_r = registerCreate("recommend")   
	registerSetInteger(reg_r, "isDownloadDisable", 0)
end

function listItemLabelOnSelect(sprite)
	local selectDisplay = GetSpriteParent(sprite)
	local listItemButton = GetSpriteParent(selectDisplay)
	local demandListitem = GetSpriteParent(GetSpriteParent(listItemButton))
	local index = SpriteListItem_GetIndex( demandListitem )
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	--[[  内容集、列表式以及单集详情的判断 之后可能在此修改  ]]--
	if jsonChannel.programList[index].category == "5" and jsonChannel.programList[index].formType == "1" then 
		require("module.protocol.protocol_infolabel")
		local reg = registerCreate("download_select")
		registerSetString(reg,"filepath",jsonChannel.programList[index].urlPath)
		Requestlabel(105, jsonChannel.programList[index].urlPath)
	elseif jsonChannel.programList[index].category == "5" and jsonChannel.programList[index].formType == "2" then
		require("module.protocol.protocol_infolist")
		local reg = registerCreate("download_select")
		registerSetString(reg,"filepath",jsonChannel.programList[index].urlPath)
		WriteLogs("filepath---"..jsonChannel.programList[index].urlPath)		
		RequestList(106, jsonChannel.programList[index].urlPath)
	end
	
	local reg = registerCreate("product")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root ,"loadarea")
	enterLoading(loadarea)
end

--begin [、Jone]
--desc:响应按下左右按键的事件函数
function PressLR_btn(sprite, keyCode)
	if keyCode >= 7 and keyCode <= 8 then
		local spriteItem = SpriteList_GetListItem(FindChildSprite(GetRootSprite(sprite), "product-channel-list"), keyCode - 6)
		local spriteItemBtn = FindChildSprite(spriteItem, string.format("channel-button-%d", SpriteListItem_GetIndex(spriteItem)))
		ChangeChannelItem(spriteItemBtn)
	end
end

--[[  added by：yaoxiangyin @2010.08.23  ]]--
function productDemandItemKeyUp(sprite,keyCode)
	local productReg = registerCreate("product")
	registerSetInteger(productReg,"productDemand",sprite)
	registerSetInteger(productReg, "lastFocusFlag",1)
	--[[  modified by：ksw @2010.08.23  ]]--
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local ItemList={}
	WriteLogs("KeyUp message Received, code :"..keyCode)
	
	--product-programgroup-list区域内操作
	local spriteList = FindChildSprite(GetRootSprite(sprite),"product-programgroup-list")															--product-programgroup-list节点
	local spriteRightArrow = FindChildSprite(GetRootSprite(spriteList),"rightArrow")				--与product-programgroup-list节点平级的向右翻页按钮
	local spriteLeftArrow = FindChildSprite(GetRootSprite(spriteList), "leftArrow")					--与product-programgroup-list节点平级的向左翻页按钮
	
	local spriteChannelList = FindChildSprite(GetRootSprite(sprite),"product-channel-list")	--product-channel-list节点
	local channelCount = SpriteList_GetListItemCount(spriteChannelList)
	local channelFocusNum
	for i=0,channelCount-1 do
		local testChannelSprite=SpriteList_GetListItem(spriteChannelList,i)
		x,y,width,height=GetSpriteRect(testChannelSprite)
		if width==62 then
			channelFocusNum=i
			break
		end
	end
	local preIndex
	local nextIndex
	if channelFocusNum==0 then
		preIndex=1
		nextIndex=2
	elseif channelFocusNum==1 then
		preIndex=3
		nextIndex=0
	elseif channelFocusNum==2 then
		preIndex=0
		nextIndex=4
	elseif channelFocusNum==3 then
		preIndex=4
		nextIndex=1
	elseif channelFocusNum==4 then        
		preIndex=2
		nextIndex=3
	end
	
	local itemName = GetSpriteName(sprite)
	local itemFocusNum = 0
	local itemCount=SpriteList_GetListItemCount(spriteList)
	local pageNum=math.ceil(itemCount/6) --六条记录一页，共几页
	
	--为表ItemList赋值
	for j=0,itemCount-1 do
		ItemList[j]="item-button-"..j
	end
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if ItemList[i]==itemName then
	    itemFocusNum=i
	  end
	end
	
	local pageIndex=math.floor(itemFocusNum/6) --当前页码，从0开始
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	
	if keyCode== ApKeyCode_Down then
		if  itemFocusNum>=pageIndex*6 and itemFocusNum<pageIndex*6+5 then
			local setFocusSprite=FindChildSprite(spriteList,ItemList[itemFocusNum+1])
			SetSpriteFocus(setFocusSprite)
			saveTouchFocus(setFocusSprite)
			SetSpriteVisible(FindChildSprite(setFocusSprite,"select-display"),1)
			SetSpriteEnable(FindChildSprite(setFocusSprite,"select-display"),1)
			SetSpriteVisible(FindChildSprite(setFocusSprite,"unselect-display"),0)
			SetSpriteEnable(FindChildSprite(setFocusSprite,"unselect-display"),0)
			SetSpriteProperty(FindChildSprite(setFocusSprite,"boardImage"),"src","file:///image/product/jiaodian_bg.PNG")
		end
	elseif keyCode== ApKeyCode_Up then
		if 	itemFocusNum>pageIndex*6 and itemFocusNum<=pageIndex*6+5 then
			local setFocusSprite=FindChildSprite(spriteList,ItemList[itemFocusNum-1])
			SetSpriteFocus(setFocusSprite)
			saveTouchFocus(setFocusSprite)
			SetSpriteVisible(FindChildSprite(setFocusSprite,"select-display"),1)
			SetSpriteEnable(FindChildSprite(setFocusSprite,"select-display"),1)
			SetSpriteVisible(FindChildSprite(setFocusSprite,"unselect-display"),0)
			SetSpriteEnable(FindChildSprite(setFocusSprite,"unselect-display"),0)
			SetSpriteProperty(FindChildSprite(setFocusSprite,"boardImage"),"src","file:///image/product/jiaodian_bg.PNG")
		end
	elseif keyCode== ApKeyCode_Enter then
			SetSpriteRect(GetSpriteParent(GetSpriteParent(sprite)),0,0,220,39)
			SetSpriteRect(FindChildSprite(sprite,"select-display"),0,0,220,39)
			SetSpriteRect(FindChildSprite(sprite,"boardImage"),0,0,220,39)
			SetSpriteProperty(FindChildSprite(sprite,"boardImage"),"src","file:///image/product/jiaodian_bg2.png")
			SetSpriteVisible(FindChildSprite(sprite,"list-video-caption-stars"),1)
			if jsonChannel.programList[itemFocusNum].category == "5" then
				SetSpriteVisible(FindChildSprite(sprite,"playbutton1"), 1)
				SetSpriteFocus(FindChildSprite(sprite,"playbutton1"))
				saveTouchFocus(FindChildSprite(sprite,"playbutton1"))
			else
				SetSpriteVisible(FindChildSprite(sprite,"playbutton"), 1)
				SetSpriteVisible(FindChildSprite(sprite,"descbutton"),1)
				SetSpriteFocus(FindChildSprite(sprite,"playbutton"))
				saveTouchFocus(FindChildSprite(sprite,"playbutton"))
			end
		SpriteList_Adjust(spriteList)
	elseif keyCode==ApKeyCode_CharA and pageIndex>0 then	--*号键
			listUpButtonOnSelect(spriteLeftArrow)
	elseif keyCode==ApKeyCode_CharB and pageIndex<pageNum-1 then	--#号键
			listDownButtonOnSelect(spriteRightArrow)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_Right and LoadingFlag() then
		if dnr == nil then
			dnr = 1
			local nextChannelButtonSprite=FindChildSprite(SpriteList_GetListItem(spriteChannelList,nextIndex),"channel-button-"..nextIndex)
			channelListiItemOnSelect(nextChannelButtonSprite)
			SetTimer(1,2500,"changeDnr")
		end
	elseif keyCode == ApKeyCode_Left and LoadingFlag() then
		if dnr == nil then
			dnr = 1
			local preChannelButtonSprite=FindChildSprite(SpriteList_GetListItem(spriteChannelList,preIndex),"channel-button-"..preIndex) 
			channelListiItemOnSelect(preChannelButtonSprite)
			SetTimer(1,2500,"changeDnr")
		end
	end
end

function changeDnr()
	dnr = nil
end

function listKeyUp_Demand(sprite,keyCode)
	local productReg = registerCreate("product")
	registerSetInteger(productReg,"productDemand",sprite)
	registerSetInteger(productReg, "lastFocusFlag",1)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local ItemList={}
	local spriteList =FindChildSprite(GetRootSprite(sprite),"product-programgroup-list") --product-programgroup-list节点
	local spriteRightArrow=FindChildSprite(GetRootSprite(spriteList),"rightArrow")   --与product-programgroup-list节点平级的向右翻页按钮
	local spriteLeftArrow=FindChildSprite(GetRootSprite(spriteList), "leftArrow")     --与product-programgroup-list节点平级的向左翻页按钮
	
	local spriteChannelList=FindChildSprite(GetRootSprite(sprite),"product-channel-list")  --product-channel-list节点
	local channelCount=SpriteList_GetListItemCount(spriteChannelList)
	local channelFocusNum
	for i=0,channelCount-1 do
		local testChannelSprite=SpriteList_GetListItem(spriteChannelList,i)
		x,y,width,height=GetSpriteRect(testChannelSprite)
		if width==62 then
			channelFocusNum=i
			break
		end
	end
	
	local preIndex
	local nextIndex
	if channelFocusNum==0 then
		preIndex=1
		nextIndex=2
	elseif channelFocusNum==1 then
		preIndex=3
		nextIndex=0
	elseif channelFocusNum==2 then
		preIndex=0
		nextIndex=4
	elseif channelFocusNum==3 then
		preIndex=4
		nextIndex=1
	elseif channelFocusNum==4 then        
		preIndex=2
		nextIndex=3
	end
	
	local presentSprite
	if GetSpriteName(sprite) == "playbutton1" then
		presentSprite=GetParentSprite(GetParentSprite(sprite))
	else
		presentSprite=GetParentSprite(GetParentSprite(GetParentSprite(GetParentSprite(sprite))))
	end
	local itemName = GetSpriteName(presentSprite)
	local itemFocusNum = 0
	local itemCount=SpriteList_GetListItemCount(spriteList)
	local pageNum=math.ceil(itemCount/6) --六条记录一页，共几页
	
	--为表ItemList赋值
	for j=0,itemCount-1 do
		ItemList[j]="item-button-"..j
	end
	
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if ItemList[i]==itemName then
	    itemFocusNum=i
	  end
	end
	
	local pageIndex=math.floor(itemFocusNum/6) --当前页码，从0开始
	
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode==ApKeyCode_Down then
		if GetSpriteName(sprite)=="playbutton" then
			SetSpriteFocus(FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"descbutton"))
			saveTouchFocus(FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"descbutton"))
		elseif (GetSpriteName(sprite)=="descbutton" or GetSpriteName(sprite)=="playbutton1") and itemFocusNum>=pageIndex*6 and itemFocusNum<pageIndex*6+5 then
			if itemFocusNum~=itemCount-1 then
			--焦点即将离开区域
			SetSpriteRect(FindChildSprite(presentSprite,"select-display"),0,0,220,24)
			SetSpriteRect(FindChildSprite(presentSprite,"boardImage"),0,0,220,24)
			SetSpriteProperty(FindChildSprite(presentSprite,"boardImage"),"src","file:///image/product/unSelectbg.png")
			SetSpriteVisible(FindChildSprite(presentSprite,"list-video-caption-stars"),0)
			SetSpriteVisible(FindChildSprite(presentSprite,"select-display"),0)
			SetSpriteEnable(FindChildSprite(presentSprite,"select-display"),0)
			SetSpriteVisible(FindChildSprite(presentSprite,"unselect-display"),1)
			SetSpriteEnable(FindChildSprite(presentSprite,"unselect-display"),1)
			if GetSpriteName(sprite)=="playbutton1" then
				SetSpriteVisible(FindChildSprite(presentSprite,"playbutton1"), 0)
			else
				SetSpriteVisible(FindChildSprite(presentSprite,"playbutton"), 0)
				SetSpriteVisible(FindChildSprite(presentSprite,"descbutton"),0) 
			end
			--焦点即将进入区域
			local setFocusSprite=FindChildSprite(spriteList,ItemList[itemFocusNum+1])
			SetSpriteVisible(FindChildSprite(setFocusSprite,"select-display"),1)
			SetSpriteEnable(FindChildSprite(setFocusSprite,"select-display"),1)
			SetSpriteVisible(FindChildSprite(setFocusSprite,"unselect-display"),0)
			SetSpriteEnable(FindChildSprite(setFocusSprite,"unselect-display"),0)
			SetSpriteProperty(FindChildSprite(setFocusSprite,"boardImage"),"src","file:///image/product/jiaodian_bg.PNG")
			SetSpriteFocus(setFocusSprite)
			saveTouchFocus(setFocusSprite)
			end
		end
	elseif keyCode==ApKeyCode_Up then
		if GetSpriteName(sprite)=="descbutton" then
			SetSpriteFocus(FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"playbutton"))
			saveTouchFocus(FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"playbutton"))
		elseif (GetSpriteName(sprite)=="playbutton" or GetSpriteName(sprite)=="playbutton1") and itemFocusNum>pageIndex*6 and itemFocusNum<=pageIndex*6+5 then
			--焦点即将离开区域
			SetSpriteRect(FindChildSprite(presentSprite,"select-display"),0,0,220,24)
			SetSpriteRect(FindChildSprite(presentSprite,"boardImage"),0,0,220,24)
			SetSpriteProperty(FindChildSprite(presentSprite,"boardImage"),"src","file:///image/product/unSelectbg.png")
			SetSpriteVisible(FindChildSprite(presentSprite,"list-video-caption-stars"),0)
			SetSpriteVisible(FindChildSprite(presentSprite,"select-display"),0)
			SetSpriteEnable(FindChildSprite(presentSprite,"select-display"),0)
			SetSpriteVisible(FindChildSprite(presentSprite,"unselect-display"),1)
			SetSpriteEnable(FindChildSprite(presentSprite,"unselect-display"),1)
			if GetSpriteName(sprite)=="playbutton1" then
				SetSpriteVisible(FindChildSprite(presentSprite,"playbutton1"), 0)
			else
				SetSpriteVisible(FindChildSprite(presentSprite,"playbutton"), 0)
				SetSpriteVisible(FindChildSprite(presentSprite,"descbutton"),0) 
			end
			--焦点即将进入区域
			local setFocusSprite=FindChildSprite(spriteList,ItemList[itemFocusNum-1])
			SetSpriteVisible(FindChildSprite(setFocusSprite,"select-display"),1)
			SetSpriteEnable(FindChildSprite(setFocusSprite,"select-display"),1)
			SetSpriteVisible(FindChildSprite(setFocusSprite,"unselect-display"),0)
			SetSpriteEnable(FindChildSprite(setFocusSprite,"unselect-display"),0)
			SetSpriteProperty(FindChildSprite(setFocusSprite,"boardImage"),"src","file:///image/product/jiaodian_bg.PNG")
			SetSpriteFocus(setFocusSprite)
			saveTouchFocus(setFocusSprite)
		end
	elseif keyCode==ApKeyCode_Enter then
			if jsonChannel.programList[itemFocusNum].category == "5" then
				listItemLabelOnSelect(sprite)
			else
				listItemDemandOnSelect(sprite)
			end
	elseif keyCode==ApKeyCode_CharA and pageIndex>0 then	--*号键
			listUpButtonOnSelect(spriteLeftArrow)
	elseif keyCode==ApKeyCode_CharB and pageIndex<pageNum-1  then	--#号键
			listDownButtonOnSelect(spriteRightArrow)
	elseif keyCode == ApKeyCode_F1  and LoadingFlag() then
		local curItemButton=FindChildSprite(spriteList,"item-button-"..itemFocusNum) 
		local curName=GetSpriteName(curItemButton)
		WriteLogs("yaoxiangyin:@@@@@@@@@@@@@@@@@@@@curName=="..curName)
		local ToDigReg = registerCreate("ToDigReg")
		registerSetInteger(ToDigReg,"ToDigFocus",curItemButton)
		registerSetInteger(ToDigReg,"KeyFlag",1)
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(curItemButton)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_Right and LoadingFlag()  then
		if dnr == nil then
			dnr = 1
			local nextChannelButtonSprite=FindChildSprite(SpriteList_GetListItem(spriteChannelList,nextIndex),"channel-button-"..nextIndex)
			channelListiItemOnSelect(nextChannelButtonSprite)
			SetTimer(1,2500,"changeDnr")
		end
	elseif keyCode == ApKeyCode_Left and LoadingFlag()  then
		if dnr == nil then
			dnr = 1
			local preChannelButtonSprite=FindChildSprite(SpriteList_GetListItem(spriteChannelList,preIndex),"channel-button-"..preIndex) 
			channelListiItemOnSelect(preChannelButtonSprite)
			SetTimer(1,2500,"changeDnr")
		end
	end
end

function channelListItemKeyUp(sprite,keyCode)
	local productReg = registerCreate("product")
	registerSetInteger(productReg,"productDemand",sprite)
	registerSetInteger(productReg, "lastFocusFlag",1)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local spriteChannelList=FindChildSprite(GetRootSprite(sprite),"product-channel-list")  --product-channel-list节点
	local channelCount=SpriteList_GetListItemCount(spriteChannelList)
	local channelFocusNum
	for i=0,channelCount-1 do
		local testChannelSprite=SpriteList_GetListItem(spriteChannelList,i)
		x,y,width,height=GetSpriteRect(testChannelSprite)
		if width==62 then
			channelFocusNum=i
			break
		end
	end
	
	local preIndex
	local nextIndex
	if channelFocusNum==0 then
		preIndex=1
		nextIndex=2
	elseif channelFocusNum==1 then
		preIndex=3
		nextIndex=0
	elseif channelFocusNum==2 then
		preIndex=0
		nextIndex=4
	elseif channelFocusNum==3 then
		preIndex=4
		nextIndex=1
	elseif channelFocusNum==4 then        
		preIndex=2
		nextIndex=3
	end
	
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode == ApKeyCode_Right and LoadingFlag() then
		local nextChannelButtonSprite=FindChildSprite(SpriteList_GetListItem(spriteChannelList,nextIndex),"channel-button-"..nextIndex)
		channelListiItemOnSelect(nextChannelButtonSprite)
	elseif keyCode == ApKeyCode_Left and LoadingFlag() then
		local preChannelButtonSprite=FindChildSprite(SpriteList_GetListItem(spriteChannelList,preIndex),"channel-button-"..preIndex) 
		channelListiItemOnSelect(preChannelButtonSprite)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

function DemandItemOnSetFocus(sprite)
	SetSpriteVisible(FindChildSprite(sprite,"select-display"),1)
	SetSpriteEnable(FindChildSprite(sprite,"select-display"),1)
	SetSpriteVisible(FindChildSprite(sprite,"unselect-display"),0)
	SetSpriteEnable(FindChildSprite(sprite,"unselect-display"),0)
	SetSpriteRect(FindChildSprite(sprite,"select-display"),0,0,220,24)
	SetSpriteRect(FindChildSprite(sprite,"boardImage"),0,0,220,24)
	SetSpriteRect(GetSpriteParent(GetSpriteParent(sprite)),0,0,220,24)
	SetSpriteProperty(FindChildSprite(sprite,"boardImage"),"src","file:///image/product/jiaodian_bg.PNG")
	SetSpriteVisible(FindChildSprite(sprite,"list-video-caption-stars"),0)
	SetSpriteVisible(FindChildSprite(sprite,"playbutton"), 0)
	SetSpriteVisible(FindChildSprite(sprite,"descbutton"),0)
	local demanditemsprite = GetSpriteParent(sprite)
	local spriteList =FindChildSprite(GetCurScene(),"product-programgroup-list")
	SpriteList_Adjust(spriteList)
end

function DemandItemOnLostFocus(sprite)
	SetSpriteVisible(FindChildSprite(sprite,"select-display"),0)
	SetSpriteEnable(FindChildSprite(sprite,"select-display"),0)
	SetSpriteVisible(FindChildSprite(sprite,"unselect-display"),1)
	SetSpriteEnable(FindChildSprite(sprite,"unselect-display"),1)
	SetSpriteRect(FindChildSprite(sprite,"select-display"),0,0,220,24)
	SetSpriteRect(FindChildSprite(sprite,"boardImage"),0,0,220,24)
	SetSpriteRect(GetSpriteParent(GetSpriteParent(sprite)),0,0,220,24)
	SetSpriteProperty(FindChildSprite(sprite,"boardImage"),"src","file:///image/product/unSelectbg.png")
	SetSpriteVisible(FindChildSprite(sprite,"list-video-caption-stars"),0)
	SetSpriteVisible(FindChildSprite(sprite,"select-display"),0)
	SetSpriteEnable(FindChildSprite(sprite,"select-display"),0)
	SetSpriteVisible(FindChildSprite(sprite,"unselect-display"),1)
	SetSpriteEnable(FindChildSprite(sprite,"unselect-display"),1)
	SetSpriteVisible(FindChildSprite(sprite,"playbutton"), 0)
	SetSpriteVisible(FindChildSprite(sprite,"descbutton"),0)
	local demanditemsprite = GetSpriteParent(sprite)
	local index = SpriteListItem_GetIndex(demanditemsprite)
	local spriteList =FindChildSprite(GetCurScene(),"product-programgroup-list")
	SpriteList_Adjust(spriteList)
end

function DemandItemOnMouseDown(sprite)
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	SetSpriteVisible(FindChildSprite(sprite,"select-display"),1)
	SetSpriteEnable(FindChildSprite(sprite,"select-display"),1)
	SetSpriteVisible(FindChildSprite(sprite,"unselect-display"),0)
	SetSpriteEnable(FindChildSprite(sprite,"unselect-display"),0)
	productDemandItemKeyUp(sprite,ApKeyCode_Enter)
end
----------------------------------------------------------------------------------------------------------------
