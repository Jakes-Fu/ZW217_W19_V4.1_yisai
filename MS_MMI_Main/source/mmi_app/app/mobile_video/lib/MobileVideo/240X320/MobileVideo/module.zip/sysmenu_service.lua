﻿--@module 	SystemMenu
--@note 		底部菜单
--@author 	chengzhongjie
--@date 		2010/05/25
--@brief 		用于显示弹出菜单

require "module.sysmenu"
function registerOnSelect(sprite)
	hideMenuSprite();
	WriteLogs("registerOnSelect");	
	require "module.protocol.protocol_usercheck"
	local whitelistUrl = "http://c2.cmvideo.cn/ugcapp/uploadFile/UGC_CheckUser.html"
	local T_TYPE = "?T_TYPE=001"	
	whitelistUrl = whitelistUrl..T_TYPE
	Loading()
	--RequestUserCheck(122, 001)
	local Status = GetUserAuthority(122,"001")
	require "module.dialog.useDialog"	
	require "module.common.registerScene"
	require "module.common.SceneUtils"	
	--local Status = OnPipeUserCheckDecode()
	local regHandle = registerCreate("SCMngr_handle");
	local SceneName = registerGetString(regHandle, string.format("%d", GetCurScene()))
	if Status == 2 then
		SetReturn1(sceneRegisterInformation)
		Go2Scene(sceneRegisterInformation)		
	elseif Status == 1 then
		setDialogParam("免费注册", "您不是白名单用户", "BT_OK",SceneName, SceneName,spriteEvent)	
		Go2Scene(sceneDialog)
	elseif Status == 3 then	
		setDialogParam("免费注册", "您已经注册", "BT_OK",SceneName ,SceneName,spriteEvent)			
		Go2Scene(sceneDialog)
	else 	
		setDialogParam("免费注册", "网络错误", "BT_OK",SceneName ,SceneName,spriteEvent)	
		Go2Scene(sceneDialog)
	end
exitLoading()		
	--RequestWhiteListUserVerify(122, whitelistUrl)
end


function Loading() 
	local root = GetCurScene()
	local loadarea = FindChildSprite(root,"loadarea")
	require("module.loading.useLoading")
	enterLoading(loadarea)
end


function myOrderOnSelect(button)
	WriteLogs("myOrderOnSelect");

	hideMenuSprite()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\myorder.xml")
	WriteLogs("99999999999999999999999999999999999999999999999")
	Go2Scene("MODULE:\\myorder.xml")	
end

function mailBoxOnSelect(button)
	WriteLogs("mailBoxOnSelect");
	
	hideMenuSprite()
	--hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\receivemessage.xml")	
	Go2Scene("MODULE:\\receivemessage.xml")	
end

function SetReturn1(nextScenceName)
	local	regQuick = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(regQuick, "rootSprite")
	local   rootScene = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle");
	local SceneName = registerGetString(regHandle, string.format("%d", rootScene))	
	if SceneName ~= sceneHome and nextScenceName ~= sceneRegisterInformation then
		FreeScene(rootScene)
	end
	--找到数据仓库
 	reg = registerCreate(keyQuickLauncherBar);
 	--需要返回的总数+1
 	local count = registerGetInteger(reg, "Count")+1; 	
	registerSetInteger(reg, "Count", count);
	
	--得到CurPage，这个值保存当前页面名称，因为通过底部菜单条进入其他页面，无法知道当前页面是什么，
	--所以把这个变量存入ReturnTable，如果通过底部菜单条进入其他页面，则将这个变量设置成PageName，以便后续面页面返回
	require("module.setting");
	local CurPage = registerGetString(reg, "CurPage");
	registerSetString(reg, "PageName" .. count, CurPage);
	registerSetString(reg, "CurPage", nextScenceName)
--	registerSave(reg, Cfg.GetTempPath("returntable.xml") );
end

function sysServiceKeyup(sprite,keyCode)
	local reg=registerCreate("PassLeft")
	 registerSetInteger(reg,"spritePassLeft",sprite)

	servicereg=registerCreate("serviceButtonSprite")
	registerSetInteger(servicereg,"serviceButton",FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"myorder"))
	WriteLogs("-------------------++++++++++++++++++++++++++++:"..keyCode)
	item=GetParentSprite(sprite)
	local menuList=GetParentSprite(GetParentSprite(sprite))
	itemCount = SpriteList_GetListItemCount(menuList)
	WriteLogs("______name:"..GetSpriteName(menuList))
	index = SpriteListItem_GetIndex(item)
	WriteLogs(".....index:"..index)
	local list={"myorder","message","resign"}
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
		local lastFocus=registerGetInteger(homeLastFoucsReg,"lastFocusSprite")
	if keyCode==10 and index <=itemCount-1 then
			listitem=SpriteList_GetListItem(menuList, index+1)
			cursprite=FindChildSprite(listitem,list[index+2])
			if IsSpriteEnable(cursprite) ~= 0 then
				SetSpriteFocus(cursprite)
			end
	elseif keyCode==7  then
				flag=1
			local flagReg=registerCreate("flagnum")
			registerSetInteger(flagReg,"flagnum",flag)
			local regInfor=registerCreate("passSprite")
			local senceSprite=registerGetInteger(regInfor,"CurSprite")
			WriteLogs("=-=-=-=-2013=-012=3012=30"..GetSpriteName(senceSprite))
			SetSpriteFocus(senceSprite)
			
			local reg=registerCreate("popS")
			popSprite=registerGetInteger(reg,"pop")
			ShowPopupMenu(popSprite,0)
			--SetSpriteVisible(GetParentSprite(GetParentSprite(sprite)),0)
			--SetSpriteEnable(GetParentSprite(GetParentSprite(sprite)),0)
	
		elseif keyCode == 1 then
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			require("module.menuopen")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
			
		elseif keyCode == 2  then
			require("module.menuopen")
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
	
	elseif keyCode==9 and index>=1 then
		if index==0 then return 0
		else 
		listitem=SpriteList_GetListItem(menuList, index-1)
		WriteLogs("---------"..SpriteListItem_GetIndex(listitem))
		cursprite=FindChildSprite(listitem,list[index])
		SetSpriteFocus(cursprite)
		
		end
	end
		return 0
end

function ShowPopupMenu(popSprite, show)
	if show == 0 then
		SetSpriteVisible(popSprite, 0);
		SetSpriteEnable(popSprite, 0);
		childPopSprite = FindChildSpriteByClass(popSprite, "list");
		if childPopSprite ~= 0 then
			SpriteList_SetCurItem(childPopSprite, -1);
		end
	else
		SetSpriteVisible(popSprite, 1);
		SetSpriteEnable(popSprite, 1);
	end
end

function hidePopupSprites()
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	
	if hideMenuSprite(rootSprite) == 1 then	return	1;	end
	if hideBottomSprite(rootSprite) == 1 then	return	1;end

	return	0;
end

