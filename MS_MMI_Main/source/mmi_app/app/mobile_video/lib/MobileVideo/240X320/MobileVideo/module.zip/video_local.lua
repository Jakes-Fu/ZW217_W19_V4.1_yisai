﻿--@module video
--@note 播放界面
--@author cuiyizhou
--@date 2010/05/25
require "module.keyCode.keyCode"
require "module.protocol.protocol_video"
require "module.protocol.protocol_infovolume"
require "module.Loading.useLoading"
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.video_com"
local myKeyCode=""
local myBarSprite
local mySeekTime=0
local firstFlag=1
function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--
	reg = registerCreate("video")
	registerSetInteger(reg, "root", sprite)
	http = pluginCreate("HttpPipe", "comHttpPipe")
	observer = pluginGetObserver()
	--[[  以下为组点播时的面板创建  ]]--   
	local regflag = registerCreate("buttonclickflag")
	--[[	flag值为0时playerinterfaceOnTick函数会直接返回，即不移动播放器面板	]]--
	registerSetInteger(regflag, "flag", 0)
	--[[	preflag值置1，默认第一次播放器面板的运动为向上	]]--
	registerSetInteger(regflag, "preflag", 1)
	
	jsonCreateData()  		--解析数据
	
	InitScene()				--初始化场景
	setPreNetButtonBgImage() --初始化节目按钮图片
	FullScreen=FindChildSprite(sprite,"FullSec")
	FullSelect=FindChildSprite(sprite,"item-playercontrols-fullscreen")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin == 0 then
		MediapalyPlugin = pluginCreate("MediaPlayer")
		pluginInvoke(MediapalyPlugin, "Create", 0, 35, 240, 160)
		SetTimer(1, 1000, "movewindow_Local")
	end
	
	if MediapalyPlugin == 0 then
		SetStatusText("创建播放器失败，请重新安装程序")
	else
		registerSetInteger(reg, "MediapalyPlugin", MediapalyPlugin)
	end
	initData()
	return 1
end

function bodyOnSpriteEvent(message, params)
	require("module.common.commonMsg")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if message == MSG_EXCEPTIVEKEY then
		WriteLogs("***MSG_EXCEPTIVEKEY: "..params)
		if params == 23 then
			VolumeUpOnButtonClick(nil)
		elseif params == 24 then
			VolumeDownOnButtonClick(nil)
		end
	elseif message == MSG_ACTIVATE then
		regtimer=registerCreate("timerflag")
		registerSetInteger(regtimer, "flag",1)
		curPageIsVideo = true
		SetStatusText("")
		WriteLogs("MSG_ACTIVATE ")
		jsonCreateData()
		setPreNetButtonBgImage() --初始化节目按钮图片
		if MediapalyPlugin == 0 and urlpath then
			MediapalyPlugin = pluginCreate("MediaPlayer")
			local open = pluginInvoke(MediapalyPlugin, "Open", urlpath)
			pluginInvoke(MediapalyPlugin, "Play")
			if open ==1 then
				local Volume = pluginInvoke(MediapalyPlugin, "GetVolume")
				curVolume = Volume
				registerSetInteger(reg, "MediapalyPlugin", MediapalyPlugin)
			else
				SetStatusText("文件格式不支持")
			end
		else
			pluginInvoke(MediapalyPlugin, "Open", urlpath)
			pluginInvoke(MediapalyPlugin, "Play")
			local Volume = pluginInvoke(MediapalyPlugin, "GetVolume")
			curVolume = Volume
		end
		IsReview = registerGetString(reg, "IsReview")
		registerSetString(reg, "IsReview","")
		--pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 30, 240, 162)
		SetTimer(1, 1000, "movewindow_Local")
		SetTimer(1, 500, "OnGetStatus")
	elseif message == MSG_DEACTIVATE then
		WriteLogs("MSG_DEACTIVATE")
		curPageIsVideo = false
		if MediapalyPlugin == 0 then
			MediapalyPlugin = pluginCreate("MediaPlayer")
			WriteLogs("MSG_DEACTIVATE Create MediapalyPlugin")
		end
		pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 35, 240, 160)
		pluginInvoke(MediapalyPlugin, "Show" , 0)
		SetStatusText("")
		local left2, top2, width2, height2 = GetSpriteRect(huaKuaiSprite)
		SetSpriteRect(huaKuaiSprite, huaKuai_left,top2, width2, height2)
		local left2, top2, width2, height2 = GetSpriteRect(spritehighlight)
		SetSpriteRect(spritehighlight, left2, top2, 0, height2)
		SetSpriteRect(spritehighred, left2, top2, 0, height2)
	elseif message == MSG_MINIMIZED then
		reg = registerCreate("video")
		WriteLogs("MSG_MINIMIZED")
		regtimer=registerCreate("timerflag")
	  registerSetInteger(regtimer, "flag",0)
		if MediapalyPlugin then
			if iffull == 1 then
				iffull =0
				pluginInvoke(MediapalyPlugin, "FullScreen", 0)
				ReleaseSpriteCapture(FullSec)
				SetSpriteProperty(FullSec,"enable","false")
			end
			pluginInvoke(MediapalyPlugin, "Show" , 0)
			pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 35, 240, 160)
			pluginInvoke(MediapalyPlugin, "Pause")
			if HasSpriteFocus(FullScreen)==1 then
				WriteLogs("焦点在：FullSec上 ")
				SetSpriteFocus(FullSelect)
			end
		end
	elseif message == MSG_MAXIMIZED then
		reg = registerCreate("video")
		WriteLogs("MSG_MAXIMIZED")
		regtimer=registerCreate("timerflag")
	  registerSetInteger(regtimer, "flag",1)
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Show" , 1)
			SetTimer(1, 1000, "movewindow_Local")
			if HasSpriteFocus(FullScreen)==1 then
				SetSpriteFocus(FullSelect)
				end
		end		
		if HasSpriteFocus(FullScreen)==1 then
				WriteLogs("焦点在：FullSec上 ")
				SetSpriteFocus(FullSelect)
		end
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		if MediapalyPlugin ~= 0 then
				pluginInvoke(MediapalyPlugin, "Stop")
				pluginInvoke(MediapalyPlugin, "Show" , 0)
		end
	elseif message == MSG_SMS then
		hintSMS()
	end
end
--start 设置状态
function SetStatusText(text,type)
	if type == nil and statuslabel and statuslabe2 then
		SetSpriteProperty(statuslabel, "text", text)
		SetSpriteProperty(statuslabe2, "text", text)	
		return 1
	elseif type == "sms" then
		SetSpriteVisible(statuslabel, 0)
		SetSpriteVisible(statuslabe2, 0)	
		SetSpriteProperty(statusSMS, "text", text)
		SetSpriteVisible(smsStatusImage, 1)
		return 1
	end
end

--start 解析数据
function jsonCreateData()
	json = OnVideoDecode()
	localUrlList ={}
	videoCount = 0
	videoCurnum = 0
	--[[播放器页面推荐只用取最后一条记录]]--
	videoCount = registerGetInteger(reg, "videoCount")
	for i =1, videoCount do
		localUrlList[i] = registerGetString(reg, "localUrl" ..i)
	end
	videoCurnum = registerGetInteger(reg, "curVideo")
	urlpath = localUrlList[videoCurnum]
	videoName = getFilename(urlpath)
	local isTemp = string.find(videoName,"temp_")
	if isTemp ~= nil then
		videoName = string.gsub(videoName, "temp_", "")
	end
	playurl = registerGetString(reg, "localUrl" ..videoCurnum)
	return 1
end

function InitScene()
	createLocalVideo() --[[  以下为本地播放时的面板创建  ]]--
	createGlobalValue()
end

--@function	createLocalVideo
--@brief	当场景为视屏本地播放时，创建相应的界面，在bodyBuildChildrenFinished中调用
function createLocalVideo() 
	--[[	获取根节点	]]--
	local root = registerGetInteger(reg, "root")
	--[[	创建listitem类的节点	]]--
	local playercontrolsitemSprite = CreateSprite("listitem")
	local playercontrolsSprite = FindChildSprite(root, "list-playercontrols")
	--[[	用已有模板中数据填充该节点	]]--
	LoadSprite(playercontrolsitemSprite, "MODULE:\\video_localvideomodule.xml")
	SetSpriteRect(playercontrolsitemSprite, 0, 0, 240, 100)
	--[[	把该节点插入到场景中	]]--
	AddChildSprite(playercontrolsSprite, playercontrolsitemSprite)
	SpriteList_AddListItem(playercontrolsSprite, playercontrolsitemSprite)
	--[[	重新调节场景中播放面板位置参数	]]--
	local playerinterfacesprite = FindChildSprite(root, "item-playerinterface")
	SetSpriteRect(playerinterfacesprite,0,235,240,58)
	dw_fullsec = FindChildSprite(playercontrolsitemSprite, "item-playercontrols-fullscreen")  ---FullSec
	dw_down = FindChildSprite(playercontrolsitemSprite, "item-playercontrols-volumedown")
	dw_up = FindChildSprite(playercontrolsitemSprite, "item-playercontrols-volumeup")
	dw_pre=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-pre")
	dw_play=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-play")
	dw_pause=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-pause")
	dw_next=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-next")
	SetSpriteFocus(dw_fullsec)  
	local reg=registerCreate("fullBt")
	registerSetInteger(reg,"FullBt",dw_fullsec)
	saveTouchFocus(dw_fullsec)
	return 1
end

function OnPluginEvent(message, param)
	if MSG_SMS_ID == message then
		DealMsgContent(sceneVideolocal, sceneVideolocal)
		videoDealSMS()
	end
end

function FullChangeKeyUp(sprite,keyCode)
	WriteLogs("keyCode:"..keyCode)
	
	WriteLogs("退出全屏")
	if keyCode then
	FullSecOnButtonClick(sprite)
	
	end
	return 0
end

function listKeyUp(sprite, keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local jiaodian = {"item-playercontrols-fullscreen","item-playercontrols-volumedown","item-playercontrols-volumeup","pre","play","next"}
	WriteLogs("-----------keyCode:"..keyCode)
	local name= GetSpriteName(sprite)
	item=GetSpriteParent(sprite)
	ParName=GetSpriteName(item)
	for i=1,6 do
		if name==jiaodian[i] then
		Num=i 
		break
		end
	end
	WriteLogs("_________________________________________")
		Pre_result=IsSpriteEnable(dw_pre)
		Next_result=IsSpriteEnable(dw_next)
		WriteLogs("Pre_result:"..Pre_result)
		WriteLogs("Next_result:"..Next_result)
	
		local reg= registerCreate("video")
	    local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		local status = pluginInvoke(MediapalyPlugin, "GetStatus")  
		if status~=nil  then  
		WriteLogs("status:"..status)
		end
		WriteLogs("Name:"..name)
		WriteLogs("Parent:"..ParName)
	
	if keyCode==ApKeyCode_Right then		
		if name=="item-playercontrols-volumeup"  then		
			WriteLogs("前无节目")
			if Pre_result==0  then
				if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering or status==EPlayerStatus_Connecting or status==nil then
						SetSpriteFocus(dw_pause)
						saveTouchFocus(dw_pause)
				else	SetSpriteFocus(dw_play)
						saveTouchFocus(dw_play)
				end		
			else SetSpriteFocus(dw_pre)
				 saveTouchFocus(dw_pre)
			end
		elseif name=="item-playercontrols-pre" then
			WriteLogs("1111111111111")
				if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering or status==EPlayerStatus_Connecting or status==nil then
							SetSpriteFocus(dw_pause)
							saveTouchFocus(dw_pause)
				else	SetSpriteFocus(dw_play)
						saveTouchFocus(dw_play)
				end
		elseif ParName=="play" then
			
			if Next_result==0 then
			return 1
			else SetSpriteFocus(dw_next)
				 saveTouchFocus(dw_next)
			end
		elseif Num<=3 then
			local NextFocus= FindChildSprite(item,jiaodian[Num+1])
			SetSpriteFocus(NextFocus)
			saveTouchFocus(NextFocus)
		elseif name=="item-playercontrols-next" and Next_result==0 then
			return 1
		
		end
	
	elseif keyCode==ApKeyCode_Left then	
		if name=="item-playercontrols-next"  then		
			if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering or status==EPlayerStatus_Connecting or status==nil  then
					SetSpriteFocus(dw_pause)
					saveTouchFocus(dw_pause)
			else	SetSpriteFocus(dw_play)
					saveTouchFocus(dw_play)
			end		
  
		elseif ParName=="play" then
			WriteLogs("CCCCCCCCCCCCCCCCCCC")
			if Pre_result==0 then
			SetSpriteFocus(dw_up)
			saveTouchFocus(dw_up)
			else SetSpriteFocus(dw_pre)
				 saveTouchFocus(dw_pre)
			end
		elseif name=="item-playercontrols-pre" then
			SetSpriteFocus(dw_up)
			saveTouchFocus(dw_up)
		elseif Num>1  then
			local NextFocus= FindChildSprite(GetSpriteParent(item),jiaodian[Num-1])
			SetSpriteFocus(NextFocus)
			saveTouchFocus(NextFocus)
		end
	elseif keyCode == ApKeyCode_F1 then		
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)

	
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		
	elseif keyCode == ApKeyCode_Up then
		local root=GetRootSprite(sprite)
		local Focus=FindChildSprite(root,"splider-bar")
		SetSpriteFocus(Focus) 
		saveTouchFocus(Focus)
	elseif keyCode == 3 then
		if name=="item-playercontrols-fullscreen" and status==EPlayerStatus_Playing then FullScreenOnButtonClick(sprite)
			WriteLogs("进入全屏")
			SetSpriteFocus(FindChildSprite(GetRootSprite(sprite),"FullSec"))
			local reg=registerCreate("Fullselect")		--将全屏按钮键写入数据仓库
			registerSetInteger(reg,"FullFocus",sprite)
			saveTouchFocus( FindChildSprite(GetRootSprite(sprite),"FullSec"))
		elseif name =="item-playercontrols-volumedown" then VolumeDownOnButtonClick(sprite)
		elseif name =="item-playercontrols-volumeup" then VolumeUpOnButtonClick(sprite)
		elseif name =="item-playercontrols-pause" then 
		local reg=registerCreate("pauseButton")
			 registerSetInteger(reg,"pause",sprite)
			PauseOnButtonClick(sprite)		
		elseif name =="item-playercontrols-play"  then 
			local reg=registerCreate("playButton")
			 registerSetInteger(reg,"pause",sprite)
			PlayOnButtonClick(sprite)			 			
		
		elseif name =="item-playercontrols-pre" then 
		PreVideoOnButtonClick(sprite) 
			local flagpre=0
			local falgReg=registerCreate("flagReg")			--dw
			flagpre =registerGetInteger(falgReg,"flagNum")
			if flagpre==1 then
			if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering or status==EPlayerStatus_Connecting  or status==nil then
					SetSpriteFocus(dw_pause)
					saveTouchFocus(dw_pause)
			else	SetSpriteFocus(dw_play)
					saveTouchFocus(dw_play)
			end		--dw
			registerSetInteger(falgReg,"flagNum",0)
			end
		elseif name =="item-playercontrols-next" then 
		NextVideoOnButtonClick(sprite)
		local falgNextReg=registerCreate("flagNextReg")			--dw
			local flagNext=0
			flagNext=registerGetInteger(falgNextReg,"flagNextNum")
			if flagNext==1 then
			if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering or status==EPlayerStatus_Connecting  or status==nil then
					SetSpriteFocus(dw_pause)
					saveTouchFocus(dw_pause)
			else	SetSpriteFocus(dw_play)
					saveTouchFocus(dw_play)
			end	
			registerSetInteger(falgNextReg,"flagNextNum",0)
			end
		end
	end
	
	return 1
end


function barOnKeyUp(sprite,keyCode)
	WriteLogs("bar:"..keyCode)
	local reg = registerCreate("video")
	local seekTime
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
    local spriteR=registerGetInteger(reg, "root")
  	labelStartTimeSprite = FindChildSprite(spriteR, "item-playerinterface-curtime")
    local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
    local totalTime=pluginInvoke(MediapalyPlugin, "GetTotalTime")
	if keyCode==ApKeyCode_Down then
		SetSpriteFocus(dw_fullsec)
		saveTouchFocus(dw_fullsec)
	elseif keyCode == ApKeyCode_Left  then
	  myKeyCode=""
	  CancelTimer(2)
	  local reg = registerCreate("video")
	  local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	  pluginInvoke(MediapalyPlugin, "Play")
	  pluginInvoke(MediapalyPlugin, "Seek", mySeekTime)
	  firstFlag=1
	  mySeekTime=0
	  return 0
	elseif keyCode == ApKeyCode_Right then
      myKeyCode=""
	  CancelTimer(2)
	  local reg = registerCreate("video")
	  local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	  pluginInvoke(MediapalyPlugin, "Play")
	  pluginInvoke(MediapalyPlugin, "Seek", mySeekTime)
	  firstFlag=1
	  mySeekTime=0
	  return 0
	elseif keyCode == ApKeyCode_F1 then		
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)

	
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end 

	 return 0

end

function movewindow_Local()
  regtimer=registerCreate("timerflag")
	  timeflag=registerGetInteger(regtimer, "flag")
	  WriteLogs("dondondodn"..timeflag)
	  if timeflag==1 then
	    reg = registerCreate("video")
	    local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	 --   pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 40, 240, 180)  --融创播放器
   		pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 35, 240, 160)
    end
end

function barOnKeyDown(sprite,keyCode)
	if keyCode==ApKeyCode_Left then
		pressLeftBar(sprite)
	elseif keyCode==ApKeyCode_Right then
		pressRightBar(sprite)
	end
end


function barOnKeyPress(sprite,keyCode)
	WriteLogs("do barOnKeyPress keyCode=="..keyCode)
	myKeyCode=keyCode
	myBarSprite=sprite
	if keyCode==ApKeyCode_Left then
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		pluginInvoke(MediapalyPlugin,"Pause")
		SetTimer(2,200,"pressOnTimer")
	elseif keyCode==ApKeyCode_Right then
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		pluginInvoke(MediapalyPlugin,"Pause")
		SetTimer(2,200,"pressOnTimer")
	end
end

function pressLeftBar(sprite)
	local reg = registerCreate("video")
	local seekTime
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
    local spriteR=registerGetInteger(reg, "root")
  	labelStartTimeSprite = FindChildSprite(spriteR, "item-playerinterface-curtime")
    local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
    local totalTime=pluginInvoke(MediapalyPlugin, "GetTotalTime")
	WriteLogs("左移滑块")
    if firstFlag==1 then
		seekTime=curTime-30
		firstFlag=0
		mySeekTime=seekTime
	else
		mySeekTime=mySeekTime-50
		seekTime=mySeekTime
	end
    WriteLogs("@@@@@@@@@@@@@@@@@seekTime"..seekTime)
    WriteLogs("@@@@@@@@@@@@@@@@@totalTime"..totalTime)
	spriteS=GetSpriteParent(GetSpriteParent(sprite))
	local Bg_x,Bg_y=GetSpriteRect(FindChildSprite(spriteS,"item-playerinterface-progressbar"))
	changeL=seekTime/totalTime*132
	WriteLogs("@@@@@@@@@@@@@@@@@totalTime"..totalTime)
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighred")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	SetSpriteRect(spriteR,X,Y,changeL,Y1)
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighlight")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	SetSpriteRect(spriteR,X,Y,changeL,Y1)
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressblock")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	if seekTime<0 then
	SetSpriteRect(spriteR,Bg_x,Y,X1,Y1)
	setSecTime(labelStartTimeSprite, 0)	
	mySeekTime=0
	return 0
	else
	SetSpriteRect(spriteR,changeL+45,Y,X1,Y1)  
	end
	setSecTime(labelStartTimeSprite, seekTime)	
	pluginInvoke(MediapalyPlugin, "Seek", seekTime)
end

function pressRightBar(sprite)
	local reg = registerCreate("video")
	local seekTime
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
    local spriteR=registerGetInteger(reg, "root")
  	labelStartTimeSprite = FindChildSprite(spriteR, "item-playerinterface-curtime")
    local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
    local totalTime=pluginInvoke(MediapalyPlugin, "GetTotalTime")
	if firstFlag==1 then
		seekTime=curTime+30
		firstFlag=0
		mySeekTime=seekTime
	else
		mySeekTime=mySeekTime+50
		seekTime=mySeekTime
	end
    WriteLogs("@@@@@@@@@@@@@@@@@seekTime"..seekTime)
    WriteLogs("@@@@@@@@@@@@@@@@@totalTime"..totalTime)
    spriteS=GetSpriteParent(GetSpriteParent(sprite))
	local Bg_x,Bg_y=GetSpriteRect(FindChildSprite(spriteS,"item-playerinterface-progressbar"))
	changeL=seekTime/totalTime*132
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighred")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	SetSpriteRect(spriteR,X,Y,changeL,Y1)
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighlight")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	SetSpriteRect(spriteR,X,Y,changeL,Y1)
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressblock")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	if seekTime>totalTime then
	SetSpriteRect(spriteR,Bg_x+130,Y,X1,Y1)
	setSecTime(labelStartTimeSprite, totalTime-0)	
	mySeekTime=totalTime
	return 0
	else
	SetSpriteRect(spriteR,changeL+45,Y,X1,Y1)  
	end
	setSecTime(labelStartTimeSprite, seekTime)	
	pluginInvoke(MediapalyPlugin, "Seek", seekTime)	
end

function pressOnTimer()
	if myKeyCode==ApKeyCode_Left then
		pressLeftBar(myBarSprite)
	elseif myKeyCode==ApKeyCode_Right then
		pressRightBar(myBarSprite)
	end
end
