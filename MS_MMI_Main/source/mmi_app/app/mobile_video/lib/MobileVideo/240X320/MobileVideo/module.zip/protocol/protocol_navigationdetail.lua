--author ljc
--date	2010/06/01
-- request navigationdetail
function RequestNavigationDetail(protocolNumber, searchUrl)
	WriteLogs("request")
	local regSystem = registerCreate("System")
	local http = pluginCreate("HttpPipe")
	local observer = pluginGetObserver()
	WriteLogs("observer="..observer)
	local fileName = GetLocalFilename(searchUrl)
	local reg = registerCreate("navigationdetail")
	registerSetString(reg, "navigationDetailsFileName", fileName)
	pluginInvoke(http, "AppendCommand", 0, searchUrl, "", fileName, observer, protocolNumber, 0, 0)
end

function OnNavigationDetailDecode()
	local reg = registerCreate("navigationdetail")
	local fileName = registerGetString(reg, "navigationDetailsFileName")
	WriteLogs("OnNavigationDetailDecode="..fileName)
	if fileName ~= nil and fileName ~= "" then
		return jsonLoadFile(fileName)
	end

	return nil
end
