﻿--@module	download
--@note	用于下载选择界面的UI显示
--@author	shenyi
--@date	2010/05/30

require "module.Loading.useLoading"
require "module.common.SceneUtils"
require "module.protocol.protocol_downloadinfor"
require "module.common.commonMsg"
require "module.keyCode.keyCode"
downloadSelect_ItemHeight = 25
downloadSelect_ItemWidth = 222


overwriteFile = {}
overwriteTask = {}
downloadTask = {}
videoDataUrl = {}
videoDataName = {}

--@tag-action	body:BuildChildrenFinished
--@brief	创建下载选择列表
function bodyBuildChildrenFinished(sprite)
	--debugData()
	local reg = registerCreate("download_select")   
	registerSetInteger(reg, "root", sprite)
	LoadFileData()
	CreatedownloadSelectList(sprite)
	return 1
end

backImageList = {"file:///image/DownloadSelect/item_normal.png","file:///image/DownloadSelect/item_jiaodian.png"}
selectImage = {"file:///image/dialog/boxunselected.png", "file:///image/dialog/boxselected.png"}
select = {}
allSelect = nil
volumeCount = nil
programLabel = nil
prevSelItem = nil
contentLabel = nil
downloadurl = {}
curDownUrl = {}
downCount = nil
downNum = nil
subroName = {}

--测试数据
function debugData()
	volumeCount = 20
	programLabel = "影视 > 剧集 > 欧美"
end

--@function	CreatedownloadSelectList
--@brief	创建下载选择列表
function CreatedownloadSelectList(sprite)
	local spriteProgram = FindChildSprite(sprite, "info-content-caption")
	SetSpriteProperty(spriteProgram,"text",programLabel)
	local spriteContent = FindChildSprite(sprite,"download-name")
	local spriteContent1 = FindChildSprite(sprite,"download-name1")
	SetSpriteProperty(spriteContent,"text",contentLabel)
	SetSpriteProperty(spriteContent1,"text",contentLabel)
	local spriteList = FindChildSprite(sprite, "download-list")
	SpriteList_LoadListItem(spriteList, "MODULE:\\downloadSelectList1.xml", 1)
	local downloadSprite = SpriteList_GetListItem(spriteList, 0)
--[[----------------------------修改人：yaoxiangyin 修改时间：2010.8.20-------------------------------------------]]--
    local allSelectButtonSprite=FindChildSprite(downloadSprite,"item-button")
	SetSpriteProperty(allSelectButtonSprite,"name","item-button-0")
	SetSpriteProperty(allSelectButtonSprite,"OnKeyUp","downloadButtonSelectKeyUp")
-----------------------------------------------------------------------------------------------------------------------
	SetSpriteRect(downloadSprite,0 , 0, downloadSelect_ItemWidth, downloadSelect_ItemHeight)
	allSelect = 0
	SpriteList_LoadListItem(spriteList, "MODULE:\\downloadSelectList.xml", volumeCount)
	for i=1,volumeCount do
		local downloadSprite = SpriteList_GetListItem(spriteList, i)	
		
		WriteLogs("downloadSprite"..downloadSprite)
--[[--------------------------修改人：yaoxiangyin 修改时间：2010.08.19----------------------------------------------------]]--		
		local selectButtonSprite=FindChildSprite(downloadSprite,"item-button")
		SetSpriteProperty(selectButtonSprite,"name",string.format("item-button-%d", i))
		SetSpriteProperty(selectButtonSprite,"OnKeyUp","downloadButtonSelectKeyUp")
-------------------------------------------------------------------------------------------------------------------------------			
		SetSpriteRect(downloadSprite,0 , 0, downloadSelect_ItemWidth, downloadSelect_ItemHeight)
		local spritedownloadText = FindChildSprite(downloadSprite, "download-label")
		local volumeText = nil
		-- if i < 10 then
			-- volumeText = "第0"..i.."集"
		-- else
			-- volumeText = "第"..i.."集"
		-- end
		--volumeText = subroName[i-1]
		SetSpriteProperty(spritedownloadText,"text",subroName[i-1])
				
		select[i] = 0
	end
--[[---------------------------修改人：yaoxiangyin 修改时间：2010.08.19----------------------------------]]--
	local defaultFocusButton=FindChildSprite(SpriteList_GetListItem(spriteList,1),"item-button-1")
	WriteLogs("@@@@@@@@@@@@###########$$$$$$$$$$$$"..GetSpriteName(defaultFocusButton))
	SetSpriteProperty(FindChildSprite(GetParentSprite(defaultFocusButton),"backimage"),"src","file:///image/DownloadSelect/item_jiaodian.png")
	SetSpriteFocus(defaultFocusButton)
-----------------------------------------------------------------------------------------
	SpriteList_Adjust(spriteList)
	require "module.common.commonScroll"
	CreateScrollBar(sprite,"download-list",volumeCount*downloadSelect_ItemHeight ,76)	
	local totalHeight = downloadSelect_ItemHeight*(volumeCount+2) 
	if totalHeight > 223 then
		scroll_region = totalHeight-223
	else
		local spriteImage = FindChildSprite(sprite,"scrollbar-image")
		local spriteScroll = FindChildSprite(sprite,"scroll")
		local spriteSplider = FindChildSprite(sprite,"splider-bar")
		SetSpriteVisible(spriteImage,1)
		SetSpriteVisible(spriteSplider,0)
		SetSpriteEnable(spriteScroll,0)
		SetSpriteEnable(spriteSplider,0)
	end
end

function itemButtonSelect(sprite)
	WriteLogs("itemButtonSelect")
	if prevSelItem then
		local spriteImage1 = FindChildSprite(prevSelItem,"backimage")
		local spriteLabel1 = FindChildSprite(prevSelItem,"download-label")
		SetSpriteProperty(spriteImage1,"src",backImageList[1])
		SetSpriteProperty(spriteLabel1,"color","#0B5495")
	end
	local spriteListItem = GetSpriteParent(sprite)
	local index = SpriteListItem_GetIndex(spriteListItem)	
	local spriteImage = FindChildSprite(spriteListItem,"backimage")
	local spriteLabel = FindChildSprite(spriteListItem,"download-label")
	SetSpriteProperty(spriteImage,"src",backImageList[2])
	SetSpriteProperty(spriteLabel,"color","#FFFFFF")
	prevSelItem = spriteListItem
end

--@function	selectButtonOnSelect
--@tag-name	select-button
--@tag-action	button:OnSelect
--@brief	用于响应选择框按钮点击事件
function selectButtonOnSelect(sprite)
	WriteLogs("selectButtonOnSelect")
	local spriteListItem = GetSpriteParent(sprite)
	local index = SpriteListItem_GetIndex(spriteListItem)	
	local spriteSelect = FindChildSprite(spriteListItem,"select-image")
	local spriteItem = FindChildSprite(spriteListItem,"item-button")
	if index == 0 then
		if allSelect == 0 then
			allSelect =  1
			local spriteList = GetSpriteParent(spriteListItem)
			for i=0,volumeCount do
				local downloadSprite = SpriteList_GetListItem(spriteList, i)
				local spriteSelect1 = FindChildSprite(downloadSprite,"select-image")
				SetSpriteProperty(spriteSelect1,"src",selectImage[2])
				select[i] = 1
			end
		elseif allSelect == 1 then
			allSelect =  0
			local spriteList = GetSpriteParent(spriteListItem)
			for i=0,volumeCount do
				local downloadSprite = SpriteList_GetListItem(spriteList, i)
				local spriteSelect1 = FindChildSprite(downloadSprite,"select-image")
				SetSpriteProperty(spriteSelect1,"src",selectImage[1])
				select[i] = 0
			end		
		end
	else
		if select[index] == 0 then
			select[index] = 1
			SetSpriteProperty(spriteSelect,"src",selectImage[2])			
		elseif select[index] == 1 then
			select[index] = 0
			SetSpriteProperty(spriteSelect,"src",selectImage[1])			
		end
	end	
end

function downloadButtonOnSelect(sprite)
	WriteLogs("downloadButtonOnSelect 下载url")
	downCount = 0
	if allSelect == 1 then
		for i = 1,volumeCount do
			downCount = downCount + 1
			curDownUrl[downCount] = downloadurl[i-1]	
			WriteLogs("第"..i.."集 downurl---"..curDownUrl[downCount])			
		end
	else
		for i = 1,volumeCount do
			if select[i] == 1 then
				downCount = downCount + 1
				curDownUrl[downCount] = downloadurl[i-1]
				WriteLogs("第"..i.."集 downurl---"..curDownUrl[downCount])
			end
		end
	end	
	if downCount > 0 then
		local reg = registerCreate("download_select")
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root, "loadarea")
		enterLoading(loadarea)
		downNum = 1
		WriteLogs("RequestDownloadVideo downNum---"..downNum)
		WriteLogs("downurl---"..curDownUrl[downNum])		
		require "module.protocol.protocol_videoloading"
		RequestDownloadVideo(107,curDownUrl[downNum])
	end
end

--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	WriteLogs("OnPluginEvent")
	if message == 107 then
		WriteLogs("videoData return")
		require "module.protocol.protocol_videoloading"
		videoData = OnDownloadVideoDecode()
		if videoData and videoData.success == "true" then
			WriteLogs("AppendDownloadQueue downNum"..downNum)
			WriteLogs("videoData.urls[0].url---"..videoData.urls[0].url)
			WriteLogs("videoData.urls[0].name---"..videoData.urls[0].name)
			videoDataUrl[downNum] = videoData.urls[0].url
			videoDataName[downNum] = videoData.urls[0].name
			require("module.setting")
			local path = Cfg.GetDownloadPath()
			local dir = OpenDirectory(path..videoData.urls[0].name..Cfg.GetVideoType())
			if dir then
				WriteLogs(downNum.." insert overwriteFile")		
				WriteLogs("videoDataName---"..videoDataName[downNum])
				table.insert(overwriteFile,downNum)				
			else
				if videoData.urls[0].url and videoData.urls[0].url ~= "" then				
					local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name,1)
					WriteLogs("result---"..result)
					if result == -1 then
						WriteLogs(downNum.." insert overwriteTask")
						table.insert(overwriteTask,downNum)
					else
						table.insert(downloadTask,downNum)
					end									
				end
			end
					
			local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name,1)
			--WriteLogs("downNum--"..downNum)
			--WriteLogs("downCount--"..downCount)
		end
		if downNum < downCount then
			downNum  = downNum + 1
			WriteLogs("RequestDownloadVideo downNum---"..downNum)
			WriteLogs("downurl---"..curDownUrl[downNum])
			require "module.protocol.protocol_videoloading"
			RequestDownloadVideo(107,curDownUrl[downNum])
		elseif  downNum == downCount then	
			exitLoading()
			require "module.common.registerScene"
			require "module.dialog.useDialog"
			WriteLogs("overwriteFile count"..#overwriteFile)
			WriteLogs("overwriteTask count"..#overwriteTask)
			if #overwriteFile > 0 or #overwriteTask > 0 then
				local reg = registerCreate("download_select")   
				local sprite = registerGetInteger(reg, "root")
				local spriteEvent = FindChildSprite(sprite,"event")
				setDialogParam("提示", "任务已存在,是否需要覆盖下载?", "BT_OK_CANCEL", sceneDownloadSelect, sceneDownloadSelect, spriteEvent)
				Go2Scene(sceneDialog)
			else			
				setDialogParam("提示", "文件已添加到下载队列", "BT_OK", sceneDownloadSelect, sceneDownloadSelect, GetCurScene())
				Go2Scene(sceneDialog)
			end
		end
	end
	return 1
end

function bodyOnSpriteEvent(message, params)
	--WriteLogs("bodyOnSpriteEvent message-----"..message)
	--[[  返回事件  ]]--
	if message == MSG_RETURN then
		WriteLogs("bodyOnSpriteEvent")
		WriteLogs("FreeScene")
		FreeScene(GetCurScene())
	end	
	return 1
end

function OnSpriteEvent(message, params)
	if message == 1001 then		
		if #overwriteFile > 0 then
			for i=1,table.maxn(overwriteFile) do
				local index = overwriteFile[i]
				WriteLogs("OnSpriteEvent overwriteFile"..index)
				WriteLogs("videoDataName---"..videoDataName[index])
				os.remove(Cfg.GetDownloadPath()..videoDataName[index]..Cfg.GetVideoType())
				local result = AppendDownloadQueue(videoDataUrl[index],videoDataName[index],1)	
				if result == -1 then
					require "module.common.DownloadUpload"
					PauseOneDownloadTask(videoDataName[index], "true")
					local result = AppendDownloadQueue(videoDataUrl[index],videoDataName[index],1)				
				end
			end		
		end
		if #overwriteTask > 0 then
			for i=1,table.maxn(overwriteTask) do
				local index = overwriteTask[i]
				WriteLogs("OnSpriteEvent overwriteTask"..index)
				WriteLogs("videoDataName---"..videoDataName[index])
				require "module.common.DownloadUpload"
				PauseOneDownloadTask(videoDataName[index], "true")
				local result = AppendDownloadQueue(videoDataUrl[index],videoDataName[index],1)			
			end	
		end
		SetTimer(1, 1000, "OnTimer")
	elseif 	message == 1002 then
		WriteLogs("message 1002")
		for i=1,table.maxn(downloadTask) do
			require "module.common.DownloadUpload"
			local index = downloadTask[i]
			WriteLogs("PauseOneDownloadTask--"..index)
			PauseOneDownloadTask(videoDataName[index], "true")
		end
	end	
end

function OnTimer(idEvent)
	if idEvent == 1 then
		setDialogParam("提示", "文件已添加到下载队列", "BT_OK", sceneDownloadSelect, sceneDownloadSelect, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function LoadFileData()
	local reg = registerCreate("download_select")
	local filePath = registerGetString(reg, "filepath")
	WriteLogs("filePath---"..filePath)
	local fileName = GetLocalFilename(filePath)
	--local fileName = "CACHE:\\7682035c7f0ef125dda4ca4d7b359761.txt"
	WriteLogs("fileName---"..fileName)
	if fileName then
		local jsonString = jsonOpenFile(fileName)
		WriteLogs("jsonString---"..jsonString)
		if jsonString and jsonString ~= 0 then
			jsondata = jsonToTable(jsonString)
			CreateDownloadData(jsondata)
		end
	end
end

function CreateDownloadData(json)
	if json.path then
		programLabel = json.path
		WriteLogs("programLabel---"..programLabel)
	end
	if json.contentName then
		contentLabel = json.contentName
	end
	if json.subIds then
		volumeCount = table.maxn(json.subIds)+1
		for i = 0,volumeCount-1 do
			downloadurl[i] = json.subIds[i].downUrl
			subroName[i] = json.subIds[i].subName
		end
	end	
end

--[[-----------------------------修改人：yaoxiangyin 修改时间：2010.08.19--------------------------------------------]]--
function downloadButtonSelectKeyUp(sprite,keyCode)
	local downloadSelectReg = registerCreate("download_select") 
	registerSetInteger(downloadSelectReg,"lastFocus",sprite)
	registerSetNumber(downloadSelectReg,"lastFocusFlag",1)
	local itemList={}  --存放列表项中的Button名
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	--download-list区域内操作
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --download-list节点
	WriteLogs("@@@@@@@@@@@"..GetSpriteName(spriteList))
	local itemName = GetSpriteName(sprite)
	local itemFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	for j=0,itemCount-1 do
		itemList[j]="item-button-"..j
	end
	
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if itemList[i]==itemName then
	    itemFocusNum=i
	  end
	end
	
	if keyCode== ApKeyCode_Down then
		if itemList[itemFocusNum+1]~=nil then
			local lostFocusBackimage=FindChildSprite(GetSpriteParent(sprite),"backimage")
			SetSpriteProperty(lostFocusBackimage,"src","file:///image/DownloadSelect/item_normal.png")
			local defaultFocusButton=FindChildSprite(SpriteList_GetListItem(spriteList,itemFocusNum+1),itemList[itemFocusNum+1])
			local setFocusBackimage=FindChildSprite(GetSpriteParent(defaultFocusButton),"backimage")
			SetSpriteProperty(setFocusBackimage,"src","file:///image/DownloadSelect/item_jiaodian.png")
			SetSpriteFocus(defaultFocusButton)
		end
	elseif keyCode== ApKeyCode_Up then
		if itemList[itemFocusNum-1]~=nil then
			local lostFocusBackimage=FindChildSprite(GetSpriteParent(sprite),"backimage")
			SetSpriteProperty(lostFocusBackimage,"src","file:///image/DownloadSelect/item_normal.png")
			local defaultFocusButton=FindChildSprite(SpriteList_GetListItem(spriteList,itemFocusNum-1),itemList[itemFocusNum-1])
			local setFocusBackimage=FindChildSprite(GetSpriteParent(defaultFocusButton),"backimage")
			SetSpriteProperty(setFocusBackimage,"src","file:///image/DownloadSelect/item_jiaodian.png")
			SetSpriteFocus(defaultFocusButton)
		end
	elseif keyCode== ApKeyCode_Enter then	
		--if GetSpriteName(sprite)=="download-button" then
			--downloadButtonOnSelect(sprite)
		--else
			selectButtonOnSelect(FindChildSprite(GetSpriteParent(sprite),"select-button"))
			SetSpriteFocus(sprite)
		--end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_Right and GetSpriteName(sprite)=="item-button-0" then
		local downloadButtonSprite=FindChildSprite(GetParentSprite(sprite),"download-button")
		SetSpriteFocus(downloadButtonSprite)
		local lostFocusBackimage=FindChildSprite(GetSpriteParent(sprite),"backimage")
		SetSpriteProperty(lostFocusBackimage,"src","file:///image/DownloadSelect/item_normal.png")
	--elseif keyCode == ApKeyCode_Left and GetSpriteName(sprite)=="download-button" then
		--WriteLogs("@@@@@@@@@@@@########$$$$$$$$$$$i can come in this block")
		--local downloadItemSprite=FindChildSprite(GetParentSprite(sprite),"item-button-0")
		--SetSpriteFocus(downloadItemSprite)
		--local lostFocusBackimage=FindChildSprite(GetSpriteParent(sprite),"backimage")
		--SetSpriteProperty(lostFocusBackimage,"src","file:///image/DownloadSelect/item_jiaodian.png")
	end
end

--下载按钮键盘操作
function downloadButtonKeyUp(sprite,keyCode)
	local downloadSelectReg = registerCreate("download_select") 
	registerSetInteger(downloadSelectReg,"lastFocus",sprite)
	registerSetNumber(downloadSelectReg,"lastFocusFlag",1)
	if keyCode == ApKeyCode_Left then
		local downloadItemSprite=FindChildSprite(GetParentSprite(sprite),"item-button-0")
		SetSpriteFocus(downloadItemSprite)
		local setFocusBackimage=FindChildSprite(GetSpriteParent(sprite),"backimage")
		SetSpriteProperty(setFocusBackimage,"src","file:///image/DownloadSelect/item_jiaodian.png")
	elseif keyCode == ApKeyCode_Down then
		local downloadItemSprite=FindChildSprite(SpriteList_GetListItem(GetParentSprite(GetParentSprite(sprite)),1),"item-button-1")
		SetSpriteFocus(downloadItemSprite)
		local setFocusBackimage=FindChildSprite(GetSpriteParent(downloadItemSprite),"backimage")
		SetSpriteProperty(setFocusBackimage,"src","file:///image/DownloadSelect/item_jiaodian.png")
		local lostFocusBackimage=FindChildSprite(GetSpriteParent(sprite),"backimage")
		SetSpriteProperty(lostFocusBackimage,"src","file:///image/DownloadSelect/item_normal.png")
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode== ApKeyCode_Enter then
		local reg = registerCreate("download_select")   
		registerSetInteger(reg, "lastFocus", sprite)
		downloadButtonOnSelect(sprite)
	end
	
end
---------------------------------------------------------------------------------
