--author ljc
--date	2010/06/01
-- request navigation
function RequestNavigation(protocolNumber, navigationUrl)
	local regSystem = registerCreate("System")
	local http = pluginCreate("HttpPipe")
	--local http = registerGetInteger(regSystem, "comHttpPipe")
	-- if http == nil or http == 0 then
		-- http = pluginCreate("HttpPipe")
		-- registerSetInteger(regSystem, "comHttpPipe", http)
	-- end

	local reg = registerCreate("navigation")
	local fileName = GetLocalFilename(navigationUrl)
	registerSetString(reg, "navigationFileName", fileName)

	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, navigationUrl, "", fileName, observer, protocolNumber, 0, 0)

end

function OnNavigationDecode()
	local reg = registerCreate("navigation")
	local fileName = registerGetString(reg, "navigationFileName")
	if fileName ~= nil and fileName ~= "" then
		WriteLogs("OnNavigationDecode cache = "..fileName);
		return jsonLoadFile(fileName)
	end
	return nil
end

function NavigationData()
	local reg = registerCreate("navigation")
	local json = registerGetInteger(reg, "navigationNetwork")
	if not json or json == 0 then
		return LoadChannelGroupData()
	end
	return json
end

function LoadNavigationData()
	local reg = registerCreate("navigation")
	local fileName = registerGetString(reg, "navigationFileName")
	if fileName then
		local jsonString = jsonOpenFile(fileName)
		if jsonString and jsonString ~= 0 then
			registerSetInteger(reg, "navigationNetwork", jsonString)
			return jsonString
		else
			registerSetInteger(reg, "navigationNetwork", 0)
		end
	end
	return nil
end

--�÷������ͷű����Json����
function ReleaseNavigationData()
	local reg = registerCreate("navigation")
	local jsonNetworkData = registerGetInteger(reg, "navigationNetwork")
	if jsonNetworkData ~= 0 then
		jsonRelease(jsonNetworkData)
		registerSetInteger(reg, "navigationNetwork", 0)
	end
end
