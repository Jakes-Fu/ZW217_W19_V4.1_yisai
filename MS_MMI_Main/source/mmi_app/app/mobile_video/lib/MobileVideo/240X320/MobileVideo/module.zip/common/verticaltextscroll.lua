﻿--@module VerticalTextScroll
--@note 文字标签垂直切换滚动
--@author cuiyizhou
--@date 2010/11/01
TextList = {}
function CreateVerticalTextScroll(buttonSprite,normalSpriteName,focusSpriteName,tempTable,subName)
	CreateTextList(tempTable,subName)
	normalSprite = FindChildSprite(buttonSprite,normalSpriteName)
	normalSpritebk = FindChildSprite(buttonSprite,normalSpriteName.."_bk")
	focusSprite = FindChildSprite(buttonSprite,focusSpriteName)
	focusSpritebk = FindChildSprite(buttonSprite,focusSpriteName.."_bk")
	l_TextScroll,t_TextScroll,w_TextScroll,h_TextScroll = GetSpriteRect(normalSprite)
	t_TextScroll = 0
	SetSpriteVisible(normalSpritebk,0)
	SetSpriteVisible(focusSpritebk,0)
	SetSpriteRect(normalSprite,l_TextScroll,0,w_TextScroll,h_TextScroll)
	SetSpriteRect(focusSprite,l_TextScroll,0,w_TextScroll,h_TextScroll)
	SetSpriteRect(normalSpritebk,l_TextScroll,0+h_TextScroll,w_TextScroll,h_TextScroll)
	SetSpriteRect(focusSpritebk,l_TextScroll,0+h_TextScroll,w_TextScroll,h_TextScroll)
	local reg = registerCreate("VerticalTextScroll")
	registerSetInteger(reg, "CurIndex",0)
	CancelTimer(1)
	SetTimer(1,3000,"VerticalTextScroll")
end

function VerticalTextScroll()
	if ScrollTimes == nil then
		ScrollTimes = 0
	end
	local reg = registerCreate("VerticalTextScroll")
	local Index = registerGetInteger(reg, "CurIndex")
	if Index == 0 then
		SetSpriteProperty(normalSpritebk,"text",TextList[1])
		SetSpriteProperty(focusSpritebk,"text",TextList[1])
	end
	SetSpriteVisible(normalSpritebk,1)
	SetSpriteVisible(focusSpritebk,1)
	SetSpriteRect(normalSprite,l_TextScroll,t_TextScroll-h_TextScroll*(ScrollTimes+1)/8,w_TextScroll,h_TextScroll)
	SetSpriteRect(normalSpritebk,l_TextScroll,t_TextScroll+h_TextScroll-h_TextScroll*(ScrollTimes+1)/8,w_TextScroll,h_TextScroll)
	SetSpriteRect(focusSprite,l_TextScroll,t_TextScroll-h_TextScroll*(ScrollTimes+1)/8,w_TextScroll,h_TextScroll)
	SetSpriteRect(focusSpritebk,l_TextScroll,t_TextScroll+h_TextScroll-h_TextScroll*(ScrollTimes+1)/8,w_TextScroll,h_TextScroll)
	ScrollTimes = ScrollTimes + 1
	if ScrollTimes > 8 then
		ScrollTimes = 0
		SetSpriteRect(normalSprite,l_TextScroll,t_TextScroll,w_TextScroll,h_TextScroll)
		SetSpriteRect(focusSprite,l_TextScroll,t_TextScroll,w_TextScroll,h_TextScroll)
		SetSpriteVisible(normalSpritebk,0)
		SetSpriteVisible(focusSpritebk,0)
		SetTimer(1,3000,"VerticalTextScroll")
		if Index == table.maxn(TextList) then 
			registerSetInteger(reg, "CurIndex",0)
			SetSpriteProperty(normalSprite,"text",TextList[0])
			SetSpriteProperty(focusSprite,"text",TextList[0])
		else
			registerSetInteger(reg, "CurIndex",Index+1)
			SetSpriteProperty(normalSprite,"text",TextList[Index+1])
			SetSpriteProperty(focusSprite,"text",TextList[Index+1])
		end
			
		if Index+1 == table.maxn(TextList) then 
			SetSpriteProperty(normalSpritebk,"text",TextList[0])
			SetSpriteProperty(focusSpritebk,"text",TextList[0])
		elseif Index == table.maxn(TextList) then
			SetSpriteProperty(normalSpritebk,"text",TextList[1])
			SetSpriteProperty(focusSpritebk,"text",TextList[1])
		else
			SetSpriteProperty(normalSpritebk,"text",TextList[Index+2])
			SetSpriteProperty(focusSpritebk,"text",TextList[Index+2])
		end
	else
		SetTimer(1,80,"VerticalTextScroll")
	end
end

function CreateTextList(tempTable,subName)
	if tempTable then
		local num = table.maxn(tempTable)
		for i=0,num do
			if tempTable[i][subName] ~= "" then
				TextList[i] = tempTable[i][subName]
			end
		end
	end
end
