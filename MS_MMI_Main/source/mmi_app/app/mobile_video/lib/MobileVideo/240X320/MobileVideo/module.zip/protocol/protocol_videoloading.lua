--RequestVideo请求播放函数
--protocolNumbers 	----监听号
--palyurl			----视频请求地址，本地播放器为视频名称
--pathurl 			----视频详情请求地址,本地播放为任意字符串
--videoName			----视频节目名称
--videoType			----播放类型 "local"--本地播放 流媒体播放为任意字符串
--外部调整页面调用
function RequestVideo(protocolNumber, playurl, pathurl, videoName, videoType)
	local reg = registerCreate("video")
	if videoType == "local" then
		--[[  直接跳转本地播放  ]]--
	else
		local fileName = GetLocalFilename(playurl)
		registerSetString(reg, "videoFileName", fileName)
		registerSetString(reg, "videoType", videoType)
		registerSetString(reg, "playurl", playurl)
		registerSetString(reg, "pathurl", pathurl)
		registerSetString(reg, "videoName", videoName)
		local observer = pluginGetObserver()
		local regSystem = registerCreate("System")
		local http = registerGetInteger(regSystem, "comHttpPipe")
		pluginInvoke(http, "AppendCommand", 0, playurl, 0, fileName, observer, protocolNumber, 0,1)
	end
end

function RequestHistoryVideo(protocolNumber, playurl, pathurl, videoName, videoType)
	local reg = registerCreate("video")
	if videoType == "local" then
		registerSetString(reg, "localUrl1", playurl)
		registerSetInteger(reg, "videoCount", 1)
		registerSetInteger(reg, "curVideo", 1)
		registerSetString(reg, "videoName", videoName)
		registerSetString(reg, "videoType", videoType)
	else
		local fileName = GetLocalFilename(playurl)
		local reg = registerCreate("video")
		registerSetString(reg, "videoFileName", fileName)
		registerSetString(reg, "videoType", videoType)
		registerSetString(reg, "playurl", playurl)
		registerSetString(reg, "pathurl", pathurl)
		registerSetString(reg, "videoName", videoName)
		local observer = pluginGetObserver()
		pluginInvoke(http, "AppendCommand", 0, playurl, 0, fileName, observer, protocolNumber, 0,1)
	end
end

--读取历史记录
--由播放器页面与历史记录页面共同维护
function LoadHistoryVideoList()
	require ("module.setting")
	local regVideoList = registerCreate("historyVideoList")
	local filename = Cfg.GetTempPath("history.xml")
	registerLoad(regVideoList, filename)
	count = registerGetInteger(regVideoList, "historyItemCount")
	if count ~= nil then
		for i=1, count do
			local strData = registerGetString(regVideoList, "history"..i)
			_,j = string.find(strData,"},{")
			historyplayurl[i],j = FindNextProperty(strData,j)
			historypathurl[i],j = FindNextProperty(strData,j)
			historydate[i],j = FindNextProperty(strData,j)
			historyname[i],j = FindNextProperty(strData,j)
			historyvideoType[i],j = FindNextProperty(strData,j)
			historyIsReview[i],j = FindNextProperty(strData,j)
		end
	end
	registerRelease("historyVideoList")
end

function FindNextProperty(str,startIndex)
	local k = string.find(str,"{",startIndex)
	local l = string.find(str,"}",startIndex)
	local returnData = string.sub(str,k+1,l-1)
	if returnData == nil then returnData = "" end
	return returnData,l+2
end

function OnVideoDecode()
	local reg = registerCreate("video")
	local filename = registerGetString(reg, "videoFileName")
	local json = jsonLoadFile(filename)
	if json ~= nil and json ~= "" then
		return json
	end
end

function RequestDownloadVideo(protocolNumber, downloadurl)
	local regSystem = registerCreate("System")
	http = registerGetInteger(regSystem, "comHttpPipe")
	local fileName = GetLocalFilename(downloadurl)
	local reg = registerCreate("video")
	registerSetString(reg, "videoDownloadFileName", fileName)
	
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, downloadurl, 0, fileName, observer, protocolNumber, 0,1)
end

function OnDownloadVideoDecode()
	local reg = registerCreate("video")
	local filename = registerGetString(reg, "videoDownloadFileName")	
	local json = jsonLoadFile(filename)
	if json ~= nil and json ~= "" then
		return json
	else
		WriteLogs("that json file is nil !!!!!!!!!!");
	end
end

function FreeVideoLoadingFuncs()
	RequestVideo = nil
	OnVideoDecode = nil
end
