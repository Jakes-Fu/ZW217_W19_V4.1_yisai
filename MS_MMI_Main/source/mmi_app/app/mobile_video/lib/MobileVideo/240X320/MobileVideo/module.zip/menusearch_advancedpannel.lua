﻿require "module.keyCode.keyCode"
function bodyAdvancedPannelFinished(sprite)
	local reg_a = registerCreate("advancedsearch")
	registerSetInteger(reg_a, "advancedpannelroot",sprite)
	local combobox1text = registerGetString(reg_a, "combobox1text")
	local combobox2text = registerGetString(reg_a, "combobox2text")
	if combobox1text and combobox1text ~= "" then
		local combobox1sprite = FindChildSprite(sprite,"combobox1text")
		SetSpriteProperty(combobox1sprite,"text",combobox1text)
	end
	if combobox2text and combobox2text ~= "" then
		local combobox2sprite = FindChildSprite(sprite,"combobox2text")
		SetSpriteProperty(combobox2sprite,"text",combobox2text)
	end
end

function combobox1OnSelect(sprite)
	local comboListFrame = FindChildSprite(GetCurScene(),"comboListFrame")
	local comboList1 = FindChildSprite(comboListFrame,"comboList1")
	local a,b,c,d = GetSpriteRect(sprite)
	SetSpriteRect(comboListFrame,a,b+d,c,d*6)
	SetSpriteRect(comboList1,0,0,c,d*6)
	local temptable = {"全部","按分类","按品牌"}
	CreateComboboxItems(comboList1,temptable)
	SetSpriteEnable(comboList1,1)
	SetSpriteVisible(comboList1,1)
	local hidecombolist_upper = FindChildSprite(GetCurScene(),"hidecombolist_upper")
	local hidecombolist_lower = FindChildSprite(GetCurScene(),"hidecombolist_lower")
	SetSpriteEnable(hidecombolist_upper,1)
	SetSpriteEnable(hidecombolist_lower,1)
	local reg_m = registerCreate("advancedsearch")
	registerSetInteger(reg_m, "comboboxIndex",1)
end

function combobox2OnSelect(sprite)
	local comboListFrame = FindChildSprite(GetCurScene(),"comboListFrame")
	local comboList1 = FindChildSprite(comboListFrame,"comboList1")
	local a,b,c,d = GetSpriteRect(sprite)
	local Combobox1Text = GetCombobox1Text(text)
	local temptable = {}
	if Combobox1Text == "全部" then
		temptable = {"全部"}
	elseif Combobox1Text == "按分类" then
		table.insert(temptable,"全部")
		require "module.protocol.protocol_home"
		HomeNetworkData()
		local jsontable = LoadJsonHomeNetworkData()
		ReleaseHomeNetworkData()
		local reg_m = registerCreate("advancedsearch")
		for i=0,table.maxn(jsontable.specialChannel) do
			if jsontable.specialChannel and jsontable.specialChannel[i] and jsontable.specialChannel[i].channelName then
				table.insert(temptable,jsontable.specialChannel[i].channelName)
				registerSetString(reg_m, jsontable.specialChannel[i].channelName,jsontable.specialChannel[i].channelId)
			end
		end
	elseif Combobox1Text == "按品牌" then
		table.insert(temptable,"全部")
		require "module.protocol.protocol_home"
		HomeNetworkData()
		local jsontable = LoadJsonHomeNetworkData()
		ReleaseHomeNetworkData()
		local reg_m = registerCreate("advancedsearch")
		for i=0,table.maxn(jsontable.channel) do
			if jsontable.channel and jsontable.channel[i] and jsontable.channel[i].channelName then
				table.insert(temptable,jsontable.channel[i].channelName)
				registerSetString(reg_m,jsontable.channel[i].channelName,jsontable.channel[i].channelId)
			end
		end
	end
	SetSpriteRect(comboListFrame,a,b+d,c,(d-1)*6)
	SetSpriteRect(comboList1,0,0,c,d*table.maxn(temptable))
	CreateComboboxItems(comboList1,temptable)
	SetSpriteEnable(comboList1,1)
	SetSpriteVisible(comboList1,1)
	local hidecombolist_upper = FindChildSprite(GetCurScene(),"hidecombolist_upper")
	local hidecombolist_lower = FindChildSprite(GetCurScene(),"hidecombolist_lower")
	SetSpriteEnable(hidecombolist_upper,1)
	SetSpriteEnable(hidecombolist_lower,1)
	local reg_m = registerCreate("advancedsearch")
	registerSetInteger(reg_m, "comboboxIndex",2)
end

function combobox1ItemOnSelect(sprite)
	local rootSprite = GetCurScene()
	local gettext = FindChildSprite(sprite,"comboboxitem_textn")
	local text = GetSpriteText(gettext)
	local reg_m = registerCreate("advancedsearch")
	local flag = registerGetInteger(reg_m, "comboboxIndex")
	if flag == 1 then
		local combobox1Sprite = FindChildSprite(rootSprite,"combobox1")
		SetCombobox1Text(text)
		SetCombobox2Text("全部")
		SetSpriteFocus(combobox1Sprite)
	elseif flag == 2 then
		local combobox2Sprite = FindChildSprite(rootSprite,"combobox2")
		SetCombobox2Text(text)
		SetSpriteFocus(combobox2Sprite)
	end
	HideComboboxlist()
end

function SetCombobox1Text(text)
	local comboboxtext = FindChildSprite(GetCurScene(),"combobox1text")
	SetSpriteProperty(comboboxtext,"text",text)
	local reg_a = registerCreate("advancedsearch")
	registerSetString(reg_a, "combobox1text",text)
end

function GetCombobox1Text(text)
	local comboboxtext = FindChildSprite(GetCurScene(),"combobox1text")
	return GetSpriteText(comboboxtext)
end

function SetCombobox2Text(text)
	local combobox2text = FindChildSprite(GetCurScene(),"combobox2text")
	SetSpriteProperty(combobox2text,"text",text)
	local reg_a = registerCreate("advancedsearch")
	registerSetString(reg_a, "combobox2text",text)
end

function CreateComboboxItems(listsprite,textTable)
	local itemCount = SpriteList_GetListItemCount(listsprite)
	if itemCount ~= 0 then
		SpriteList_ClearListItem(listsprite, 1, 1)
	end
	local itemCount = table.maxn(textTable)
	if tempTable ~= textTable then
		tempTable = textTable
		SpriteList_LoadListItem(listsprite, "MODULE:\\menusearch_comboboxitem.xml", itemCount, "CreateComboboxItemcallback")
		SpriteList_Adjust(listsprite)
	end
	
	--------将焦点设在下拉列表的第一个元素上---------
	local spriteItemStart = SpriteList_GetListItem(listsprite, 0)
	local searchButtonSprite = FindChildSprite(spriteItemStart,"searchButton")
	SetSpriteFocus(searchButtonSprite)
	
	-------------------------------------------------
	
	local index = SpriteList_GetListItemCount(listsprite)
	if index > 6 then
		require "module.common.commonScroll"
		CreateScrollBar(GetCurScene(),"comboList1",index*20,50)
	else
		require "module.common.commonScroll"
		HideScrollArea()
	end
end

function CreateComboboxItemcallback(spriteList, spriteItem, index)
	local searchButton = FindChildSprite(spriteItem,"searchButton")
	local a,b,c,d = GetSpriteRect(searchButton)
	SetSpriteRect(spriteItem,a,b,c,d+1)
	local text1 = FindChildSprite(spriteItem,"comboboxitem_textn")
	local text2 = FindChildSprite(spriteItem,"comboboxitem_textf")
	SetSpriteProperty(text1,"text",tempTable[index+1])
	SetSpriteProperty(text2,"text",tempTable[index+1])
end

function HideComboboxlist()
	local comboList1 = FindChildSprite(GetCurScene(),"comboList1")
	SetSpriteEnable(comboList1,0)
	SetSpriteVisible(comboList1,0)
	local hidecombolist_upper = FindChildSprite(GetCurScene(),"hidecombolist_upper")
	local hidecombolist_lower = FindChildSprite(GetCurScene(),"hidecombolist_lower")
	SetSpriteEnable(hidecombolist_upper,0)
	SetSpriteEnable(hidecombolist_lower,0)
	require "module.common.commonScroll"
	HideScrollArea()
end

function comboboxKeyUp(sprite,keyCode)
	local spriteName = GetSpriteName(sprite)
	if keyCode == ApKeyCode_Up then
		local rootSprite =GetCurScene()
		local closeadvanced =FindChildSprite(rootSprite,"closeadvanced")
		SetSpriteFocus(closeadvanced)
	elseif keyCode == ApKeyCode_Right then
		if spriteName == "combobox1" then
			SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite),"combobox2"))
		end
	elseif keyCode == ApKeyCode_Left then
		if spriteName == "combobox2" then
			SetSpriteFocus(FindChildSprite(GetSpriteParent(sprite),"combobox1"))
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	else
		return 0
	end
end

function comboboxItemKeyUp(sprite,keyCode)
	local listItem = GetSpriteParent(sprite)
	local item_x,item_y,item_w,item_h=GetSpriteRect(listItem)
	local list = GetSpriteParent(listItem)
	local list_x,list_y,list_w,list_h=GetSpriteRect(list)
	local index = SpriteListItem_GetIndex(listItem)
	local y = item_y + list_y
	if keyCode == ApKeyCode_Up then
		if index ~= 0 then
			if y == 0 then
				SetSpriteRect(list,list_x,list_y+20,list_w,list_h)
				ChangeScrollPositon(listItem,"up")
			end
			local preItem = SpriteList_GetListItem(list, index-1)
			local searchButton = FindChildSprite(preItem,"searchButton")
			if searchButton ~= "" then
				SetSpriteFocus(searchButton)
			end
		end
	elseif keyCode == ApKeyCode_Down then
		if index ~= SpriteList_GetListItemCount(list)-1 then
			if y == (6-1)*20 then
				SetSpriteRect(list,list_x,list_y-20,list_w,list_h)
				ChangeScrollPositon(listItem,"down")
			end
			local nextItem = SpriteList_GetListItem(list, index+1)
			local searchButton = FindChildSprite(nextItem,"searchButton")
			if searchButton ~= "" then
				SetSpriteFocus(searchButton)
			end
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	else
		return 0
	end
end

--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local CurIndex = SpriteListItem_GetIndex(sprite)
	require "module.common.commonScroll"
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,6-1,0)
	else
		ScrollBarAdjust(CurIndex + 1,6-1,1)
	end
end