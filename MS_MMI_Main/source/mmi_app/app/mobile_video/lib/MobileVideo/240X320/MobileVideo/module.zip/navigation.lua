require "module.Loading.useLoading"
require "module.protocol.protocol_navigation"
require "module.protocol.protocol_navigationdetail"
require "module.protocol.protocol_infolabel"
require "module.protocol.protocol_infolist"
require "module.common.registerScene"
require "module.common.SceneUtils"
require "module.keyCode.keyCode"

local NAVIGATION = "navigation"
local NAVIGATIONDETAIL = "navigationdetail"
local MENUPROGRAMINFO_LABEL = "menuprograminfo_label"

navigation_ButtonWidth = 100
navigation_ButtonHeight = 20
-- local BUTTON_WIDTH = 100
-- local BUTTON_HEIGHT = 20
local SORT_BROWSE_COUNT = 6
local HOT_RECOMMEND_COUNT = 8
local SORT_BROWSE_PAGE_COUNT = 0 		--��������ܹ�ҳ��
local SORT_BROWSE_PAGE_CUR = 0  		 --���������ǰ����ҳ,Ĭ��ѡ��Ϊ��һҳ
local SORT_BROWSE_ROW = 4	 	  		 --���������
local SORT_BROWSE_COL = 2  			--���������
local HOT_RECOMMEND_PAGE_COUNT = 0 	--�����Ƽ��ܹ�ҳ��
local HOT_RECOMMEND_PAGE_CUR = 0  	--�����Ƽ���ǰ����ҳ,Ĭ��ѡ��Ϊ��һҳ
local HOT_RECOMMEND_ROW = 4	 		--�����Ƽ���
local HOT_RECOMMEND_COL = 2  			--�����Ƽ���



function bodyBuildChildrenFinished(sprite)
	regCreate = registerCreate(NAVIGATION)
	registerSetInteger(regCreate, "root", sprite)
	--����
	--http = pluginCreate("HttpPipe", "myhttp1")
	--observer = pluginGetObserver()
	
	--�������������ص�����
	createNavigationData()
	--��̬������Ŀ��ǩ
	createColumnLabel()
	--��������Ԫ��
	createSortBrowse()
	createHotRecommend()
	--��ҳ�İ�ť�Ƿ���ò���
	arrowSortBroseHasVisible()
	arrowHotRecommendHasVisible()
	return 1
end

--��̬������Ŀ��ǩ
function createColumnLabel()
	--[[  ��ȡ���ڵ� ]]--
	local root = registerGetInteger(regCreate, "root")
	
	--[[  ���ݻ��� ]]--
	local sprite = FindChildSprite(root , "info-content-caption")
	SetSpriteProperty(sprite,"text",infoContentCaption)	
end

--��̬���������������
function createSortBrowse()
--[[----------------------------------------------------------------]]--
	pageIndexReg= registerCreate("pageIndex")
	registerSetNumber(pageIndexReg,"browsePageIndex",0)
------------------------------------------------------------------------	
	if sortBrowseDataArray and 0 ~= #sortBrowseDataArray then
		local sprite = registerGetInteger(regCreate, "root")
		local spriteList = FindChildSprite(sprite, "sort-browse-list")
		
		local n = #sortBrowseDataArray
		for i=0, n do
			
			local SortBrowseSprite = CreateSprite("listitem")
			LoadSprite(SortBrowseSprite, "MODULE:\\navigationlist.xml")
			SetSpriteRect(SortBrowseSprite, 0, 0, navigation_ButtonWidth-4, navigation_ButtonHeight)
			
			--��̬������ť����������ѡ�кͷ�ѡ������
			local spriteButton = FindChildSprite(SortBrowseSprite, "buttonChangeName")
			SetSpriteProperty(spriteButton, "OnSelect", "OnSelectFromSortBrowseButton")
--[[------------------------------�޸��ˣ�yaoxiangyin �޸����ڣ�2010.08.12----------------------------------]]--
			SetSpriteProperty(spriteButton, "name", string.format("browse-button-%d", i))
			SetSpriteProperty(spriteButton, "OnKeyUp","navigationButtonBrowseOnKeyUp")
----------------------------------------------------------------------------------------------------------------			
			SetSpriteRect(spriteButton, 0, 0,navigation_ButtonWidth,navigation_ButtonHeight)
			
			local spriteImageNormal = FindChildSprite(SortBrowseSprite, "img_n")
			SetSpriteRect(spriteImageNormal, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			local spriteImageForcus = FindChildSprite(SortBrowseSprite, "img_f")
			SetSpriteRect(spriteImageForcus, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			--��̬������ť������Ϣ
			local spriteLabel = FindChildSprite(SortBrowseSprite, "navigationlist-label")
			local spriteLabel1 = FindChildSprite(SortBrowseSprite, "navigationlist-label1")	
			SetSpriteProperty(spriteLabel, "text", sortBrowseDataArray[i].channelName)
			SetSpriteProperty(spriteLabel1, "text", sortBrowseDataArray[i].channelName)
			SetSpriteRect(spriteLabel, GetSpriteRect(SortBrowseSprite))
			SetSpriteRect(spriteLabel1, GetSpriteRect(SortBrowseSprite))
			AddChildSprite(spriteList, SortBrowseSprite)
			SpriteList_AddListItem(spriteList, SortBrowseSprite)
					
		end
		
		SpriteList_Adjust(spriteList)
--[[------------------------------�޸��ˣ�yaoxiangyin �޸����ڣ�2010.08.12----------------------------------]]--
			local defaultFocusButton
			defaultFocusButton=FindChildSprite(SpriteList_GetListItem(spriteList,0),"browse-button-0") 
			SetSpriteFocus(defaultFocusButton)
----------------------------------------------------------------------------------------------------------------
	end	
end


--��̬���������Ƽ�����
function createHotRecommend()
--[[----------------------------------------------------------------]]--
	pageIndexReg= registerCreate("pageIndex")
	registerSetNumber(pageIndexReg,"recommendPageIndex",0)
------------------------------------------------------------------------
	if hotRecommendDataArray then -- and 0 ~= #hotRecommendDataArray then
		local sprite = registerGetInteger(regCreate, "root")
		local spriteList = FindChildSprite(sprite, "hot-recommed-list")
		
		--local n = #hotRecommendDataArray
		local n = table.maxn( hotRecommendDataArray );
		
		WriteLogs("createHotRecommend = "..n);
		
		for i=0, n do
		    --WriteLogs("i = "..i);
			--WriteLogs("channelName = "..hotRecommendDataArray[i].contentName );
		
			local hotRecommedSprite = CreateSprite("listitem")
			LoadSprite(hotRecommedSprite, "MODULE:\\navigationlist.xml")
			SetSpriteRect(hotRecommedSprite, 0, 0, navigation_ButtonWidth-4, navigation_ButtonHeight)
			
			--��̬������ť����������ѡ�кͷ�ѡ������
			local spriteButton = FindChildSprite(hotRecommedSprite, "buttonChangeName")
			SetSpriteProperty(spriteButton, "OnSelect", "OnSelectFromHotRecommedButton")
--[[------------------------------�޸��ˣ�yaoxiangyin �޸����ڣ�2010.08.12----------------------------------]]--
			SetSpriteProperty(spriteButton, "name", string.format("recommend-button-%d", i))
			SetSpriteProperty(spriteButton, "OnKeyUp","navigationButtonRecommendOnKeyUp")
----------------------------------------------------------------------------------------------------------------				
			SetSpriteRect(spriteButton, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			local spriteImageNormal = FindChildSprite(hotRecommedSprite, "img_n")
			SetSpriteRect(spriteImageNormal, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			local spriteImageForcus = FindChildSprite(hotRecommedSprite, "img_f")
			SetSpriteRect(spriteImageForcus, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			--��̬������ť������Ϣ
			local spriteLabel = FindChildSprite(hotRecommedSprite, "navigationlist-label")
			local spriteLabel1 = FindChildSprite(hotRecommedSprite, "navigationlist-label1")	
			SetSpriteProperty(spriteLabel, "text", hotRecommendDataArray[i].contentName)
			SetSpriteProperty(spriteLabel1, "text", hotRecommendDataArray[i].contentName)
			SetSpriteRect(spriteLabel, GetSpriteRect(hotRecommedSprite))
			SetSpriteRect(spriteLabel1, GetSpriteRect(hotRecommedSprite))
			AddChildSprite(spriteList, hotRecommedSprite)
			SpriteList_AddListItem(spriteList, hotRecommedSprite)
		end
		
		SpriteList_Adjust(spriteList)
	end
end

function OnSelectFromSortBrowseButton(sprite)
	SetSpriteFocus(sprite)
	local name = GetSpriteName(sprite)
	if name == "buttonChangeName" then
		local root = registerGetInteger(regCreate, "root")
		local nodeLoading = FindChildSprite(root, "loadarea")
		enterLoading(nodeLoading)		
		local spriteListItem = GetSpriteParent(sprite)
		nSelSrotBrowseIndex = SpriteListItem_GetIndex(spriteListItem)	
		RequestNavigationDetail(101, sortBrowseDataArray[nSelSrotBrowseIndex].urlPath)		
	end
end

function OnSelectFromHotRecommedButton(sprite)
	SetSpriteFocus(sprite)
	local name = GetSpriteName(sprite)
	if name == "buttonChangeName" then
		local root = registerGetInteger(regCreate, "root")
		local nodeLoading = FindChildSprite(root, "loadarea")
		enterLoading(nodeLoading)		
		local spriteListItem = GetSpriteParent(sprite)
		local nSelHotRecommendIndex = SpriteListItem_GetIndex(spriteListItem)
		if hotRecommendDataArray[nSelHotRecommendIndex].category == "1" then
			RequestVolume(102, hotRecommendDataArray[nSelHotRecommendIndex].urlPath)
		else
			if hotRecommendDataArray[nSelHotRecommendIndex].formType == "1" then
				Requestlabel(102, hotRecommendDataArray[nSelHotRecommendIndex].urlPath)
			elseif hotRecommendDataArray[nSelHotRecommendIndex].formType == "2" then
				RequestList(103, hotRecommendDataArray[nSelHotRecommendIndex].urlPath)
			end
		end
	end
end

function createNavigationData()
	local json = OnNavigationDecode()
	--[[--test data--]]
	--fileName = "MODULE:\\cache\\15e7506e9d854d467a7676bdb588f5c1.txt"
	--local json = jsonLoadFile(fileName)
	--���������صķ����������
	sortBrowseDataArray = {}	
	if (json.category1 ~= nil) then
		local cotegory1Count = table.maxn(json.category1)
		for i=0, cotegory1Count do	
			sortBrowseDataArray[i] = {
				channelId  	 	= json.category1[i].channelId,
				channelName 	= json.category1[i].channelName,
				urlPath		 	= json.category1[i].urlPath,
			}
		end
	SORT_BROWSE_PAGE_COUNT = (cotegory1Count / SORT_BROWSE_COUNT)
	SORT_BROWSE_PAGE_COUNT = math.floor(SORT_BROWSE_PAGE_COUNT)
	end
	--���������ص������Ƽ�����	
	hotRecommendDataArray = {}	
	if (json.category2 ~= nil) then
		local cotegory2Count = table.maxn(json.category2)
		for i=0, cotegory2Count do	
			hotRecommendDataArray[i] = {
				contentId 		= json.category2[i].contentId,
				contentName 	= json.category2[i].contentName,
				category 		= json.category2[i].category,
				formType 		= json.category2[i].formType,
				displayType 	= json.category2[i].displayType,
				urlPath 		= json.category2[i].urlPath,
			}

		end	
		HOT_RECOMMEND_PAGE_COUNT = (cotegory2Count / HOT_RECOMMEND_COUNT)
		HOT_RECOMMEND_PAGE_COUNT = math.floor(HOT_RECOMMEND_PAGE_COUNT)
	end
	--��Ŀ��ǩ����
	if (json.path ~= nil) then
		infoContentCaption = json.path
	end
end

function bodyOnPluginEvent(message, param)
	require "module.videoexpress-common"
	if message == 101 then
		local regNavigationDetail =registerCreate(NAVIGATIONDETAIL)
		registerSetString(regNavigationDetail, "browseChannelName", sortBrowseDataArray[nSelSrotBrowseIndex].channelName)
		exitLoading()
		SetReturn(sceneNavigation, sceneNavigationDetail)
		FreeScene(FindScene(sceneNavigationDetail))
		Go2Scene(sceneNavigationDetail)
	elseif message == 102 then
		exitLoading()
		SetReturn(sceneNavigation, scenePrograminfo_label)
		Go2Scene(scenePrograminfo_label)
	elseif message == 103 then
		exitLoading()
		SetReturn(sceneNavigationDetail, scenePrograminfo_list)
		GoAndFreeScene(scenePrograminfo_list)
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneNavigation, sceneNavigation)
	end
	
end

--�����������ҳ��ť
function btnSortBrowseLeftOnSelect()
	if SORT_BROWSE_PAGE_CUR > 0 then
		SORT_BROWSE_PAGE_CUR = SORT_BROWSE_PAGE_CUR - 1
		registerSetNumber(pageIndexReg,"browsePageIndex",(registerGetInteger(pageIndexReg, "browsePageIndex")-1))
		refurbishSortBrowseList()
	end
end

--����������ҷ�ҳ��ť
function btnSortBrowseRightOnSelect()
	WriteLogs(",SORT_BROWSE_PAGE_CUR="..SORT_BROWSE_PAGE_CUR..",HOT_RECOMMEND_PAGE_COUNT="..HOT_RECOMMEND_PAGE_COUNT)
	if SORT_BROWSE_PAGE_CUR < SORT_BROWSE_PAGE_COUNT then
		SORT_BROWSE_PAGE_CUR = SORT_BROWSE_PAGE_CUR + 1
		registerSetNumber(pageIndexReg,"browsePageIndex",(registerGetInteger(pageIndexReg, "browsePageIndex")+1))
		refurbishSortBrowseList()
	end
end

--�����Ƽ�����ҳ��ť
function btnHotRecommendLeftOnSelect()
	if HOT_RECOMMEND_PAGE_CUR > 0 then
		HOT_RECOMMEND_PAGE_CUR = HOT_RECOMMEND_PAGE_CUR - 1
		registerSetNumber(pageIndexReg,"recommendPageIndex",(registerGetInteger(pageIndexReg, "recommendPageIndex")-1))
		refurbishHotRecommendList()
	end
end

--�����Ƽ����ҷ�ҳ��ť
function btnHotRecommendRightOnSelect()
	if HOT_RECOMMEND_PAGE_CUR < HOT_RECOMMEND_PAGE_COUNT then
		HOT_RECOMMEND_PAGE_CUR = HOT_RECOMMEND_PAGE_CUR + 1
		registerSetNumber(pageIndexReg,"recommendPageIndex",(registerGetInteger(pageIndexReg, "recommendPageIndex")+1))
		refurbishHotRecommendList()
	end
end

function refurbishSortBrowseList()
	arrowSortBroseHasVisible()
	local root = registerGetInteger(regCreate, "root")
	local groupbtnsSprite = FindChildSprite(root,"sort-browse-list")

	--local count = SORT_BROWSE_PAGE_CUR * SORT_BROWSE_ROW * SORT_BROWSE_COL
	local count = registerGetInteger(pageIndexReg, "browsePageIndex") * SORT_BROWSE_ROW * SORT_BROWSE_COL
	SpriteList_SetStartItem(groupbtnsSprite, count)
--[[--------------------------------------------------------------------------]]--
	local defaultFocusButton=FindChildSprite(groupbtnsSprite,"browse-button-"..count)
	SetSpriteFocus(defaultFocusButton)
-----------------------------------------------------------------------------------	
end

function refurbishHotRecommendList()
	arrowHotRecommendHasVisible()
	local root = registerGetInteger(regCreate, "root")
	local groupbtnsSprite = FindChildSprite(root, "hot-recommed-list")
	--local count = HOT_RECOMMEND_PAGE_CUR  * HOT_RECOMMEND_ROW * HOT_RECOMMEND_COL
	local count = registerGetInteger(pageIndexReg, "recommendPageIndex") * SORT_BROWSE_ROW * SORT_BROWSE_COL
	SpriteList_SetStartItem(groupbtnsSprite, count)
--[[--------------------------------------------------------------------------]]--
	local defaultFocusButton=FindChildSprite(groupbtnsSprite,"recommend-button-"..count)
	SetSpriteFocus(defaultFocusButton)
-----------------------------------------------------------------------------------	
end

function arrowSortBroseHasVisible()
	local root = registerGetInteger(regCreate, "root")
	local leftVisible = FindChildSprite(root,"sort-browse-left-visible")
	local leftDisVisible = FindChildSprite(root,"sort-browse-left-disvisible")
	local rightVisible = FindChildSprite(root,"sort-browse-right-visible")
	local rightDisVisible = FindChildSprite(root,"sort-browse-right-disvisible")
	if 0 == SORT_BROWSE_PAGE_COUNT then
		SetSpriteVisible(leftVisible, 0)
		SetSpriteVisible(leftDisVisible, 1)
		SetSpriteVisible(rightVisible, 0)
		SetSpriteVisible(rightDisVisible, 1)
	elseif SORT_BROWSE_PAGE_CUR == SORT_BROWSE_PAGE_COUNT then
		SetSpriteVisible(leftVisible, 1)
		SetSpriteVisible(leftDisVisible, 0)
		SetSpriteVisible(rightVisible, 0)
		SetSpriteVisible(rightDisVisible, 1)
	elseif SORT_BROWSE_PAGE_CUR ~= SORT_BROWSE_PAGE_COUNT then
		if 0 == SORT_BROWSE_PAGE_CUR then
			SetSpriteVisible(leftVisible, 0)
			SetSpriteVisible(leftDisVisible, 1)
		else
			SetSpriteVisible(leftVisible, 1)
			SetSpriteVisible(leftDisVisible, 0)
		end
		SetSpriteVisible(rightVisible, 1)
		SetSpriteVisible(rightDisVisible, 0)
	 end
end

function arrowHotRecommendHasVisible()
	local root = registerGetInteger(regCreate, "root")
	local leftVisible = FindChildSprite(root,"hot-recommend-left-visible")
	local leftDisVisible = FindChildSprite(root,"hot-recommend-left-disvisible")
	local rightVisible = FindChildSprite(root,"hot-recommend-right-visible")
	local rightDisVisible = FindChildSprite(root,"hot-recommend-right-disvisible")
	if 0 == HOT_RECOMMEND_PAGE_COUNT then
		SetSpriteVisible(leftVisible, 0)
		SetSpriteVisible(leftDisVisible, 1)
		SetSpriteVisible(rightVisible, 0)
		SetSpriteVisible(rightDisVisible, 1)
	elseif HOT_RECOMMEND_PAGE_CUR == HOT_RECOMMEND_PAGE_COUNT then
		SetSpriteVisible(leftVisible, 1)
		SetSpriteVisible(leftDisVisible, 0)
		SetSpriteVisible(rightVisible, 0)
		SetSpriteVisible(rightDisVisible, 1)
	elseif HOT_RECOMMEND_PAGE_CUR ~= HOT_RECOMMEND_PAGE_COUNT then
		if 0 == HOT_RECOMMEND_PAGE_CUR then
			SetSpriteVisible(leftVisible, 0)
			SetSpriteVisible(leftDisVisible, 1)
		else
			SetSpriteVisible(leftVisible, 1)
			SetSpriteVisible(leftDisVisible, 0)
		end
		SetSpriteVisible(rightVisible, 1)
		SetSpriteVisible(rightDisVisible, 0)
	 end
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	end
end

--[[--------------------------------�޸��ˣ�yaoxiangyin �޸����ڣ�2010.08.12--------------------------------------]]--
--�������������̲���
function navigationButtonBrowseOnKeyUp(sprite,keyCode)
	local browseList={}  --����б����е�Button��
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	--sort-browse-list�����ڲ���
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --sort-browse-list�ڵ�
	--WriteLogs("@@@@@@@@@@@"..GetSpriteName(spriteList))
	
	local spriteRightArrow=FindChildSprite(GetSpriteParent(spriteList),"sort-browse-right")  --��sort-browse-right�ڵ�ƽ�������ҷ�ҳ��ť
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(spriteList),"sort-browse-left")    --��sort-browse-left�ڵ�ƽ��������ҳ��ť
	local browseName = GetSpriteName(sprite)
	local browseFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	--WriteLogs("@@@@@@@@@@@ itemCount total=="..itemCount)
	--WriteLogs("@@@@@@@@@@@ browseName=="..browseName)
	for j=0,itemCount-1 do
		browseList[j]="browse-button-"..j
	end
	
	local pageNum --��ҳ��
	if itemCount%8==0 then
		pageNum=itemCount/8
	else
		pageNum=math.ceil(itemCount/8)
	end
	for i=0,itemCount-1 do  --Ѱ�ҵ�ǰButton�ڵ���
	  if browseList[i]==browseName then
	    browseFocusNum=i
	  end
	end
	
	local downPositionFlag=0  --��ǰλ���Ƿ����¶α�־0��ʾ��1��ʾ��
	local upPositionFlag=0    --��ǰλ���Ƿ����϶α�־0��ʾ��1��ʾ��
	for i=0,pageNum-1 do
		if browseFocusNum>=i*8+6 and browseFocusNum<=i*8+7 then
			downPositionFlag=1
			break
		elseif browseFocusNum>=i*8 and browseFocusNum<=i*8+1 then
			upPositionFlag=1
			break
		end
	end
	
	local lineNum --������
	lineNum=math.ceil(itemCount/2) 
	local rightEdgeFalg=0 --��ǰλ���Ƿ����ұ�Ե��־0��ʾ��1��ʾ��
	local leftEdgeFalg=0  --��ǰλ���Ƿ������Ե��־0��ʾ��1��ʾ��
	for i=0,lineNum-1 do
		if browseFocusNum==i*2+1 then
			rightEdgeFalg=1
			break
		elseif browseFocusNum==i*2 then
			leftEdgeFalg=1
			break
		end
	end
	
	local recommedSpriteList=GetSpriteParent(GetSpriteParent(spriteList))   --hot-recommed�ڵ�
	local naviFocusReg=registerCreate("naviLastFocus")
	registerSetNumber(naviFocusReg,"naviFocusSprite",sprite)
	
	if keyCode== ApKeyCode_Right then
		if rightEdgeFalg==0 then --������������������ƶ�
			if browseList[browseFocusNum+1]~=nil then
				local sprite1=FindChildSprite(spriteList,browseList[browseFocusNum+1])
				SetSpriteFocus(sprite1)
			end
		elseif rightEdgeFalg==1 then --��������ұ߽����
			if registerGetInteger(pageIndexReg,"browsePageIndex")<pageNum-1 then
			btnSortBrowseRightOnSelect()
			end
		end
	elseif keyCode== ApKeyCode_Left then
		if leftEdgeFalg==0 then --����������������ƶ�
			if browseList[browseFocusNum-1]~=nil then
				local sprite1=FindChildSprite(spriteList,browseList[browseFocusNum-1])
				SetSpriteFocus(sprite1)
			end
		elseif leftEdgeFalg==1 then --���������߽����
			if registerGetInteger(pageIndexReg,"browsePageIndex")>0 then
			btnSortBrowseLeftOnSelect()
			end
		end
	elseif keyCode== ApKeyCode_Up then
		if upPositionFlag~=1 then  --������������������ƶ�
			if browseList[browseFocusNum-2]~=nil then 
				local sprite1=FindChildSprite(spriteList,browseList[browseFocusNum-2])
				SetSpriteFocus(sprite1)
			end
		end
	elseif keyCode== ApKeyCode_Down then
		if downPositionFlag~=1 then  --������������������ƶ�
			if browseList[browseFocusNum+2]~=nil then
				WriteLogs("@@@@@@@@@@@ do down operation")
				local sprite1=FindChildSprite(spriteList,browseList[browseFocusNum+2])
				SetSpriteFocus(sprite1)
			else --���һҳ�������
				local recommedListSprite
				local defautFocusRecommedButton
				local defautFocusIndex
				recommedListSprite=FindChildSprite(SpriteList_GetListItem(recommedSpriteList,2),"hot-recommed-list") 
				defautFocusIndex=browseFocusNum%2+registerGetInteger(pageIndexReg, "recommendPageIndex")*8
				defautFocusRecommedButton=FindChildSprite(SpriteList_GetListItem(recommedListSprite,defautFocusIndex),"recommend-button-"..defautFocusIndex) 
				SetSpriteFocus(defautFocusRecommedButton)
			end
		else  --������������±߽����
			local recommedListSprite
			local defautFocusRecommedButton
			local defautFocusIndex
			recommedListSprite=FindChildSprite(SpriteList_GetListItem(recommedSpriteList,2),"hot-recommed-list") 
			defautFocusIndex=browseFocusNum%2+registerGetInteger(pageIndexReg, "recommendPageIndex")*8
			defautFocusRecommedButton=FindChildSprite(SpriteList_GetListItem(recommedListSprite,defautFocusIndex),"recommend-button-"..defautFocusIndex) 
			SetSpriteFocus(defautFocusRecommedButton)
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	return 0
end

--�����Ƽ�������̲���
function navigationButtonRecommendOnKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	local recommendList={}  --����б����е�Button��
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	
	--hot-recommed-list�����ڲ���
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --hot-recommed-list�ڵ�
	--WriteLogs("@@@@@@@@@@@"..GetSpriteName(spriteList))
	
	local spriteRightArrow=FindChildSprite(GetSpriteParent(spriteList),"hot-recommed-right")  --��hot-recommed-right�ڵ�ƽ�������ҷ�ҳ��ť
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(spriteList),"hot-recommed-left")    --��hot-recommed-left�ڵ�ƽ��������ҳ��ť
	local recommendName = GetSpriteName(sprite)
	local recommendFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	--WriteLogs("@@@@@@@@@@@ itemCount total=="..itemCount)
	--WriteLogs("@@@@@@@@@@@ recommendName=="..recommendName)
	
	for j=0,itemCount-1 do
		recommendList[j]="recommend-button-"..j
	end
	
	local pageNum --��ҳ��
	if itemCount%8==0 then
		pageNum=itemCount/8
	else
		pageNum=math.ceil(itemCount/8)
	end
	for i=0,itemCount-1 do  --Ѱ�ҵ�ǰButton�ڵ���
	  if recommendList[i]==recommendName then
	    recommendFocusNum=i
	  end
	end
	
	local downPositionFlag=0  --��ǰλ���Ƿ����¶α�־0��ʾ��1��ʾ��
	local upPositionFlag=0    --��ǰλ���Ƿ����϶α�־0��ʾ��1��ʾ��
	for i=0,pageNum-1 do
		if recommendFocusNum>=i*8+6 and recommendFocusNum<=i*8+7 then
			downPositionFlag=1
			break
		elseif recommendFocusNum>=i*8 and recommendFocusNum<=i*8+1 then
			upPositionFlag=1
			break
		end
	end
	
	local lineNum --������
	lineNum=math.ceil(itemCount/2) 
	local rightEdgeFalg=0 --��ǰλ���Ƿ����ұ�Ե��־0��ʾ��1��ʾ��
	local leftEdgeFalg=0  --��ǰλ���Ƿ������Ե��־0��ʾ��1��ʾ��
	for i=0,lineNum-1 do
		if recommendFocusNum==i*2+1 then
			rightEdgeFalg=1
			break
		elseif recommendFocusNum==i*2 then
			leftEdgeFalg=1
			break
		end
	end
	
	local recommedSpriteList=GetSpriteParent(GetSpriteParent(spriteList))   --hot-recommed�ڵ�
	
	local naviFocusReg=registerCreate("naviLastFocus")
	registerSetNumber(naviFocusReg,"naviFocusSprite",sprite)
	
	if keyCode== ApKeyCode_Right then
		if rightEdgeFalg==0 then --�����Ƽ������������ƶ�
			if recommendList[recommendFocusNum+1]~=nil then
				local sprite1=FindChildSprite(spriteList,recommendList[recommendFocusNum+1])
				SetSpriteFocus(sprite1)
			end
		elseif rightEdgeFalg==1 then --�����Ƽ��ұ߽����
			if registerGetInteger(pageIndexReg,"recommendPageIndex")<pageNum-1 then
			btnHotRecommendRightOnSelect()
			end
		end
	elseif keyCode== ApKeyCode_Left then
		if leftEdgeFalg==0 then --�����Ƽ����������ƶ�
			if recommendList[recommendFocusNum-1]~=nil then
				local sprite1=FindChildSprite(spriteList,recommendList[recommendFocusNum-1])
				SetSpriteFocus(sprite1)
			end
		elseif leftEdgeFalg==1 then --�����Ƽ���߽����
			if registerGetInteger(pageIndexReg,"recommendPageIndex")>0 then
			btnHotRecommendLeftOnSelect()
			end
		end
	elseif keyCode== ApKeyCode_Up then
		if upPositionFlag~=1 then  --�����Ƽ������������ƶ�
			if recommendList[recommendFocusNum-2]~=nil then 
				local sprite1=FindChildSprite(spriteList,recommendList[recommendFocusNum-2])
				SetSpriteFocus(sprite1)
			end
		else --�����Ƽ������ϱ߽����
			local browseListSprite
			local defautFocusBrowseButton
			local defautFocusIndex=recommendFocusNum%2+registerGetInteger(pageIndexReg, "browsePageIndex")*8+6
			browseListSprite=FindChildSprite(SpriteList_GetListItem(recommedSpriteList,1),"sort-browse-list")
			for i=defautFocusIndex,0,-1 do
				if FindChildSprite(SpriteList_GetListItem(browseListSprite,i),"browse-button-"..i)~=0 then
					defautFocusBrowseButton=FindChildSprite(SpriteList_GetListItem(browseListSprite,i),"browse-button-"..i)
					break
				end
			end
			SetSpriteFocus(defautFocusBrowseButton)
		end
	elseif keyCode== ApKeyCode_Down then
		if downPositionFlag~=1 then  --�����Ƽ������������ƶ�
			if recommendList[recommendFocusNum+2]~=nil then
				WriteLogs("@@@@@@@@@@@ do down operation")
				local sprite1=FindChildSprite(spriteList,recommendList[recommendFocusNum+2])
				SetSpriteFocus(sprite1)
			end
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	end
	return 0
end
------------------------------------------------------------------------------------------------------------------------