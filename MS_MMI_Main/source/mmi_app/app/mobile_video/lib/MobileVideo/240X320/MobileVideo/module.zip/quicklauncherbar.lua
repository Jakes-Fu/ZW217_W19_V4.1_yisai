require "module.common.SceneUtils"
require "module.common.registerScene"
require("module.loading.useLoading")
--require "module.protocol.protocol_menushortcut"

keyQuickLauncherBar = "QuickLauncherBar";
SPRITENAME_SYSMENU = "sysmenu";
SPRITENAME_BOTTOMMENU = "bottommenu";
buttonList = {"menu","Home","TopTen","Search","MenuBottom","Return"}

function bodyBuildChildrenFinished(sprite)
	reg = registerCreate(keyQuickLauncherBar)
	registerSetInteger(reg, "rootSprite", sprite)
	
	local qkLhBar=registerCreate("QkLHBAR")
	registerSetInteger(qkLhBar,"qKLunchText",sprite)

	local regObserver = registerCreate("saveObserver")
	registerSetInteger(regObserver, "observer", pluginGetObserver())

end

--@brief 				用于显示弹出菜单
function menuButtonOnSelect(sprite)
	FocusProc(sprite)
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	hideBottomSprite(rootSprite);

	if hideMenuSprite(rootSprite) == 0 then
		require "module.protocol.protocol_video"
		OnMenuButton()
		menuSprite = CreateSprite("node", rootSprite);
		SetSpriteName(menuSprite, SPRITENAME_SYSMENU);
		LoadSprite(menuSprite, "MODULE:\\sysmenu.xml");
		SetSpriteCapture(rootSprite);
	end
end

--@brief 		进入首页
function homeButtonOnSelect(sprite)
	FocusProc(sprite)
	hidePopupSprites();
	
	--清空返回列表
	local	reg = registerCreate(keyQuickLauncherBar);
	local count = registerGetInteger(reg, "Count");
	for i=1, count do
		registerRemove(reg, "PageName"..i)
	end
	local regInfo = registerCreate(keyQuickLauncherBar)
	SenceSprite=registerGetInteger(regInfo,"rootSprite")
	regInfor = registerCreate("sysSprite")
	local SenceSpriteRoot=registerGetInteger(reg,"rootSprite")
	registerSetInteger(reg, "Count", 0)
	registerSetString(reg, "CurPage", sceneHome)
	
	FreeCurScene()
	local	reg = registerCreate(keyQuickLauncherBar);
	
	require "module.protocol.protocol_video"
	require "module.common.SceneUtils"
	OnReturnButton()
	WriteLogs("homeButtonOnSelect");
	
	GoAndFreeScene(sceneHome)
	
--[[---------------------------------修改人：yaoxiangyin 修改日期：2010.8.16-----------------------------------------]]--	
	local homeInitFoucsReg= registerCreate("homeInitFoucs")
	local init=registerGetInteger(homeInitFoucsReg,"InitFocusSprite")
	WriteLogs("初始化焦点"..init)
	SetSpriteFocus(init)
------------------------------------------------------------------------------------------------------------------------	
	OnPluginEvent(103,param)
	
--	return 1
end

--@brief 		进入排行榜页面
function topButtonOnSelect(sprite)
	FocusProc(sprite)
	hidePopupSprites();
	WriteLogs("topButtonOnSelect");
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.protocol.protocol_topten"
	Loading()
	
	
	http = pluginCreate("HttpPipe")		
	local reg = registerCreate("home")
	local fileName = registerGetString(reg, "HomeUrlFileName")
	local homeData = jsonLoadFile(fileName)		
	if homeData and homeData.subject then
		local subjectDataArray = homeData.subject
		local n = table.maxn(subjectDataArray)
		for i=0, n do
			if ( "3" == subjectDataArray[i].nodeDisplayType and "排行榜" == subjectDataArray[i].channelName) then
				local phreg = registerCreate("paihang")
				registerSetString(phreg,"urlpath" , subjectDataArray[i].urlPath)
				break
			end
		end
	end
	local phreg = registerCreate("paihang")
	local PaihangUrl = registerGetString(phreg,"urlpath" )
	if PaihangUrl ~="" then
		RequestTopTen(114, PaihangUrl, 1)
	end
	
	WriteLogs("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
end

--@brief 		进入分类关键字
function searchButtonOnSelect(sprite)
	FocusProc(sprite)
	hidePopupSprites();
	WriteLogs("searchButtonOnSelect");
	require "module.protocol.protocol_video"
	OnReturnButton()
	local reg = registerCreate("home")
	local fileName = registerGetString(reg, "HomeUrlFileName")
	local json = jsonLoadFile(fileName)
	if json and json.moreKeyUrl ~= "" then
		require("module.protocol.protocol_menusearch")
		RequestMenuSearch(113, json.moreKeyUrl, 1)
		Loading()
	end
	--OnPluginEvent(113,param)
end

--@brief 		弹出"更多"菜单
function bottomButtonOnSelect(sprite)
	FocusProc(sprite)
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");

	hideMenuSprite(rootSprite);

	if hideBottomSprite(rootSprite) == 0 then
		require "module.protocol.protocol_video"
		OnMenuButton()
		bottomSprite = CreateSprite("node", rootSprite);
		SetSpriteName(bottomSprite, SPRITENAME_BOTTOMMENU);
		LoadSprite(bottomSprite, "MODULE:\\bottommenu.xml");
		SetSpriteCapture(rootSprite);
	end
end

--@brief 				返回
function returnButtonOnSelect(sprite)
	WriteLogs("zgh:returnButtonOnSelect--quicklauncherbar")
	FocusProc(sprite)
	if hidePopupSprites() == 1 then
		---用于解决触摸点击菜单后，再次点击返回失焦点问题---
		local reg = registerCreate("PopMenuHide") 
		local sencePreFocus=registerGetInteger(reg,"sencePreFocus") 
		SetSpriteFocus(sencePreFocus)
		return 1
	end	
	require "module.common.SceneUtils"
	require "module.common.registerScene"
	local curScene = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle");
	local SceneName = registerGetString(regHandle, string.format("%d", curScene))
	WriteLogs("zgh:sceneName"..SceneName)
	if SceneName == sceneHome then
		WriteLogs("zgh:if_QuickLauncherBar.lua")
		require "module.dialog.useDialog"
		local	reg = registerCreate(keyQuickLauncherBar);
		local	rootSprite = registerGetInteger(reg, "rootSprite");
		local spriteEvent = FindChildSprite(rootSprite,"event")		
		local dlgImg = {}
		dlgImg.OK_N_IMG = "file:///image/dialog/ok.png"
		dlgImg.OK_F_IMG = "file:///image/dialog/ok_alt.png"		
		setDialogParam("退出", "您确认要退出吗？", "BT_OK_CANCEL",sceneHome ,sceneHome,spriteEvent,nil,dlgImg)
		Go2Scene(sceneDialog)
		return 1
	end

	require "module.protocol.protocol_video"
	OnReturnButton()


	--找数据ReturnTable仓库
 	local regReturn = registerCreate(keyQuickLauncherBar);
 	--得到ReturnTable中"PageName"的总数,就是找到最近的页面
 	local count = registerGetInteger(regReturn, "Count");
 	--得到ReturnTable中最近的页面的名字
	local LastPageName = registerGetString(regReturn, "PageName"..count)
	local CurScene = GetCurScene()
	--如果存在，返回那个页面
	if LastPageName ~= "" and LastPageName ~= nil then		
		--由页面控制free
		local	reg = registerCreate(keyQuickLauncherBar);
		local	rootSprite = registerGetInteger(reg, "rootSprite")
		local   rootScene = GetCurScene()
		require "module.common.commonMsg"
		--发给当前场景
		SendSpriteEvent(rootScene, MSG_RETURN)	--	MSG_RETURN	= USER_MSG + 99  
		
		--以下处理当前场景和目标场景相同的情况
		while 1 do
			LastPageName = registerGetString(regReturn, "PageName"..count)
			if LastPageName ~= SceneName then
				if LastPageName == sceneVideoGroup or LastPageName == sceneVideoLiveDemand or LastPageName == sceneVideoLiveDemand_NB or LastPageName == sceneVideolocal or LastPageName == sceneRecommend then
					if SceneName ~= sceneRecommend then
						LastPageName = registerGetString(regReturn, "PageName"..count-1)	
						count = count - 1						
					else
						Go2Scene(LastPageName)
						break
					end					
				else
					Go2Scene(LastPageName)
					break
				end
			else
				LastPageName = registerGetString(regReturn, "PageName"..count-1)
				count = count - 1
			end
		end			
		
		registerSetString(regReturn, "CurPage", LastPageName)
		if count >= 1 then
			registerRemove(regReturn, "PageName"..count)
		count = count - 1	
	end
	else
		GoAndFreeScene(sceneHome)
		registerSetString(regReturn, "CurPage", sceneHome)
		for i=1, count do
			registerRemove(regReturn, "PageName"..i)
		end
		count = 0
	end	
	registerSetInteger(regReturn, "Count", count)	
	local regVideo = registerCreate("video")
	registerSetString(regVideo, "isDownloading","")	
end

function hideMenuSprite(rootSprite)
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	WriteLogs("!!!!!!!!!!:"..GetSpriteName(rootSprite))
	local menuSprite = FindChildSprite(rootSprite, SPRITENAME_SYSMENU);
	WriteLogs("222222222222222:"..menuSprite)
	if menuSprite ~= 0 then
		RemoveChildSprite(rootSprite, menuSprite, 1);
		ReleaseSpriteCapture(rootSprite);
		return	1;
	end
	return	0;
end

function hideBottomSprite(rootSprite)
	---用于解决触摸点击菜单后，再次点击菜单失焦点问题---
	local reg = registerCreate("PopMenuHide") 
	local sencePreFocus=registerGetInteger(reg,"sencePreFocus") 
	SetSpriteFocus(sencePreFocus)
	----------------------------------------------------
	local bottomSprite = FindChildSprite(rootSprite, SPRITENAME_BOTTOMMENU);
	if bottomSprite ~= 0 then
		RemoveChildSprite(rootSprite, bottomSprite, 1);
		ReleaseSpriteCapture(rootSprite);
		return	1;
	end
	return	0;
end

function hidePopupSprites()
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	
	if hideMenuSprite(rootSprite) == 1 then	return	1;	end
	if hideBottomSprite(rootSprite) == 1 then	return	1;end

	return	0;
end

function ChangeScence(nextScenceName)	

	require "module.common.SceneUtils"
	Go2Scene(nextScenceName)
	return 1
end

function Loading() 
	local root = GetCurScene()
	local loadarea = FindChildSprite(root,"loadarea")
	require("module.loading.useLoading")
	enterLoading(loadarea)
end

function OnPluginEvent(message, param)
	WriteLogs("bodyOnPluginEvent")
	require "module.common.SceneUtils"
	local regReturn = registerCreate(keyQuickLauncherBar);
 	--得到ReturnTable中"PageName"的总数,就是找到最近的页面
 	local count = registerGetInteger(regReturn, "Count");
 	--得到ReturnTable中最近的页面的名字
	local LastPageName = registerGetString(regReturn, "CurPage")
	---------------------------------------------------add by yaoxiangyin-------------------------------------
	local curScene = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle");
	local curSceneName = registerGetString(regHandle, string.format("%d", curScene))
	---------------------------------------------------------------------------------------------------------
	if message == 113 then
		--add by yaoxiangyin 针对渠道版，解决从宫格页面进入搜索页面第一次加载无数据问题--
		exitLoading()
		require "module.protocol.protocol_menusearch"
		local menusearchJson=OnMenuSearchDecode()
		if menusearchJson then
			SetReturn(LastPageName,sceneSearch)
			FreeCurScene()
			ChangeScence(sceneSearch)
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据失败", "BT_OK", curSceneName, curSceneName, nil)
			Go2Scene(sceneDialog)	
		end
	-------------------------------------------------	
	elseif message == 114 then
	--add by yaoxiangyin 针对渠道版，解决从宫格页面进入排行版页面第一次加载无数据问题--
		exitLoading()
		require "module.protocol.protocol_topten"
		local toptenJson=LoadJsonTopTenNetworkData()
		if toptenJson then
			SetReturn(LastPageName,scenePaihang)
			FreeCurScene()
			ChangeScence(scenePaihang)
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据失败", "BT_OK", curSceneName, curSceneName, nil)
			Go2Scene(sceneDialog)	
		end
	-------------------------------------------------
	elseif message == 103 then
		require "module.protocol.protocol_home"
		WriteLogs("Download JSON OK And Call ChangeScene()")
		local homeData = HomeNetworkData()
		if homeData then
			--FreeCurScene()
			--Go2Scene(sceneHome)
			local   rootScene = GetCurScene()
			require "module.common.commonMsg"
		--发给当前场景
		SendSpriteEvent(rootScene, MSG_RETURN)
			--exitLoading()
			SetReturn(LastPageName,sceneHome)
			FreeCurScene()
			GoAndFreeScene(sceneHome)
			WriteLogs("成功进入")
		else
		    WriteLogs("message==103, but homeData not invalid!")
		end
		elseif message > 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", LastPageName, LastPageName, nil)
		Go2Scene(sceneDialog)	
	end
	
end

function OnSpriteEvent(message, params)
	WriteLogs("bodyOnSpriteEvent message"..message)
	if message == 1001 then
		local reg_vc = registerCreate("videoexpress-common")
		local EnoughSpace = registerGetString(reg_vc, "EnoughSpace")
		if EnoughSpace == "false" then
			GoAndFreeScene("MODULE:\\receivemessage.xml")
		else
			local reg = registerCreate("product")
			local jsonString = registerGetInteger(reg, "ChannelNetwork")
			if jsonString ~= 0 then
				jsonRelease(jsonString)
				registerSetInteger(reg, "ChannelNetwork", 0)
			end
			local reg = registerCreate("guide")
			local jsonString = registerGetInteger(reg, "channelGroupNetwork")
			if jsonString ~= 0 then
				jsonRelease(jsonString)
				registerSetInteger(reg, "channelGroupNetwork", 0)
			end
			local reg = registerCreate("home")
			local jsonString = registerGetInteger(reg, "HomeNetwork")
			if jsonString ~= 0 then
				jsonRelease(jsonString)
				registerSetInteger(reg, "HomeNetwork", 0)
			end
			local reg = registerCreate("topTen")
			local jsonString = registerGetInteger(reg, "channelGroupNetwork")
			if jsonString ~= 0 then
				jsonRelease(jsonString)
				registerSetInteger(reg, "channelGroupNetwork", 0)
			end
			checkCacheCondition()
			Exit()
		end
	elseif message == 1002 then
		WriteLogs("bodyOnSpriteEvent message"..message)	
		require "module.common.SceneUtils"
		require "module.common.registerScene"
	end
end

function FreeCurScene()
	require "module.common.registerScene"
	require "module.common.SceneUtils"
	require "module.common.commonMsg"
	local	regQuick = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(regQuick, "rootSprite")
	local	rootScene = GetRootSprite(rootSprite)
	--发给当前场景
	SendSpriteEvent(rootScene, MSG_RETURN)	--	MSG_RETURN	= USER_MSG + 99  
	return 1
end

function RequestHomeData()
	require "module.protocol.protocol_home"
	RequestHome(103,loginInfo.defaultDataUrl)
end

function OnSelectBackButton(sprite)
	Exit()
end

function myFavOnSelect(button)
	WriteLogs("myFavOnSelect");
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\favorite.xml")
	Go2Scene("MODULE:\\favorite.xml")	
end

function historyOnSelect(button)
	reg = registerCreate(keyQuickLauncherBar)
	SenceSprite=registerGetInteger(reg,"rootSprite")
	WriteLogs("historyOnSelect");
	 local reg = registerCreate("sysSprite")
	 local SenceSpriteRoot=registerGetInteger(reg,"rootSprite")
	------------------------------------------------------------------------------------------------------------------------------------------------
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	------------------------------------------------------------------------------------------------------------------------------------------------
--	local sprite_child=FindChildSprite(SenceSprite,"quicklauncherbar")
--	WriteLogs("-------hello---------"..GetSpriteName(FindChildSprite(sprite_child,"menu-title")))
	--SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","欢迎使用手机视频业务")
	------------------------------------------------------------------------------------------------------------------------------------------------
	SetReturn1("MODULE:\\history.xml")
	Go2Scene("MODULE:\\history.xml")	
end

function addFavOnSelect(button)
	WriteLogs("addFavOnSelect");
	require("module.common.commonMsg")
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	local root = GetCurScene()
	SendSpriteEvent(root, MSG_ADD_FAV)
end


function myFavOnSelect(button)
	WriteLogs("myFavOnSelect");
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\favorite.xml")
	Go2Scene("MODULE:\\favorite.xml")	
end

function localFileOnSelect(button)
	WriteLogs("localFileOnSelect");
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\LocalFile.xml")
	WriteLogs("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
		Go2Scene("MODULE:\\LocalFile.xml")	
		return 1
end

function SetReturn1(nextScenceName)
	local regQuick = registerCreate(keyQuickLauncherBar)
	local rootSprite = registerGetInteger(regQuick, "rootSprite")
	local rootScene = GetCurScene()
	local regHandle = registerCreate("SCMngr_handle")
	local SceneName = registerGetString(regHandle, string.format("%d", rootScene))
	if SceneName ~= sceneChannelHomePage and SceneName ~= sceneHome and SceneName ~= sceneVideoLiveDemand and SceneName ~= sceneVideolocal and SceneName ~= sceneVideoLiveDemand_NB then
		FreeScene(rootScene)
	end
	if SceneName ~= sceneRecommend and SceneName ~= sceneDownloadSelect then
	 	local reg = registerCreate(keyQuickLauncherBar)
	 	local count = registerGetInteger(reg, "Count")+1
		registerSetInteger(reg, "Count", count)
		
		require("module.setting")
		local CurPage = registerGetString(reg, "CurPage")
		registerSetString(reg, "PageName" .. count, CurPage)
		registerSetString(reg, "CurPage", nextScenceName)
	end
end

function SysGetSeceOpenSprite(sprite)
	reg = registerCreate("sysOpenSprite")			--创建数据仓库，获取F1前的焦点
	registerSetInteger(reg,"sprite_name1",sprite)
end

function sysopen(sprite,keyCode)
	WriteLogs("执行？")
	 reg = registerCreate("sysOpenSprite")
	 SenceSprite1=registerGetInteger(reg,"sprite_name1")
	
	 
	homeReg=registerCreate("homeButton")
	registerSetInteger(homeReg,"homeButton",FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"menu-home"))
	 
	 regpass=registerCreate("PassLeft")
	 registerSetInteger(regpass,"spritePassLeft",sprite)
	 WriteLogs("talent:"..GetSpriteName(sprite))
	WriteLogs("-------------------++++++++++++++++++++++++++++:"..keyCode)
	item=GetParentSprite(sprite)
	local menuList=GetParentSprite(GetParentSprite(sprite))
	itemCount = SpriteList_GetListItemCount(menuList)
	WriteLogs("______name:"..GetSpriteName(menuList))
	index = SpriteListItem_GetIndex(item)
	WriteLogs(".....index:"..index)
	local list={"menu-home","menu-sc","menu-ss","menu-ls","menu-bdmt","menu-wdzz","menu-hysp","menu-phb"}
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		local lastFocus=registerGetInteger(homeLastFoucsReg,"lastFocusSprite")
	if keyCode==10 and index <=itemCount-1 then
		if index==(itemCount-1) then return 0
		else
			if list[index+1]~="menu-bdmt" then
				listitem=SpriteList_GetListItem(menuList, index+1)
				cursprite=FindChildSprite(listitem,list[index+2])
				SetSpriteFocus(cursprite)
			else
				listitem=SpriteList_GetListItem(menuList, index+3)
				cursprite=FindChildSprite(listitem,list[index+4])
				SetSpriteFocus(cursprite)
			end
			result=HasSpriteFocus(cursprite)
		end
	elseif keyCode==9 and index>=1 then
		if index==0 then return 0
		else 
			if list[index+1]~="menu-phb" then
				listitem=SpriteList_GetListItem(menuList, index-1)
				cursprite=FindChildSprite(listitem,list[index])
				SetSpriteFocus(cursprite)
			else
				listitem=SpriteList_GetListItem(menuList, index-3)
				cursprite=FindChildSprite(listitem,list[index-2])
				SetSpriteFocus(cursprite)
			end
		end

		elseif keyCode == 1 then
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			require("module.menuopen")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
			
		elseif keyCode == 2  then
			require("module.menuopen")
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
	
	elseif keyCode==7 then
			flag=1
			local flagReg=registerCreate("flagnum")
			registerSetInteger(flagReg,"flagnum",flag)
			local regInfor=registerCreate("passSprite")
			local senceSprite=registerGetInteger(regInfor,"CurSprite")
			
			SetSpriteFocus(senceSprite)
			local reg=registerCreate("popS")
			popSprite=registerGetInteger(reg,"pop")
			ShowPopupMenu(popSprite,0)
			
			--SetSpriteVisible(GetParentSprite(GetParentSprite(sprite)),0)
			--SetSpriteEnable(GetParentSprite(GetParentSprite(sprite)),0)
		
		
	end
		return 0
end


function FocusProc(sprite)
		require "module.common.SceneUtils"
	ReleaseSpriteCapture(sprite)
	KillSpriteFocus(sprite)
end



function ShowPopupMenu(popSprite, show)
	if show == 0 then
		SetSpriteVisible(popSprite, 0);
		SetSpriteEnable(popSprite, 0);
		childPopSprite = FindChildSpriteByClass(popSprite, "list");
		if childPopSprite ~= 0 then
			SpriteList_SetCurItem(childPopSprite, -1);
		end
	else
		SetSpriteVisible(popSprite, 1);
		SetSpriteEnable(popSprite, 1);
	end
end

function returnButtonOnMouseDown(sprite)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"KeyFlag",0)
	returnButtonOnSelect(sprite)
end

function menuButtonOnMouseUp(sprite)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"KeyFlag",0)
	menuButtonOnSelect(sprite)
end

