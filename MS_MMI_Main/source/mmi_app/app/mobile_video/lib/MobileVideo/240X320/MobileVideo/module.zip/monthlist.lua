﻿require "module.keyCode.keyCode"
--@module monthlist
--@note 大包月
--@author Abigale
--@date 2010/07/05
function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("Month")
	registerSetInteger(reg, "root", sprite)   
	CreateMonthList(sprite)
	return 1
end

function OnPluginEvent (message,param)
	if message == 299 then
		exitLoading()
		pathName = "MODULE:\\monthguidelist.xml"
		--[[   把包月列表从我的订购界面中移除  ]]--
		MonthlistOnMouseUp()
		GoAndFreeScene(pathName)
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneMonthlist, sceneMonthlist)
	end
end

function CreateMonthList(sprite)
	require "module.myorder"
	local json = OnMyOrderDecode()	
	local spriteList = FindChildSprite(sprite, "month-list")
	SpriteList_ClearListItem( spriteList, 1, 1 )
	
	local regSystem = registerCreate("system")				
	local index = registerGetInteger(regSystem, "IndexData")
	if  json and json.orderList  then 
		if json.orderList[index] then
			if json.orderList[index].bigPList then 
				jsonDataArray = json.orderList[index].bigPList
				local n = table.maxn(jsonDataArray)
				count = n
				local xmlNode=xmlLoadFile("MODULE:\\monthlistitem.xml")
				for i = 0, n  do
					local monthlistSprite = CreateSprite("listitem")
					LoadSpriteFromNode(monthlistSprite, xmlNode)
					SetSpriteRect(monthlistSprite, 10,30,70,19)
					
					--------------找button节点-----------------------------------------------------
					local initMonthListItemButtonFocus = FindChildSprite(monthlistSprite, "subject-button-1")
					--------------------------------------------------------------------------------
					
					---------------------设置每个listItem的默认选中选中------------------
					SetSpriteProperty(monthlistSprite, "defaultFocusName", "subject-button-1")
					---------------------------------------------------------------------
					
					------------------设置listItem的名称--------------------
					SetSpriteProperty(monthlistSprite, "name", i)
					---------------------------------------------------------
					
					---------------设置listItem的键盘点击事件----------------
					SetSpriteProperty(monthlistSprite, "OnKeyUp", "monthListItemButtonSubjectKeyUp")
					---------------------------------------------------------
					
					local spritetextNTitle = FindChildSprite(monthlistSprite, "ButtontextN")
					local spritetextTitle = FindChildSprite(monthlistSprite, "ButtontextF")			
					local spritetextNTitleS = FindChildSprite(monthlistSprite, "ButtontextNS")
					local spritetextTitleS = FindChildSprite(monthlistSprite, "ButtontextFS")
					local width = GetTextSize(jsonDataArray[i].nodeName)
					if width > 66 then
						SetSpriteVisible(spritetextNTitle,0)
						SetSpriteVisible(spritetextTitle,0)
						SetSpriteVisible(spritetextNTitleS,1)
						SetSpriteVisible(spritetextTitleS,1)
					else
						SetSpriteVisible(spritetextNTitle,1)
						SetSpriteVisible(spritetextTitle,1)
						SetSpriteVisible(spritetextNTitleS,0)
						SetSpriteVisible(spritetextTitleS,0)
					end
					SetSpriteProperty(spritetextNTitle, "text", jsonDataArray[i].nodeName)
					SetSpriteProperty(spritetextTitle, "text", jsonDataArray[i].nodeName)				
					SetSpriteProperty(spritetextNTitleS, "text", jsonDataArray[i].nodeName)
					SetSpriteProperty(spritetextTitleS, "text", jsonDataArray[i].nodeName)	
					AddChildSprite(spriteList, monthlistSprite)
					SpriteList_AddListItem(spriteList, monthlistSprite)
					
					-------------设置第一个节点为焦点----------------设置一个数据仓库，将initMonthListItemButton放入其中
					if i == 0 then
						local reg2 = registerCreate("spriteF")                                                               
	                    registerSetInteger(reg2, "sprite", initMonthListItemButtonFocus)
					end
				end
				xmlRelease(xmlNode)
			else
			    WriteLogs("json.orderList[index].bigPList == nil ")
			end		
		else
		    WriteLogs("json.orderList[index] = nil ")
		end		
  else
      WriteLogs("json and json.orderList == nil ")
	end
	SpriteList_Adjust(spriteList)	
	exitLoading()
end

--------------------------设置键盘对listItem的点击事件------------------------------
function monthListItemButtonSubjectKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local monthListItemIndex = SpriteListItem_GetIndex(sprite)
	WriteLogs("monthListItemButtonSubjectKeyUp start============")
	local preItem
	local nextItem
	local downItem
	local upItem
	if keyCode == ApKeyCode_F1 then
		MonthlistOnMouseUp()
	elseif keyCode == ApKeyCode_F2  then
		MonthlistOnMouseUp()
	elseif keyCode == ApKeyCode_Right  then
		if monthListItemIndex ~= 8 then
			nextItem = FindChildSprite(SpriteList_GetListItem(GetSpriteParent(sprite),monthListItemIndex+1),"subject-button-1")
			SetSpriteFocus(nextItem)
		end
	elseif keyCode == ApKeyCode_Left  then
		if monthListItemIndex ~= 0 then
			preItem = FindChildSprite(SpriteList_GetListItem(GetSpriteParent(sprite),monthListItemIndex-1),"subject-button-1")
			SetSpriteFocus(preItem)
		end
	elseif keyCode == ApKeyCode_Up  then
		if monthListItemIndex-3 >= 0 then
			upItem = FindChildSprite(SpriteList_GetListItem(GetSpriteParent(sprite),monthListItemIndex-3),"subject-button-1")
			SetSpriteFocus(upItem)
		end
	elseif keyCode == ApKeyCode_Down  then
		if monthListItemIndex+3 <= 8 then
			downItem = FindChildSprite(SpriteList_GetListItem(GetSpriteParent(sprite),monthListItemIndex+3),"subject-button-1")
			SetSpriteFocus(downItem)
		end
	end
end

function OnProgramClick(sprite)
	--载入状态loading
	local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadingNode3")
	enterLoading(nodeLoading)
	
	--get index of the myorderitem
	local regSystem = registerCreate("system")				
	local index = registerGetInteger(regSystem, "IndexData")
	
	--get index of the monthlistitem
	local SpriteItem = GetSpriteParent(sprite)
	indexMonthlistitem = SpriteListItem_GetIndex(SpriteItem)
	require "module.myorder"
	local json = OnMyOrderDecode()	
	if  json and json.orderList  then 
		if json.orderList[index] then
			if json.orderList[index].bigPList then 
				local url = json.orderList[index].bigPList[indexMonthlistitem].nodeUrl
				require "module.protocol.protocol_monthguide"
				RequestMonthGuide(299,url)
			end
		end
	end
end

function MonthlistOnMouseUp()
	local reg = registerCreate("Myorder") 
	local root = registerGetInteger(reg, "root")
	local Monthlist = FindChildSprite(root, "Monthlist") 
	if Monthlist == 0 or Monthlist == nil then 
		Monthlist = CreateSprite("node", root) 
		SetSpriteProperty(Monthlist,"name","Monthlist") 
	end
	ReleaseSpriteCapture(Monthlist)
RemoveChildSprite(root, Monthlist)
	FreeScene(Monthlist)
	local reg3 = registerCreate("spriteH")                                                               
	SetSpriteFocus(registerGetInteger(reg3, "Jsprite"))
end