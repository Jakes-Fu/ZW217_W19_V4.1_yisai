﻿
function RequestMagazine(protocolNumber, magazineUrl)
	local i,j = string.find(magazineUrl,"http")
	local k,l = string.find(magazineUrl,"WONDER")
	if j and j ~= 0 then
		--[[  正常请求  ]]--
		local fileName = GetLocalFilename(magazineUrl)
		local reg = registerCreate("magazine")
		registerSetString(reg, "magazineUrl", magazineUrl)
		registerSetString(reg, "magazineUrlFileName", fileName)
		local regSystem = registerCreate("System")
		local http = registerGetInteger(regSystem, "comHttpPipe")
		if http == nil or http == 0 then
			http = pluginCreate("HttpPipe")
			registerSetInteger(regSystem, "comHttpPipe", http)
		end
		local observer = pluginGetObserver()
		WriteLogs("Magazine fileName:" .. fileName)
		pluginInvoke(http, "AppendCommand", 0, magazineUrl, "", fileName, observer, protocolNumber, 0, 0)
	elseif l and l ~= 0 then
		--[[  从二级收件箱到magazine  ]]--
		local reg = registerCreate("magazine")
		registerSetString(reg, "magazineUrl", magazineUrl)
		registerSetString(reg, "magazineUrlFileName", magazineUrl)
		GoAndFreeScene(sceneMagazine)
	else
		--[[  专门为本地数据上下翻页使用  ]]--
		local reg = registerCreate("magazine")
		local i = string.find(magazineUrl,"/")
		if i and i > 0 then
			magazineUrl = string.gsub(magazineUrl,string.sub(magazineUrl,1,i),"")
		end
		local localmagazinepath = "MODULE:\\videoexpress\\"..registerGetString(reg,"magazinename").."\\"..magazineUrl
		registerSetString(reg, "magazineUrlFileName", localmagazinepath)
		return -1
	end
end

function MagazineNetworkData()
	local reg = registerCreate("magazine")
	local fileName = registerGetString(reg, "magazineUrlFileName")
	WriteLogs("Magazine local filepath : "..fileName)
	local strNetworkData = registerGetInteger(reg, "MagazineNetwork")
	if strNetworkData ~= 0 then
		jsonRelease(strNetworkData)
		registerSetInteger(reg, "MagazineNetwork", 0)
	end
	local jsonString = jsonOpenFile(fileName)
	if jsonString and jsonString ~= 0 then
		registerSetInteger(reg, "MagazineNetwork", jsonString)
		return jsonString
	end
	return nil
end

function ReleaseMagazineNetworkData()
	local reg = registerCreate("magazine")
	local strNetworkData = registerGetInteger(reg, "MagazineNetwork")
	if strNetworkData ~= 0 then
		jsonRelease(strNetworkData)
		registerSetInteger(reg, "MagazineNetwork", 0)
	end
end

function LoadJsonMagazineNetworkData()
	local reg = registerCreate("magazine")
	local strNetworkData = registerGetInteger(reg, "MagazineNetwork")
	if strNetworkData then
		local jsonTable = jsonToTable(strNetworkData)
		return jsonTable
	end
	return nil
end

function LoadMagazinePage(jsonTable)
	require "module.common.SceneUtils"
	if jsonTable.type == 1 then
		Go2Scene("MODULE:\\forepage.xml")
	elseif jsonTable.type == 2 then
		Go2Scene("MODULE:\\test1.xml")
	elseif jsonTable.type == 3 then
		Go2Scene("MODULE:\\backpage.xml")
	end
end

function WriteMagazien2MessageBox(contentName,foldName)
	require("module.protocol.protocol_channel")
	messageContent = ""
	if nil ~= contentName and "" ~= contentName then
		if messageContent then
			messageContent = messageContent.."{MsgTitle}:{"..contentName.."},"
			messageContent = messageContent.."{ChannelName}:{"..contentName.."},"
			WriteLogs("WriteMagazien2MessageBox--ContentName="..contentName)
		else
			messageContent = "{MsgTitle}:{"..contentName.."},"
			messageContent = "{ChannelName}:{"..contentName.."},"
			WriteLogs("WriteMagazien2MessageBox-json.ContentName="..contentName)
		end
	end
	
	if messageContent and foldName then
		messageContent = messageContent.."{UrlPath}:{MODULE:\\videoexpress\\"..foldName.."\\cover.js},"
	else
		messageContent = "{UrlPath}:{MODULE:\\videoexpress\\"..foldName.."\\cover.js},"
	end
	
	if messageContent and foldName then
		messageContent = messageContent.."{magazineItemName}:{"..foldName.."},"
	else
		messageContent = "{magazineItemName}:{"..foldName.."},"
	end
	
	local year, month, day, hour, minute, second = GetTime()
	local receiveData = year.."-"..(month).."-"..(day).." "..(hour)..":"..(minute)..":"..(second)
	messageContent = messageContent.."{receiveData}:{"..receiveData.."},"
	
	--需判断文件是否存在，不存在则创建新文件
	require "module.common.io"
	local regCreate = registerCreate("friendsrecommended_detail")
	registerSetString(regCreate, "recommendMsgCategoryID", "5")
	local filename ="MODULE:\\videoexpress\\categoryID5.xml"
	local fileExist = fileExist(filename)
	if nil == fileExist then
		local regCategory = registerCreate("temp")
		registerSetString(regCategory, "count", "0")
		registerSetString(regCategory, "categoryName", "视频杂志")
		registerSave(regCategory, filename)
		WriteLogs("createNewFile 成功")
		local regCategory0 = registerCreate("Category0")
		registerLoad(regCategory0, "MODULE:\\videoexpress\\categoryID0.xml")
		local totalcount = registerGetInteger(regCategory0, "totalcount")
		if 5 > totalcount then
			registerSetString(regCategory0, "totalcount", 5)
			registerSave(regCategory0, "MODULE:\\videoexpress\\categoryID0.xml")
		end
		registerRelease("temp")
		registerRelease("Category0")
	end
	local regCategory = registerCreate("temp")
	registerLoad(regCategory, filename)
	local count = registerGetInteger(regCategory, "count")
	count = count + 1
	WriteLogs("count="..count)
	registerSetString(regCategory, "count", tostring(count)) --用于遍历计算item个数

	--跳转之后读取数据需要的参数
	local reg_f = registerCreate("friendsrecommended_detail")

	if nil ~= messageContent and "" ~= messageContent then
		local itemIndex = "item"..count
		WriteLogs("itemIndex="..itemIndex)
		registerSetString(regCategory, itemIndex, messageContent)
		WriteLogs("messageContent="..messageContent)
	end

	registerSave(regCategory, filename)
	registerRelease("temp")
end

function GetTime()
	require ("module.protocol.protocol_systime")
	local jsonfile = OnSysDataDecode()
	if jsonfile and jsonfile.sysDate then
		local year, month, day, hour, minute, second = ParseDate(jsonfile.sysDate)
		return ParseDate(jsonfile.sysDate)
	else
		local m_date=os.date("*t", os.time())
		return m_date.year, m_date.month, m_date.day, m_date.hour, m_date.min, m_date.sec
	end
end

--时间格式20100621125251
function ParseDate(time)
	if time ~= "" then
		local year = string.sub(time,1,4)
		local month = string.sub(time,5,6)
		local day = string.sub(time,7,8)
		local hour = string.sub(time,9,10)
		local minute = string.sub(time,11,12)
		local second = string.sub(time,13,14)
		return year, month, day, hour, minute, second
	else
		return 0
	end
end

