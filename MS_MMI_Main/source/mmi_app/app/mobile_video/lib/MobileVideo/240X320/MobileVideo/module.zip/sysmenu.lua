﻿
popmenu_map = {
									menuitem_open = "sysmenu_open",
									menuitem_file = "sysmenu_file",
									menuitem_tool = "sysmenu_tool",
									menuitem_service = "sysmenu_service",
									menuitem_help = "sysmenu_help",
									menuitem_theme = "sysmenu_theme",
};
isEnable = 1
keyQuickLauncherBar = "QuickLauncherBar";
SPRITENAME_SYSMENU = "sysmenu";

function popMenuOnSelect(sprite)
	WriteLogs("Name:"..GetSpriteName(sprite))
	if GetSpriteName(sprite)=="menu-sz" then
	return 0 end
	local	reg = registerCreate(keyQuickLauncherBar)
	local	rootSprite = registerGetInteger(reg, "rootSprite")
	local menuSprite = FindChildSprite(rootSprite, SPRITENAME_SYSMENU)
	local	menuName = GetSpriteName(GetParentSprite(sprite))
	local popSprite = FindChildSprite(rootSprite, popmenu_map[menuName])
	
	if popSprite == 0 then
		popSprite = CreateSprite("node", menuSprite)
		SetSpriteName(popSprite, popmenu_map[menuName])
		LoadSprite(popSprite, "MODULE:\\" .. popmenu_map[menuName] .. ".xml")
		require("module." .. popmenu_map[menuName])
	end
	home_menu=popSprite
	if popmenu_map[menuName] == "sysmenu_service" then
		require "module.protocol.protocol_usercheck"
		local Status = GetUserAuthority(122,"001")
		if Status == 2 then
		else
			local freeregist = FindChildSprite(rootSprite, "resign")
			SetSpriteEnable(freeregist,0)
		end
	end
	if popmenu_map[menuName] == "sysmenu_file" then
		require "module.protocol.protocol_usercheck"
		local Status = GetUserAuthority(122,"001")
		if Status ~= 1 then
		else
			local uploadManager = FindChildSprite(rootSprite, "upload")
			local uploadFile = FindChildSprite(rootSprite, "uploadFile")
			SetSpriteEnable(uploadManager,0)
			SetSpriteEnable(uploadFile, 0)
		end
	end
	ShowPopupMenu(popSprite, 1);
	local reg=registerCreate("popS")
	registerSetInteger(reg,"pop",popSprite)
	
	--↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓点击事件和键盘事件一样处理↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
		local homeReg=registerCreate("homeButton")
		local homeSprite=registerGetInteger(homeReg,"homeButton")
		
		local toolReg=registerCreate("toolButtonSprite")
		local toolSprite=registerGetInteger(toolReg,"toolButton")
		
		local fileReg=registerCreate("fileButtonSprite")
		local fileSprite=registerGetInteger(fileReg,"fileButton")
	
		
		local servicereg=registerCreate("serviceButtonSprite")
		local serviceSprite=registerGetInteger(servicereg,"serviceButton")
		
		local helpreg=registerCreate("helpButtonSprite")
		local helpSprite=registerGetInteger(helpreg,"helpButton")
		local list1={"menuitem_open","menuitem_tool","menuitem_file","menuitem_service","menuitem_help","menuitemexit","menuitem_theme"}
		local  reg1= registerCreate("passSprite") --add
		if menuName==list1[1] then
			SetSpriteFocus(FindChildSprite(home_menu,"menu-home"))
		elseif menuName==list1[2] then
			SetSpriteFocus(FindChildSprite(home_menu,"menu-sc"))
			local reg=registerCreate("popS")
			popSprite=registerGetInteger(reg,"pop")
			local regLeft=registerCreate("popL")
			registerSetInteger(regLeft,"pop",popSprite)
			registerSetInteger(reg1, "CurSprite", sprite) --add
		elseif menuName==list1[3] then
			SetSpriteFocus(FindChildSprite(home_menu,"down"))
		elseif menuName==list1[4] then
			SetSpriteFocus(FindChildSprite(home_menu,"myorder"))
		elseif menuName==list1[5] then
			SetSpriteFocus(FindChildSprite(home_menu,"help"))
		elseif menuName==list1[6] then 
			menuExitButtonOnSelect(FindChildSprite(sprite,list[6]))
		elseif menuName==list1[7] then 
			--[[add]]--
			local list = GetParentSprite(FindChildSprite(home_menu,"menuitem_theme"))
			registerSetInteger(reg1, "SettingSprite", sprite)
			SetSpriteFocus(FindChildSprite(home_menu,"black"))
			SetSpriteEnable(list, 1)
			SetSpriteVisible(list, 1)

			--registerSetInteger(reg1, "CurSprite", sprite) --add
			--SetSpriteFocus(FindChildSprite(home_menu,"black"))
		end
	--↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑点击事件和键盘事件一样处理↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
end

function menuBoardOnMouseUp(sprite, x, y)
	hideMenuSprite();
	---用于解决触摸点击菜单后，再次点击空白区域失焦点问题---
	local reg = registerCreate("PopMenuHide") 
	local sencePreFocus=registerGetInteger(reg,"sencePreFocus") 
	SetSpriteFocus(sencePreFocus)
	----------------------------------------------------
end

function menuItemOnStatusChanged(sprite, selected)
	local button = FindChildSpriteByClass(sprite, "button")
	if button ~= 0 then
		if selected == 0 then
			SetSpriteProperty(button, "selected", "false")
			local	menuName = GetSpriteName(sprite)
			if popmenu_map[menuName] then
				local	reg = registerCreate(keyQuickLauncherBar)
				local	rootSprite = registerGetInteger(reg, "rootSprite")
				popSprite = FindChildSprite(rootSprite, popmenu_map[menuName])
				if popSprite ~= 0 then
					ShowPopupMenu(popSprite, 0)
				end
			end
		else
			SetSpriteProperty(button, "selected", "true")
		end
	end
end

function ShowPopupMenu(popSprite, show)
	if show == 0 then
		SetSpriteVisible(popSprite, 0)
		SetSpriteEnable(popSprite, 0)
		childPopSprite = FindChildSpriteByClass(popSprite, "list")
		if childPopSprite ~= 0 then
			SpriteList_SetCurItem(childPopSprite, -1)
		end
	else
		SetSpriteVisible(popSprite, 1)
		SetSpriteEnable(popSprite, 1)
	end
end

function hideMenuSprite(rootSprite)
	local	reg = registerCreate(keyQuickLauncherBar)
	local	rootSprite = registerGetInteger(reg, "rootSprite")
	local menuSprite = FindChildSprite(rootSprite, SPRITENAME_SYSMENU)

	if menuSprite ~= 0 then
		ReleaseSpriteCapture(rootSprite)
		RemoveChildSprite(rootSprite, menuSprite, 1)
	end
end

function menuExitButtonOnSelect(button)
	hideMenuSprite()
	WriteLogs("menuExitButtonOnSelect")
	require "module.dialog.useDialog"
	require "module.common.SceneUtils"
	local	reg = registerCreate(keyQuickLauncherBar)
	local	rootSprite = registerGetInteger(reg, "rootSprite")
	local 	spriteEvent = FindChildSprite(rootSprite,"event")
	local   rootScene =  GetCurScene()
	local regHandle = registerCreate("SCMngr_handle")
	local SceneName = registerGetString(regHandle, string.format("%d", rootScene))
	
	local dlgImg = {}
	dlgImg.OK_N_IMG = "file:///image/common/tc1.png"
	dlgImg.OK_F_IMG = "file:///image/common/tc2.png"
	setDialogParam("退出", "您确认要退出吗？", "BT_OK_CANCEL",SceneName ,nil,spriteEvent,nil,dlgImg)
	Go2Scene(sceneDialog)
end

--@function 		SetReturn
--@tag-name 		无
--@tag-action		OnSelect
--@brief 				返回前需要做的事，如果该页面需要被返回，则调用这个函数
function SetReturn1(nextScenceName)
	require "module.common.registerScene"
	local	regQuick = registerCreate(keyQuickLauncherBar)
	local	rootSprite = registerGetInteger(regQuick, "rootSprite")
	local   rootScene =  GetCurScene()
	local regHandle = registerCreate("SCMngr_handle")
	local SceneName = registerGetString(regHandle, string.format("%d", rootScene))
	if SceneName ~= sceneHome and nextScenceName ~= sceneRegisterInformation then
		FreeScene(rootScene)
	end
	
	--找到数据仓库
 	reg = registerCreate(keyQuickLauncherBar)
 	--需要返回的总数+1
 	local count = registerGetInteger(reg, "Count")+1
	registerSetInteger(reg, "Count", count)
	local CurPage = registerGetString(reg, "CurPage")
	registerSetString(reg, "PageName" .. count, CurPage)
	registerSetString(reg, "CurPage", nextScenceName)
end

function OnSpriteEvent_SysMenu(message, params)
	if message == 1001 then
		local reg = registerCreate("product")
		local jsonString = registerGetInteger(reg, "ChannelNetwork")
		if jsonString ~= 0 then
			jsonRelease(jsonString)
			registerSetInteger(reg, "ChannelNetwork", 0)
		end
		local reg = registerCreate("guide")
		local jsonString = registerGetInteger(reg, "channelGroupNetwork")
		if jsonString ~= 0 then
			jsonRelease(jsonString)
			registerSetInteger(reg, "channelGroupNetwork", 0)
		end
		local reg = registerCreate("home")
		local jsonString = registerGetInteger(reg, "HomeNetwork")
		if jsonString ~= 0 then
			jsonRelease(jsonString)
			registerSetInteger(reg, "HomeNetwork", 0)
		end
		local reg = registerCreate("topTen")
		local jsonString = registerGetInteger(reg, "channelGroupNetwork")
		if jsonString ~= 0 then
			jsonRelease(jsonString)
			registerSetInteger(reg, "channelGroupNetwork", 0)
		end
		require "module.common.SceneUtils"
		checkCacheCondition()
		Exit()
	elseif message == 1002 then

	end
end

function OnPluginEvent_SysMenu(message, param)
	WriteLogs("bodyOnPluginEvent")
	if message == 122 or message == 123 or message ==124 then

	end
end

function addFavOnSelect(button)
	WriteLogs("addFavOnSelect");
	require("module.common.commonMsg")
	hideMenuSprite()
	require "module.protocol.protocol_video"
	OnReturnButton()
	local root = GetCurScene()
	SendSpriteEvent(root, MSG_ADD_FAV)
	require "module.sysmenu_tool"
	systools(button, 3)
end

function SysGetSeceSprite(sprite)
        reg = registerCreate("sysSprite")			--创建数据仓库，获取F1前的焦点
		registerSetInteger(reg,"sprite_name",sprite)
end

function AllowAddFav(_value)
	if 0 == _value then
		local scSprite = FindChildSprite(home_menu,"lab_SC")
		SetSpriteProperty(scSprite,"color","#848484")
		isEnable = 0
		SetSpriteFocus(FindChildSprite(home_menu,"menu-zt"))
	elseif 1 == _value then
		SetSpriteFocus(FindChildSprite(home_menu,"menu_sc"))
		isEnable = 1
	end
end


function buttonSelectKeyUp(sprite,keyCode)
	flag=0
	local homeReg=registerCreate("homeButton")
	local homeSprite=registerGetInteger(homeReg,"homeButton")
	
	local toolReg=registerCreate("toolButtonSprite")
	local toolSprite=registerGetInteger(toolReg,"toolButton")
	
	local fileReg=registerCreate("fileButtonSprite")
	local fileSprite=registerGetInteger(fileReg,"fileButton")

	
	local servicereg=registerCreate("serviceButtonSprite")
	local serviceSprite=registerGetInteger(servicereg,"serviceButton")
	
	local helpreg=registerCreate("helpButtonSprite")
	local helpSprite=registerGetInteger(helpreg,"helpButton")
	
	
	
    
	
	require("module.QuickLauncherBar")
	SysGetSeceOpenSprite(sprite)
	require("module.keyCode.keyCode")
	WriteLogs("---------------::keyCode:"..keyCode)
	WriteLogs(".......spriteName:"..GetSpriteName(sprite))
	BtName=GetSpriteName(sprite)
	local list1={"menuitem_open","menuitem_tool","menuitem_file","menuitem_service","menuitem_help","menuitemexit"}
	local list={"open","tools","file","service","help","exit"}
	local listtable={"menuitem_open","menuitem_tool","menuitem_file","menuitem_service","menuitem_help"}
	for i=1,6  do
		if BtName==list1[i] then
		 num=i 
		 break
		end
	end
		if keyCode == ApKeyCode_Enter or keyCode== ApKeyCode_Right  then
			WriteLogs("+++++++_------------------++++")
			local  reg = registerCreate("passSprite")
			registerSetInteger(reg, "CurSprite", sprite)
			
			local flagReg=registerCreate("flagnum")
			flag=registerGetInteger(flagReg,"flagnum")
			 WriteLogs("标志位："..flag)
			if flag==0 then
				name=GetSpriteName(sprite)
				for i=1,6 do
					if name==list1[i] then 
						if i==1 then popMenuOnSelect(FindChildSprite(sprite,list[1]))   								
								SetSpriteFocus(FindChildSprite(home_menu,"menu-home"))
								break
						elseif i==2 then popMenuOnSelect(FindChildSprite(sprite,list[2])) 
									WriteLogs("==dw==")									
									local curScene = GetCurScene()
									local SCname	= FindScene(scenePrograminfo_volume)
									local Productname	= FindScene(sceneProduct)
									WriteLogs("==dw== curScene = "..curScene)
									WriteLogs("==dw== SCname = "..SCname)
									if curScene == SCname or curScene == Productname then
										AllowAddFav(1)
									else
										AllowAddFav(0)
									end

								local reg=registerCreate("popS")
									popSprite=registerGetInteger(reg,"pop")
									local regLeft=registerCreate("popL")
									registerSetInteger(regLeft,"pop",popSprite)
									break
						elseif i==3 then popMenuOnSelect(FindChildSprite(sprite,list[3]))
									SetSpriteFocus(FindChildSprite(home_menu,"down"))
									break
						elseif i==4 then popMenuOnSelect(FindChildSprite(sprite,list[4])) 
									SetSpriteFocus(FindChildSprite(home_menu,"myorder"))
									break
						elseif i==5 then popMenuOnSelect(FindChildSprite(sprite,list[5])) 
									SetSpriteFocus(FindChildSprite(home_menu,"help"))
									break
						elseif i==6 then menuExitButtonOnSelect(FindChildSprite(sprite,list[6])) break
						end
						
					end
				end
			elseif flag==1 then
		
			
			registerSetInteger(flagReg,"flagnum",0)
				for j=1,6 do
					if BtName==list1[6] then
						cursprite=FindChildSprite(sprite,list[6])
						menuExitButtonOnSelect(cursprite)
					
						break
					elseif BtName==list1[j] then
						local regpass=registerCreate("PassLeft")--传递参数
						local passSpritePath=registerGetInteger(regpass,"spritePassLeft")
						cursprite=FindChildSprite(sprite,list[j])
						popMenuOnSelect(cursprite)
						WriteLogs("curspriteName="..GetSpriteName(passSpritePath))
						SetSpriteVisible(GetParentSprite(GetParentSprite(passSpritePath)),1)
						SetSpriteEnable(GetParentSprite(GetParentSprite(passSpritePath)),1)

						local Name=GetSpriteName(GetParentSprite(GetParentSprite(passSpritePath)))
					
						local SpriteName=GetSpriteName(sprite)
			
						
							for m=1,5 do
								if Name==SpriteName then
									SetSpriteFocus(passSpritePath) 
									break
								elseif SpriteName==listtable[1] then
										
										popMenuOnSelect(cursprite) 
										SetSpriteFocus(homeSprite)
										break
								elseif SpriteName==listtable[2] then
										WriteLogs("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH")
										popMenuOnSelect(cursprite) 
										SetSpriteFocus(toolSprite)
										break
								elseif  SpriteName==listtable[3] then
										
										popMenuOnSelect(cursprite)
										
										SetSpriteFocus(fileSprite)
										
										break
										
								elseif SpriteName==listtable[4] then
										
										popMenuOnSelect(cursprite) 
										SetSpriteFocus(serviceSprite)
										break
										
								elseif SpriteName==listtable[5] then
										
										popMenuOnSelect(cursprite) 
										SetSpriteFocus(helpSprite)
										break
								end
							end
						break
					end
					
				end
				return 1
			end	
		
		elseif keyCode==ApKeyCode_Down and num<=6 then
				WriteLogs("9999999999999999999999999999")
				local flagReg=registerCreate("flagnum")
				registerSetInteger(flagReg,"flagnum",0)
				if num==6 then 
				SetSpriteFocus(FindChildSprite(GetParentSprite(sprite),list1[1]))
				else
				cursprite=FindChildSprite(GetParentSprite(sprite),list1[num+1])
				SetSpriteFocus(FindChildSprite(GetParentSprite(sprite),list1[num+1]))
				WriteLogs("+_+_+_+__+_+_+_+_+_+__+_"..GetSpriteName(FindChildSprite(GetParentSprite(sprite),list1[num+1])))
				
				
				end
		
		elseif keyCode==ApKeyCode_Up   then
			local flagReg=registerCreate("flagnum")
			registerSetInteger(flagReg,"flagnum",0)
			if num==1 then 
				SetSpriteFocus(FindChildSprite(GetParentSprite(sprite),list1[6]))
			else
			cursprite=FindChildSprite(GetParentSprite(sprite),list1[num-1])
			SetSpriteFocus(FindChildSprite(GetParentSprite(sprite),list1[num-1]))
		
			end



		
		elseif keyCode == ApKeyCode_F1 then
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			require("module.menuopen")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
			WriteLogs("SenceSprite:"..GetSpriteName(SenceSprite))
			WriteLogs("result="..HasSpriteFocus(SenceSprite))
			WriteLogs("sysmenuName:_-+_+_+_+_+_+_+"..GetSpriteName(sprite))
		elseif keyCode == ApKeyCode_F2  then
			require("module.menuopen")
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
	end

	return 1
end





