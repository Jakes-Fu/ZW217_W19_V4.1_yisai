﻿--author xf_pan
--date  2010/05/31

require "module.Loading.useLoading"

function bodyBuildChildrenFinished(sprite)
--[[
	reg = registerCreate("Loading_")
	registerSetInteger(reg, "root", sprite)
	
	local backgroundSprite = FindChildSprite(sprite, "back-groud")
	
	backScene, background = GetLoadingParam()
	WriteLogs("backScene:" .. backScene)
	WriteLogs("background:" .. background)
	if background ~= nil and background ~= "" then
		WriteLogs("backgroundSprite:" .. background)
		AddChildSprite(backgroundSprite, background)
	end
	--]]
	return 1
end

function backOnClick()

	if backScene ~= nil and backScene ~= "" then
		SetCurScenen(backScene)
	end
end