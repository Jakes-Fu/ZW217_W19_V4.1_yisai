﻿--@module magazine
--@note 视频杂志
--@author wangzhiyuan wangweipeng
--@date 2010/08/25
require "module.protocol.protocol_magazine"
require "module.common.commonScroll"
require "module.Loading.useLoading"
require "module.common.SceneUtils"

local categoryName = {"视频", "音频", "图片", "复合", "内容集"}
local category = {
    {"category11", visible = {1, 0, 0}},
    {"category21", "category22", visible = {0, 1, 0}},
    {"category31", "category32", "category33", visible = {0, 0, 1}}
}
local json = {}
local URL = "" --"http://172.16.14.119/data/"

function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("magazine")
	registerSetInteger(reg, "root", sprite)
end

function OnSpriteEvent(message, params)
	require("module.common.commonMsg")
	if message == MSG_ACTIVATE then
		loadMagazineFile()
	elseif message == MSG_RETURN then
		require("module.common.SceneUtils")
		FreeScene(GetCurScene())
	end
end

function loadMagazineFile()
	if not MagazineNetworkData() then
		require "module.dialog.useDialog"
		setDialogParam("提示", "服务器返回数据错误", "BT_OK", sceneHome, sceneMagazine, nil)
		Go2Scene(sceneDialog)
		return
	end
	json = LoadJsonMagazineNetworkData()
	if json.type == "101" then
		beforeCreateSprite(0, 0, 1, "MODULE:\\magazine_cover.xml")
		loadMagazineCover(json.items, "title", "MODULE:\\magazine_listItem_cover.xml", 69,json.magazine)
	elseif json.type == "102" then
		beforeCreateSprite(1, 1, 1, "MODULE:\\magazine_content.xml")
		loadMagazineContent()
	elseif json.type == "103" then
		beforeCreateSprite(1, 1, 0, "MODULE:\\magazine_back.xml")
		loadMagazineCover(json.recommends, "nodeName", "MODULE:\\magazine_listItem_backcover.xml", 61 ,json.magazine)
	else
		require "module.dialog.useDialog"
		setDialogParam("提示", "服务器返回数据错误", "BT_OK",sceneHome, sceneMagazine, nil)
		Go2Scene(sceneDialog)
	end
end

function loadMagazineCover(titleList, field, itemXmlPath, percentlimit ,specialuse)
	local sprite = registerGetInteger(registerCreate("magazine"), "root")
	local spriteList = FindChildSprite(sprite, "subject-list")
	local count = #titleList
	SpriteList_LoadListItem(spriteList, itemXmlPath, count + 1)
	for i = 0, count do
		local menuprograminfoSprite = SpriteList_GetListItem(spriteList, i)
		SetSpriteRect(menuprograminfoSprite, 0,0,205,28)
		local spritetextN = FindChildSprite(menuprograminfoSprite, "subjectButtontextN")
		local spritetextF = FindChildSprite(menuprograminfoSprite, "subjectButtontextF")
		SetSpriteProperty(spritetextN, "text", titleList[i][field])
		SetSpriteProperty(spritetextF, "text", titleList[i][field])
	end
	SpriteList_Adjust(spriteList)
	local page = split(json.magazine[0].pageInfo, "/")
	SetSpriteProperty(FindChildSprite(sprite, "list-status"), "text", "第" .. page[1] .. "页 / 共" .. page[2] .. "页")
	local itemPerPage = SpriteList_GetItemPerPage(spriteList)
	CreateScrollBar(sprite, "subject-list", 28 * math.min(itemPerPage, count + 1), percentlimit)
	if specialuse and specialuse[0] and specialuse[0].homeUrl then
		local i,j = string.find(specialuse[0].homeUrl,"http")
		if not( j and j > 0 ) then
			local download = FindChildSprite(sprite,"download")
			SetSpriteVisible(download,0)
			SetSpriteEnable(download,0)
		end
	end
	if specialuse and specialuse[0] and specialuse[0].bgImgPath then
		SetSpriteProperty(FindChildSprite(sprite, "coverimage"),"src", specialuse[0].bgImgPath)
	end
end

function loadMagazineContent()
	local root = registerGetInteger(registerCreate("magazine"), "root")
	CreateScrollBar(root, "testnode", 177, 69)
	local layout = tonumber(json.layout)
	setMagazineContent(layout, unpack(category[layout].visible))
end

function MenuItemOnSelect(sprite)
	local index = SpriteListItem_GetIndex(GetSpriteParent(sprite))
	ReleaseSpriteCapture(sprite)
	if json.items[index].urlPath ~= nil and json.items[index].urlPath ~= "" then
		if -1 == RequestMagazine(2012, URL .. json.items[index].urlPath) then
			loadMagazineFile()
		else
			local reg = registerCreate("magazine")
			enterLoading(FindChildSprite(registerGetInteger(reg, "root") ,"loadarea"))
		end
	elseif json.items[index].pageID ~= nil and json.items[index].pageID ~= "" then
		RequestMagazine(2012,"page-"..json.items[index].pageID..".js")
		loadMagazineFile()
	end
end

function RecommendItemOnSelect(sprite)
	local index = SpriteListItem_GetIndex(GetSpriteParent(sprite))
	ReleaseSpriteCapture(sprite)
	if json.recommends[index].recommUrl ~= nil and json.recommends[index].recommUrl ~= "" then
		if -1 == RequestMagazine(2012, URL .. json.recommends[index].recommUrl) then
			loadMagazineFile()
		else
			local reg = registerCreate("magazine")
			enterLoading(FindChildSprite(registerGetInteger(reg, "root") ,"loadarea"))
		end
	end
end

function OnPluginEvent(message, param)
	if message == 2012 then
		exitLoading()
		loadMagazineFile()
	elseif message == 103 then
		require "module.common.SceneUtils"
		RequestPlay("MODULE:\\magazine.xml")
	elseif message == 984 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "下载成功,请在收件箱中查看", "BT_OK", sceneMagazine, sceneMagazine, nil)
		Go2Scene(sceneDialog)
		if magazineItemName and magazineItemName ~= "" then
			WriteMagazien2MessageBox(magazineItemName)
			Makefolder("MODULE:\\videoexpress\\"..magazineItemName)
			local src = "MODULE:\\videoexpress\\"..magazineItemName..".zip"
			local target = "MODULE:\\videoexpress\\"..magazineItemName.."\\"
			local unzip = BeginUnzip(src, target)
			if not unzip then
				WriteLogs("bad ZPKG file")
			else
				while GoToUnzipNextFile(unzip) do
					ProcessUnzip(unzip)
				end
				EndUnzip(unzip)
			end
		end
		os.remove(GetDefaultFolder(WDFIDL_MODULE).."videoexpress\\"..magazineItemName..".zip")
	elseif message > 32768 then
		exitLoading()
		require "module.dialog.useDialog"
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneMagazine, sceneMagazine, nil)
		Go2Scene(sceneDialog)
	elseif message == 32768 then
		require "module.dialog.useDialog"
		setDialogParam("提示", "拨号失败", "BT_OK", sceneMagazine, sceneMagazine, nil)
		dailFail = 1
		Go2Scene(sceneDialog)
	elseif MSG_SMS_ID == message then
		require "module.videoexpress-common"
		DealMsgContent(sceneMagazine, sceneMagazine)
	end
end

function playButtonOnClick1()
	toPlay(0)
end

function playButtonOnClick2()
	toPlay(1)
end

function playButtonOnClick3()
	toPlay(2)
end

function nextPageOnClick(sprite)
	ReleaseSpriteCapture(sprite)
	if -1 == RequestMagazine(2012, URL .. json.magazine[0].nextPageUrl) then
		loadMagazineFile()
	else
		local reg = registerCreate("magazine")
		enterLoading(FindChildSprite(registerGetInteger(reg, "root") ,"loadarea"))
	end
end

function prePageOnClick(sprite)
	ReleaseSpriteCapture(sprite)
	if -1 == RequestMagazine(2012, URL .. json.magazine[0].prePageUrl) then
		loadMagazineFile()
	else
		local reg = registerCreate("magazine")
		enterLoading(FindChildSprite(registerGetInteger(reg, "root") ,"loadarea"))
	end
end

function backToMenu(sprite)
	ReleaseSpriteCapture(sprite)
	if -1 == RequestMagazine(2012, URL .. json.magazine[0].homeUrl) then
		loadMagazineFile()
	else
		local reg = registerCreate("magazine")
		enterLoading(FindChildSprite(registerGetInteger(reg, "root") ,"loadarea"))
	end
end

function reviewButtonSelect(sprite)
	ReleaseSpriteCapture(sprite)
	if -1 == RequestMagazine(2012, URL .. json.magazine[0].homeUrl) then
		loadMagazineFile()
	else
		local reg = registerCreate("magazine")
		enterLoading(FindChildSprite(registerGetInteger(reg, "root") ,"loadarea"))
	end
end

function downloadButtonSelect(sprite)
	ReleaseSpriteCapture(sprite)
	require("module.protocol.protocol_downloadinfor")
	local reg = registerCreate("magazine")
	local folder = OpenDirectory(GetDefaultFolder(WDFIDL_MODULE).."videoexpress\\"..registerGetString(reg,"magazinename").."\\")
	if not folder then
		if json and json.magazine and json.magazine[0] and json.magazine[0].downUrl then
			AppendDownloadQueueForMagazine(json.magazine[0].downUrl,registerGetString(reg,"magazinename"),984)
			enterLoading(FindChildSprite(registerGetInteger(reg, "root") ,"loadarea"))
			magazineItemName = registerGetString(reg, "magazinename")
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "错误的下载地址", "BT_OK", sceneMagazine, sceneMagazine, nil)
			Go2Scene(sceneDialog)
		end
	else
		require("module.dialog.useDialog")
		setDialogParam("提示", "该杂志已存在于收件箱中", "BT_OK", sceneMagazine, sceneMagazine, nil)
		Go2Scene(sceneDialog)
	end
end

function split(str, flag)
	local begin, m, n = 1, 1, 1
	local list = {}
	while true do
		m, n = string.find(str, flag, begin)
		if not n then
			table.insert(list, string.sub(str, begin, #str))
			return list
		end
		table.insert(list, string.sub(str, begin, m - 1))
		begin = n + 1
	end
end

function toPlay(n)
	require "module.protocol.protocol_videoloading"
	local reg = registerCreate("magazine")
	require "module.Loading.useLoading"
	enterLoading(FindChildSprite(registerGetInteger(reg, "root") ,"loadarea"))
	RequestVideo(103, json.contents[n].playUrl, "", registerGetString(reg,"magazinename") ,"demand")
	local reg = registerCreate("product")
	registerSetString(reg, "playurl", json.contents[n].playUrl)
	registerSetString(reg, "contentid", json.contents[n].contentId)
end

function setMagazineContent(layout, play1, play2, play3)
	local reg = registerCreate("magazine")
	local root = registerGetInteger(reg, "root")
	SetSpriteVisible(FindChildSprite(root, "play1"), play1)
	SetSpriteVisible(FindChildSprite(root, "play2"), play2)
	SetSpriteVisible(FindChildSprite(root, "play3"), play3)
	SetSpriteEnable(FindChildSprite(root, "button11"), play1)
	SetSpriteEnable(FindChildSprite(root, "button21"), play2)
	SetSpriteEnable(FindChildSprite(root, "button22"), play2)
	SetSpriteEnable(FindChildSprite(root, "button31"), play3)
	SetSpriteEnable(FindChildSprite(root, "button32"), play3)
	SetSpriteEnable(FindChildSprite(root, "button33"), play3)
	local page = split(json.magazine[0].pageInfo, "/")
	SetSpriteProperty(FindChildSprite(root, "titleText"), "text", json.magazine[0].title)
	SetSpriteProperty(FindChildSprite(root, "list-status"), "text", "第" .. page[1] .. "页 / 共" .. page[2] .. "页")
	SetSpriteProperty(FindChildSprite(root, "textarea"), "text", json.magazine[0].paragraphe)
	for i = 1, #category[layout] do
		SetSpriteProperty(FindChildSprite(root, category[layout][i]), "text", categoryName[tonumber(json.contents[i - 1].category)])
	end
	if play1 == 1 then
		local i,j = string.find(json.magazine[0].imgPath,"http")
		if j and j > 0 then
			WriteLogs("Magazine Image Type:remote ")
			WriteLogs("remote path :"..json.magazine[0].imgPath)
			local img = FindChildSprite(root, "magazine_img1")
			SetSpriteProperty(img, "src", json.magazine[0].imgPath)
		else
			WriteLogs("Magazine Image Type:local ")
			local dir = OpenDirectory(GetDefaultFolder(WDFIDL_MODULE).."videoexpress\\"..registerGetString(reg,"magazinename").."\\*.png")
			for c=0,#dir do
				local filename = dir[c].filename
				local g,h = string.find(dir[c].filename,json.magazine[0].pageId)
				if h and h > 0 then
					SetSpriteProperty(FindChildSprite(root, "magazine_img1"), "src", "file://videoexpress/"..registerGetString(reg,"magazinename").."/"..dir[c].filename)
				end
			end
		end
	elseif play2 == 1 then
		local i,j = string.find(json.magazine[0].imgPath,"http")
		if j and j > 0 then
			WriteLogs("Magazine Image Type:remote ")
			WriteLogs("remote path :"..json.magazine[0].imgPath)
			local img = FindChildSprite(root, "magazine_img2")
			SetSpriteProperty(img, "src", json.magazine[0].imgPath)
		else
			local dir = OpenDirectory(GetDefaultFolder(WDFIDL_MODULE).."videoexpress\\"..registerGetString(reg,"magazinename").."\\*.png")
			for c=0,#dir do
				WriteLogs("Magazine Image Type:local ")
				local filename = dir[c].filename
				local g,h = string.find(dir[c].filename,json.magazine[0].pageId)
				if h and h > 0 then
					SetSpriteProperty(FindChildSprite(root, "magazine_img2"), "src", "file://videoexpress/"..registerGetString(reg,"magazinename").."/"..dir[c].filename)
				end
			end
		end
	end
end

function beforeCreateSprite(menu, prePage, nextPage, xmlPath)
	local root = registerGetInteger(registerCreate("magazine"), "root")
	SetSpriteEnable(FindChildSprite(root, "button-backmenu"), menu)
	SetSpriteEnable(FindChildSprite(root, "button-backprogram"), prePage)
	SetSpriteEnable(FindChildSprite(root, "button-nextprogram"), nextPage)
	local superSprite = FindChildSprite(root, "superSprite")
	ClearChildSprite(superSprite)
	LoadSprite(superSprite, xmlPath)
end
