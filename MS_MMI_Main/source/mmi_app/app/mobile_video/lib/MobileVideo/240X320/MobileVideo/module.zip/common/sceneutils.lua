﻿--@module SceneUtils.lua
--@note 和场景操作有关的一组通用函数
--@author pxf
--@date 2010/06/01
require("module.common.registerScene")

--场景跳转
--@param hiddenMenu  nil:显示菜单   1:不显示
function Go2Scene(nextSceneName, hiddenMenu)
	-- 由于用法不同，部分场景依然不会使用 registerScene 中的内容，导致一些大小问题，从而无法正确获取场景指针
	local regKey = registerCreate("SCMngr")
	local nextSceneHandle = registerGetInteger(regKey,nextSceneName)
	WriteLogs("Go2Scene sc:"..nextSceneName.." handle:"..nextSceneHandle)
	if GetSceneName() == sceneRecommend and nextSceneName == sceneDialog then
		--[[  互动界面到对话框界面需要控制播放器不stop，特此发9999消息  ]]--
		SendSpriteEvent(GetCurScene(),9999)
	end
	if nil == nextSceneHandle or nextSceneHandle == 0 then
		nextSceneHandle = CreateSprite()
		LoadSprite(nextSceneHandle, nextSceneName)
		SetSpriteProperty(nextSceneHandle,"name",nextSceneName)
		registerSetInteger(regKey, nextSceneName, nextSceneHandle)
		--[[ 提供句柄到名字的查找  ]]--
		local regHandle = registerCreate("SCMngr_handle")
		registerSetString(regHandle, string.format("%d", nextSceneHandle), nextSceneName)
	end
	if hiddenMenu == nil and nextSceneName ~= sceneDialog and nextSceneName ~= sceneRecommendMsgDialog then
		removeMenu(GetCurScene())
		LoadQuickLauncherBar(nextSceneHandle)
		------------------------------------------------------------------------------------------dw
		WriteLogs("reuqist...reuqist..reuqist..reuqist.reuqist.reuqist.reuqist.reuqistreuqist")
		local qkLhBar=registerCreate("QkLHBAR")
		SenceSprite=registerGetInteger(qkLhBar,"qKLunchText")	
		local sprite_child=FindChildSprite(SenceSprite,"quicklauncherbar")						
		WriteLogs("TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT......................"..GetSpriteName(sprite_child))
		WriteLogs("nextName:"..nextSceneName)
		if nextSceneName==scenePrograminfo_volume then
			SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按 # 键展开剧情介绍")
		elseif nextSceneName==sceneProduct then
		require("module.protocol.protocol_channel")
			local channelData = ChannelNetworkData()
			jsonChannel = LoadJsonChannelNetworkData()
			if jsonChannel and jsonChannel.imgListNavi then
				for i=0,table.maxn(jsonChannel.imgListNavi) do
					if jsonChannel.imgListNavi[i].haveData == "true" then
						if jsonChannel.imgListNavi[i].channelType == "1" then 
							SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按*或#键可进行翻页")
						elseif jsonChannel.imgListNavi[i].channelType == "2"  or  jsonChannel.imgListNavi[i].channelType == "3" then 
							SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按1,3,7,9键可切换节目单")
						end
						break
					end
				end
				SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","返回")
				SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","返回")
			end
		elseif nextSceneName==sceneHome then
			SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","欢迎使用手机视频业务")
			SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","退出")
			SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","退出")
			local homeLastFoucsReg= registerCreate("homeLastFoucs")
			local homeSprite=registerGetInteger(homeLastFoucsReg,"homeBackSprite")
			SetSpriteFocus(homeSprite)
		elseif nextSceneName==sceneSearchResult then
				SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按*或#键可进行翻页")
				SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","返回")
			SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","返回")
			
		elseif nextSceneName==sceneBulletin then
				SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按 # 键返回页面顶部")
				SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","返回")
			SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","返回")
		elseif nextSceneName==sceneVideoGroup then
				SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按 # 键可展开播放列表")
				SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","返回")
			SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","返回")
		elseif nextSceneName==sceneHelp then
				WriteLogs("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH")
				SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按 # 键返回页面顶部")
					SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","返回")
			SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","返回")
		elseif nextSceneName==sceneHistory then
					SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按 # 键清空历史记录")
					SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","返回")
					SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","返回")
		elseif nextSceneName==sceneReceiveSecondary then
					SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","按 # 键清空消息记录")
					SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","返回")
					SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","返回")
		else
				WriteLogs("ELSE...else...else....else...else")
				SetSpriteProperty(FindChildSprite(sprite_child,"menu-title"),"text","欢迎使用手机视频业务")
				SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"normalName"),"text","返回")
				SetSpriteProperty(FindChildSprite(FindChildSprite(sprite_child,"back"),"focusName"),"text","返回")
		end
		----------------------------------------------------------------------------------------dw
	
end
	SetCurScene(nextSceneHandle)
end

function GetSceneName(scene)
	local tarScene = 0
	if scene == nil then 
		tarScene = GetCurScene()
	else
		tarScene = scene
	end
	local regHandle = registerCreate("SCMngr_handle");
	local SceneName = registerGetString(regHandle, string.format("%d", tarScene))
	return SceneName
end

--@sceneName 场景名字
function SceneMngrAdd(sceneName, sceneHandle)
	local regKey = registerCreate("SCMngr")
	local scene = registerGetInteger(regKey,sceneName)
	if(scene == sceneHandle) then
		return false
	end
	registerSetInteger(regKey, sceneName, sceneHandle)
	--[[ 提供句柄到名字的查找  ]]--
	local regHandle = registerCreate("SCMngr_handle")
	registerSetString(regHandle, string.format("%d", sceneHandle), sceneName)
		
	return 1
end

function removeMenu(scene)
	local menuRoot = FindChildSprite(scene, "MenuBar")
	local returncapture = FindChildSprite(menuRoot,"Return")
	ReleaseSpriteCapture(returncapture)
	if menuRoot ~= nil and menuRoot ~= 0 then
		local regKey = registerCreate("Menu_bar")
		local menu = registerGetInteger(regKey, "static_menu")
		if menu ~= nil and menu ~= 0 then
			RemoveChildSprite(menuRoot, menu)
		end
	end
end

--释放场景
function ByeScene(curSceneName)
	local regKey = registerCreate("SCMngr")
	local curSceneHandle = registerGetNumber(regKey,curSceneName)
	if nil ~= curSceneHandle then
		registerRemove(regKey,curSceneName)
	else
		curSceneHandle = GetCurScene()
	end
	FreeSprite(curSceneHandle)
end

--@brief 页面如需返回，则在跳转前调用，如不需返回，则不调用，
--@brief thisScence是当前场景，nextScence是下一个场景
function SetReturn(thisScence,nextScence)
	if ( thisScence == nil or nextScence == nil ) then
		return
	end
	--[[  找到数据仓库  ]]--
	reg = registerCreate("QuickLauncherBar")
	--需要返回的总数+1
	local count = registerGetInteger(reg, "Count")
	local LastPageName = registerGetString(reg, "PageName"..count)
	if LastPageName ~= thisScence then
		count = count + 1
		if ( count == nil ) then
			count = 1
		end
		registerSetInteger(reg, "Count", count)
		--[[  将当前页面保存  ]]--
		registerSetString(reg, "PageName" .. count, thisScence)
		registerSetString(reg, "CurPage", nextScence)
	end
end

--@brief 载入菜单资源，在bodyBuildChildrenFinished中调用即可
function LoadQuickLauncherBar(sprite)
  local QuickLauncherBar = FindChildSprite(sprite, "MenuBar")
  if QuickLauncherBar == 0 or QuickLauncherBar == nil then
		QuickLauncherBar = CreateSprite("node", sprite)
		SetSpriteProperty(QuickLauncherBar,"name","MenuBar")
	end
	local regKey = registerCreate("Menu_bar")
	local menu = registerGetInteger(regKey,"static_menu")

	--[[  载入菜单资源  ]]--
	if menu == 0 or menu == nil then
		menu = CreateSprite("listitem")
		LoadSprite(menu, 	sceneQuickLaucherButton)
		registerSetInteger(regKey,	"static_menu",	menu);
		registerSetString(regKey,	"isMenuButtomButtonDown", "0");
		registerSetString(regKey,	"isMenuButtonDown",	"0");
	end
	AddChildSprite(QuickLauncherBar, menu)
end

--@brief 当前场景句柄
function FreeScene(scene)
	if scene == nil or scene == 0 then
		return false
	end
	removeMenu(scene)
	local regHandle = registerCreate("SCMngr_handle")
	local SceneName = registerGetString(regHandle, string.format("%d", scene))
	if SceneName ~= ""  then
		local regKey = registerCreate("SCMngr");
		registerRemove(regKey, SceneName)
	end
	FreeSprite(scene)
end

--@brief 场景查找
function FindScene(pathName)
	WriteLogs(string.format("FindScene: %s", pathName))
	local regKey = registerCreate("SCMngr")
	return registerGetInteger(regKey, pathName)
end

--@brief 请求播放
function RequestPlay(returnname)
	local reg = registerCreate("video")
	local filename = registerGetString(reg, "videoFileName")
	registerSetInteger(reg, "isLive",0)
	require "module.protocol.protocol_videoloading"
	local videoData = OnVideoDecode()
	if videoData then
		if videoData.success == "true" then
			--[[  点播直播界面界面  ]]--
			exitLoading()
			local volumeSprite = GetCurScene()
			local regHandle = registerCreate("SCMngr_handle");
			local SceneName = registerGetString(regHandle, string.format("%d", volumeSprite))
			if SceneName == sceneSearchResult or SceneName == sceneFavoriteList then
				FreeScene(GetCurScene())
			end
			local reg = registerCreate("video")
			local videoType = registerGetString(reg, "videoType")
			if videoType == "demand" or videoType == "live" then
				SetReturn(returnname, sceneVideoLiveDemand)
				Go2Scene(sceneVideoLiveDemand)
			elseif videoType == "group" then
				SetReturn(returnname, sceneVideoGroup)
				GoAndFreeScene(sceneVideoGroup)
			end
		else
			exitLoading()
			if videoData.feeds or videoData.once then
				--[[  转到订购，在productorder中保存路径  ]]--
				local regv = registerCreate("video")
				local filename = registerGetString(regv, "videoFileName")
				local regp = registerCreate("productorder")
				registerSetString(regp,"fileName",filename)
				registerSetString(regp,"returntype","play")
				SetReturn(returnname, sceneVideoLiveDemand)
				GoAndFreeScene(sceneOrderProduct)
			else
				require "module.dialog.useDialog"
				setDialogParam("提示", "获取网络数据错误", "BT_OK", returnname, returnname, GetCurScene())
				Go2Scene(sceneDialog)
			end
		end
	else
		exitLoading()
		require "module.dialog.useDialog"
		setDialogParam("提示", "正在获取数据，请稍后重试", "BT_OK", returnname, returnname, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

--@brief 请求播放（预播放）
function RequestPlay_NB(returnname)
	local reg = registerCreate("video")
	local filename = registerGetString(reg, "videoFileName")
	registerSetInteger(reg, "isLive",0)
	require "module.protocol.protocol_videoloading"
	local videoData = OnVideoDecode()
	if videoData then
		if videoData.success == "true" then
			--[[  点播直播界面界面  ]]--
			exitLoading()
			local volumeSprite = GetCurScene()
			local regHandle = registerCreate("SCMngr_handle");
			local SceneName = registerGetString(regHandle, string.format("%d", volumeSprite))
			local reg = registerCreate("video")
			local videoType = registerGetString(reg, "videoType")
			if videoType == "demand" or videoType == "live" then
				SetReturn(returnname, sceneVideoLiveDemand_NB)
				Go2Scene(sceneVideoLiveDemand_NB)
			end
		else
			exitLoading()
			if videoData.feeds or videoData.once then
				--[[  转到订购，在productorder中保存路径  ]]--
				local regv = registerCreate("video")
				local filename = registerGetString(regv, "videoFileName")
				registerSetString(regv, "videoFileNameDelete",filename)
				local regp = registerCreate("productorder")
				registerSetString(regp,"fileName",filename)
				registerSetString(regp,"returntype","play")
				SetReturn(returnname, sceneVideoLiveDemand)
				FreeScene(GetCurScene())
				GoAndFreeScene(sceneOrderProduct)
			else
				require "module.dialog.useDialog"
				setDialogParam("提示", "获取网络数据错误", "BT_OK", returnname, returnname, GetCurScene())
				Go2Scene(sceneDialog)
			end
		end
	else
		exitLoading()
		require "module.dialog.useDialog"
		setDialogParam("提示", "正在获取数据，请稍后重试", "BT_OK", returnname, returnname, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

--@brief 界面跳转（并释放目标界面）
function GoAndFreeScene(pathName)
	local scene = FindScene(pathName)
	if scene and scene ~= 0 then
		FreeScene(scene)
	end
	Go2Scene(pathName, nil)
end

--@brief 保存默认焦点
function SaveDefaultFocus(sprite)
	local system = registerCreate("System")
	if sprite and sprite ~= 0 then
		ReleaseSpriteCapture(sprite)
		registerSetInteger(system,"LastFocus",sprite)
	end
end

--@brief 把焦点设到之前默认点
function SetFocus2Latest()
	local system = registerCreate("System")
	local lastfocus = registerGetInteger(system,"LastFocus")
	if lastfocus and lastfocus ~=0 then
		--这里会有问题暂时注释
		--SetSpriteFocus(lastfocus)
		--registerSetInteger(system,"LastFocus",0)
	end
end

--@brief 移除快捷菜单
function hideMenu(SPRITENAME)
	local	reg = registerCreate("QuickLauncherBar");
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	local bottomSprite = FindChildSprite(rootSprite, SPRITENAME)
	if bottomSprite ~= 0 then
		RemoveChildSprite(rootSprite, bottomSprite, 1)
		ReleaseSpriteCapture(rootSprite)
		return	1
	end
	return	0
end

function ParseMagazineName(url)
	local t={}
	local k=0
	while true do
		k=string.find(url,"\/",k+1)
		if k==nil then break end
		table.insert(t,k)
	end	
	local position = t[#t]+1
	local filename = string.sub(url,position)
	filename = string.sub(filename,1,string.len(filename)-4)
	return filename
end

function checkCacheCondition()
	require "module.setting"
	local LastLoginDate = Cfg.GetLastLoginDate()
	require "module.protocol.protocol_systime"
	local sysjson = OnSysDataDecode()
	if LastLoginDate == ""  then
		if sysjson and sysjson.sysDate then
			local CurDate = string.format("%s",(string.sub(sysjson.sysDate,1,8)))
			Cfg.SaveLastLoginDate(CurDate)
		end
	else
		if sysjson and sysjson.sysDate then
			local CurDate = string.format("%s",(string.sub(sysjson.sysDate,1,8)))
			if cmpDate(LastLoginDate,CurDate,3) == 1 then
				require "module.common.io"
				deleteDir("CACHE:\\image\\")
				deleteDir("CACHE:\\")
				Cfg.SaveLastLoginDate(string.sub(sysjson.sysDate,1,8))
			end
		end
	end
end

function cmpDate(LastLoginDate,CurDate,days)
	local year_c = tonumber(string.sub(CurDate,1,4))
	local year_p = tonumber((string.sub(LastLoginDate,1,4)))
	if year_p ~= year_c then
		return year_p < year_c and 1 or 0
	end
	local month_c = tonumber(string.sub(CurDate,5,6))
	local month_p = tonumber(string.sub(LastLoginDate,5,6))
	if month_p ~= month_c then
		return month_p < month_c and 1 or 0
	end
	local day_c = tonumber(string.sub(CurDate,7,8))
	local day_p = tonumber(string.sub(LastLoginDate,7,8))
	if day_p ~= day_c then
		return day_p < day_c - days and 1 or 0
	end
	return 0
end

---用于解决触摸点击菜单后，再次点击菜单失焦点问题---
function saveTouchFocus(sprite)
	local touchFocusReg = registerCreate("PopMenuHide") 
	registerSetInteger(touchFocusReg,"sencePreFocus",sprite) 
end				
