--
require ("module.setting")
function RequestClientInit(protocolNumber)
	local observer = pluginGetObserver()
	require ("module.common.partiners")
	local partiner = GetPartiners()
		
	local clientInitURL = Cfg.GetServer()..Cfg.GetPortal().."/commonCommunication.msp"
	local postData = string.format("q=<?xml version=\"1.0\" encoding=\"UTF-8\"?><Root><header /><body><request type=\"ClientInit\" serial=\"1\"><clientversion>1.0.0</clientversion><dealer>%s</dealer></request></body></Root>", partiner)
	local clientInitUrlFileName = GetLocalFilename(string.format("%s%s", clientInitURL, postData))
	local key = registerCreate("REG_CLIENTINIT");
	registerSetString( key , "clientInitUrlFileName", clientInitUrlFileName )
  WriteLogs("clientInitUrlFileName = "..clientInitUrlFileName)
	pluginInvoke(http, "AppendCommand", 1, clientInitURL, postData, clientInitUrlFileName, observer, protocolNumber, 0, 1)
end

--
function OnPipeClientInitDecode()
	local key = registerCreate("REG_CLIENTINIT");
	local clientInitUrlFileName = registerGetString( key , "clientInitUrlFileName" );

	local nodeTree = xmlLoadFile(clientInitUrlFileName)
	local UUID = nil
	if nodeTree ~= 0 then
		local nodeRoot = xmlFindElement(nodeTree, nodeTree, "Root")
		if nodeRoot ~= 0 then
			local nodeBody = xmlFindElement(nodeTree, nodeRoot, "body")
			if nodeBody ~= 0 then
				local nodeResponse = xmlFindElement(nodeRoot, nodeBody, "response")
				if nodeResponse ~= 0 then
					local nodeUUID = xmlFindElement(nodeBody, nodeResponse, "uuid")
					if nodeUUID ~= 0 then
						UUID = xmlGetText(nodeUUID)
					end
				end
			end
		end
	end	
	xmlRelease(nodeTree)
	return UUID
end
