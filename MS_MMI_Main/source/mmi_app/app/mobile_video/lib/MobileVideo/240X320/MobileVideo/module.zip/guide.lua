
require("module.loading.useLoading")
require "module.common.registerScene"
require "module.common.SceneUtils"	
require "module.keyCode.keyCode"
jsonChannelGroup = {}
local recommContent=""  --add by yaoxiangyin
local bulletContent=""  --add by yaoxiangyin
local createFinishFlag=false  --判断宫格界面是否已创建完，创建完为真，还没用为假。用来防止创建过程中弹出菜单，使焦点混乱。
function bodyBuildChildrenFinished(sprite)
	createFinishFlag=false
	local reg = registerCreate("guide")
	registerSetInteger(reg, "root", sprite)
	--[[  UGC特别处理标志  ]]--
	pageclick = 1
	local regSystem = registerCreate("System")
	http = registerGetInteger(regSystem, "comHttpPipe")
--[[-----------------------------------------------------------------]]--	
	local ChannelReg=registerCreate("guideChannel")
	registerSetNumber(ChannelReg,"channelFlag",1)  --是否第一次进入0表示否，1表示是	
------------------------------------------------------------------	
--[[------------------------修改人：yaoxiangyin 修改时间：2010.09.20-----------------------------]]--
	local defaultGuideBtn=FindChildSprite(sprite,"defaultGuideBtn") 
	SetSpriteFocus(defaultGuideBtn)
-------------------------------------------------------------------------------------
	SetTimer(1, 1, "OnTimerCreateRecommend")
	return 1
end

function OnTimerCreateRecommend()
	require("module.protocol.protocol_channelGroup")
	local jsonData = ChannelGroupData()
	jsonChannelGroup.bulletin = jsonToTable(jsonData, "bulletin")
	jsonChannelGroup.recommend = jsonToTable(jsonData, "recommend")
	
	require "module.common.VerticalTextScroll"
	local reg = registerCreate("guide")
	local root = registerGetInteger(reg, "root")
	local buttonSprite = FindChildSprite(root,"recommendBtn")
	require("module.setting")
	if ( Cfg.IsChannelVersion() ) then
		if jsonChannelGroup and jsonChannelGroup.bulletin then
			if table.maxn(jsonChannelGroup.bulletin) >= 1 then
				CreateVerticalTextScroll(buttonSprite,"recommend_normal_txt","recommend_focus_txt",jsonChannelGroup.bulletin,"contentName")	
			end
		else
			initRecommend(root)
		end
	else
		if jsonChannelGroup and jsonChannelGroup.recommend then
			if table.maxn(jsonChannelGroup.recommend) >= 1 then
				CreateVerticalTextScroll(buttonSprite,"recommend_normal_txt","recommend_focus_txt",jsonChannelGroup.recommend,"contentName")	
			end
		else
			initRecommend(root)
		end
	end
	setRecommend(jsonChannelGroup)
	SetTimer(1, 1, "OnTimerCreateChannel")
end

function OnTimerCreateChannel()
	local jsonData = ChannelGroupData()
	jsonChannelGroup.imgListNavi = jsonToTable(jsonData, "imgListNavi")
	changeChannelList(jsonChannelGroup)
	createChannelList(jsonChannelGroup)
	SetTimer(1, 1, "OnTimerCreateContent")
end

function OnTimerCreateContent()
	local jsonData = ChannelGroupData()
	jsonChannelGroup.imgList = jsonToTable(jsonData, "imgList")
	createContentList(jsonChannelGroup)
	WriteLogs("@@@@@@@@@@@@@@@###################$$$$$$$$$$$$$$$$$$$$")
	if jsonChannelGroup.imgList==nil then
		--local ChannelReg=registerCreate("guideChannel")
		--WriteLogs(GetSpriteName(registerGetInteger(ChannelReg,"channelFocus")))
		--SetSpriteFocus(registerGetInteger(ChannelReg,"channelFocus"))
		WriteLogs("jsonChannelGroup.imgList is nil")
	end
	SetTimer(1, 1, "OnCreateLoadingSprite")
	ReleaseChannelGroupData()
end

function OnCreateLoadingSprite()
	local reg = registerCreate("guide")
	local sprite = registerGetInteger(reg, "root")
	
	local nodeLoad =  FindChildSprite(sprite, "loadarea")
	if nodeLoad == nil or nodeLoad == 0 then
		nodeLoad = CreateSprite("node", sprite)
		SetSpriteProperty(nodeLoad, "name", "loadarea")
		SetSpriteRect(nodeLoad, 0,0,240,320)
	end
	createFinishFlag=true
	-- 不再使用预存图片
	--SetTimer(1, 1, "OnTimerUnzipProduct")
end

--@解压product页面数据图片
--function OnTimerUnzipProduct()
--	local src = "MODULE:\\ComNetwork.dll"
--	local target = "MODULE:\\"
--	local unzip = BeginUnzip(src, target)
--	if not unzip then
--		WriteLogs("bad ZPKG file")
--	else
--		while ProcessUnzip(unzip) ~= 0 do			
--		end
--		EndUnzip(unzip)
--		WriteLogs("ZPKG file end")		
--	end
--end
function GoAndFreeScene(pathName)
	local scene = FindScene(pathName)
	if scene and scene ~= 0 then
		FreeScene(scene)
	end
	SetReturn("MODULE:\\guide.xml", pathName)
	Go2Scene(pathName, nil)
end

function OnPluginEvent(message, Param)
	require "module.videoexpress-common"
	require("module.common.commonMsg")
	if message == 101 then 	--主业务界面
		exitLoading()
		local reg = registerCreate("guide")
		local sprite = registerGetInteger(reg, "root")
		local channelspriteList = FindChildSprite(sprite, "guide-content-list")	
		SpriteList_SetStartItem(channelspriteList, 0)
		SpriteList_Adjust(channelspriteList)
		
		local channelData = LoadChannelGroupData()
		if channelData then
			local reg = registerCreate("guide")
			sprite = registerGetInteger(reg, "root")
			
			deleteContentList(sprite)
			deleteChannelList(sprite)
			SetTimer(1, 1, "OnTimerCreateRecommend")
		end
	elseif message == 102 then --列表式导航
		exitLoading()
		local productData = ChannelNetworkData()
		if productData then
		if productData.imgListNavi then
			GoAndFreeScene("MODULE:\\product.xml")
		else
			require("module.dialog.useDialog")
--[[--------------------------------------------------------------------------------------------]]--			
			guideFocusReg=registerCreate("guideLastFocus")
			local lastFocusSprite=registerGetInteger(guideFocusReg,"guideFocusSprite")
			KillSpriteFocus(lastFocusSprite)
------------------------------------------------------------------------------------------------------			
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneGuide, sceneGuide, GetCurScene())
			Go2Scene(sceneDialog)
		end
	else
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneGuide, sceneGuide, GetCurScene())
			Go2Scene(sceneDialog)
		end
	elseif message == 103 then --标签式导航
		exitLoading()
		local navigationData = LoadNavigationData()
		if navigationData then
			GoAndFreeScene("MODULE:\\navigation.xml")
		end
	elseif message == 104 then --排行榜
		exitLoading()
		local topTenData = LoadJsonTopTenNetworkData()
		if topTenData then
			GoAndFreeScene("MODULE:\\paihang.xml")
		end
	elseif message == 2000 then
		exitLoading()
		GoAndFreeScene(sceneBulletin)
	elseif message == 2002 then
		exitLoading()
		GoAndFreeScene( scenePrograminfo_volume )
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneGuide, sceneGuide)
	elseif message == 213 then
		require("module.protocol.protocol_channel")
		require ("module.protocol.protocol_systime")
		local jsonfile = OnSysDataDecode()
		if jsonfile and jsonfile.sysDate then
			local regLive = registerCreate("live")
			registerSetString(regLive, "sysTime", jsonfile.sysDate)
		end
		RequestChannel(102, channelObjectTime.urlPath)
	elseif message == 101 + MSG_CACHEDATA_RELOAD then
		require("module.guidReload")
		ReloadGuidData()
	elseif message == 102 + MSG_CACHEDATA_RELOAD  then
		WriteLogs("guide message == 102 + MSG_CACHEDATA_RELOAD")
		require "module.productReload"
		ReloadProductData()
	elseif message > 32768 and message ~= MSG_SMS_ID + 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneGuide, sceneGuide, nil)
		Go2Scene(sceneDialog)
	elseif message == 32768 then
		require("module.dialog.useDialog")
		require "module.common.SceneUtils"
		require "module.common.registerScene"
		local regHandle = registerCreate("SCMngr_handle");
		local SceneName = registerGetString(regHandle, string.format("%d", GetCurScene()))
		setDialogParam("提示", "拨号失败", "BT_OK", SceneName, SceneName, GetCurScene())
		dailFail = 1
		Go2Scene(sceneDialog)
	end
end

--Network Data  Change Channel
function changeChannelList(jsonChannelGroupData)
	if jsonChannelGroupData.imgListNavi then
--		0 1 2 3 4 5 
--		排成 5 3 1 0 2 4 5 3 1 0 2 4
--		得到这个表的索引	
		local valueMax = table.maxn(jsonChannelGroupData.imgListNavi)
		local imgListNaviCount = table.maxn(jsonChannelGroupData.imgListNavi) + 1
		local nBegin = (valueMax % 2) ~= 0 and valueMax or valueMax - 1
		local nCount = 0
		local nIndex = nBegin
		local array = {}
--		奇数
		for nIndex = nBegin, 1, -2 do
			array[nCount] = nIndex
			nCount = nCount + 1
		end
--		偶数
		for nIndex = 0, valueMax, 2 do
			array[nCount] = nIndex
			nCount = nCount + 1
		end
				
		nIndex = 0
        local arrMax = (valueMax + 1) * 2 - 1
		for nCount = nCount, arrMax do
			array[nCount] = array[nIndex]
			nIndex = nIndex + 1
		end

		local nFindIndex = 0
		for i=0, table.maxn(jsonChannelGroupData.imgListNavi) do
			local haveData = jsonChannelGroupData.imgListNavi[i].haveData
			if string.match(haveData, "true") then
				nFindIndex = i
			end
		end
		for i=0, #array do
			if array[i] == nFindIndex then 
				nFindIndex = i
				break
			end
		end
		nFindIndex = (nFindIndex < imgListNaviCount / 2) and (nFindIndex + imgListNaviCount) or nFindIndex
--		构建数据数组
		local newImgList = {}
		nIndex2 = 0
		nIndex = 1
		newImgList[nIndex2] = jsonChannelGroupData.imgListNavi[array[nFindIndex]]
		nIndex2 = nIndex2 + 1
		while nIndex < 5 and #newImgList < valueMax do
    	if (nFindIndex - nIndex) >= 0 then
				newImgList[nIndex2] = jsonChannelGroupData.imgListNavi[array[nFindIndex - nIndex]]
				nIndex2  = nIndex2 + 1
      end
      if ( (nFindIndex + nIndex) < (imgListNaviCount * 2)) then
				newImgList[nIndex2] = jsonChannelGroupData.imgListNavi[array[nFindIndex + nIndex]]
				nIndex2 = nIndex2 + 1
    	end
     	nIndex = nIndex + 1
		end
		jsonChannelGroupData.imgListNavi = newImgList
	end
end

function setRecommend(jsonChannelGroupData)
	local reg = registerCreate("guide")
	local sprite = registerGetInteger(reg, "root")
	--渠道版本只显示公告，普通版本显示推荐
	local spriteLabel1 = FindChildSprite(sprite, "guide-recommend-label1")
	local spriteLabel2 = FindChildSprite(sprite, "guide-recommend-label2")	
	local spriteContentN = FindChildSprite(sprite, "recommend_normal_txt")
	local spriteContentF = FindChildSprite(sprite, "recommend_focus_txt")
	
	require("module.setting")
	if ( Cfg.IsChannelVersion() ) then
	    SetSpriteProperty(spriteLabel1 , "text", "公告：")
		SetSpriteProperty(spriteLabel2 , "text", "公告：")
		
		if jsonChannelGroupData and jsonChannelGroupData.bulletin and table.maxn(jsonChannelGroupData.bulletin) >= 0 then
			SetSpriteProperty(spriteContentN, "text", jsonChannelGroupData.bulletin[0].contentName)
			SetSpriteProperty(spriteContentF, "text", jsonChannelGroupData.bulletin[0].contentName)
			bulletContent=jsonChannelGroupData.bulletin[0].contentName		--add by yaoxiangyin
		end
	else
		SetSpriteProperty(spriteLabel1 , "text", "推荐：")
		SetSpriteProperty(spriteLabel2 , "text", "推荐：")

		if jsonChannelGroupData and jsonChannelGroupData.recommend and table.maxn(jsonChannelGroupData.recommend) >= 0 then
			SetSpriteProperty(spriteContentN, "text", jsonChannelGroupData.recommend[0].contentName)
			SetSpriteProperty(spriteContentF, "text", jsonChannelGroupData.recommend[0].contentName)
			recommContent=jsonChannelGroupData.recommend[0].contentName		--add by yaoxiangyin
		end
	end
end

function  createContentList(jsonChannelGroupData)
WriteLogs("........................Set ContentButton Focus begin...........................")
--[[----------------------------------------------------------------]]--
	pageIndexReg= registerCreate("pageIndex")
	registerSetNumber(pageIndexReg,"contentPageIndex",0)
	
------------------------------------------------------------------------	
	local reg = registerCreate("guide")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "guide-content-list")
	WriteLogs("........................Set ContentButton Focus 2222222222222222222...........................")	
	local imgListArray = jsonChannelGroupData.imgList
	WriteLogs("........................Set ContentButton Focus 5555555555555555555555...........................")	
	if  imgListArray then
		local n = table.maxn(imgListArray)
		WriteLogs("........................Set ContentButton Focus 4444444444444444444444444444...........................")
		local xmlNode=xmlLoadFile("MODULE:\\guideContentItem.xml")
		for i=0, n do
			local guideContentSprite = CreateSprite("listitem")
			LoadSpriteFromNode(guideContentSprite, xmlNode)
			SetSpriteProperty(guideContentSprite, "name", string.format("content-listItem-%d", i))
			SetSpriteRect(guideContentSprite, 5, 0, 70, 60)			
			local spriteButton = FindChildSprite(guideContentSprite, "buttonChangeName")
			SetSpriteProperty(spriteButton, "name", string.format("content-button-%d", i))
--[[-------------------------------------修改人：yaoxiangyin 修改日期：2010.8.10--------------------------------------------]]--			
			SetSpriteProperty(spriteButton,"OnKeyUp","guideButtonContentKeyUp")
------------------------------------------------------------------------------------------------------------------	
			WriteLogs("........................Set ContentButton Focus "..i.."...........................")
			--[[ 小图标	]]--
			local spriteSmallImg = FindChildSprite(guideContentSprite, "smallImg")
			if jsonChannelGroupData.imgList[i].img then
				SetSpriteProperty(spriteSmallImg, "src", jsonChannelGroupData.imgList[i].img)
			end					
			--[[  文字  ]]--
			local spriteText = FindChildSprite(guideContentSprite, "subjectname")
			if jsonChannelGroupData.imgList[i].channelName then
				SetSpriteProperty(spriteText, "text", jsonChannelGroupData.imgList[i].channelName)
				--[[  文字太短了，不需要滚动，这个时候需要重新调整 坐标  ]]--
				local widthMax = 49;
				local offX = adjustOffx( jsonChannelGroupData.imgList[i].channelName , 11, widthMax );
				SetSpriteRect(spriteText, offX ,43, widthMax, 16);				
			end	
			AddChildSprite(spriteList, guideContentSprite)
			SpriteList_AddListItem(spriteList, guideContentSprite)
		end
		xmlRelease(xmlNode)
	WriteLogs("........................Set ContentButton Focus 3333333333333333333333...........................")	
		if jsonChannelGroupData.imgListNavi[0].channelName == "UGC" then
			local guideUploadSprite = CreateSprite("listitem")
			LoadSprite(guideUploadSprite, "MODULE:\\guideContentItem.xml")
			SetSpriteProperty(guideUploadSprite, "name", "iwanttoupload")
			SetSpriteRect(guideUploadSprite, 5, 0, 70, 60)
			local buttonChangeName = FindChildSprite(guideUploadSprite,"buttonChangeName")
			SetSpriteProperty(buttonChangeName,"OnSelect","iwantuploadButtonOnSelect")
			SetSpriteProperty(buttonChangeName, "name", string.format("content-button-%d",n+1))  --add by yaoxiangyin
			SetSpriteProperty(buttonChangeName,"OnKeyUp","guideButtonContentKeyUp")		--add by yaoxiangyin
			local spriteSmallImg = FindChildSprite(guideUploadSprite, "smallImg")
			SetSpriteProperty(spriteSmallImg, "src", "file://image/guidedisconnect/iwantupload.png")
			--[[  文字  ]]--
			local spriteText = FindChildSprite(guideUploadSprite, "subjectname")
			SetSpriteProperty(spriteText, "text", "我要上传")
			AddChildSprite(spriteList, guideUploadSprite)
			SpriteList_AddListItem(spriteList, guideUploadSprite)
		end
		SpriteList_Adjust(spriteList)
		if n > 4 then
			SpriteList_SetCurItem(spriteList, 2)
		end
		local start = SpriteList_GetStartItem(spriteList)
		local listItemCount = SpriteList_GetListItemCount(spriteList)
		local itemPerPage = SpriteList_GetItemPerPage(spriteList)
		
		local spriteLeftImage = FindChildSprite(sprite, "guid-content-left-arrow-image")
		local spriteRightImage = FindChildSprite(sprite, "guid-content-right-arrow-image")
		DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
--[[------------------------------------修改人：yaoxiangyin  修改日期：2010.8.10----------------------------------------]]--
		local defaultFocusButton
		local ChannelReg=registerCreate("guideChannel")
		if registerGetInteger(ChannelReg,"channelFlag")==1 then
			if n>=4 then
				defaultFocusButton=FindChildSprite(SpriteList_GetListItem(spriteList,4),"content-button-4")
				SetSpriteFocus(defaultFocusButton)
				saveTouchFocus(defaultFocusButton)
			elseif n>=0 and n<4 then
				defaultFocusButton=FindChildSprite(SpriteList_GetListItem(spriteList,0),"content-button-0")
				SetSpriteFocus(defaultFocusButton)
				saveTouchFocus(defaultFocusButton)
			end
		--else
			--WriteLogs("############$$$$$$$$$$$$$$$$$$$@@@@@@@@@@@@@@!!!!!!!!!!!!!!111111122222223333333"..GetSpriteName(registerGetInteger(ChannelReg,"channelFocus")))
			--defaultFocusButton=registerGetInteger(ChannelReg,"channelFocus")
			
		end
----------------------------------------------------------------------------------------------------------------------------	
	end
	
end

function deleteContentList(sprite)
	local spriteList = FindChildSprite(sprite, "guide-content-list")
	SpriteList_ClearListItem(spriteList, 1, 1)
end

--文字太短了，不需要滚动，这个时候需要重新调整 坐标
function adjustOffx( text, startX , maxLineX )
	--local startX = 15;
	local offX = startX;
	local textLineSize = GetTextSize( text )
	textLineSize = math.floor( ( maxLineX - textLineSize  )/2)
	if ( textLineSize >0 )then 
		offX = startX + textLineSize;
	end
	return offX;
end

function createChannelList(jsonChannelGroupData)	
	local reg = registerCreate("guide")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "guide-channel-list")
	
	local nSelSizeX = 47 --选中时的尺寸W
	local nSelSizeY = 43 --选中时的尺寸H
	local nSizeX = 32	--非选中时的尺寸W
	local nSizeY = 32	--非选中时的尺寸H
	local n = 6			--间隔
	local ptX = nSizeX + n --这样只计算一次了
	local ptImg = {}
	
	if 4 == 6 then
		ptImg[0] = {ptX * 3 , 3}
		ptImg[1] = {ptX * 2 , 13}
		ptImg[2] = {ptX * 3 + nSelSizeX + n, 13}
		ptImg[3] = {ptX * 1, 13}
		ptImg[4] = {ptX * 4 + nSelSizeX + n, 13}	
		ptImg[5] = {0 , 13}
		ptImg[6] = {ptX * 5 + nSelSizeX + n, 13}
	elseif 4 == 4 then
		ptImg[0] = {ptX * 2 , 3}
		ptImg[1] = {ptX, 13}
		ptImg[2] = {ptX * 2 + nSelSizeX + n, 13}
		ptImg[3] = {0, 13}
		ptImg[4] = {ptX * 3 + nSelSizeX + n, 13}
	end
	
	
	--对于0的元素的操作是保证中间的显示大图
	--由于大图为选中状态，小图并不显示所以FORCU的图片也是一样的！
	--local spritelabel = FindChildSprite(sprite, "debug")
	if jsonChannelGroupData.imgListNavi	then
		local nMax = math.min(table.maxn(jsonChannelGroupData.imgListNavi), 4)
		local xmlNode=xmlLoadFile("MODULE:\\guideChannalItem.xml")
		for i=0, nMax do
			local guideChannelSprite = CreateSprite("listitem")
			LoadSpriteFromNode(guideChannelSprite, xmlNode)
			SetSpriteProperty(guideChannelSprite, "name", string.format("channel-listItem-%d", i))
		--设置坐标点
			if 0 == i then
				SetSpriteRect(guideChannelSprite, ptImg[i][1], ptImg[i][2], nSelSizeX, nSelSizeY)
			else
				SetSpriteRect(guideChannelSprite, ptImg[i][1], ptImg[i][2], nSizeX, nSizeY)
			end
		--按键名修改设置
			local spriteButton = FindChildSprite(guideChannelSprite, "buttonChangeName")
			SetSpriteProperty(spriteButton, "name", string.format("channel-button-%d", i))
--[[------------------------------修改人：yaoxiangyin 修改日期：2010.8.11----------------------------------]]--			
			SetSpriteProperty(spriteButton, "OnKeyUp","guideButtonChannelKeyUp")
------------------------------------------------------------------------------------------------------			
			if 0 == i then
				SetSpriteRect(spriteButton, 0, 0, nSelSizeX, nSelSizeY)
			else
				SetSpriteRect(spriteButton, 0, 0, nSizeX, nSizeY)
			end	
			
			local smallImg =  FindChildSprite( guideChannelSprite , "smallImg" );
			local selectImg = FindChildSprite( guideChannelSprite , "selectImg" );
			SetSpriteProperty( smallImg, "src",jsonChannelGroupData.imgListNavi[i].smallImg );
			SetSpriteProperty( selectImg, "src",jsonChannelGroupData.imgListNavi[i].smallImg );
			if ( 0 == i ) then
			    SetSpriteVisible( smallImg , 0 )
				SetSpriteVisible( selectImg, 1 )
			else
			    SetSpriteVisible( smallImg , 1 )
				SetSpriteVisible( selectImg, 0 )
			end
			
			-------------------modify by Abigale----start------
			WriteLogs(string.format("jsonChannelGroupData.imgListNavi[%d].channelName = %s",i,jsonChannelGroupData.imgListNavi[i].channelName))

			--非选中时图片控件的设置
			local spriteImageNormal = FindChildSprite(guideChannelSprite, "buttonNormal")
			SpriteNormal = FindChildSprite(guideChannelSprite, "buttonNormal1")
			SpritebigNormal = FindChildSprite(guideChannelSprite, "buttonBigNormal")	

			if 0 == i then			
			    ----
				SetSpriteVisible(SpriteNormal, 0)
				SetSpriteVisible(SpritebigNormal, 1)
				local spriteNormalText = FindChildSprite(guideChannelSprite, "subjectname")
				
				if jsonChannelGroupData.imgListNavi[i].channelName then
					SetSpriteProperty(spriteNormalText, "text", jsonChannelGroupData.imgListNavi[i].channelName)

					--文字太短了，不需要滚动，这个时候需要重新调整 坐标
                    local widthMax = 32;
				    local offX = adjustOffx( jsonChannelGroupData.imgListNavi[i].channelName , 10, widthMax );
					SetSpriteRect(spriteNormalText, offX ,24, widthMax, 16);

				end	
				SetSpriteVisible(spriteNormalText, 1)
			else			
				SetSpriteVisible(SpriteNormal, 1)
				SetSpriteVisible(SpritebigNormal, 0)
			end
	
--选中时图片控件的设置
			local spriteImageForcus = FindChildSprite(guideChannelSprite, "buttonFocus")
			SpriteFocus = FindChildSprite(guideChannelSprite, "buttonFocus1")
			SpritebigFocus = FindChildSprite(guideChannelSprite, "buttonBigFocus")	
			if 0 == i then	
			--0位置获取焦点状态
				SetSpriteVisible(SpriteFocus, 0)
				SetSpriteVisible(SpritebigFocus, 1)
			--选中状态的text				
				local spriteFocusText = FindChildSprite(guideChannelSprite, "subjectname")
				if jsonChannelGroupData.imgListNavi[i].channelName then
					SetSpriteProperty(spriteFocusText, "text", jsonChannelGroupData.imgListNavi[i].channelName)
					
					--文字太短了，不需要滚动，这个时候需要重新调整 坐标
                    local widthMax = 32;
				    local offX = adjustOffx( jsonChannelGroupData.imgListNavi[i].channelName , 10, widthMax );
					SetSpriteRect(spriteFocusText, offX ,24, widthMax, 16);
					
				end		
				SetSpriteVisible(spriteFocusText, 1)
			else
			--非0状态获取焦点状态
				SetSpriteVisible(SpriteFocus, 1)
				SetSpriteVisible(SpritebigFocus, 0)
			end
			
-------------------modify by Abigale----end------
			AddChildSprite(spriteList, guideChannelSprite)
			SpriteList_AddListItem(spriteList, guideChannelSprite)
		end
		xmlRelease(xmlNode)
--[[------------------------------修改人：yaoxiangyin 修改日期：2010.08.16------------------------------------------]]--		
		local ChannelReg=registerCreate("guideChannel")
		SetSpriteFocus(FindChildSprite(SpriteList_GetListItem(spriteList,0),"channel-button-0"))
		saveTouchFocus(FindChildSprite(SpriteList_GetListItem(spriteList,0),"channel-button-0"))
		local ToDigReg = registerCreate("ToDigReg")
		registerSetInteger(ToDigReg,"ToDigFocus",FindChildSprite(SpriteList_GetListItem(spriteList,0),"channel-button-0"))
-------------------------------------------------------------------------------------------------------------------------------		
	
		
	end
	local start = SpriteList_GetStartItem(spriteList)
	local listItemCount 
--[[---------------------------------修改人：yaoxiangyin 修改时间：2010.09.20------------------------------------]]--	
	if jsonChannelGroupData.imgListNavi~=nil then
		listItemCount = table.maxn(jsonChannelGroupData.imgListNavi) + 1
	else
		GoAndFreeScene(sceneHome)
	end
------------------------------------------------------------------------------------------------------	
	local itemPerPage = SpriteList_GetItemPerPage(spriteList)
	
	local spriteLeftImage = FindChildSprite(sprite, "guid-channel-left-arrow-image")
	local spriteRightImage = FindChildSprite(sprite, "guid-channel-right-arrow-image")
	DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount, 1)
	--SpriteList_Adjust(spriteList)
end

function deleteChannelList(sprite)
	local spriteList = FindChildSprite(sprite, "guide-channel-list")
	SpriteList_ClearListItem(spriteList, 1, 1)
end
---------------------------------------------------
function DisplayButton(spriteLeftImage, spriteRightImage, start, step, total, isRing)
	if isRing then --环状
		if spriteLeftImage and spriteLeftImage ~= 0 then
			if step < total then
				SetSpriteVisible(spriteLeftImage, 1)
			else
				SetSpriteVisible(spriteLeftImage, 0)
			end
		end
		if spriteRightImage and spriteRightImage ~= 0 then
			if step < total then
				SetSpriteVisible(spriteRightImage, 1)
			else
				SetSpriteVisible(spriteRightImage, 0)
			end
		end
	else
		if spriteLeftImage and spriteLeftImage ~= 0 then
			if start >= step then
				SetSpriteVisible(spriteLeftImage, 1)
			else
				SetSpriteVisible(spriteLeftImage, 0)
			end
		end
		if spriteRightImage and spriteRightImage ~= 0 then
			if start + step < total then
				SetSpriteVisible(spriteRightImage, 1)
			else
				SetSpriteVisible(spriteRightImage, 0)
			end
		end
	end
end

function contentListButtonOnSelect(spriteButton)
	local contentSpriteRoot = GetSpriteParent(spriteButton)
	if contentSpriteRoot and contentSpriteRoot ~= 0 then
		local contentList = FindChildSprite(contentSpriteRoot, "guide-content-list")
		local spriteLeftButton = FindChildSprite(contentSpriteRoot, "guid-content-left-arrow-button")
		local spriteRightButton = FindChildSprite(contentSpriteRoot, "guid-content-right-arrow-button")
		
		if contentList and contentList ~= 0 then
			local listItemCount = SpriteList_GetListItemCount(contentList)
			local itemPerPage = SpriteList_GetItemPerPage(contentList)
			
			--可以进行翻页操作
			if itemPerPage < listItemCount then
				local start = SpriteList_GetStartItem(contentList)
--[[------------------------------------------------------------------------------------------------]]--
				local startItem
				local startButton
--------------------------------------------------------------------------------------------------------				
				local spriteLeftImage = FindChildSprite(spriteLeftButton, "guid-content-left-arrow-image")
				local spriteRightImage = FindChildSprite(spriteRightButton, "guid-content-right-arrow-image")
						
				if spriteButton == spriteLeftButton then
						start = start - itemPerPage
					if start >= 0 then
-------------------------------------------------------------------------------------------------------------
						startItem=SpriteList_GetListItem(contentList,start)
						startButton=FindChildSprite(startItem,"content-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
--------------------------------------------------------------------------------------------------------------							
						SpriteList_SetStartItem(contentList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end
				elseif spriteButton == spriteRightButton then
						start = start + itemPerPage
					if start < listItemCount then
-----------------------------------------------------------------------------------------------------------						
						startItem=SpriteList_GetListItem(contentList,start)
						startButton=FindChildSprite(startItem,"content-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
--------------------------------------------------------------------------------------------------------------
						SpriteList_SetStartItem(contentList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end	
				end
			end
		end
		SpriteList_Adjust(contentList)
	end
end

function iwantuploadButtonOnSelect(sprite)
	require "module.protocol.protocol_usercheck"
	local whitelistUrl = "http://c2.cmvideo.cn/ugcapp/uploadFile/UGC_CheckUser.html"
	local T_TYPE = "?T_TYPE=001"	
	whitelistUrl = whitelistUrl..T_TYPE
	local Status = -1	
	local Status = GetUserAuthority(122,"001")
	require "module.dialog.useDialog"	
	SetSpriteFocus(sprite)
	if Status == 3 then
		SetReturn(sceneGuide,sceneUpload)
		FreeScene(GetCurScene())
		Go2Scene(sceneUpload)
	elseif Status == 1 then
		setDialogParam("上传管理", "您不是白名单用户", "BT_OK",sceneGuide, sceneGuide,nil)	
		Go2Scene(sceneDialog)
	elseif Status == 2 then	
		SetReturn1(sceneRegisterInformation)
		Go2Scene(sceneRegisterInformation)
	else 	
		setDialogParam("上传管理", "网络错误", "BT_OK",sceneGuide ,sceneGuide,nil)	
		Go2Scene(sceneDialog)
	end
end 

--响应到事件
function channelListButtonOnSelect(spriteButton)

	local spriteParent = GetSpriteParent(spriteButton)
	local spriteList = FindChildSprite(spriteParent, "guide-channel-list")
	if spriteList and spriteList ~= 0 and GetSpriteName(spriteList) == "guide-channel-list" then
		if	jsonChannelGroup.imgListNavi then
			if GetSpriteName(spriteButton) == "guide-channel-left-arrow" and 5 <= table.maxn(jsonChannelGroup.imgListNavi) then
				RequestObject(jsonChannelGroup.imgListNavi[1])
			elseif GetSpriteName(spriteButton) == "guide-channel-right-arrow" and 6 <= table.maxn(jsonChannelGroup.imgListNavi) then
				RequestObject(jsonChannelGroup.imgListNavi[2])
			end
		end
	end
end

function OnSelectFromRecommendButton(sprite)
	local reg = registerCreate("VerticalTextScroll")
	local Index = registerGetInteger(reg, "CurIndex")
	require("module.setting")
	if ( Cfg.IsChannelVersion() ) then
		if jsonChannelGroup and jsonChannelGroup.bulletin and table.maxn(jsonChannelGroup.bulletin) >= 0 then
			require("module.protocol.protocol_bulletin");
			local reg = registerCreate("bulletin")   
			registerSetString(reg, "type", "open")
			RequestBulletin( 2000 , jsonChannelGroup.bulletin[Index].urlPath  )	
			loadAnimation()
      WriteLogs("in Guide , i request bulletin!");		
    else
      WriteLogs("in Guide, i try to request bulletin, but faild!");		
		end
	else
		if jsonChannelGroup and jsonChannelGroup.recommend and table.maxn(jsonChannelGroup.recommend) >= 0 then
			require("module.protocol.protocol_infovolume");
      RequestVolume( 2002 , jsonChannelGroup.recommend[Index].urlPath  )
			loadAnimation()
     	WriteLogs("in Guide , i request recommend!");	
		else
      WriteLogs("in Guide, i try to request recommend, but faild!");		
		end
	end
end

function listItemOnSelect(sprite)
	local spriteListItem = GetSpriteParent(sprite)
	local spriteList = GetSpriteParent(spriteListItem)	
	local index = SpriteListItem_GetIndex(spriteListItem)
	if GetSpriteName(spriteList) == "guide-content-list" then		
		RequestObject(jsonChannelGroup.imgList[index])
	elseif GetSpriteName(spriteList) == "guide-channel-list" then
		RequestObject(jsonChannelGroup.imgListNavi[index])
	end
	ReleaseSpriteCapture(sprite)
end

function RequestObject(channelObject)
	local typeID = channelObject.nodeDisplayType
	channelObjectTime =  channelObject
	if typeID == "0" then 			--列表式
		if channelObject.channelType ~= 2 then
			--获取当前时间
			require ("module.protocol.protocol_systime")
			RequestSysTime(213)
		else
			require("module.protocol.protocol_channel")
			RequestChannel(102, channelObject.urlPath)	
		end	
	elseif typeID == "1" then		--业务式
		require("module.protocol.protocol_channelGroup")
		RequestChannelGroup(101, channelObject.urlPath)
	elseif typeID == "2" then		--标签式
		require("module.protocol.protocol_navigation")
		RequestNavigation(103, channelObject.urlPath)
	elseif typeID == "3" then		--排列榜
		require("module.protocol.protocol_topten")
		RequestTopTen(104, channelObject.urlPath)
	end
	loadAnimation()
end

function loadAnimation()
	local reg = registerCreate("guide")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	require("module.loading.useLoading")
	enterLoading(loadarea)
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	require "module.common.commonMsg"
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_RELOAD then
		require("module.guidReload")
		require("module.protocol.protocol_channelGroup")		
		local channelData = LoadChannelGroupData()
		if channelData then
			local reg = registerCreate("guide")
			sprite = registerGetInteger(reg, "root")
			SetSpriteCapture(sprite)
			ReleaseSpriteCapture(sprite)
			local spriteBack = FindChildSprite(sprite,"back-progress")
			local spriteFore = FindChildSprite(sprite,"fore-progress")
			SetSpriteRect(spriteBack,0,20,240,6)
			SetSpriteRect(spriteFore,0,20,0,6)	
			
			hideMenu("sysmenu")
			hideMenu("bottommenu")
			SetTimer(1, 1, "OnTimerProgress")
			
		end	
	elseif message == 1001 then
		if dailFail and dailFail == 1 then
			Exit()
		end
	end
end

function OnTimerProgress()
	local reg = registerCreate("guide")
	sprite = registerGetInteger(reg, "root")
	local spriteBack = FindChildSprite(sprite,"back-progress")
	local spriteFore = FindChildSprite(sprite,"fore-progress")
	SetSpriteRect(spriteBack,0,22,240,6)
	SetSpriteRect(spriteFore,0,22,120,6)	
	SetTimer(1, 500, "OnTimerProgress2")	
end

function OnTimerProgress2()
	local reg = registerCreate("guide")
	sprite = registerGetInteger(reg, "root")
	local spriteBack = FindChildSprite(sprite,"back-progress")
	local spriteFore = FindChildSprite(sprite,"fore-progress")
	SetSpriteRect(spriteBack,0,22,240,6)
	SetSpriteRect(spriteFore,0,22,240,6)	
	SetTimer(1, 200, "OnTimerReload")	
end

function OnTimerReload()
	local reg = registerCreate("guide")
	sprite = registerGetInteger(reg, "root")	
	local spriteBack = FindChildSprite(sprite,"back-progress")
	local spriteFore = FindChildSprite(sprite,"fore-progress")
	SetSpriteRect(spriteBack,0,0,0,0)
	SetSpriteRect(spriteFore,0,0,0,0)
	deleteContentList(sprite)
	deleteChannelList(sprite)
	SetTimer(1, 1, "OnTimerCreateRecommend")		
end

function SetReturn1(nextScenceName)
	require "module.common.registerScene"
	local	regQuick = registerCreate("QuickLauncherBar");
	local	rootSprite = registerGetInteger(regQuick, "rootSprite")
	local   rootScene =  GetCurScene()
	local regHandle = registerCreate("SCMngr_handle");
	local SceneName = registerGetString(regHandle, string.format("%d", rootScene))
	if SceneName ~= sceneHome and nextScenceName ~= sceneRegisterInformation then
		FreeScene(rootScene)
	end
	
	--找到数据仓库
 	reg = registerCreate("QuickLauncherBar");
 	--需要返回的总数+1
 	local count = registerGetInteger(reg, "Count")+1; 	
	registerSetInteger(reg, "Count", count);
	
	--得到CurPage，这个值保存当前页面名称，因为通过底部菜单条进入其他页面，无法知道当前页面是什么，
	--所以把这个变量存入ReturnTable，如果通过底部菜单条进入其他页面，则将这个变量设置成PageName，以便后续面页面返回
	local CurPage = registerGetString(reg, "CurPage")
	registerSetString(reg, "PageName" .. count, CurPage)
	registerSetString(reg, "CurPage", nextScenceName)
end

--[[----------------------------修改人：yaoxiangyin 修改日期：2010.8.11---------------------------------]]--

--guide-content-list区域内键盘操作

function guideButtonContentKeyUp(sprite,keyCode)
	local contentList={}  --存放列表项中的Button名
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	--guide-content-list区域内操作
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --guide-content-list节点
	local spriteRightArrow=FindChildSprite(GetSpriteParent(spriteList),"guid-content-right-arrow-button")   --与guide-content-list节点平级的向右翻页按钮
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(spriteList), "guid-content-left-arrow-button")    --与guide-content-list节点平级的向左翻页按钮
	
	local contentName = GetSpriteName(sprite)
	local contentFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	local ListLine = SpriteList_GetLineCount(spriteList)		--行数2
	local ListCol = SpriteList_GetColCount(spriteList)		--列数4
	local ListCount = SpriteList_GetItemPerPage(spriteList)		--总数8
	--为表contentList赋值
	for j=0,itemCount-1 do
		contentList[j]="content-button-"..j
	end
	
	local pageNum --总页数
	if itemCount%ListCount==0 then
		pageNum=itemCount/ListCount
	else
		pageNum=math.ceil(itemCount/ListCount)
	end
	
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if contentList[i]==contentName then
	    contentFocusNum=i
	  end
	end
	
	local downPositionFlag=0  --当前位置是否在下段标志0表示否，1表示是
	local upPositionFlag=0    --当前位置是否在上段标志0表示否，1表示是
	for i=0,pageNum-1 do
		if contentFocusNum>=i*ListCount+ListCount-ListCol and contentFocusNum<=i*ListCount+ListCount-1 then
			downPositionFlag=1
			break
		elseif contentFocusNum>=i*ListCount and contentFocusNum<=i*ListCount+ListCol-1 then
			upPositionFlag=1
			break
		end
	end
	
	local lineNum --总行数
	if itemCount%ListLine==0 then
		lineNum=itemCount/ListLine
	else
		lineNum=math.ceil(itemCount/ListLine) 
	end
	local rightEdgeFalg=0 --当前位置是否在右边缘标志0表示否，1表示是
	local leftEdgeFalg=0  --当前位置是否在左边缘标志0表示否，1表示是

	if contentFocusNum % ListCol == 0 and contentFocusNum >= ListCount then
		leftEdgeFalg = 1
	elseif contentFocusNum % ListCol == ListCol - 1 and math.floor(contentFocusNum/ListCount) < math.floor(itemCount/ListCount) then
		rightEdgeFalg = 1
	end
	
	local guideSpriteList=GetSpriteParent(GetSpriteParent(spriteList))   --顶级栏目导航界面guide节点
	guideFocusReg=registerCreate("guideLastFocus")
	registerSetNumber(guideFocusReg,"guideFocusSprite",sprite)
	registerSetNumber(guideFocusReg,"guideContentFocusIndex",contentFocusNum)
	registerSetNumber(guideFocusReg,"lastFocusFlag",1)
	-------------------------------------------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	
	if keyCode== ApKeyCode_Right then
		if rightEdgeFalg==0 then --content区域内向右移动
			if contentList[contentFocusNum+1]~=nil then
				local sprite1=FindChildSprite(spriteList,contentList[contentFocusNum+1])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		elseif rightEdgeFalg==1 then --content右边界操作
			if registerGetInteger(pageIndexReg,"contentPageIndex")<pageNum-1 then
			registerSetNumber(pageIndexReg,"contentPageIndex",(registerGetInteger(pageIndexReg, "contentPageIndex")+1))
			contentListButtonOnSelect(spriteRightArrow)
			end
		end
		return 1
	elseif keyCode== ApKeyCode_Left then
		if leftEdgeFalg==0 then --content区域内向左移动
			if contentList[contentFocusNum-1]~=nil then
				local sprite1=FindChildSprite(spriteList,contentList[contentFocusNum-1])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		elseif leftEdgeFalg==1 then --content左边界操作
			if registerGetInteger(pageIndexReg,"contentPageIndex")>0 then
			registerSetNumber(pageIndexReg,"contentPageIndex",(registerGetInteger(pageIndexReg, "contentPageIndex")-1))
			contentListButtonOnSelect(spriteLeftArrow)
			end
		end
		return 1
	elseif keyCode== ApKeyCode_Up then
		if upPositionFlag~=1 then  --content区域内向上移动
			if contentList[contentFocusNum-ListCol]~=nil then 
				local sprite1=FindChildSprite(spriteList,contentList[contentFocusNum-ListCol])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		else
			 if recommContent~="" or bulletContent~="" then
			 SetSpriteFocus(FindChildSprite(GetRootSprite(sprite),"recommendBtn"))
			 saveTouchFocus(FindChildSprite(GetRootSprite(sprite),"recommendBtn"))
			 local guideReg = registerCreate("guide")
			 registerSetInteger(guideReg,"ledgeFocus",sprite)
			 end
		end
		return 1
	elseif keyCode== ApKeyCode_Down then
		if downPositionFlag~=1 then  --content区域内向下移动
			if contentList[contentFocusNum+ListCol]~=nil then
				local sprite1=FindChildSprite(spriteList,contentList[contentFocusNum+ListCol])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			else
				local channelListSprite
				local defautFocusChannelButton
				channelListSprite=FindChildSprite(SpriteList_GetListItem(guideSpriteList,1),"guide-channel-list") 
				defautFocusChannelButton=FindChildSprite(SpriteList_GetListItem(channelListSprite,0),"channel-button-0") 
				SetSpriteFocus(defautFocusChannelButton)
				saveTouchFocus(defautFocusChannelButton)
			end
		else  --content区域下边界操作
			local channelListSprite
			local defautFocusChannelButton
			channelListSprite=FindChildSprite(SpriteList_GetListItem(guideSpriteList,1),"guide-channel-list") 
			defautFocusChannelButton=FindChildSprite(SpriteList_GetListItem(channelListSprite,0),"channel-button-0") 
			SetSpriteFocus(defautFocusChannelButton)
			saveTouchFocus(defautFocusChannelButton)
		end
		return 1
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() and createFinishFlag  then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	end
	
	return 0
end

--guide-channel-list区域内键盘操作
function guideButtonChannelKeyUp(sprite,keyCode)
	local channelList={}
	local ChannelReg=registerCreate("guideChannel")
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	--guide-channel-list区域内操作
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --guide-channel-list节点
	local spriteRightArrow=FindChildSprite(GetSpriteParent(spriteList),"guid-channel-right-arrow-button")   --与guide-channel-list节点平级的向右翻页按钮
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(spriteList), "guid-channel-left-arrow-button")    --与guide-channel-list节点平级的向左翻页按钮
	
	local channelName = GetSpriteName(sprite)
	local channelFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	
	--为表channelList赋值
	for j=0,itemCount-1 do
		channelList[j]="channel-button-"..j
	end
	
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if channelList[i]==channelName then
	    channelFocusNum=i
	  end
	end
	
	WriteLogs("@@@@@@@@@@@"..channelList[channelFocusNum])
	local leftChannelIndex
	local rightChannelIndex
	local leftChannelButton
	local rightChannelButton
	
	--找出左右相邻两项
	if channelFocusNum==0 then
		leftChannelIndex=1
		rightChannelIndex=2
	elseif channelFocusNum==1 then
		leftChannelIndex=3
		rightChannelIndex=0
	elseif channelFocusNum==2 then
		leftChannelIndex=0
		rightChannelIndex=4
	elseif channelFocusNum==3 then
		leftChannelIndex=5
		rightChannelIndex=1
	elseif channelFocusNum==4 then
		leftChannelIndex=2
		rightChannelIndex=5
	elseif channelFocusNum==5 then
		leftChannelIndex=4
		rightChannelIndex=3
	end
	
	local guideSpriteList=GetSpriteParent(GetSpriteParent(spriteList))   --顶级栏目导航界面guide节点
	
	
	guideFocusReg=registerCreate("guideLastFocus")
	registerSetNumber(guideFocusReg,"guideFocusSprite",sprite)
	registerSetNumber(guideFocusReg,"lastFocusFlag",1)
	--------------------------------------------ksw------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	
	if keyCode== ApKeyCode_Right then
		rightChannelButton=FindChildSprite(SpriteList_GetListItem(spriteList,rightChannelIndex),channelList[rightChannelIndex])
		registerSetInteger(ChannelReg,"channelFocus",rightChannelButton)
		registerSetInteger(ChannelReg,"channelFlag",0)
		listItemOnSelect(rightChannelButton)
		return 1
	elseif keyCode== ApKeyCode_Left then
		leftChannelButton=FindChildSprite(SpriteList_GetListItem(spriteList,leftChannelIndex),channelList[leftChannelIndex])
		registerSetInteger(ChannelReg,"channelFocus",leftChannelButton)
		registerSetInteger(ChannelReg,"channelFlag",0)
		listItemOnSelect(leftChannelButton)
		return 1
	elseif keyCode== ApKeyCode_Up then
		local defautFocusContentIndex=registerGetNumber(guideFocusReg,"guideContentFocusIndex")
		local guideContentList= FindChildSprite(SpriteList_GetListItem(guideSpriteList,0),"guide-content-list") --guide-content-list节点
		
		local itemCount = SpriteList_GetListItemCount(guideContentList)
		local ListLine = SpriteList_GetLineCount(guideContentList)		--行数2
		local ListCol = SpriteList_GetColCount(guideContentList)		--列数4
		local ListCount = SpriteList_GetItemPerPage(guideContentList)		--总数8
		local ListStartItem = SpriteList_GetStartItem(guideContentList)
		local page = math.floor(ListStartItem/ListCount)+1
		local pageCount = math.ceil(itemCount/ListCount)
		
		if page < pageCount then
			local defautFocusContentButton= FindChildSprite(SpriteList_GetListItem(guideContentList,ListCount*page-1),"content-button-"..(ListCount*page-1))
			SetSpriteFocus(defautFocusContentButton)
			saveTouchFocus(defautFocusContentButton)
		else
			local defautFocusContentButton= FindChildSprite(SpriteList_GetListItem(guideContentList,itemCount-1),"content-button-"..(itemCount-1))
			SetSpriteFocus(defautFocusContentButton)
			saveTouchFocus(defautFocusContentButton)
		end
		return 1
	elseif keyCode== ApKeyCode_Down then
		return 1
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() and createFinishFlag then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		registerSetNumber(guideFocusReg,"guideFocusSprite",sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	end
	return 0
end

function recommendKeyUp(sprite,keyCode)
--------------------------------------------ksw------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
-------------------------------------------------------------------------------------------
local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode==ApKeyCode_Down then
		local guideReg = registerCreate("guide")
		SetSpriteFocus(registerGetInteger(guideReg,"ledgeFocus")) 
		saveTouchFocus(registerGetInteger(guideReg,"ledgeFocus"))
	elseif keyCode==ApKeyCode_Enter then
		OnSelectFromRecommendButton(sprite)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() and createFinishFlag then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

function defaultGuideBtnKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode == ApKeyCode_F1 and LoadingFlag() and createFinishFlag then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
------------------------------------------------------------------------------------------------------------

--当获得推荐或公告数据为空时，用空字符串覆盖上此留下的推荐内容
function initRecommend(root)
	local recommendNormalTxt=FindChildSprite(root,"recommend_normal_txt")
	local recommendNormalTxtBk=FindChildSprite(root,"recommend_normal_txt_bk")
	local recommendFocusTxt=FindChildSprite(root,"recommend_focus_txt")
	local recommendFocusTxtBk=FindChildSprite(root,"recommend_focus_txt_bk")
	CancelTimer(1)
	SetSpriteProperty(recommendNormalTxt,"text","")
	SetSpriteProperty(recommendNormalTxtBk,"text","")
	SetSpriteProperty(recommendFocusTxt,"text","")
	SetSpriteProperty(recommendFocusTxtBk,"text","")
end