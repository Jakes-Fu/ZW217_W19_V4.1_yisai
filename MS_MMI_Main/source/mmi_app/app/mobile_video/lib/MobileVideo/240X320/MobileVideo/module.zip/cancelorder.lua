﻿--author Abigale
--date	2010/06/01
-- cancelorder

require "module.Loading.useLoading"
require "module.common.registerScene"
require "module.common.SceneUtils"
--require "module.common.ascertainTargetScene"
require "module.myorder"
require "module.dialog.useDialog"
require "module.keyCode.keyCode"

function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("cancelorder")
	registerSetInteger(reg, "root", sprite)
	buttonArray={
					FindChildSprite(sprite, "option-box1"),FindChildSprite(sprite, "option-box2"),
					FindChildSprite(sprite, "option-box3"),FindChildSprite(sprite, "option-box4"),
					FindChildSprite(sprite, "order-cancel"),FindChildSprite(sprite, "cancel")
				}
	CreateCancelorderList(sprite)
	return 1
end

function CreateCancelorderList(sprite)
	local json = {}
	json = OnMyOrderDecode()
	local spriteReason1 = FindChildSprite(sprite, "option1")
	local spriteReason2 = FindChildSprite(sprite, "option2")
	local spriteReason3 = FindChildSprite(sprite, "option3")
	local spriteReason4 = FindChildSprite(sprite, "option4")
	WriteLogs("记忆像阵阵花香-CreateCancelorderList")
	
	WriteLogs("记忆像阵阵花香-spriteReason1"..spriteReason1)
	WriteLogs("记忆像阵阵花香-spriteReason2"..spriteReason2)
	WriteLogs("记忆像阵阵花香-spriteReason3"..spriteReason3)
	WriteLogs("记忆像阵阵花香-spriteReason4"..spriteReason4)
			
	local regSystem = registerCreate("system")
	index = registerGetInteger(regSystem, "IndexData")
	
	if	json and json.orderList then
		local reg = registerCreate("cancelorder")
		registerSetString(reg, "cancelOrderUrlFileName", json.orderList[index].url)
	end	
	if  json and json.orderList and json.orderList[index].opts then
		CancelReasonArray = json.orderList[index].opts
		local n = table.maxn(CancelReasonArray)
		----test---end---				
		WriteLogs("CancelReasonArray(maxn)=>"..n);				
		for i=0, n do 
		   WriteLogs("id=>"..CancelReasonArray[i].optId);
		   WriteLogs("name=>"..CancelReasonArray[i].optName);				   
		end	
		----test---end--				
		local spriteArr = {spriteReason1, spriteReason2, spriteReason3, spriteReason4}								
		for j= 0, n do
		  SetSpriteProperty( spriteArr[j+1], "text", CancelReasonArray[j].optName)				
		end						
	end
end

function RequestCancelOrder(url,tag)
	WriteLogs(string.format("1. RequestCancelOrder URL [%s]", url))	
	fileName = GetLocalFilename(url)
	WriteLogs(fileName)
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	local reg = registerCreate("cancelorder")
	registerSetString(reg, "cancelOrderUrlFileName", fileName)
	local observer = pluginGetObserver()
	pluginInvoke(http, "AppendCommand", 0, url, 0, fileName, observer, 101, 0,1)
	
--	CreatResultDialogData()
end

function bodyOnPluginEvent(message, param)
	require "module.videoexpress-common"
	WriteLogs("bodyOnPluginEvent: " .. message)
	if message == 101 then
		exitLoading()
		WriteLogs("cancelorder-response")
		local reg = registerCreate("cancelorder")
		local sprite = registerGetInteger(reg,"root")
		CreatResultDialogData()
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneCancelOrder, sceneCancelOrder)
	elseif message > 32768 then 
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneCancelOrder, sceneCancelOrder, GetCurScene())
		Go2Scene(sceneDialog)
	end
end

function OnCancelOrderResponseDecode()
	local reg = registerCreate("cancelorder")
	local rescanceorder = registerGetString(reg, "cancelOrderUrlFileName")
	WriteLogs("rescanceorder="..rescanceorder)
	--just for test
--	rescanceorder = "CACHE:\\cancelorderresponse.txt"
	--myorder.txt  cancelorderresponse	
	return jsonLoadFile(rescanceorder)
end

function CreatResultDialogData()
	json = OnCancelOrderResponseDecode()
	local returnsprite = FindChildSprite(GetCurScene(),"event4return")
	if  json ~= nil and json.desc ~= nil  then
		WriteLogs("json.desc="..json.desc)
		setDialogParam("提示", json.desc, "BT_OK", sceneCancelOrderDetail, sceneCancelOrderDetail, returnsprite, nil, nil, nil, "", "")
	else
		setDialogParam("提示", "获取网络数据失败!", "BT_OK", sceneCancelOrderDetail, sceneCancelOrderDetail, returnsprite, nil, nil, nil, "", "")
	end
	Go2Scene(sceneDialog)
	local regReturn = registerCreate("QuickLauncherBar")
 	local count = registerGetInteger(regReturn, "Count")
	local LastPageName = registerGetString(regReturn, "PageName"..count)
	registerSetString(regReturn, "CurPage", sceneMyOrder)
	if count >= 1 then
		registerRemove(regReturn, "PageName"..count)	
	end
end
--------------------以下是按钮操作事件-------------------------------------------
	--退订原因按钮
function optionOnSelect(curSprite)
		
		
        local   parentSprite = GetSpriteParent(curSprite)		
		local	name=GetSpriteName(curSprite)
		for i=1,4 do
			if GetSpriteName(curSprite) == GetSpriteName(buttonArray[i]) then
				SetSpriteProperty(FindChildSprite(curSprite,"option"..i), "color",  "#F472B2")
			else
				SetSpriteProperty(FindChildSprite(buttonArray[i],"option"..i), "color",  "#585858")
			end
		end
		
		WriteLogs("GetSpriteName(curSprite)**************"..name)
		WriteLogs("GetSpriteName(buttonArray[1])**************"..GetSpriteName(buttonArray[1]))
		local	image1 = FindChildSprite(curSprite, "normal-img")
		local	image2 = FindChildSprite(curSprite, "select-img")

	--先切换当前选中的按键的状态，
	if IsSpriteVisible(image2)==1 then
		SetSpriteVisible(image1,1)
		SetSpriteVisible(image2,0)
	
	elseif IsSpriteVisible(image1)==1 then
		SetSpriteVisible(image1,0)
		SetSpriteVisible(image2,1)
	end
		SetSpriteFocus(curSprite)
	local SelectOption = ""
	for n = 1, 4 do
		local selBoxName = "option-box"..n 
		local selOption = FindChildSprite(parentSprite,selBoxName)
		local selectImg = FindChildSprite(selOption, "select-img")
		if  IsSpriteVisible( selectImg ) == 1 then
			if "" ~= SelectOption then
				SelectOption = SelectOption .. ","
			end
			SelectOption = SelectOption..CancelReasonArray[n-1].optId
		end
	end

		--just store the value , and when i request the data to server, i will use the value.
		--pls look at the cancelorderButtonOnSelect funciton
		local regKey = registerCreate("cancelorder")
		registerSetString(regKey,"MYORDER_OPTION", SelectOption )

		WriteLogs("My order select string: ".. SelectOption );
end
--退订按钮
function cancelorderButtonOnSelect(sprite)
	--载入状态loading
	local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadingNodeCancel")
	enterLoading(nodeLoading)
	
	local reg = registerCreate("cancelorder")
	local url = registerGetString(reg, "cancelOrderUrlFileName")
	local myOrderOption = registerGetString(reg,"MYORDER_OPTION")	

	 local regURL =  string.format("%s%s",url,myOrderOption)
	 RequestCancelOrder(regURL,101)
	local orderProductFlagReg=registerCreate("orderProductFlagReg")
		registerSetString(orderProductFlagReg,"OrderProduct","None")
	
	
end
--取消
function cancelButtonOnSelect(sprite)
	local reg = registerCreate("orderdetail") 
	local root = registerGetInteger(reg, "root")
	local cancelOrder = FindChildSprite(root, "cancelOrder") 
	if cancelOrder == 0 or cancelOrder == nil then 
		cancelOrder = CreateSprite("node", root) 
		SetSpriteProperty(Monthlist,"name","cancelOrder") 
	end
	ReleaseSpriteCapture(cancelOrder)
	RemoveChildSprite(root, cancelOrder, 1)

	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)

end
--------------------以上是按钮操作事件-------------------------------------------

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	end
end


---------------------键盘点击操作-----------------
function clickCheckbox(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	local temp
	for i=1,table.getn(buttonArray) do
		if GetSpriteName(sprite) == GetSpriteName(buttonArray[i]) then
			temp = i
			break
		end
	end
	WriteLogs("-------------temp----------"..temp)
	if 	keyCode == ApKeyCode_Left then
		if temp ~= 1 then
			if temp == table.getn(buttonArray)-1 then
				SetSpriteProperty(FindChildSprite(buttonArray[temp-1],"option"..(temp-1)), "color",  "#F472B2")
			elseif temp < table.getn(buttonArray)-1 then
				SetSpriteProperty(FindChildSprite(buttonArray[temp-1],"option"..(temp-1)), "color",  "#F472B2")
				SetSpriteProperty(FindChildSprite(sprite,"option"..temp), "color",  "#585858")
			end
			SetSpriteFocus(buttonArray[temp-1])
			WriteLogs("-------------ApKeyCode_Left----------")
		end
	elseif keyCode == ApKeyCode_Right then
		if temp ~= table.getn(buttonArray) then
			if temp+1 == table.getn(buttonArray)-1 then
				SetSpriteProperty(FindChildSprite(sprite,"option"..temp), "color",  "#585858")
			elseif temp+1 < table.getn(buttonArray)-1 then
				SetSpriteProperty(FindChildSprite(buttonArray[temp+1],"option"..(temp+1)), "color",  "#F472B2")
				SetSpriteProperty(FindChildSprite(sprite,"option"..temp), "color",  "#585858")
			end
			SetSpriteFocus(buttonArray[temp+1])
			WriteLogs("-------------ApKeyCode_Right----------")
		end
	elseif keyCode == ApKeyCode_Up then
		if temp > 2 then
			if temp >  4 then
				SetSpriteProperty(FindChildSprite(buttonArray[temp-2],"option"..(temp-2)), "color",  "#F472B2")
			elseif temp >2 and temp < 5 then
				SetSpriteProperty(FindChildSprite(buttonArray[temp-2],"option"..(temp-2)), "color",  "#F472B2")
				SetSpriteProperty(FindChildSprite(sprite,"option"..temp), "color",  "#585858")
			end
			SetSpriteFocus(buttonArray[temp-2])
			WriteLogs("-------------ApKeyCode_Up----------")
		end
	elseif keyCode == ApKeyCode_Down then
		if temp < table.getn(buttonArray) then
			if temp >= 3 and temp <=4 then
				SetSpriteProperty(FindChildSprite(sprite,"option"..temp), "color",  "#585858")
			elseif temp <= 2 then
				SetSpriteProperty(FindChildSprite(buttonArray[temp+2],"option"..(temp+2)), "color",  "#F472B2")
				SetSpriteProperty(FindChildSprite(sprite,"option"..temp), "color",  "#585858")
			end
			SetSpriteFocus(buttonArray[temp+2])
			WriteLogs("-------------ApKeyCode_Down----------")
		end
	elseif keyCode == ApKeyCode_Enter then
		if temp < 5 then
			optionOnSelect(sprite)
			WriteLogs("-------------ApKeyCode_Enter----------")
		elseif temp == 5 then
			cancelorderButtonOnSelect(sprite)
			WriteLogs("-------------ApKeyCode_Enter----------")
		elseif temp > 5 then
			cancelButtonOnSelect(sprite)
			WriteLogs("-------------ApKeyCode_Enter----------")
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		--SysGetSeceSprite(sprite)
		--menuButtonOnSelect(sprite)
	
		--SetSpriteFocus(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		cancelButtonOnSelect(sprite)
	end
end
