﻿--@author cuiyizhou
--@date  2010/06/17

function receiveMsgBrowse(sprite)
	--[[  先从未读信息中删除  ]]--
	local node = GetSpriteParent(sprite)
	local button = GetSpriteParent(node)
	local listitem = GetSpriteParent(button)
	local count = SpriteListItem_GetIndex(listitem)+1
	
	local reg = registerCreate("temp")
	registerLoad(reg, "MODULE:\\videoexpress\\categoryID0.xml")
	local categoryID = FindValue(reg,ListDataKey[count],"categoryID")
	local categoryName = FindValue(reg,ListDataKey[count],"categoryName")
	local value = registerGetString(reg,ListDataKey[count])
	registerRemove(reg, ListDataKey[count])
	local listcount = registerGetInteger(reg,"count")
	for i=count,listcount-1 do
		registerSetString(reg,"item"..i,registerGetString(reg,"item"..(i+1)))
	end
	registerRemove(reg, "item"..listcount)
	registerSetInteger(reg,"count",listcount-1)
	registerSave(reg,"MODULE:\\videoexpress\\categoryID0.xml")
		
	if nil ~= categoryID and "" ~= categoryID then
		local filename ="MODULE:\\videoexpress\\categoryID"
		filename = filename..categoryID..".xml"
		--[[  需判断文件是否存在，不存在则创建新文件  ]]--
		require "module.common.io"
		local fileExist = fileExist(filename)	
		if tonumber(categoryID) > registerGetInteger(reg,"totalcount") then
			registerSetString(reg, "totalcount", categoryID)
			registerSave(reg, "MODULE:\\videoexpress\\categoryID0.xml")
		end
		if nil == fileExist then
			local reg_new = registerCreate("new")
			registerSetString(reg_new, "count", "0")
			registerSetString(reg_new, "categoryName", categoryName)
			registerSave(reg_new, filename)
		end
	end
	registerRelease("temp")
	
	--[[  再添加到相应目录  ]]--
	local reg = registerCreate("temp")
	registerLoad(reg, "MODULE:\\videoexpress\\categoryID"..categoryID..".xml")
	local count = registerGetInteger(reg,"count")
	count = count + 1
	registerSetInteger(reg,"count",count)
	registerSetString(reg,"item"..count,value)
	registerSave(reg,"MODULE:\\videoexpress\\categoryID"..categoryID..".xml")
	registerRelease("temp")
	--[[  跳转之后读取数据需要的参数  ]]--
	local reg_f = registerCreate("friendsrecommended_detail")
	registerSetString(reg_f,"ItemNo",count)
	registerSetString(reg_f,"ListNo",categoryID)
	return categoryID
end

function receiveMsgDelete(sprite)
	local node = GetSpriteParent(sprite)
	local button = GetSpriteParent(node)
	local listitem = GetSpriteParent(button)
	local count = SpriteListItem_GetIndex(listitem)+1

	local reg = registerCreate("temp")
	registerLoad(reg, "MODULE:\\videoexpress\\categoryID0.xml")
	registerRemove(reg, ListDataKey[count])
	
	local listcount = registerGetInteger(reg,"count")
	for i=count,listcount-1 do
		registerSetString(reg,"item"..i,registerGetString(reg,"item"..(i+1)))
	end
	registerRemove(reg, "item"..listcount)
	registerSetInteger(reg,"count",listcount-1)
	
	registerSave(reg,"MODULE:\\videoexpress\\categoryID0.xml")
	registerRelease("temp")
end

function MoveMsg()
	local reg_f = registerCreate("friendsrecommended_detail")
	local count = registerGetString(reg_f,"ItemNo")	
	local reg = registerCreate("temp")
	registerLoad(reg, "MODULE:\\videoexpress\\categoryID0.xml")
	local itemIndex = "item"..count
	local categoryID = FindValue(reg,itemIndex,"categoryID")
	local categoryName = FindValue(reg,itemIndex,"categoryName")
	local value = registerGetString(reg,itemIndex)	
	registerRemove(reg, itemIndex)
	local listcount = registerGetInteger(reg,"count")
	for i=count,listcount-1 do
		registerSetString(reg,"item"..i,registerGetString(reg,"item"..(i+1)))
	end
	registerRemove(reg, "item"..listcount)
	registerSetInteger(reg,"count",listcount-1)
	registerSave(reg,"MODULE:\\videoexpress\\categoryID0.xml")
	
	if nil ~= categoryID and "" ~= categoryID then
		local filename ="MODULE:\\videoexpress\\categoryID"
		filename = filename..categoryID..".xml"
		--[[  需判断文件是否存在，不存在则创建新文件  ]]--
		require "module.common.io"
		local fileExist = fileExist(filename)	
		if tonumber(categoryID) > registerGetInteger(reg,"totalcount") then
			registerSetString(reg, "totalcount", categoryID)
			registerSave(reg, "MODULE:\\videoexpress\\categoryID0.xml")
		end
		if nil == fileExist then
			local reg_new = registerCreate("new")
			registerSetString(reg_new, "count", "0")
			registerSetString(reg_new, "categoryName", categoryName)
			registerSave(reg_new, filename)
		end
	end
	registerRelease("temp")
	
	--[[  再添加到相应目录  ]]--
	local reg = registerCreate("temp")
	registerLoad(reg, "MODULE:\\videoexpress\\categoryID"..categoryID..".xml")
	local count = registerGetInteger(reg,"count")
	
	count = count + 1
	registerSetInteger(reg,"count",count)
	registerSetString(reg,"item"..count,value)
	registerSave(reg,"MODULE:\\videoexpress\\categoryID"..categoryID..".xml")
	registerRelease("temp")
	--[[  跳转之后读取数据需要的参数  ]]--
	local reg_f = registerCreate("friendsrecommended_detail")
	registerSetString(reg_f,"ItemNo",count)
	registerSetString(reg_f,"ListNo",categoryID)
	return categoryID
end