﻿--@module video
--@note 播放界面
--@author cuiyizhou
--@date 2010/05/25
require "module.video_com"
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.keyCode.keyCode"
require "module.Loading.useLoading"
function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]-- 
	reg = registerCreate("video")   
	registerSetInteger(reg, "root", sprite)
	http = pluginCreate("HttpPipe", "comHttpPipe")
	observer = pluginGetObserver()
	--[[  以下为组点播时的面板创建  ]]--   
	local regflag = registerCreate("buttonclickflag")
	--[[	flag值为0时playerinterfaceOnTick函数会直接返回，即不移动播放器面板	]]--
	registerSetInteger(regflag, "flag", 0)
	--[[	preflag值置1，默认第一次播放器面板的运动为向上	]]--
	registerSetInteger(regflag, "preflag", 1)
	
	jsonCreateData()  		--解析数据
	
	InitScene()
	initData_v()	
	return 1
end

function bodyOnSpriteEvent(message, params)
	require("module.common.commonMsg")
	reg = registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if message == MSG_EXCEPTIVEKEY then
		WriteLogs("MSG_EXCEPTIVEKEY: "..params)
		if params == 23 then
			VolumeUpOnButtonClick(nil)
		elseif params == 24 then
			VolumeDownOnButtonClick(nil)
		end
	elseif message == MSG_ACTIVATE then
		local FullScreenBT=FindChildSprite(GetCurScene(),"item-playercontrols-fullscreen")  --一进入直播点播界面就将默认焦点设在全屏按钮上
		ReleaseSpriteCapture(FullScreenBT)
		SetSpriteCapture(FullScreenBT)
		SetSpriteFocus(FullScreenBT)
		saveTouchFocus(FullScreenBT)
		require "module.common.DownloadUpload"
		PauseDownloadTask()
		PauseUploadTask()
		curPageIsVideo = true
		SetStatusText("")
		WriteLogs("MSG_ACTIVATE urlpath===" ..urlpath)
		jsonCreateData()
		local urlCmp = registerGetString(reg, "urlCmp")	
		
		if urlCmp == urlpath then			--当前播放和上次播放一样
			local isReplay = registerGetString(reg, "isReplay")
			if isReplay == "true" then
				zeroProgress()
				pluginInvoke(MediapalyPlugin, "Open",urlpath)
				pluginInvoke(MediapalyPlugin, "MoveWindow",0, 35, 240, 160)
				registerSetString(reg, "isReplay", "")
			elseif videoType == videoTypeList[4] then
				GetSysTime()
				require("module.setting")
				zeroProgress()
				if Cfg.GetVideoType() == ".3gp" then				--华为播放器
					pluginInvoke(MediapalyPlugin, "Stop")
					pluginInvoke(MediapalyPlugin, "Open", urlpath)
					pluginInvoke(MediapalyPlugin, "Play")
				else								--荣创播放器
					pluginInvoke(MediapalyPlugin, "Open", urlpath)
				end
				pluginInvoke(MediapalyPlugin, "MoveWindow",0, 35, 240, 160)
			else
				pluginInvoke(MediapalyPlugin, "Play")
				pluginInvoke(MediapalyPlugin, "MoveWindow",0, 35, 240, 160)
			end

		else 						--当前播放和上次播放不一样
			zeroProgress()
			pluginInvoke(MediapalyPlugin, "Play", urlpath)
			pluginInvoke(MediapalyPlugin, "MoveWindow",0, 35, 240, 160)
			registerSetString(reg, "urlCmp", urlpath)
		end
		WriteLogs("MediapalyPlugin" ..MediapalyPlugin)
		SetTimer(1, 500, "OnGetStatus")
		initData_v()
		IsReview = registerGetString(reg, "IsReview")
		registerSetString(reg, "IsReview","")
	elseif message == MSG_DEACTIVATE then
		WriteLogs("MSG_DEACTIVATE")
		curPageIsVideo = false
		if MediapalyPlugin == 0 then
			MediapalyPlugin = pluginCreate("MediaPlayer")
			WriteLogs("MSG_DEACTIVATE Create MediapalyPlugin")
		end
		local is2recommend = registerGetInteger(reg, "is2recommend")
		if is2recommend == 0 then
			zeroProgress()
			pluginInvoke(MediapalyPlugin, "Stop")
		else
			registerSetInteger(reg, "is2recommend", 0)			
		end
		pluginInvoke(MediapalyPlugin, "Show" , 0)
		SetStatusText("")

	elseif message == MSG_MINIMIZED then
		reg = registerCreate("video")
		WriteLogs("MSG_MINIMIZED")
		if MediapalyPlugin then
			if iffull == 1 then
				iffull =0
				pluginInvoke(MediapalyPlugin, "FullScreen", 0)
				ReleaseSpriteCapture(FullSec)
				SetSpriteProperty(FullSec,"enable","false")
			end
			pluginInvoke(MediapalyPlugin, "Show" , 0)
			pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 30, 0, 0)
			pluginInvoke(MediapalyPlugin, "Pause")
		end
	elseif message == MSG_MAXIMIZED then
		reg = registerCreate("video")
		WriteLogs("MSG_MAXIMIZED")
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Show" , 1)
			SetTimer(1, 1000, "movewindow111")
		end
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		if MediapalyPlugin ~= 0 then
			pluginInvoke(MediapalyPlugin, "Stop")
			pluginInvoke(MediapalyPlugin, "Show" , 0)
		end
	elseif message == MSG_SMS then
		WriteLogs("播放中短信到来")
		hintSMS()
	end
end

function OnPluginEvent(message, param)
	if message == 101 then
		exitLoading()
		--SetReturn(sceneHome, scenePrograminfo_volume)
		GoAndFreeScene(scenePrograminfo_volume)
	elseif MSG_SMS_ID == message then
		WriteLogs("OnPluginEvent videoDealSMS()")
		DealMsgContent(sceneVideoLiveDemand_NB, sceneVideoLiveDemand_NB)
		videoDealSMS()
	end
end
--start 解析数据
function jsonCreateData()
	commendUrlList={"item-playerinterface-recommand1","item-playerinterface-recommand2"}
	commendNameList={"item-playerinterface-recommand1","item-playerinterface-recommand2"}
	commendUrlList["item-playerinterface-recommand1"]=""
	commendUrlList["item-playerinterface-recommand2"]=""
	commendNameList["item-playerinterface-recommand1"]=""
	commendNameList["item-playerinterface-recommand2"]=""
	require ("module.protocol.protocol_video")
	json =OnVideoDecode()
	if json then
		WriteLogs("json ~= nil")
	else
		WriteLogs("json == nil")
		return
	end
	
	urlpath =""
	--[[  播放器页面推荐只用取最后一条记录  ]]--
	if json.commend1 ~= nil then 
		for i=0, table.maxn(json.commend1) do
			if json.commend1[i].urlPath ~= nil then
				commendUrlList["item-playerinterface-recommand1"] = json.commend1[i].urlPath
				commendNameList["item-playerinterface-recommand1"] = json.commend1[i].contentName
			end
		end
	end
	if json.commend2 ~= nil then
		for i=0, table.maxn(json.commend2) do	
			if json.commend2[i].urlPath ~=nil then
				commendUrlList["item-playerinterface-recommand2"] = json.commend2[i].urlPath
				commendNameList["item-playerinterface-recommand2"] = json.commend2[i].contentName
			end
		end
	end
	urlpath = json.url
	
	SaveHistoryVideoList()
	return 1
end

function InitScene()	
	createLiveVideo()	--[[  以下为直播时的面板创建  ]]--
	createGlobalValue()
end

function initData_v()
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	setSecTime(labelStartTimeSprite, pluginInvoke(MediapalyPlugin, "GetCurTime"))
	gTotalTime = pluginInvoke(MediapalyPlugin, "GetTotalTime")
	setSecTime(labelEndTimeSprite, gTotalTime)
	
	local normalLable = FindChildSprite(recommand1Button, "normal")
	local focusLable = FindChildSprite(recommand1Button, "focus")
	SetSpriteProperty(normalLable, "text" ,commendNameList["item-playerinterface-recommand1"] )
	SetSpriteProperty(focusLable, "text" ,commendNameList["item-playerinterface-recommand1"] )
	normalLable = FindChildSprite(recommand2Button, "normal")
	focusLable = FindChildSprite(recommand2Button, "focus")
	SetSpriteProperty(normalLable, "text" ,commendNameList["item-playerinterface-recommand2"] )
	SetSpriteProperty(focusLable, "text" ,commendNameList["item-playerinterface-recommand2"] )
end

function RecommandOnSelect(sprite)
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	local tuijianName=GetSpriteName(sprite)
	WriteLogs(tuijianName)	
	WriteLogs(commendUrlList[tuijianName])	
	if commendUrlList[tuijianName] ~="" then
  	if MediapalyPlugin then
    	pluginInvoke(MediapalyPlugin, "Stop")
    else
    	WriteLogs("show")
    end
    SetStatusText("")
    RequestGuide(commendUrlList[tuijianName], nil)
  end
end

--@function	createLiveVideo
--@brief	当场景为视屏直播时，创建相应的界面，在bodyBuildChildrenFinished中调用
function createLiveVideo()
	--[[	获取根节点	]]--
	local root = registerGetInteger(reg, "root")
	--[[	创建listitem类的节点	]]--
	local playercontrolsitemSprite = CreateSprite("listitem")
	local playercontrolsSprite = FindChildSprite(root, "list-playercontrols")
	--[[	用已有模板中数据填充该节点	]]--
	LoadSprite(playercontrolsitemSprite, "MODULE:\\video_livevideomodule.xml")
	SetSpriteRect(playercontrolsitemSprite, 0, 0, 240, 100)
	--[[	把该节点插入到场景中	]]--
	AddChildSprite(playercontrolsSprite, playercontrolsitemSprite)
	SpriteList_AddListItem(playercontrolsSprite, playercontrolsitemSprite)
	dw_FullSec=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-fullscreen") 
	dw_Down=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-volumedown") 
	dw_Up=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-volumeup") 
	dw_Play=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-play") 
	dw_Paus=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-pause") 
	dw_More=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-recommend") 
	dw_Tj1=FindChildSprite(playercontrolsitemSprite, "item-playerinterface-recommand1") 
	dw_Tj2=FindChildSprite(playercontrolsitemSprite, "item-playerinterface-recommand2") 
	SetSpriteFocus(dw_FullSec)
	return 1
end

--brief 播放器键盘事件
--author 杜威

function FullChangeKeyUp(sprite,keyCode)
	WriteLogs("keyCode:"..keyCode)
	
	WriteLogs("退出全屏")
	if keyCode then
	FullSecOnButtonClick(sprite)
	
	end
	return 0
end


function listKeyUp(sprite,keyCode)
	FlagK=0	
	local Jiaodian = {"item-playercontrols-fullscreen","item-playercontrols-volumedown","item-playercontrols-volumeup","play","item-playercontrols-recommend"}
	local JiaodianUD= {"splider-bar","item-playerinterface-recommand1","item-playerinterface-recommand2","item-playercontrols-fullscreen"}
	local name=GetSpriteName(sprite)
	local reg= registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	status = pluginInvoke(MediapalyPlugin, "GetStatus")  
	item=GetSpriteParent(sprite)
	--WriteLogs("status:"..status)
	WriteLogs("keyCode:"..keyCode)
	WriteLogs("Name:"..name)
	for i=1,5 do
    if Jiaodian[i]==name or Jiaodian[i]==GetSpriteName(item) then
	    Num=i
		FlagK=1
	    break
	  end   
	end   
	WriteLogs(Num)
	if keyCode==ApKeyCode_Right then	
			if Num<3 and name~= JiaodianUD[1] and  name~=JiaodianUD[2] and name~=JiaodianUD[3]then
				local NextFocus= FindChildSprite(item,Jiaodian[Num+1])
				SetSpriteFocus(NextFocus)
			elseif name==Jiaodian[3] then
				 if status==EPlayerStatus_Paused  or status==EPlayerStatus_Finished     then
					SetSpriteFocus(dw_Play) 
				else SetSpriteFocus(dw_Paus)
				end
			elseif GetSpriteName(item)=="play" then
				SetSpriteFocus(dw_More)
			elseif name==JiaodianUD[2] then return
			elseif name==JiaodianUD[3] then return
			elseif name==JiaodianUD[1] then
				local reg = registerCreate("video")
				local seekTime
				local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
				local spriteR=registerGetInteger(reg, "root")
				labelStartTimeSprite = FindChildSprite(spriteR, "item-playerinterface-curtime")
				local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
				local totalTime=pluginInvoke(MediapalyPlugin, "GetTotalTime")
			
				seekTime=curTime+30
				spriteS=GetSpriteParent(GetSpriteParent(sprite))
				changeL=seekTime/totalTime*132
				spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighred")
				X,Y,X1,Y1=GetSpriteRect(spriteR)
				SetSpriteRect(spriteR,X,Y,changeL,Y1)
				spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighlight")
				X,Y,X1,Y1=GetSpriteRect(spriteR)
				SetSpriteRect(spriteR,X,Y,changeL,Y1)
				spriteR=FindChildSprite(spriteS,"item-playerinterface-progressblock")
				X,Y,X1,Y1=GetSpriteRect(spriteR)
				SetSpriteRect(spriteR,changeL+48,Y,X1,Y1)     
				setSecTime(labelStartTimeSprite, seekTime)	
				pluginInvoke(MediapalyPlugin, "Seek", seekTime)
				return 0
			end
	elseif keyCode==ApKeyCode_Left then
			if name=="item-playercontrols-recommend" then
				if status==EPlayerStatus_Paused  or status==EPlayerStatus_Finished     then
					SetSpriteFocus(dw_Play) 
				else SetSpriteFocus(dw_Paus)
				end
			elseif GetSpriteName(item)=="play" then
			SetSpriteFocus(dw_Up)
			elseif Num>1 and name~=JiaodianUD[1] and name~=JiaodianUD[2] and name~=JiaodianUD[3] then SetSpriteFocus(FindChildSprite(item,Jiaodian[Num-1]))
			elseif name==JiaodianUD[2] then return
			elseif name==JiaodianUD[3] then return
			elseif name==JiaodianUD[1] then
				if  curTime>=30  then
					local reg = registerCreate("video")
					local seekTime
					local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
					local spriteR=registerGetInteger(reg, "root")
					labelStartTimeSprite = FindChildSprite(spriteR, "item-playerinterface-curtime")
					local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
					local totalTime=pluginInvoke(MediapalyPlugin, "GetTotalTime")
					seekTime=curTime-30
		 
					spriteS=GetSpriteParent(GetSpriteParent(sprite))
					changeL=seekTime/totalTime*132
					WriteLogs("@@@@@@@@@@@@@@@@@totalTime"..totalTime)
					spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighred")
					X,Y,X1,Y1=GetSpriteRect(spriteR)
					SetSpriteRect(spriteR,X,Y,changeL,Y1)
					spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighlight")
					X,Y,X1,Y1=GetSpriteRect(spriteR)
					SetSpriteRect(spriteR,X,Y,changeL,Y1)
					spriteR=FindChildSprite(spriteS,"item-playerinterface-progressblock")
					X,Y,X1,Y1=GetSpriteRect(spriteR)
					SetSpriteRect(spriteR,changeL+48,Y,X1,Y1)
				end
				setSecTime(labelStartTimeSprite, seekTime)	
				pluginInvoke(MediapalyPlugin, "Seek", seekTime)
			
			end
	
	elseif keyCode==ApKeyCode_Up then
			
			if json == nil then
				SetSpriteFocus(Bar) return
			end
			if json.commend2 ~= nil and FlagK==1 then
				SetSpriteFocus(dw_Tj2)
			elseif  json.commend1 ~= nil  and name==JiaodianUD[3] then
				SetSpriteFocus(dw_Tj1)
			elseif name==JiaodianUD[2] then
				SetSpriteFocus(Bar)
			elseif json.commend2 == nil and  json.commend1 ~= nil  and FlagK==1 then
				SetSpriteFocus(dw_Tj1)
			elseif  json.commend2 == nil and  json.commend1 == nil and FlagK==1  then
				SetSpriteFocus(Bar)
			elseif name==Jiaodian[3] and json.commend1 == nil then
				SetSpriteFocus(Bar)
			end
	elseif keyCode==ApKeyCode_Down then
			if json == nil then
				SetSpriteFocus(dw_FullSec) return
			end
			if name==JiaodianUD[1]  then
				if  json.commend1~=nil then
				SetSpriteFocus(dw_Tj1)
				elseif json.commend1==nil and json.commend2~=nil then
				SetSpriteFocus(dw_Tj2)
				else SetSpriteFocus(dw_FullSec)
				end
			elseif name==JiaodianUD[2] then
				if json.commend2~=nil then
					SetSpriteFocus(dw_Tj2)
				else SetSpriteFocus(dw_FullSec)
				
				end
			elseif name==JiaodianUD[3] then
				SetSpriteFocus(dw_FullSec)
			end
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then		
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	
	elseif keyCode ==ApKeyCode_Enter and name==Jiaodian[1]  and status==EPlayerStatus_Playing  then
		WriteLogs("点击进入全屏")
		SetSpriteFocus(FullSec_BT)
		local reg=registerCreate("Fullselect")		--将全屏按钮键写入数据仓库
		registerSetInteger(reg,"FullFocus",sprite)
	
	end
	return 0
end

function movewindow111()
   reg = registerCreate("video")
   local MediapalyPlugin=registerGetInteger(reg, "MediapalyPlugin")
   pluginInvoke(MediapalyPlugin, "MoveWindow",0, 30, 240, 162)
   WriteLogs("@播放器移动啦~~@")
end

