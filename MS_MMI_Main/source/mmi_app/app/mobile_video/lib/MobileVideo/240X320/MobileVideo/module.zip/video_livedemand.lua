﻿--@module video
--@note 播放界面
--0, 60, 320, 204)
--@author cuiyizhou
--@date 2010/05/25
require "module.video_com"
require "module.keyCode.keyCode"
require "module.common.SceneUtils"
local myKeyCode=""
local myBarSprite
local mySeekTime=0
local firstFlag=1
local iii = 0
function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--
	reg = registerCreate("video")
	registerSetInteger(reg, "root", sprite)
	FullScreen=FindChildSprite(sprite,"FullSec")
	http = pluginCreate("HttpPipe", "comHttpPipe")
	observer = pluginGetObserver()
	--[[  以下为组点播时的面板创建  ]]--
	local regflag = registerCreate("buttonclickflag")
	--[[	flag值为0时playerinterfaceOnTick函数会直接返回，即不移动播放器面板	]]--
	registerSetInteger(regflag, "flag", 0)
	--[[	preflag值置1，默认第一次播放器面板的运动为向上	]]--
	registerSetInteger(regflag, "preflag", 1)
	InitScene()
	FullSelect=FindChildSprite(sprite,"item-playercontrols-fullscreen")
	FullSec_BT=FindChildSprite(sprite,"FullSec")
	Bar=FindChildSprite(sprite,"splider-bar")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin == 0 then
		MediapalyPlugin = pluginCreate("MediaPlayer")
		pluginInvoke(MediapalyPlugin, "Create",0, 0, 0, 0)
	end
	
	if MediapalyPlugin ==0 then
		SetStatusText("创建播放器失败，请重新安装程序")
	else
		registerSetInteger(reg, "MediapalyPlugin", MediapalyPlugin)
	end
	return 1
end

function bodyOnSpriteEvent(message, params)
	require("module.common.commonMsg")
	reg = registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if message == MSG_EXCEPTIVEKEY then
		WriteLogs("MSG_EXCEPTIVEKEY: "..params)
		if params == 23 then
			VolumeUpOnButtonClick(nil)
		elseif params == 24 then
			VolumeDownOnButtonClick(nil)
		end
	elseif message == MSG_ACTIVATE then
		regtimer=registerCreate("timerflag")
		registerSetInteger(regtimer, "flag",1)
		require "module.common.DownloadUpload"
		PauseDownloadTask()
		PauseUploadTask()
		curPageIsVideo = true
		SetStatusText("")
		WriteLogs("MSG_ACTIVATE")
		jsonCreateData()
		local urlCmp = registerGetString(reg, "urlCmp")
		
		if MediapalyPlugin == 0 and urlpath then
			MediapalyPlugin = pluginCreate("MediaPlayer")
			local open = pluginInvoke(MediapalyPlugin, "Open", urlpath)
			if open == 1 then
				local Volume = pluginInvoke(MediapalyPlugin, "GetVolume")
				curVolume = Volume
				registerSetInteger(reg, "MediapalyPlugin", MediapalyPlugin)
				pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 0, 0, 0)
			else
				SetStatusText("连接服务器失败")
			end
		elseif urlpath then
			if urlCmp == urlpath then			--当前播放和上次播放一样
				local isReplay = registerGetString(reg, "isReplay")
				if isReplay == "true" then
					zeroProgress()
					SetTimer(1,500,"OpenDelay")
					registerSetString(reg, "isReplay", "")
				elseif videoType == videoTypeList[4] then
					GetSysTime()
					require("module.setting")
					zeroProgress()
					if Cfg.GetVideoType() == ".3gp" then				--华为播放器
						pluginInvoke(MediapalyPlugin, "Stop")
						SetTimer(1,500,"OpenDelay")
					else								--荣创播放器
						pluginInvoke(MediapalyPlugin, "Stop")
					end
					pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 0, 0, 0)
				else
					local status = pluginInvoke(MediapalyPlugin, "GetStatus")
					if status ==EPlayerStatus_Stopped then
					pluginInvoke(MediapalyPlugin, "Play")
					pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 0, 0, 0)
					else
					pluginInvoke(MediapalyPlugin, "Play")
					MoveWindow_L()
					OnGetStatus()
					initData_v()
					return
					end
					
				end
			else 						--当前播放和上次播放不一样
				zeroProgress()
				WriteLogs("open")
				pluginInvoke(MediapalyPlugin, "Open", urlpath)
				pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 0, 0, 0)
				registerSetString(reg, "urlCmp", urlpath)
			end
		end
		SetTimer(1, 1000, "MoveWindow_L")
		SetTimer(1, 500, "OnGetStatus")
		initData_v()
	elseif message == MSG_DEACTIVATE then
		WriteLogs("MSG_DEACTIVATE")
		curPageIsVideo = false
		if MediapalyPlugin == 0 then
			MediapalyPlugin = pluginCreate("MediaPlayer")
			WriteLogs("MSG_DEACTIVATE Create MediapalyPlugin")
		end
		
		local is2recommend = registerGetInteger(reg, "is2recommend")
		if is2recommend == 0 then
			zeroProgress()
			pluginInvoke(MediapalyPlugin, "Stop")
		else
			if videoType == videoTypeList[4] then
				zeroProgress()
			end
			registerSetInteger(reg, "is2recommend", 0)
		end
		pluginInvoke(MediapalyPlugin, "Show" , 0)
		SetStatusText("")
		local left2, top2, width2, height2 = GetSpriteRect(huaKuaiSprite)
		SetSpriteRect(huaKuaiSprite, huaKuai_left,top2, width2, height2)
		local left2, top2, width2, height2 = GetSpriteRect(spritehighlight)
		SetSpriteRect(spritehighlight, left2, top2, 0, height2)
		SetSpriteRect(spritehighred, left2, top2, 0, height2)
	elseif message == MSG_MINIMIZED then
		WriteLogs("MSG_MINIMIZED")
		regtimer=registerCreate("timerflag")
		registerSetInteger(regtimer, "flag",0)
		if MediapalyPlugin then
			if iffull == 1 then
				iffull =0
				pluginInvoke(MediapalyPlugin, "FullScreen", 0)
				ReleaseSpriteCapture(FullSec)
				SetSpriteProperty(FullSec,"enable","false")
				SetSpriteFocus(dw_FullSec)
			end
			pluginInvoke(MediapalyPlugin, "Show" , 0)
			pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 0, 0, 0)
			pluginInvoke(MediapalyPlugin, "Pause")
			if HasSpriteFocus(FullScreen)==1 then
				WriteLogs("焦点在：FullSec上 ")
				SetSpriteFocus(FullSelect)
			end
		end
	elseif message == MSG_MAXIMIZED then
		WriteLogs("MSG_MAXIMIZED")
		regtimer=registerCreate("timerflag")
	  registerSetInteger(regtimer, "flag",1)
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Show" , 1)
			SetTimer(1, 1000, "MoveWindow_L")
		end
		if HasSpriteFocus(FullScreen)==1 then
				WriteLogs("焦点在：FullSec上 ")
				SetSpriteFocus(FullSelect)
		end
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		if MediapalyPlugin ~= 0 then
				pluginInvoke(MediapalyPlugin, "Stop")
				pluginInvoke(MediapalyPlugin, "Show" , 0)
				CancelTimer(1)
		end
	elseif message == MSG_SMS then
		WriteLogs("Received a short message")
		hintSMS()
	end
end

function OnPluginEvent(message, param)
	require ("module.common.SceneUtils")
	require ("module.common.registerScene")
	if message == 101 then
		exitLoading()
		SetReturn(sceneVideoLiveDemand,scenePrograminfo_volume)
		GoAndFreeScene(scenePrograminfo_volume)
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneVideoLiveDemand, sceneVideoLiveDemand)
		videoDealSMS()
	end
end

function jsonCreateData()
	commendUrlList={"item-playerinterface-recommand1","item-playerinterface-recommand2"}
	commendNameList={"item-playerinterface-recommand1","item-playerinterface-recommand2"}
	commendUrlList["item-playerinterface-recommand1"]=""
	commendUrlList["item-playerinterface-recommand2"]=""
	commendNameList["item-playerinterface-recommand1"]=""
	commendNameList["item-playerinterface-recommand2"]=""
	require ("module.protocol.protocol_video")
	json =OnVideoDecode()
	if json == nil then
		return
	end
	urlpath =""
	--[[  播放器页面推荐只用取最后一条记录  ]]--
	if json.commend1 ~= nil then 
		for i=0, table.maxn(json.commend1) do	
			if json.commend1[i].urlPath ~= nil then
				commendUrlList["item-playerinterface-recommand1"] = json.commend1[i].urlPath
				commendNameList["item-playerinterface-recommand1"] = json.commend1[i].contentName
			end
		end
	end
	if json.commend2 ~= nil then
		for i=0, table.maxn(json.commend2) do	
			if json.commend2[i].urlPath ~=nil then
				commendUrlList["item-playerinterface-recommand2"] = json.commend2[i].urlPath
				commendNameList["item-playerinterface-recommand2"] = json.commend2[i].contentName
			end
		end
	end
	urlpath = json.url
	IsReview = registerGetString(reg, "IsReview")
	if IsReview and IsReview == "true" then
		registerSetString(reg, "toSetIsReview","true")
	else
		registerSetString(reg, "toSetIsReview","")
	end
	registerSetString(reg, "IsReview","")
	SaveHistoryVideoList(IsReview)
	return 1
end

function InitScene()	
	createLiveVideo()	--[[  以下为直播时的面板创建  ]]--
	createGlobalValue()
end

function initData_v()
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	setSecTime(labelStartTimeSprite, pluginInvoke(MediapalyPlugin, "GetCurTime"))
	gTotalTime = pluginInvoke(MediapalyPlugin, "GetTotalTime")
	setSecTime(labelEndTimeSprite, gTotalTime)
	
	local normalLable = FindChildSprite(recommand1Button, "normal")
	local focusLable = FindChildSprite(recommand1Button, "focus")
	SetSpriteProperty(normalLable, "text" ,commendNameList["item-playerinterface-recommand1"] )
	SetSpriteProperty(focusLable, "text" ,commendNameList["item-playerinterface-recommand1"] )
	normalLable = FindChildSprite(recommand2Button, "normal")
	focusLable = FindChildSprite(recommand2Button, "focus")
	SetSpriteProperty(normalLable, "text" ,commendNameList["item-playerinterface-recommand2"] )
	SetSpriteProperty(focusLable, "text" ,commendNameList["item-playerinterface-recommand2"] )
end

function RecommandOnSelect(sprite)
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	local tuijianName=GetSpriteName(sprite)
	if commendUrlList[tuijianName] ~="" then
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Pause")
			pluginInvoke(MediapalyPlugin, "Show" , 0)
		end
		local rootSprite=GetRootSprite(sprite)
		local statuslabel = FindChildSprite(rootSprite, "player-status1")													--状态信息，用于显示播放器状态
		local statuslabe2 = FindChildSprite(rootSprite, "player-status2")													--状态信息
		local statusSMS   = FindChildSprite(rootSprite, "sms-Status")															--短信状态信息
		local smsStatusImage = FindChildSprite(rootSprite, "sms-Status-image")
		SetSpriteVisible(statuslabel, 1)
		SetSpriteVisible(statuslabe2, 1)
		SetSpriteProperty(statusSMS, "text", "")
		SetSpriteVisible(smsStatusImage, 0)
		SetStatusText("")
		RequestGuide(commendUrlList[tuijianName], nil)
	end
end

--@function	createLiveVideo
--@brief	当场景为视屏直播时，创建相应的界面，在bodyBuildChildrenFinished中调用
function createLiveVideo()
	--[[	获取根节点	]]--
	local root = registerGetInteger(reg, "root")
	--[[	创建listitem类的节点	]]--
	local playercontrolsitemSprite = CreateSprite("listitem")
	local playercontrolsSprite = FindChildSprite(root, "list-playercontrols")
	local xx,yy,w,h = GetSpriteRect(playercontrolsSprite)
	--[[	用已有模板中数据填充该节点	]]--
	LoadSprite(playercontrolsitemSprite, "MODULE:\\video_livevideomodule.xml")
	SetSpriteRect(playercontrolsitemSprite,0, 0, 240, 100)
	--[[	把该节点插入到场景中	]]--
	AddChildSprite(playercontrolsSprite, playercontrolsitemSprite)
	SpriteList_AddListItem(playercontrolsSprite, playercontrolsitemSprite)
	dw_FullSec=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-fullscreen") 
	dw_Down=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-volumedown") 
	dw_Up=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-volumeup") 
	dw_Play=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-play") 
	dw_Pause=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-pause") 
	dw_More=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-recommend") 
	dw_Tj1=FindChildSprite(playercontrolsitemSprite, "item-playerinterface-recommand1") 
	dw_Tj2=FindChildSprite(playercontrolsitemSprite, "item-playerinterface-recommand2")
	if w > 280 then
		SetSpriteVisible(dw_Tj2, 0)
	end	
	SetSpriteFocus(dw_FullSec)
	saveTouchFocus(dw_FullSec)
	return 1
end

--brief 播放器键盘事件
--author 杜威

function FullChangeKeyUp(sprite,keyCode)
	WriteLogs("keyCode:"..keyCode)
	
	WriteLogs("退出全屏")
	if keyCode then
	FullSecOnButtonClick(sprite)
	
	end
	return 0
end


function listKeyUp(sprite,keyCode)
	FlagK=0	
	local Num=1
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local Jiaodian = {"item-playercontrols-fullscreen","item-playercontrols-volumedown","item-playercontrols-volumeup","play","item-playercontrols-recommend"}
	local JiaodianUD= {"splider-bar","item-playerinterface-recommand1","item-playerinterface-recommand2","item-playercontrols-fullscreen"}
	local name=GetSpriteName(sprite)
	local reg= registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	status = pluginInvoke(MediapalyPlugin, "GetStatus")  
	item=GetSpriteParent(sprite)
	--WriteLogs("status:"..status)
	WriteLogs("keyCode:"..keyCode)
	WriteLogs("Name:"..name)
	for i=1,5 do
    if Jiaodian[i]==name or Jiaodian[i]==GetSpriteName(item) then
	    Num=i
		FlagK=1
	    break
	  end   
	end   
	WriteLogs(Num)
	local isPauseEnable = IsSpriteEnable(dw_Pause)
	
	if keyCode==ApKeyCode_Right then	
		if Num<3 and name~= JiaodianUD[1] and  name~=JiaodianUD[2] and name~=JiaodianUD[3]then
			local NextFocus= FindChildSprite(item,Jiaodian[Num+1])
			SetSpriteFocus(NextFocus)
			saveTouchFocus(NextFocus)
		elseif name==Jiaodian[3] then
			if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering or status==EPlayerStatus_Connecting  or status==nil then
				if isPauseEnable == 1 then
					SetSpriteFocus(dw_Pause)
					saveTouchFocus(dw_Pause)
				else
					SetSpriteFocus(dw_More)
					saveTouchFocus(dw_More)
				
				end
			else
				SetSpriteFocus(dw_Play)
				saveTouchFocus(dw_Play)
			end
		elseif GetSpriteName(item)=="play" then		
			SetSpriteFocus(dw_More)
			saveTouchFocus(dw_More)
		elseif name==JiaodianUD[2] then return
		elseif name==JiaodianUD[3] then return
		elseif name==JiaodianUD[1] then
			local regvideo = registerCreate("video")
			local videotype =  registerGetString(regvideo, "videoType")
			if videotype=="live" then
				return 1
			end
 
			myKeyCode=""
			CancelTimer(2)
			local reg = registerCreate("video")
			local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
			pluginInvoke(MediapalyPlugin, "Play")
			pluginInvoke(MediapalyPlugin, "Seek", mySeekTime)
			mySeekTime=0
			firstFlag=1
			return 0
		end
	elseif keyCode==ApKeyCode_Left then
		if name=="item-playercontrols-recommend" then
			if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering or status==EPlayerStatus_Connecting  or status==nil then
				if isPauseEnable == 1 then
					SetSpriteFocus(dw_Pause)
					saveTouchFocus(dw_Pause)
				else
					SetSpriteFocus(dw_Up)
					saveTouchFocus(dw_Up)
				end
			else
				SetSpriteFocus(dw_Play)
			end	
		elseif GetSpriteName(item)=="play" then
		SetSpriteFocus(dw_Up)
		saveTouchFocus(dw_Up)
		elseif Num>1 and name~=JiaodianUD[1] and name~=JiaodianUD[2] and name~=JiaodianUD[3] then SetSpriteFocus(FindChildSprite(item,Jiaodian[Num-1]))
		saveTouchFocus(FindChildSprite(item,Jiaodian[Num-1]))
		elseif name==JiaodianUD[2] then return
		elseif name==JiaodianUD[3] then return
		elseif name==JiaodianUD[1] then
			local regvideo = registerCreate("video")
			local videotype =  registerGetString(regvideo, "videoType")
			if videotype=="live" then
 
				return 1
			end
			myKeyCode=""
			CancelTimer(2)
			local reg = registerCreate("video")
			local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
			pluginInvoke(MediapalyPlugin, "Play")
			pluginInvoke(MediapalyPlugin, "Seek", mySeekTime)
			firstFlag=1
			mySeekTime=0
			return 0
		end
	
	elseif keyCode==ApKeyCode_Up then
			local regvideo = registerCreate("video")
			local videotype =  registerGetString(regvideo, "videoType")
			if json == nil and videotype ~= "live" then
				SetSpriteFocus(Bar) 
				saveTouchFocus(Bar)
				return
			end
			if FlagK==1 then
				if json.commend2 ~= nil and IsSpriteVisible(dw_Tj2) == 1 then
					SetSpriteFocus(dw_Tj2)
					saveTouchFocus(dw_Tj2)
				elseif json.commend1 ~= nil and IsSpriteVisible(dw_Tj1) == 1 then
					SetSpriteFocus(dw_Tj1)
					saveTouchFocus(dw_Tj1)
				elseif videotype ~= "live" then
					SetSpriteFocus(Bar)
					saveTouchFocus(Bar)
				end
			else
				if name==JiaodianUD[3] then
					if json.commend1 ~= nil and IsSpriteVisible(dw_Tj1) == 1 then
						SetSpriteFocus(dw_Tj1)
						saveTouchFocus(dw_Tj1)
					elseif videotype ~= "live" then
						SetSpriteFocus(Bar)
						saveTouchFocus(Bar)
					end
				elseif name==JiaodianUD[2] and videotype ~= "live" then
					SetSpriteFocus(Bar)
					saveTouchFocus(Bar)
				end
			end
	elseif keyCode==ApKeyCode_Down then
			if json == nil then
				SetSpriteFocus(dw_FullSec) 
				saveTouchFocus(dw_FullSec)
				return
			end
			if name==JiaodianUD[1]  then
				if  json.commend1~=nil and IsSpriteVisible(dw_Tj1) == 1 then
					SetSpriteFocus(dw_Tj1)
					saveTouchFocus(dw_Tj1)
				elseif json.commend2~=nil and IsSpriteVisible(dw_Tj2) == 1 then
					SetSpriteFocus(dw_Tj2)
					saveTouchFocus(dw_Tj2)
				else 
					SetSpriteFocus(dw_FullSec)
					saveTouchFocus(dw_FullSec)
				end
			elseif name==JiaodianUD[2] then
				if json.commend2~=nil and IsSpriteVisible(dw_Tj2) == 1 then
					SetSpriteFocus(dw_Tj2)
					saveTouchFocus(dw_Tj2)
				else 
					SetSpriteFocus(dw_FullSec)
					saveTouchFocus(dw_FullSec)
				end
			elseif name==JiaodianUD[3] then
				SetSpriteFocus(dw_FullSec)
				saveTouchFocus(dw_FullSec)
			end
	elseif keyCode == ApKeyCode_F1 then		
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		--pluginInvoke(MediapalyPlugin, "Stop")
		require("module.menuopen")
		SetTimer(1, 200, "OnTimerReturn")
		--returnButtonOnSelect(sprite)
		
	elseif keyCode ==ApKeyCode_Enter and name==Jiaodian[1]  and status==EPlayerStatus_Playing  then
		WriteLogs("点击进入全屏")
		SetSpriteFocus(FullSec_BT)
		saveTouchFocus(FullSec_BT)
		FullScreenOnButtonClick(sprite)
	end
	return 0
end

function movewindow111()
   reg = registerCreate("video") 
   local MediapalyPlugin=registerGetInteger(reg, "MediapalyPlugin")
   pluginInvoke(MediapalyPlugin, "MoveWindow",  0, 35, 240, 160)
   WriteLogs("@播放器移动啦~~@")
end

function OnTimerReturn()
	require("module.menuopen")
	reg = registerCreate("video")   
	local sprite=registerGetInteger(reg, "root")	
	returnButtonOnSelect(sprite)
end

function barKeyDown(sprite,keyCode)
	local regvideo = registerCreate("video")
	local videotype =  registerGetString(regvideo, "videoType")
	if videotype=="live" then
		return 1
	end
 
	if keyCode==ApKeyCode_Left then
		pressLeftBar(sprite)
	elseif keyCode==ApKeyCode_Right then
		pressRightBar(sprite)
	end
end

function barKeyPress(sprite,keyCode)
	local regvideo = registerCreate("video")
	local videotype =  registerGetString(regvideo, "videoType")
	if videotype=="live" then
 
		return 1
	end
	WriteLogs("do barKeyPress keyCode=="..keyCode)
	myKeyCode=keyCode
	myBarSprite=sprite
	local reg = registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if keyCode==ApKeyCode_Left then
		pluginInvoke(MediapalyPlugin,"Pause")
		SetTimer(2,2000,"pressOnTimer")
	elseif keyCode==ApKeyCode_Right then
		pluginInvoke(MediapalyPlugin,"Pause")
		SetTimer(2,2000,"pressOnTimer")
	end
end

function pressLeftBar(sprite)
		local reg = registerCreate("video")
		local seekTime
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		local spriteR=registerGetInteger(reg, "root")
		labelStartTimeSprite = FindChildSprite(spriteR, "item-playerinterface-curtime")
		local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
		local totalTime=pluginInvoke(MediapalyPlugin, "GetTotalTime")
		if firstFlag==1 then
			seekTime=curTime-30
			firstFlag=0
			mySeekTime=seekTime
		else
			mySeekTime=mySeekTime-50
			seekTime=mySeekTime
		end
		WriteLogs("left seekTime=="..seekTime)
		spriteS=GetSpriteParent(GetSpriteParent(sprite))
		local Bg_x,Bg_y=GetSpriteRect(FindChildSprite(spriteS,"item-playerinterface-progressbar"))
		changeL=seekTime/totalTime*132
		WriteLogs("@@@@@@@@@@@@@@@@@totalTime"..totalTime)
		spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighred")
		X,Y,X1,Y1=GetSpriteRect(spriteR)
		SetSpriteRect(spriteR,X,Y,changeL,Y1)
		spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighlight")
		X,Y,X1,Y1=GetSpriteRect(spriteR)
		SetSpriteRect(spriteR,X,Y,changeL,Y1)
		spriteR=FindChildSprite(spriteS,"item-playerinterface-progressblock")
		X,Y,X1,Y1=GetSpriteRect(spriteR)
		if seekTime<0 then
		SetSpriteRect(spriteR,Bg_x,Y,X1,Y1)
		setSecTime(labelStartTimeSprite, 0)	
		mySeekTime=0
		return 0
		else
		SetSpriteRect(spriteR,changeL+45,Y,X1,Y1)  
		end
		setSecTime(labelStartTimeSprite, seekTime)	
end

function pressRightBar(sprite)
	local reg = registerCreate("video")
	local seekTime
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	local spriteR=registerGetInteger(reg, "root")
	labelStartTimeSprite = FindChildSprite(spriteR, "item-playerinterface-curtime")
	local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
	local totalTime=pluginInvoke(MediapalyPlugin, "GetTotalTime")
	if firstFlag==1 then
		seekTime=curTime+30
		firstFlag=0
		mySeekTime=seekTime
	else
		mySeekTime=mySeekTime+50
		seekTime=mySeekTime
	end
	WriteLogs("right seekTime=="..seekTime)
	spriteS=GetSpriteParent(GetSpriteParent(sprite))
	local Bg_x,Bg_y=GetSpriteRect(FindChildSprite(spriteS,"item-playerinterface-progressbar"))
	changeL=seekTime/totalTime*132
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighred")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	SetSpriteRect(spriteR,X,Y,changeL,Y1)
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighlight")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	SetSpriteRect(spriteR,X,Y,changeL,Y1)
	spriteR=FindChildSprite(spriteS,"item-playerinterface-progressblock")
	X,Y,X1,Y1=GetSpriteRect(spriteR)
	if seekTime>totalTime then
	SetSpriteRect(spriteR,Bg_x+130,Y,X1,Y1)
	setSecTime(labelStartTimeSprite, totalTime-0)
	mySeekTime=totalTime
	return 0
	else
	SetSpriteRect(spriteR,changeL+45,Y,X1,Y1)  
	end
	setSecTime(labelStartTimeSprite, seekTime)	
end

function pressOnTimer()
	if myKeyCode==ApKeyCode_Left then
		pressLeftBar(myBarSprite)
	elseif myKeyCode==ApKeyCode_Right then
		pressRightBar(myBarSprite)
	end
end

function OpenDelay()
	local reg= registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin and MediapalyPlugin ~= 0 then
		local status = pluginInvoke(MediapalyPlugin, "GetStatus")
		if status == EPlayerStatus_Stopped then
			pluginInvoke(MediapalyPlugin, "Open", urlpath)
		else
			SetTimer(1,500,"OpenDelay")
		end
	end
end