﻿--@module	upload_select
--@note	用于上传选择界面的UI显示
--@author	shenyi
--@date	2010/06/02

require("module.common.SceneUtils")

uploadSelect_SelectHeight = 43
uploadSelect_NormalHeight = 26
uploadSelect_ItemWidth = 222

dirtype = {}
dirname = {}

--@tag-action	body:BuildChildrenFinished
--@brief	创建收藏列表
function bodyBuildChildrenFinished(sprite)
	

	local reg = registerCreate("upload-select")
	registerSetInteger(reg, "root", sprite)	
	
	GetDirectoryAndFileName()
	CreateUploadselectList(sprite)
	WriteLogs("bodyBuildChildrenFinished ------> "..(#dirname))
	setUploadSelectData()
	return 1
	
end

--@function	CreateuploadList
--@brief	创建收藏列表
function CreateUploadselectList(sprite)
	local spriteList = FindChildSprite(sprite, "uploadselect-list")
	local xmlNode=xmlLoadFile("MODULE:\\upload_selectlist.xml")
	for i=1,uploadcount+1 do
		local uploadSprite = CreateSprite("listitem")
		LoadSpriteFromNode(uploadSprite, xmlNode)
		local spriteSel = FindChildSprite(uploadSprite,"select")
		local spriteUnSel = FindChildSprite(uploadSprite,"unselect")
		--WriteLogs("spriteSel"..spriteSel)
		
		if i == 1 then			
			--WriteLogs("2222222222222")
			SetSpriteVisible(spriteSel, 1)
			SetSpriteEnable(spriteSel, 1)
			SetSpriteVisible(spriteUnSel, 0)			
			SetSpriteEnable(spriteUnSel, 0)			
			SetSpriteRect(uploadSprite, 0, 0, uploadSelect_ItemWidth, uploadSelect_SelectHeight)
			prevSelectSprite = uploadSprite
			WriteLogs("CreateuploadList "..uploadSprite)
			--SetSpriteProperty(spriteList, "current", i - 1)
		else
			--WriteLogs("111111111111111")
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)
			SetSpriteRect(uploadSprite, 0, 0, uploadSelect_ItemWidth, uploadSelect_NormalHeight)
		end
		
		if i == uploadcount+1 then
			local spriteFengge = FindChildSprite(uploadSprite,"fengge")
			local spriteFengge1 = FindChildSprite(uploadSprite,"fengge1")
			SetSpriteVisible(spriteFengge,0)
			SetSpriteVisible(spriteFengge1,0)
		end
		
		--local spriteLabel = FindChildSprite(searchResultSprite, "resText")
		--SetSpriteProperty(spriteLabel, "text", result[i])
		--SetSpriteRect(uploadSprite, 0, 0, 222, 25)
		AddChildSprite(spriteList, uploadSprite)
		SpriteList_AddListItem(spriteList, uploadSprite)
	end
	xmlRelease(xmlNode)
	SpriteList_Adjust(spriteList)
	uploadlist=spriteList
	SpriteList_GetListItemCount(uploadlist,1)
	WriteLogs("@@@@@@@#!@#@!#!@#!@#@!#"..SpriteList_GetListItemCount(spriteList,1))
	start = 1
	select = 1
	perpage = 8
	local totalheight = (uploadcount+1)*25+18
	if totalheight > 223 then
		scroll_region = uploadcount*25+18-223
	else
		local spriteImage = FindChildSprite(sprite,"scrollbar-image")
		local spriteScroll = FindChildSprite(sprite,"scroll")
		local spriteSplider = FindChildSprite(sprite,"splider-bar")
		SetSpriteVisible(spriteImage,0)
		SetSpriteVisible(spriteSplider,0)
		SetSpriteEnable(spriteScroll,0)
		SetSpriteEnable(spriteSplider,0)
	end
	
	position = 0
	--[[  统一滚动条创建  ]]--
	require "module.common.commonScroll"
	CreateScrollBar(sprite,"uploadselect-list",(uploadcount-1)*uploadSelect_NormalHeight+uploadSelect_SelectHeight,76)
	ScrollBarAdjust(0,7,1)
end

--@function	setUploadSelectData
--@brief	设置上传选择数据
filedata = {"program files","Documents and Settings","My Documents","Temp","Application Data"}

function setUploadSelectData()
	local reg = registerCreate("upload-select")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite,"uploadselect-list")
	--WriteLogs("spriteList"..spriteList)
	spriteItem = SpriteList_GetListItem(spriteList, 0)
	local spriteTxt = FindChildSprite(spriteItem, "item-text")
	local spriteTxt1 = FindChildSprite(spriteItem, "item-text1")
	SetSpriteProperty(spriteTxt, "text", "进入上一级")	
	SetSpriteProperty(spriteTxt1, "text", "进入上一级")	
	local spriteImg = FindChildSprite(spriteItem,"file-image")
	local spriteImg1 = FindChildSprite(spriteItem,"file-image1")
	SetSpriteVisible(spriteImg,0)
	SetSpriteVisible(spriteImg1,0)
	local spriteLabel = FindChildSprite(spriteItem,"command-text")
	SetSpriteProperty(spriteLabel,"text","返回")
	
	for i = 2,uploadcount+1 do
		spriteItem = SpriteList_GetListItem(spriteList, i-1)
		local spriteTxt = FindChildSprite(spriteItem, "item-text")
		local spriteTxt1 = FindChildSprite(spriteItem, "item-text1")
		--WriteLogs("dirname["..i.."]"..dirname[i-1])
		SetSpriteProperty(spriteTxt, "text", dirname[i-2])	
		SetSpriteProperty(spriteTxt1, "text", dirname[i-2])	
		if dirtype[i-2] == 1 then
			local spriteImg = FindChildSprite(spriteItem,"file-image")
			local spriteImg1 = FindChildSprite(spriteItem,"file-image1")
			SetSpriteVisible(spriteImg,0)
			SetSpriteVisible(spriteImg1,0)
			local spriteLabel = FindChildSprite(spriteItem,"command-text")
			SetSpriteProperty(spriteLabel,"text","进入")
		end
	end
end

--@function	itemButtonOnSelect
--@tag-name	item-button
--@tag-action	button:OnSelect
--@brief	用于响应各列表项按钮
function itemButtonOnSelect(sprite)	
	--WriteLogs("1111111111")
	--WriteLogs("prevSelectSprite  "..prevSelectSprite)
	if prevSelectSprite ~= nil then
		WriteLogs("itemButtonOnSelect "..prevSelectSprite)
		local spriteSel1 = FindChildSprite(prevSelectSprite,"select")
		local spriteUnSel1 = FindChildSprite(prevSelectSprite,"unselect")
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(prevSelectSprite, 0, 0, uploadSelect_ItemWidth, uploadSelect_NormalHeight)
	end
	--WriteLogs("aaaaaaaaaa")
	local spriteParent = GetSpriteParent(sprite)
	local spriteupload = GetSpriteParent(spriteParent)
	local spriteSel2 = FindChildSprite(spriteupload,"select")
	local spriteUnSel2 = FindChildSprite(spriteupload,"unselect")
	SetSpriteVisible(spriteUnSel2, 0)
	SetSpriteEnable(spriteUnSel2, 0)
	SetSpriteVisible(spriteSel2, 1)			
	SetSpriteEnable(spriteSel2, 1)
	SetSpriteRect(spriteupload, 0, 0, uploadSelect_ItemWidth, uploadSelect_SelectHeight)
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "uploadselect-list")
	SpriteList_Adjust(spriteList)
	prevSelectSprite = spriteupload
	select = SpriteListItem_GetIndex(spriteupload) + 1
	--WriteLogs(select)
end


--filter={"*.3gp","*.dat"}	--需要过滤的文件类型，可以直接添加

function commandButtonOnSelect(sprite)
	local reg = registerCreate("uploadinfor")  
    local directory = registerGetString(reg,"current-directory")
	local spriteText = FindChildSprite(sprite,"command-text")	
	local text = GetSpriteText(spriteText)
		
	if text == "返回" then
		--local prevdir = registerGetString(reg,"previous-directory")
		--registerSetString(reg,"current-directory",prevdir)	
		local t={}
		local i=0
		while true do
			i=string.find(directory,"\\",i+1)
			if i==nil then break end
			table.insert(t,i)
			WriteLogs("i"..i.."")
		end
		local position = t[#t-1]
		WriteLogs("position "..position)
		local prevdir = string.sub(directory,1,position)
		WriteLogs("prevdir: "..prevdir)
	    registerSetString(reg,"current-directory",prevdir)		
		
		--WriteLogs("tail is"..tail)
    	--ByeScene("MODULE:\\upload_select.xml")
		local labelSprite = GetCurScene()
		FreeScene(labelSprite)
		Go2Scene(sceneUploadSelect)				
	elseif text == "进入" then
		local spriteParent = GetSpriteParent(sprite)
		local spriteDirname = FindChildSprite(spriteParent,"item-text1")
		local dirname = GetSpriteText(spriteDirname)
		local wholedir = directory..dirname.."\\"
		WriteLogs("directory"..directory)
		
	   registerSetString(reg,"current-directory",wholedir)
		--registerSetString(reg,"previous-directory",directory)
	   --ByeScene("MODULE:\\upload_select.xml")
		local labelSprite = GetCurScene()
		FreeScene(labelSprite)	
		Go2Scene(sceneUploadSelect)		

	elseif text == "上传" then		
	-- -- --进入上传界面
		local spriteParent = GetSpriteParent(sprite)
		local spriteFilename = FindChildSprite(spriteParent,"item-text1")
		local filename = GetSpriteText(spriteFilename)
		local filedir = directory..filename
		local reg = registerCreate("upload-select")
		registerSetString(reg, "upload-filedir", filedir)	
		registerSetString(reg, "upload_fileName",filename)
		
		FreeScene(GetCurScene())
		Go2Scene(sceneUpload)	
		
	end
	
end


--filter={"*.3gp","*.wmv","*.avi","*.mpg","*.mp4","*.rmvb"}	--需要过滤的文件类型，可以直接添加
filter1 = {}

function GetDirectoryAndFileName()
	--local dirname={}
	local dir = {}
	local filter = {}
	local reg = registerCreate("uploadinfor")  
    local directory = registerGetString(reg,"current-directory")
	--WriteLogs("select directoy is: "..directory.."")

	--WriteLogs("uploadcount"..uploadcount)
	--WriteLogs(0.."------["..dir[0].filename.."]")
	--WriteLogs(1.."------["..dir[1].filename.."]")
	
	require "module.setting"
	filter = {"*.3gp","*.wmv","*.avi","*.mpg","*.mp4"} --Cfg.GetFileter()
	local num = table.maxn(filter)
	WriteLogs("before filter max"..num)
	for i = 1,table.maxn(filter1) do
		filter[num+i] = filter1[i]
	end
	WriteLogs("after filter max"..table.maxn(filter))
	
	local count = 0
	for n = 1 ,table.maxn(filter) do
	    local fileFilter = directory.."\\"..filter[n];
		WriteLogs("fileFilter = "..fileFilter);
		dir = OpenDirectory(fileFilter)
		if dir then
			for i = 0, table.maxn(dir) do
				local prefix = string.sub(dir[i].filename,0,5)
				WriteLogs("prefix---"..prefix)
				if prefix ~= "temp_" then
					dirname[count] = dir[i].filename
					dirtype[count] = 0
					count = count + 1			
				end
			end	
		end
	end	
	
	dir = OpenDirectory(directory.."\\*.*")	
	if dir then
		for i = 0, table.maxn(dir) do
			if dir[i].attr == 1 and dir[i].filename ~= "." and dir[i].filename ~= ".." then
				dirname[count] = dir[i].filename
				dirtype[count] = 1
				count = count + 1
			end			
		end	
	end
	
	if dirname[0] then
		uploadcount = table.maxn(dirname)+1
	else
		uploadcount = 0
	end
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	end
end

function OnPluginEvent(message, Param)	
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if MSG_SMS_ID == message then			
		DealMsgContent(sceneUploadSelect, sceneUploadSelect)
	end
end


	
function commandbuttonKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	local itemCount = SpriteList_GetListItemCount(uploadlist)
	item=GetSpriteParent(GetSpriteParent(sprite))
	local index=SpriteListItem_GetIndex(item)
	local spriteunsel=FindChildSprite(item,"unselect")
	local spritesel=FindChildSprite(item,"select")
	local list_x, list_y2, list_w, list_h = GetSpriteRect(uploadlist)
	local _, list_y1 = GetSpriteRect(item)
	local list_y = list_y1+list_y2
	WriteLogs("list_y="..list_y)
	if keyCode==ApKeyCode_Down and index<=itemCount-1 then
			if index==itemCount-1 then
			return 1
			end
	SetSpriteVisible(spriteunsel,1)							--跳如下个ITem时，unselct 出现
	SetSpriteEnable(spriteunsel,1)
	SetSpriteVisible(spritesel,0)							-- select 影藏
	SetSpriteEnable(spritesel,0)
	SetSpriteRect(item, 0, 0, 222, 26)
	listitem=SpriteList_GetListItem(uploadlist, index+1)
	local spriteunsel1=FindChildSprite(listitem,"unselect")
	local spritesel1=FindChildSprite(listitem,"select")
	SetSpriteVisible(spriteunsel1,0)
	SetSpriteEnable(spriteunsel1,0)
	SetSpriteVisible(spritesel1,1)
	SetSpriteEnable(spritesel1,1)
	SetSpriteRect(listitem, 0, 0, 222, 43)
	SpriteList_Adjust(uploadlist)
	listitem=FindChildSprite(listitem,"command-button")
	SetSpriteFocus(listitem)
			if list_y >= 185 then
			SpriteScrollBar_Adjust(uploadlist)
			SetSpriteRect(uploadlist,list_x, list_y2-26,list_w, list_h)
			ChangeScrollPositon(sprite,"down")
			end
	
	elseif keyCode==ApKeyCode_Up and index>=1 then
	
	WriteLogs("index="..index)
	SetSpriteVisible(spriteunsel,1)
	SetSpriteEnable(spriteunsel,1)
	SetSpriteVisible(spritesel,0)
	SetSpriteEnable(spritesel,0)
	SetSpriteRect(item, 0, 0, 222, 26)
	listitem=SpriteList_GetListItem(uploadlist, index-1)
	local spriteunsel1=FindChildSprite(listitem,"unselect")
	local spritesel1=FindChildSprite(listitem,"select")
	SetSpriteVisible(spriteunsel1,0)
	SetSpriteEnable(spriteunsel1,0)
	SetSpriteVisible(spritesel1,1)
	SetSpriteEnable(spritesel1,1)
	SetSpriteRect(listitem, 0, 0, 222,43)
	SpriteList_Adjust(uploadlist)
	listitem=FindChildSprite(listitem,"command-button")
	SetSpriteFocus(listitem)
				if list_y <= 10 then
				SpriteScrollBar_Adjust(uploadlist)
				SetSpriteRect(uploadlist,list_x, list_y2+26,list_w, list_h)
				ChangeScrollPositon(sprite,"up")
				end
				
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		WriteLogs("_______________________________________________________________________")
		returnButtonOnSelect(sprite)	
		
	end
	
return 0
	
end
	
--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	WriteLogs("liuchaobing test spriteitem name is "..GetSpriteName(spriteitem))
	WriteLogs("liuchaobing test spriteitem index is "..CurIndex)
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,7,0)
	else
		ScrollBarAdjust(CurIndex + 1,7,1)
	end
end
	
	
	
	
	
