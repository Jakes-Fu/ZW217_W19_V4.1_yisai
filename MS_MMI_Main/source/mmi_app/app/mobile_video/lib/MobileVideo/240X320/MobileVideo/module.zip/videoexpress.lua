﻿--

require "module.setting"
require "module.protocol.clientInit"
require "module.protocol.protocol_login"
require "module.protocol.protocol_home"
require "module.protocol.protocol_videoexpress"
require "module.common.SceneUtils"
require "module.friendsrecommended_detail"
require "module.videoexpress-common"
require "module.common.registerScene"

local MSG_CONTENT_REQUEST = "http://c2.cmvideo.cn/sup/msp/qryMsg.msp?msgId="

function progressOnTick(sprite)
	local l,t,w,h = GetSpriteRect(sprite)
	l = l + 2
	if l >= 0 then
		l = -112
	end
	SetSpriteRect(sprite, l, t, w, h)
	return 1
end

--设置状态信息
function SetStatusText(text)
	local labelStatus1 = registerGetInteger(regCreate, "status1")
	SetSpriteProperty(labelStatus1, "text", text)
end

function bodyBuildChildrenFinished(sprite)
	--local setting = LoadSetting();
	
	local labelStatus1 = FindChildSprite(sprite, "status-forground")
	
	regCreate = registerCreate("videoexpress")
	registerSetInteger(regCreate, "root", sprite)
	registerSetInteger(regCreate, "status1", labelStatus1)
	
	local regSystem = registerCreate("System")
	http = pluginCreate("HttpPipe")
	registerSetInteger(regSystem, "comHttpPipe", http)
	
	SetStatusText("正在连接网络中")
	--连接网络中
	
	local uuid = Cfg.GetUUID();
	if uuid ~= nil and uuid ~= "" then
		WriteLogs("start1")
		RequestLogin(102, uuid )
	else
		WriteLogs("start2")	
		RequestClientInit(101)
	end
	
	return 1
end

function OnPluginEvent(message, param)
	if message == 101 then
		WriteLogs("101")
		local uuid = OnPipeClientInitDecode()
		if uuid then
			WriteLogs("RequestLogin()")
			RequestLogin(102, setting.uuid)
		else
		    WriteLogs("RequestLogin uuid not invalid!")
		end
	elseif message == 102 then
		WriteLogs("102")
		loginInfo, updateInfo = OnPipeLoginDecode()
		if updateInfo and checkUpdate() then 
			return 
		end
		checkLogin()
	elseif message == 103 then
		WriteLogs("103-receive")
		local homeData = HomeNetworkData()
		if homeData then
			--recommendMsgID = "10000023" --test data
			local recommendMsgID = getRecommendMsgID()
			local msgContentRequest = MSG_CONTENT_REQUEST..recommendMsgID
			RequestMessageContent(104, msgContentRequest)
		else
		    WriteLogs("message==103, but homeData not invalid!")
		end
	elseif message == 104 then --获得短信内容
		--弹出提示对话框
		WriteLogs("104----")
		local spriteRoot = registerGetInteger(regCreate, "root")
		local dialogsprite = FindChildSprite(spriteRoot, "dialogInterface")
		--DealMsgContent(false, sceneVideoExpress, sceneVideoExpress, dialogsprite)
		DealMsgContent(true, sceneVideoExpress, sceneVideoExpress, dialogsprite)
	end
	
	-- local regSystem = registerCreate("System");
	-- local srvURL  = CreateRequestURL( "/sup/msp/imagesPacking.msp" );
	
	-- http = registerGetInteger(regSystem, "comHttpPipe");
	-- pluginInvoke(http, "SetPackingUrl", srvURL)
	return 1
end

function checkUpdate()
	if updateInfo then
		if table.maxn(updateInfo) >= 0 then
			if updateInfo[1].url then
				require("module.dialog.useDialog")
				local curScene = GetCurScene()
				local reg = registerCreate("welcome")
				registerSetInteger(reg, "welcomeScene", curScene)
				local pathName = "MODULE:\\welcome.xml"
				if updateInfo[1].flags == "1" then
					setDialogParam("版本升级", "有新版本，是否需要升级!", "BT_OK_CANCEL", pathName,pathName,curScene, 1)
					local dialogScene = CreateSprite("node", curScene)
					LoadSprite(dialogScene, "MODULE:\\dialog.xml")
					return 1 
				elseif updateInfo[1].flags == "2" then
					setDialogParam("版本升级", "有新版本，必须升级!", "BT_OK_CANCEL", pathName,pathName,curScene, 1)
					local dialogScene = CreateSprite("node", curScene)
					LoadSprite(dialogScene, "MODULE:\\dialog.xml")
					return 2
				end
			end
		end
	end
	return false
end

function checkLogin()
	if loginInfo and loginInfo.code == "0" then
		RequestHome(103,loginInfo.defaultDataUrl)
	else
	    WriteLogs("RequestLogin parameters not invalid!")
	end
end

--按退出菜单
function OnSelectBackButton(sprite)
	Exit()
end

--对话框按钮的事件返回
function DialogSpriteEvent(message, params)
	WriteLogs("DialogSpriteEvent="..message)
	if 1001 == message then --0k
		local isOk = writeMsgContent2XML(true)
		--if true == isOk then
			Go2Scene(sceneFriendsRecommended)
		--else
			--Exit() --保存失败，退出程序
		--end
	elseif 1002 == message then --cancel
		writeMsgContent2XML(false)
		--退出客户端
		Exit()
	end
	WriteLogs("DialogSpriteEvent=end")	
end
