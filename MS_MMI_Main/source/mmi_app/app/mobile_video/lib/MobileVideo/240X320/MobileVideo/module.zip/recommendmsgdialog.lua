﻿--

--require "module.dialog"
require "module.dialog.useDialog"
require "module.videoexpress-common"
require "module.common.SceneUtils"
require "module.keyCode.keyCode"
		
local MSG_CONTENT_REQUEST = "http://c2.cmvideo.cn/sup/msp/qryMsg.msp?msgId="
SCENE_DIALOG 		= "dialog"
SCENE_DIALOG_ROOT	= "root"
SHOW_FLAG 				= "show-flag"

function bodyBuildChildrenFinished(sprite)
	WriteLogs("bodyBuildChildrenFinished-start")
	local reg = registerCreate(SCENE_DIALOG)
	registerSetInteger(reg, SCENE_DIALOG_ROOT, sprite)
	registerSetInteger(reg, SHOW_FLAG, 1)
	
	-- global
	
	dialogTitle, message, dialogType, backSceneName, background, observer,backSceneMenu = getDialogParam()	
	backScene	= FindScene(backSceneName)
	resultMessage	= 1000
	createDialog()

	local backSceneSprite	= FindChildSprite(sprite, "back-scene")
	local dialogRootSprite	= FindChildSprite(sprite, "dialog")
	local backgroundScene	= FindScene(background)
	if backgroundScene ~= nil and backgroundScene ~= "" then
		WriteLogs(backgroundScene)
		AddChildSprite(backSceneSprite, backgroundScene)
	end
	--SetSpriteCapture(dialogRootSprite)
	WriteLogs("bodyBuildChildrenFinished-end")
	SetSpriteFocus(FindChildSprite(sprite,"ok-button") )
	--return 1
end

--@function	createDialog
--@brief	创建对话框元素
function createDialog()
	--[[	获取根节点	]]--
	local reg = registerCreate(SCENE_DIALOG)
	local root = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	
	local titleSprite	= FindChildSprite(root, "dialog-title")
	local title2Sprite	= FindChildSprite(root, "dialog-title2")
	local bodySprite	= FindChildSprite(root, "dialog-body")
	local areaSprite	= FindChildSprite(root, "dialog-area")
	local messageSprite	= FindChildSprite(root, "dialog-message")
	local okSprite		= FindChildSprite(root, "ok-button")
	local cancelSprite	= FindChildSprite(root, "cancel-Button")
	
	-- title
	if dialogTitle ~= "" then
		SetSpriteProperty(titleSprite, "text", dialogTitle)
		SetSpriteProperty(title2Sprite, "text", dialogTitle)
	else
		SetSpriteProperty(titleSprite, "text", "提示")
		SetSpriteProperty(title2Sprite, "text", "提示")
	end
	
	local labelHeight, buttonOffset, lableOffset	= 20, 25 ,10
	
	local body_x,   body_y, 	body_w,   body_h 	= GetSpriteRect(bodySprite)
	local message_x,message_y,message_w,message_h 	= GetSpriteRect(messageSprite)
	local area_x,   area_y, 	area_w,   area_h 	= GetSpriteRect(areaSprite)
	local ok_x, 	  ok_y, 	ok_w, 	  ok_h 		= GetSpriteRect(okSprite)
	local cancel_x, cancel_y, cancel_w, cancel_h 	= GetSpriteRect(cancelSprite)
	
	-- message is empty
	if message == "" then
		body_h = body_h - labelHeight
		body_y = body_y + labelHeight
		area_h = area_h - labelHeight
		ok_y   = ok_y   - labelHeight + 5
		cancel_y = cancel_y - labelHeight + 5
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
		SetSpriteRect(areaSprite, area_x, area_y, area_w, area_h)
		SetSpriteRect(okSprite, ok_x, ok_y, ok_w, ok_h)
		SetSpriteRect(cancelSprite, cancel_x, cancel_y, cancel_w, cancel_h)
	else
		SetSpriteProperty(messageSprite, "text", message)
	end
	
	-- button type
	if dialogType == "BT_NULL" then
		body_h = body_h - labelHeight
		body_y = body_y + labelHeight
		area_h = area_h - labelHeight
		message_y = message_y + lableOffset
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
		SetSpriteRect(areaSprite, area_x, area_y, area_w, area_h)
		SetSpriteRect(messageSprite,message_x,message_y,message_w,message_h)
		
		SetSpriteVisible(okSprite, 0)
		SetSpriteVisible(cancelSprite, 0)
		SetSpriteEnable(okSprite, 0)
		SetSpriteEnable(cancelSprite, 0)
	elseif dialogType == "BT_OK" then
		SetSpriteVisible(cancelSprite, 0)
		SetSpriteEnable(cancelSprite, 0)
		ok_x = ok_x + buttonOffset
		SetSpriteRect(okSprite, ok_x, ok_y, ok_w, ok_h)
	end
	
end

function dialogBodyOnTick(sprite)

	local reg 	   = registerCreate(SCENE_DIALOG)
	local root	   = registerGetInteger(reg, SCENE_DIALOG_ROOT)
	local showFlag = registerGetInteger(reg, SHOW_FLAG)	
	
	
	if 1 == showFlag then
		local bodySprite	= FindChildSprite(root, "dialog-body")	
		local length = 10
		local body_x, body_y, body_w, body_h = GetSpriteRect(bodySprite)
		
		if body_y <= 200 then
			body_y = 200
			registerSetInteger(reg, SHOW_FLAG, 0)
		else
			body_y = body_y - length
		end
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
	elseif 2 == showFlag then
		local bodySprite = FindChildSprite(root, "dialog-body")
		local length = 10
		local body_x, body_y, body_w, body_h = GetSpriteRect(bodySprite)
		
		if body_y >= 340 then
			registerSetInteger(reg, SHOW_FLAG, 0)
			skipToScene()
			--SendSpriteEvent(observer, resultMessage)
		else
			body_y = body_y + length
		end
		SetSpriteRect(bodySprite, body_x, body_y, body_w, body_h)
	end
	
	return 1
end

function okButtonOnSelect(sprite)
	WriteLogs("okButtonOnSelect-start")
	local reg = registerCreate(SCENE_DIALOG)
	
	resultMessage = 1001
	-- 刷新背景的情况下可以加动画
	registerSetInteger(reg, SHOW_FLAG, 2)
	
	--保存数据，并且切换到下一个界面
--	removeSmsRecommend()

	--判断是否是客户端未启动状态
	local reg_System = registerCreate("System")
	local isToExit = registerGetString(reg_System, "isToExit", "true")
	if isToExit == "true" then
		registerSetString(reg_System, "isToExit", "")
	end
	require "module.common.reveiveMsgCtrl"		
	MoveMsg()
	if "true" == GetMessageContentResult() then
		setDialogReturnParam("ok")
		
		if FindScene(sceneReceiveMessage) then
			if backSceneName == sceneReceiveMessage then
				local recommendMsgDlg = FindScene(sceneRecommendMsgDialog)
				local backSceneSprite = FindChildSprite(recommendMsgDlg, "back-scene")
				local backgroundScene = FindScene(background)
				if backSceneSprite ~= 0 and backgroundScene ~= 0 then
					RemoveChildSprite(backSceneSprite, backgroundScene)
					FreeScene(FindScene(sceneReceiveMessage))
				end
			end
		end
		
		local reg_f = registerCreate("friendsrecommended_detail")
		local categoryID = registerGetString(reg_f, "recommendMsgCategoryID")
		if categoryID == "1" or categoryID == "2" or categoryID == "3" or categoryID == "6" then
			SetReturn(sceneReceiveMessage,sceneFriendsRecommended)
			if backSceneName == sceneFriendsRecommended then
				freeDialog()
				GoAndFreeScene(sceneFriendsRecommended)
				return
			else
				Go2Scene(sceneFriendsRecommended)
			end
		elseif categoryID == "5" then						--视频杂志
			local reg_f = registerCreate("friendsrecommended_detail")
			local itemNo = registerGetString(reg_f,"ItemNo")
			local listNo = registerGetString(reg_f,"ListNo")
			registerLoad(reg, "MODULE:\\videoexpress\\categoryID"..listNo..".xml")
			local name = FindValue(reg,"item"..itemNo,"ChannelName")
			local magazineItemName = FindValue(reg,"item"..itemNo,"magazineItemName")
			local urlpath = FindValue(reg,"item"..itemNo,"UrlPath")			
			if urlpath then	
				WriteLogs("urlpath===>"..urlpath)
				local curRoot = FindScene(backSceneName)
				local loadarea = FindChildSprite(curRoot, "loadarea")
				require("module.protocol.protocol_magazine")
				local reg_maga = registerCreate("magazine")
				registerSetString(reg_maga, "magazinename_new", name)
				registerSetString(reg_maga, "magazinename", magazineItemName)
				SetReturn(sceneReceiveMessage,sceneMagazine)
				RequestMagazine(108, urlpath)
			end
		elseif categoryID == "4" then 						--专题消息			
			GoAndFreeScene(sceneReceiveThird)
		end
	else
		setDialogReturnParam("cancel")
		if sceneWelcome == backSceneName then
			Exit()
		else
			Go2Scene(backSceneName)
		end
	end
	freeDialog()
	WriteLogs("okButtonOnSelect-end")
end

function cancelButtonOnSelect(sprite)
	WriteLogs("cancelButtonOnSelect-start")
	local reg = registerCreate(SCENE_DIALOG)
	setDialogReturnParam("cancel")
	resultMessage = 1002
	require "module.common.registerScene"
	-- 刷新背景的情况下可以加动画
	registerSetInteger(reg, SHOW_FLAG, 2)
	
	
	--返回到前一个界面
--	removeSmsRecommend()
	if "true" == GetMessageContentResult() then
--		writeMsgContent2XML(false)
	end
	--判断是否是客户端未启动状态
	local reg_System = registerCreate("System")
	local isToExit = registerGetString(reg_System, "isToExit")
	if isToExit == "true" then
		if backSceneName == sceneWelcome then
			Go2Scene(backSceneName,1)
		else
			Go2Scene(backSceneName)
		end
	else
		if FindScene(sceneReceiveMessage) then
			if backSceneName == sceneReceiveMessage then
				local recommendMsgDlg = FindScene(sceneRecommendMsgDialog)
				local backSceneSprite	= FindChildSprite(recommendMsgDlg, "back-scene")
				local backgroundScene	= FindScene(background)
				if backSceneSprite ~= 0 and backgroundScene ~= 0 then
					RemoveChildSprite(backSceneSprite, backgroundScene)
				end
			end
			FreeScene(FindScene(sceneReceiveMessage))
		end
		
		if backSceneName == sceneWelcome then
			Go2Scene(backSceneName,1)
		else
			Go2Scene(backSceneName)
		end
	end
	local reg_f = registerCreate("friendsrecommended_detail")
	registerSetString(reg_f, "type", "")
	SetTimer(1, 100, "CancelProc")
	WriteLogs("cancelButtonOnSelect-end")
end

function skipToScene()
	--local programInfoSprite = CreateSprite()

	if backScene ~= nil and backScene ~= "" then
		if  backSceneMenu == 1  then -- 不需要菜单
			Go2Scene(backScene,1)
		else
			Go2Scene(backScene)
		end
	end
end

function bodyOnPluginEvent(message, param)
	--处理服务器返回的信息，并跳出对话框提示用户，点OK跳转到好友推荐界面friendsrecommended_detail
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if message == 101 then		
--		local spriteRoot = registerGetInteger(regCreate, "root")
--		local dialogsprite = FindChildSprite(spriteRoot, "dialogInterface")
--		DealMsgContent("", "")
--		--FreeFunction()
		require "module.common.SceneUtils"
		require "module.common.registerScene"
		exitLoading()
		GoAndFreeScene(sceneReceiveThird)
--	elseif message == 108 then	
--		require("module.protocol.protocol_magazine")
--		local json = MagazineNetworkData()
--		exitLoading()
--		if json ~= nil and json ~= "" then
--			SetReturn(sceneReceiveMessage,sceneMagazine)
--			Go2Scene(sceneMagazine)
--		else
--			require("module.dialog.useDialog")
--			setDialogParam("提示", "服务器返回数据错误", "BT_OK", backSceneName, backSceneName, nil)
--			Go2Scene(sceneDialog)
--		end
	elseif	MSG_SMS_ID == message then	
		WriteLogs("czj==>>msgDialog Deal")	
		require("module.common.registerScene")	
		DealMsgContent(sceneRecommendMsgDialog, sceneRecommendMsgDialog)
	end
end

function FindValue(reg,itemNo,categoryName)
	local data = registerGetString(reg,itemNo)
	local i,j = string.find(data,"{"..categoryName.."}")
	if j then 
		i = string.find(data,"{",j+1)
		j = string.find(data,"}",j+1)
		if j == i+1 then 
			return 0
		else
			return string.sub(data,i+1,j-1)
		end
	else
		return 0
	end
end

function CancelProc()
	require "module.dialog.useDialog"	
	require "module.common.registerScene"
	require "module.common.SceneUtils"
	WriteLogs("信息已存入收件箱")
	local reg_System = registerCreate("System")
	local isToExit = registerGetString(reg_System, "isToExit", "true")
	if isToExit == "true" and AppPassiveStart() then
		setDialogParam("提示", "信息已存入收件箱,3秒后退出", "BT_OK",backSceneName, backSceneName,nil)
		Go2Scene(sceneDialog,1)
		SetTimer(1, 3000,"exitProc")			
	else
		if backSceneName == sceneWelcome then
			setDialogParam("提示", "信息已存入收件箱", "BT_NULL",backSceneName, backSceneName,nil)
			Go2Scene(sceneDialog,1)
			local reg_System = registerCreate("System")
			registerSetString(reg_System, "isToExit", "")
			SetTimer(1, 1000,"Autojump")
		else
			setDialogParam("提示", "信息已存入收件箱", "BT_OK",backSceneName, backSceneName,nil)
			Go2Scene(sceneDialog)
			freeDialog()
		end
	end
end

function gotohome()
	require "module.common.registerScene"
	require "module.common.SceneUtils"
	require "module.setting"
	freeDialog()
	local welcomeS = FindScene(sceneWelcome)
	FreeSprite(welcomeS)
	welcomeS = CreateSprite()
	LoadSprite( welcomeS, Cfg.GetWelcome() )
	SetCurScene( welcomeS )
	local regHandle = registerCreate("SCMngr")
	registerSetString(regHandle, "MODULE:\\welcome.xml", string.format("%d", welcomeS))
	local regHandle_r = registerCreate("SCMngr_handle")
	registerSetString(regHandle_r, string.format("%d", welcomeS), "MODULE:\\welcome.xml")
end

function exitProc()
	Exit()
end

function OnMsgDialogSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		WriteLogs("request,start")
		requestMsgContent()
	end
	return 1
end

function DialogMsgKeyUp(sprite, keyCode)
	WriteLogs("DialogMsgKeyUp")
	WriteLogs("@@@@@KeyCode="..keyCode)
	local spriteName=GetSpriteName(sprite)
	WriteLogs("@@@@@spriteName="..spriteName)
	if keyCode == ApKeyCode_Enter then
		return 0
	end
	--[[	获取根节点	]]--
	local reg = registerCreate("dialog")
	local root=registerGetInteger(reg,"root")
	if keyCode == ApKeyCode_Right and spriteName=="ok-button" then
		local cancelButtonSprite = FindChildSprite(root,"cancel-Button")
		SetSpriteFocus(cancelButtonSprite)
	elseif keyCode == ApKeyCode_Left and spriteName=="cancel-Button" then
		local okButtonSprite = FindChildSprite(root,"ok-button")
		SetSpriteFocus(okButtonSprite)
	end
end

function freeDialog()
	--free对话框
	local recommendMsgDlg = FindScene(sceneRecommendMsgDialog)
	local backSceneSprite	= FindChildSprite(recommendMsgDlg, "back-scene")
	local backgroundScene	= FindScene(background)
	if backSceneSprite ~= 0 and backgroundScene ~= 0 then
		RemoveChildSprite(backSceneSprite, backgroundScene)
	end
	FreeScene(recommendMsgDlg)
end