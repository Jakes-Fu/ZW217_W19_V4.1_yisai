require "module.Loading.useLoading"
require "module.protocol.protocol_navigationdetail"
require "module.protocol.protocol_infolabel"
require "module.protocol.protocol_infovolume"
require "module.protocol.protocol_infolist"
require "module.common.registerScene"
require "module.common.SceneUtils"

navigation_ButtonWidth = 100
navigation_ButtonHeight = 20
-- BUTTON_WIDTH = 100
-- BUTTON_HEIGHT = 20
NOT_SORT_BROWSE_COUNT = 18
local NOT_SORT_BROWSE_PAGE_COUNT = 0 		--����������ܹ�ҳ��
local NOT_SORT_BROWSE_PAGE_CUR = 0  		 --�����������ǰ����ҳ,Ĭ��ѡ��Ϊ��һҳ
local NOT_SORT_BROWSE_ROW = 9	 	  		 --�����������
local NOT_SORT_BROWSE_COL = 2  			--�����������

function bodyBuildChildrenFinished(sprite)
	regCreate = registerCreate("navigationdetail")
	registerSetInteger(regCreate, "root", sprite)
	--http = pluginCreate("HttpPipe", "myhttp1")
		
	--��������������
	createNavigationDetailData()
	--��̬������Ŀ��ǩ
	createColumnLabel()
	--��������Ԫ��
	createNotSortBrowse()
	--��ҳ�İ�ť�Ƿ���ò���
	arrowHasVisible()
	return 1
end

--��̬������Ŀ��ǩ
function createColumnLabel()
	--[[  ��ȡ���ڵ� ]]--
	local root = registerGetInteger(regCreate, "root")
	
	--[[  ���ݻ��� ]]--
	local sprite = FindChildSprite(root , "info-content-caption")
	SetSpriteProperty(sprite,"text",infoContentCaption)	
end

--��̬���������������
function createNotSortBrowse()
	local sprite = registerGetInteger(regCreate, "root")
	
	--��ʾ�������ָ��Ƶ������
	local spriteChannelNameList = FindChildSprite(sprite, "channel-name-label")
	local channelName = registerGetString(regCreate, "browseChannelName")
	if (nil ~= channelName) then
		SetSpriteProperty(spriteChannelNameList,"text",channelName)	
	end
	
	if 0 ~= #notSortBrowseDataArray then		
		--��ʾ�������ָ��Ƶ������
		local spriteList = FindChildSprite(sprite, "not-sort-browse-list")
		--specialSortBrowseArray2 = {"���﷼","��һƽ","������","����Ԫ","Ԭ����","������","������","��վ��","����","Ԫһ","����","��һƽ","������","����Ԫ","Ԭ����","������","������","��վ��","����"}
		
		local n = #notSortBrowseDataArray	
		for i=0, n do
			local SortBrowseSprite = CreateSprite("listitem")
			LoadSprite(SortBrowseSprite, "MODULE:\\navigationlist.xml")
			SetSpriteRect(SortBrowseSprite, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			--��̬������ť����������ѡ�кͷ�ѡ������
			local spriteButton = FindChildSprite(SortBrowseSprite, "buttonChangeName")
			--SetSpriteProperty(spriteButton, "name", string.format("not-SortBrowse-button-%d", i))
			SetSpriteProperty(spriteButton, "OnSelect", "OnSelectFromNotSortBrowseButton")
			SetSpriteRect(spriteButton, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			local spriteImageNormal = FindChildSprite(SortBrowseSprite, "buttonNormal")
			SetSpriteRect(spriteImageNormal, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			local spriteImageForcus = FindChildSprite(SortBrowseSprite, "buttonFocus")
			SetSpriteRect(spriteImageForcus, 0, 0, navigation_ButtonWidth, navigation_ButtonHeight)
			
			--��̬������ť������Ϣ
			if nil ~= notSortBrowseDataArray[i].contentName then
				local spriteLabel = FindChildSprite(SortBrowseSprite, "navigationlist-label")
				SetSpriteProperty(spriteLabel, "text", notSortBrowseDataArray[i].contentName)
				SetSpriteRect(spriteLabel, GetSpriteRect(SortBrowseSprite))
			end
			
			AddChildSprite(spriteList, SortBrowseSprite)
			SpriteList_AddListItem(spriteList, SortBrowseSprite)		
		end	
		SpriteList_Adjust(spriteList)
	end
end

function OnSelectFromNotSortBrowseButton(sprite)
	SetSpriteFocus(sprite)
	local name = GetSpriteName(sprite)
	if name == "buttonChangeName" then
		--SetReturn(sceneNavigation, scenePrograminfo_label)
		--Go2Scene(scenePrograminfo_label)
		
		local nodeLoading = FindChildSprite(GetRootSprite(sprite), "loadarea")
		enterLoading(nodeLoading)		
		local spriteListItem = GetSpriteParent(sprite)
		local nSelNotSortBrowseIndex = SpriteListItem_GetIndex(spriteListItem)
		if notSortBrowseDataArray[nSelNotSortBrowseIndex].category == "1" then
			RequestVolume(102, notSortBrowseDataArray[nSelNotSortBrowseIndex].urlPath)
		else
			if notSortBrowseDataArray[nSelNotSortBrowseIndex].formType == "1" then
				Requestlabel(101, notSortBrowseDataArray[nSelNotSortBrowseIndex].urlPath)
			elseif notSortBrowseDataArray[nSelNotSortBrowseIndex].formType == "2" then
				RequestList(103, notSortBrowseDataArray[nSelNotSortBrowseIndex].urlPath)
			end
		end
	end
end

function bodyOnPluginEvent(message, param)
	require "module.videoexpress-common"
	if message == 101 then
		--test data
		exitLoading()
		SetReturn(sceneNavigationDetail, scenePrograminfo_label)
		Go2Scene(scenePrograminfo_label)
	elseif message == 102 then
		--test data
		exitLoading()
		SetReturn(sceneNavigationDetail, scenePrograminfo_volume)
		GoAndFreeScene(scenePrograminfo_volume)
	elseif message == 103 then
		exitLoading()
		SetReturn(sceneNavigationDetail, scenePrograminfo_list)
		GoAndFreeScene(scenePrograminfo_list)
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneNavigationDetail, sceneNavigationDetail)
	end
	
end

function createNavigationDetailData()
	--fileName = "MODULE:\\cache\\36e6ca770c9030d9dfbf2c97fe7ed8c4.txt"
	--local json = jsonLoadFile(fileName)
	local json = OnNavigationDetailDecode()
	--���������صķ����������
	notSortBrowseDataArray = {}	
	if (json.category ~= nil) then
		local cotegoryCount = table.maxn(json.category)
		for i=0, cotegoryCount do	
			notSortBrowseDataArray[i] = {
				contentId  	 	= json.category[i].contentId,
				contentName 	= json.category[i].contentName,
				category		= json.category[i].category,
				formType		= json.category[i].formType,
				displayType		= json.category[i].displayType,
				urlPath			= json.category[i].urlPath,
			}			
		end
		if 0 ~= cotegoryCount then
			NOT_SORT_BROWSE_PAGE_COUNT = (cotegoryCount / NOT_SORT_BROWSE_COUNT)
			NOT_SORT_BROWSE_PAGE_COUNT = math.floor(NOT_SORT_BROWSE_PAGE_COUNT)
		end
	-- if cotegoryCount % NOT_SORT_BROWSE_COUNT ~= 0 then 
		-- NOT_SORT_BROWSE_PAGE_COUNT = NOT_SORT_BROWSE_PAGE_COUNT + 1
	-- end
	end

	if (json.path ~= nil) then
		infoContentCaption = json.path
	end
end

--�������������ҳ��ť
function btnNotSortBrowseLeftOnSelect()
	if NOT_SORT_BROWSE_PAGE_CUR > 0 then
		NOT_SORT_BROWSE_PAGE_CUR = NOT_SORT_BROWSE_PAGE_CUR - 1
		refurbishNotSortBrowseList()
	end
end

--������������ҷ�ҳ��ť
function btnNotSortBrowseRightOnSelect()
	if NOT_SORT_BROWSE_PAGE_CUR < NOT_SORT_BROWSE_PAGE_COUNT then
		NOT_SORT_BROWSE_PAGE_CUR = NOT_SORT_BROWSE_PAGE_CUR + 1
		refurbishNotSortBrowseList()
	end
end

function refurbishNotSortBrowseList()
	arrowHasVisible()
	local root = registerGetInteger(regCreate, "root")
	local groupbtnsSprite = FindChildSprite(root,"not-sort-browse-list")

	local count = NOT_SORT_BROWSE_PAGE_CUR * NOT_SORT_BROWSE_ROW * NOT_SORT_BROWSE_COL
	SpriteList_SetStartItem(groupbtnsSprite, count)

end

function arrowHasVisible()
	local root = registerGetInteger(regCreate, "root")
	local leftVisible = FindChildSprite(root,"not-sort-browse-left-visible")
	local leftDisVisible = FindChildSprite(root,"not-sort-browse-left-disvisible")
	local rightVisible = FindChildSprite(root,"not-sort-browse-right-visible")
	local rightDisVisible = FindChildSprite(root,"not-sort-browse-right-disvisible")
	if 0 == NOT_SORT_BROWSE_PAGE_COUNT then
		SetSpriteVisible(leftVisible, 0)
		SetSpriteVisible(leftDisVisible, 1)
		SetSpriteVisible(rightVisible, 0)
		SetSpriteVisible(rightDisVisible, 1)
	elseif NOT_SORT_BROWSE_PAGE_CUR == NOT_SORT_BROWSE_PAGE_COUNT then
		SetSpriteVisible(leftVisible, 1)
		SetSpriteVisible(leftDisVisible, 0)
		SetSpriteVisible(rightVisible, 0)
		SetSpriteVisible(rightDisVisible, 1)
	elseif NOT_SORT_BROWSE_PAGE_CUR ~= NOT_SORT_BROWSE_PAGE_COUNT then
		if 0 == NOT_SORT_BROWSE_PAGE_CUR then
			SetSpriteVisible(leftVisible, 0)
			SetSpriteVisible(leftDisVisible, 1)
		else
			SetSpriteVisible(leftVisible, 1)
			SetSpriteVisible(leftDisVisible, 0)
		end
		SetSpriteVisible(rightVisible, 1)
		SetSpriteVisible(rightDisVisible, 0)
	 end
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	end
end