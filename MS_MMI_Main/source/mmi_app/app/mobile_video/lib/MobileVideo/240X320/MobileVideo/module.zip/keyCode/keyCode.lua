ApKeyCode_Null	=	0
ApKeyCode_F1	=	1
ApKeyCode_F2	=	2
ApKeyCode_Enter	=	3
ApKeyCode_Cancel	=	4

ApKeyCode_Dial	=	5
ApKeyCode_Hangup	=	6

ApKeyCode_Left	=	7
ApKeyCode_Right	=	8
ApKeyCode_Up	=	9
ApKeyCode_Down	=	10

ApKeyCode_Char0	=	11
ApKeyCode_Char1	=	12
ApKeyCode_Char2	=	13
ApKeyCode_Char3	=	14
ApKeyCode_Char4	=	15
ApKeyCode_Char5	=	16
ApKeyCode_Char6	=	17
ApKeyCode_Char7	=	18
ApKeyCode_Char8	=	19
ApKeyCode_Char9	=	20

ApKeyCode_CharA	=	21
ApKeyCode_CharB	=	22

ApKeyCode_VolumeUp	=	23
ApKeyCode_VolumeDown	=	24
ApKeyExitApp	=	25
	