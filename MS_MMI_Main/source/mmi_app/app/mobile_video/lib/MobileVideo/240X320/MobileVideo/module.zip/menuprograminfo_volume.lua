﻿--@module menuprograminfo_volume
--@note 单节目详情
--@author cuiyizhou
--@date 2010/05/28
require "module.Loading.useLoading"
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.keyCode.keyCode"
keyQuickLauncherBar = "QuickLauncherBar";
function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("menuprograminfo_volume")   
	registerSetInteger(reg, "root", sprite)
--[[-----------------------------------------修改人：yaoxiangyin 修改时间：2010.08.13-----------------------------------------------]]--	
	local menuvolumeFocusReg=registerCreate("menuvolumeLastFocus")
	
	local defaultFocusButton
	WriteLogs("@@@@@@@@@@@$$$$$$"..registerGetString(menuvolumeFocusReg,"menuvolumeFocus"))
	if registerGetString(menuvolumeFocusReg,"menuvolumeFocus")~="" then
		defaultFocusButton=FindChildSprite(SpriteList_GetListItem(FindChildSprite(sprite,"menuprograminfo"),3),registerGetString(menuvolumeFocusReg,"menuvolumeFocus"))
	else
		defaultFocusButton=FindChildSprite(SpriteList_GetListItem(FindChildSprite(sprite,"menuprograminfo"),3),"button-play")
	end
	registerSetInteger(reg, "lastFocus",defaultFocusButton)
	SetSpriteFocus(defaultFocusButton)
	local playBtn=FindChildSprite(sprite,"button-play")
	saveTouchFocus(playBtn)
---------------------------------------------------------------------------------------------------------------------------------------	
	--[[  创建全局的标志位，控制详细信息面板的移动  ]]--  
	local regflag = registerCreate("buttonclickflag")
	registerSetInteger(regflag, "flag", 0)
	registerSetInteger(regflag, "preflag", 1)
	haveRequest = 0
	open = nil
	
	--[[  获取缓存中的数据  ]]--
	local volumeUrlFileName = registerGetString(reg, "volumeUrlFileName")
	json = jsonLoadFile(volumeUrlFileName)
	if json then
		loadJsonData()
		--[[  根据json中数据判断是否需要显示上一节目或者下一节目]]--
		local reg_s = registerCreate("system")
		local pageflag = registerGetInteger(reg_s,"page-flag")
		if pageflag and pageflag == 1  then
			registerSetInteger(reg_s,"page-flag",0)	
			local backbtn = FindChildSprite(sprite,"button-backprogram")	
			local nextbtn = FindChildSprite(sprite,"button-nextprogram")
			SetSpriteVisible(backbtn ,0)
			SetSpriteEnable(backbtn ,0)		
			SetSpriteVisible(nextbtn ,0)
			SetSpriteEnable(nextbtn ,0)	
		else
			if json.prevId then
			else
				local backbtn = FindChildSprite(sprite,"button-backprogram")
				SetSpriteVisible(backbtn ,0)
				SetSpriteEnable(backbtn ,0)
			end
			if json.nextId then
			else
				local nextbtn = FindChildSprite(sprite,"button-nextprogram")
				SetSpriteVisible(nextbtn ,0)
				SetSpriteEnable(nextbtn ,0)
			end			
		end
	end
	return 1
end

--@function OnSpriteEvent
--@tag-name body
--@tag-action sprite:OnSpriteEvent 
--@brief 响应消息
function OnSpriteEvent(message, params)
	require "module.common.commonMsg"
	require "module.videoexpress-common"
	
	if message == MSG_ACTIVATE then
		local reg = registerCreate("menuprograminfo_volume")   
		local volumeUrlFileName = registerGetString(reg, "volumeUrlFileName")
		json = jsonLoadFile(volumeUrlFileName)

		if json.playUrl and open == nil and requested == nil then
			requested = 0
			local playurl = json.playUrl
			require "module.protocol.protocol_videoloading"
			require "module.menuprograminfo"
			local reg_p = registerCreate("product")
			registerSetString(reg_p,"playurl",playurl)
			registerSetString(reg_p,"contentid",json.contentId)
			--RequestVideo(108, playurl, GetProgramInfoUrlPath(), json.contentName ,"demand")
		elseif open ~= nil then
			--require "module.protocol.protocol_videoloading"
			--local json_v = OnVideoDecode()
			--if json_v.url and json_v.url ~= "" then
			--	local reg_v = registerCreate("video")
			--	local MediapalyPlugin = registerGetInteger(reg_v, "MediapalyPlugin")
			--	open = pluginInvoke(MediapalyPlugin, "Open", json_v.url)
			--	if open == 1 then
			--		--require "module.common.DownloadUpload"
			--		--PauseUploadTask()
			--		registerSetInteger(reg_v, "MediapalyPlugin", MediapalyPlugin)
			--		pluginInvoke(MediapalyPlugin, "Show",0)
			--	else
			--		registerSetString(reg_v, "OpenStatus", "连接服务器失败")
			--	end
			--else
			--	registerSetString(reg_v, "OpenStatus", "连接服务器失败")
			--end
		end
		--local reg = registerCreate("menuprograminfo_volume")
		--local rootSprite = registerGetInteger(reg, "root")
		--PlaySprite = FindChildSprite(rootSprite, "button-play")
		--SetSpriteEnable(PlaySprite, 0)
		--SetTimer(3, 3000,"OnTimer")
	elseif message == MSG_MINIMIZED then
		local recommandSprite = FindChildSprite(GetCurScene(), "button-recommand")
        if recommandSprite ~= 0 then
            SetSpriteCapture(recommandSprite)
        end
        local addrlistSprite = FindChildSprite(GetCurScene(), "addrlist") 
        if addrlistSprite ~= 0 then
            SetSpriteCapture(addrlistSprite)
        end

		
	--[[  收藏事件  ]]--
	elseif message == MSG_ADD_FAV then --add my fav
		require("module.protocol.protocol_addmyfav")
		require("module.menuprograminfo")
		local reg = registerCreate("menuprograminfo_volume")
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
		local curVideoInfo = json
		local urlPath = GetProgramInfoUrlPath()
		urlPath = string.gsub(urlPath,"&","|")

		local playUrl = curVideoInfo.playUrl
		local pos = string.find(playUrl,"nodeId",0)
		if pos then
			local nodeId = string.sub(playUrl,pos+7)
			RequestAddMyfav(110, 1, nodeId, curVideoInfo.contentId, urlPath)
		end
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		if MediapalyPlugin ~= 0 then
			pluginInvoke(MediapalyPlugin, "Stop")
			pluginInvoke(MediapalyPlugin, "Show" , 0)
		end
		FreeScene(GetCurScene())
	elseif message == MSG_SMS then
		requestMsgContent()
	elseif message == 1001 then
		if dailFail and dailFail == 1 then
			Exit()
		end
	end
	return 1
end

--@function showDetailButtonOnSelect
--@tag-name video-bottom
--@tag-action button:OnSelect 
--@brief 控制详情显示区域的大小
function showDetailButtonOnSelect(sprite)
	local regflag = registerCreate("buttonclickflag")
	local preflag = registerGetInteger(regflag,"preflag")
	if preflag == 1 then
		registerSetInteger(regflag, "flag" ,-1)
		local normal = FindChildSprite(sprite,"img_btnNormal")
		SetSpriteProperty(normal,"src","file://image//menuprograminfo//bt_gd4.png")
		local focus = FindChildSprite(sprite,"img_btnFocus")
		SetSpriteProperty(focus,"src","file://image//menuprograminfo//bt_gd2.png")
		SetFourButtonsEnable(0)
		SetSpriteFocus(sprite)
		saveTouchFocus(sprite)
	else
		registerSetInteger(regflag, "flag" ,1)
		local normal = FindChildSprite(sprite,"img_btnNormal")
		SetSpriteProperty(normal,"src","file://image//menuprograminfo//bt_gd3.png")
		local focus = FindChildSprite(sprite,"img_btnFocus")
		SetSpriteProperty(focus,"src","file://image//menuprograminfo//bt_gd.png")
		SetFourButtonsEnable(1)
		local playBtn=FindChildSprite(GetCurScene(),"button-play")
		SetSpriteFocus(playBtn)
		saveTouchFocus(playBtn)
	end
--[[--------------------------------------------------------------------------------------]]--	
	--if registerGetInteger(reg, "firstFlag")==1 then
		
		--SetSpriteFocus(registerGetInteger(reg,"lastFocus"))
		--registerSetInteger(reg,"firstFlag",0)
	--else
		--local menuvolumeFocusReg=registerCreate("menuvolumeLastFocus")
		--SetSpriteFocus(registerGetInteger(menuvolumeFocusReg,"menuvolumeFocusSprite"))
	--end
----------------------------------------------------------------------------------------------------
end

--@function backButtonOnSelect
--@tag-name button-backprogram
--@tag-action button:OnSelect 
--@brief 上一节目
function backButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_volume")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	if nil ~= json then
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		require "module.menuprograminfo"
		--换节目也要将播放器stop
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		if MediapalyPlugin ~= 0 then
			pluginInvoke(MediapalyPlugin, "Stop")
		end
		--[[  这里应该动态获取点击按钮的具体url  ]]--
		if json.prevId[0].category == "1" then
			local volumeurl = json.prevId[0].urlPath
			require "module.protocol.protocol_infovolume"
			RequestVolume(109, volumeurl)
			--[[ sava urlPath ]]--
			SetProgramInfoUrlPath(volumeurl)
--[[----------------------------修改人：yaoxiangyin 修改时间：2010.09.01-----------------------------]]--
			local defaultFocus = FindChildSprite(root,"button-play")
			SetSpriteFocus(defaultFocus)
---------------------------------------------------------------------------------------------------------
		elseif json.prevId[0].category == "5" then
			if json.prevId[0].displayType == "5" then
				local listurl = json.prevId[0].urlPath
				require "module.protocol.protocol_infolist"
				RequestList(112, listurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(listurl)
			elseif json.prevId[0].displayType == "1" then
				local labelurl = json.prevId[0].urlPath
				require "module.protocol.protocol_infolabel"
				Requestlabel(111, labelurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(labelurl)
			end
		end
	end
end

--@function nextButtonOnSelect
--@tag-name button-nextprogram
--@tag-action button:OnSelect 
--@brief 下一节目
function nextButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_volume")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	if nil ~= json then
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		require "module.menuprograminfo"
		--换节目也要将播放器stop
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		if MediapalyPlugin ~= 0 then
			pluginInvoke(MediapalyPlugin, "Stop")
		end
		--[[  这里应该动态获取点击按钮的具体url  ]]--
		if json.nextId[0].category == "1" then
			local volumeurl = json.nextId[0].urlPath
			require "module.protocol.protocol_infovolume"
			RequestVolume(109, volumeurl)
			--[[ sava urlPath ]]--
			SetProgramInfoUrlPath(volumeurl)
--[[----------------------------修改人：yaoxiangyin 修改时间：2010.09.01-----------------------------]]--
			local defaultFocus = FindChildSprite(root,"button-play")
			SetSpriteFocus(defaultFocus)
---------------------------------------------------------------------------------------------------------
		elseif json.nextId[0].category == "5" then
			if json.nextId[0].displayType == "5" then
				local listurl = json.nextId[0].urlPath
				require "module.protocol.protocol_infolist"
				RequestList(112, listurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(listurl)
			elseif json.nextId[0].displayType == "1" then
				local labelurl = json.nextId[0].urlPath
				require "module.protocol.protocol_infolabel"
				Requestlabel(111, labelurl)
				--[[ sava urlPath ]]--
				SetProgramInfoUrlPath(labelurl)
			end
		end
	end
end

--@function introduceOnTick
--@tag-name item-video-introduce
--@tag-action list-item:OnTick
--@brief 实现控制详情显示区域的大小
function introduceOnTick(sprite)
	--[[  获取全局的标志位 ]]--
	regflag = registerCreate("buttonclickflag")
	flag = registerGetInteger(regflag, "flag")
	--[[  flag值为0代表不移动，直接返回 ]]--
	if flag == 0 then
		return 1
	end
	
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_volume")   
	local root = registerGetInteger(reg, "root")
	--[[  寻找目标列表  ]]-- 
	introduceframe = FindChildSprite(root, "distinct-introduce")
	
	if flag == 1 then
		--[[  减小显示区域  ]]-- 
		local l,t,w,h = GetSpriteRect(sprite)
		local ll,tt,ww,hh = GetSpriteRect(introduceframe)
			t = t + 4
			h = h - 4
			tt = tt + 4
			hh = hh - 4
			if t >= 174 then
				--[[  改变区域大小完成，设置falg标志位为0  ]]-- 
				registerSetInteger(regflag, "preflag", flag)
				registerSetInteger(regflag, "flag", "0")
			end
				SetSpriteRect(sprite, l, t, w, h)
				SetSpriteRect(introduceframe, ll, tt, ww, hh)
		return	1
	else
		--[[  增大显示区域  ]]-- 
		local l,t,w,h = GetSpriteRect(sprite)
		local ll,tt,ww,hh = GetSpriteRect(introduceframe)
			t = t - 4
			h = h + 4
			tt = tt - 4
			hh = hh + 4
			if t <= 148 then
				--[[  改变区域大小完成，设置falg标志位为0  ]]-- 
				registerSetInteger(regflag, "preflag", flag)
				registerSetInteger(regflag, "flag", "0")
				SetSpriteProperty(introduceframe,"top",0)
			end
				SetSpriteRect(sprite, l, t, w, h)
				SetSpriteRect(introduceframe, ll, tt, ww, hh)
		return 1
	end
end

--@function voteOnButtonClick
--@tag-name button-vote
--@tag-action button:OnSelect
--@brief 投票按钮，用户可以评价视屏的功能点
function voteOnButtonClick(sprite)
	ReleaseSpriteCapture(sprite)
	SaveDefaultFocus(sprite)
	--[[	这里的全局量是互动模板的读取路径，在messagepannel中用到	]]--
	local messagepannel = registerCreate("messagepannel")
	registerSetString(messagepannel, "loadpath","MODULE:\\vote.xml")
	registerSetString(messagepannel, "returnpath",scenePrograminfo_volume)
	registerSetString(messagepannel, "returnpathname","menuprograminfo_volume")
	registerSetString(messagepannel, "title","您给这条记录的评价是")
	--[[  获得根节点  ]]--
	local reg = registerCreate("menuprograminfo_volume")
	local root = registerGetInteger(reg, "root")
	local myshadow = FindChildSprite(root,"myshadow")
	SetSpriteVisible(myshadow,1)
	local MessagePannel = FindChildSprite(root, "MessagePannel") 
	if MessagePannel == 0 or MessagePannel == nil then 
		MessagePannel = CreateSprite("node", root) 
		SetSpriteProperty(MessagePannel,"name","MessagePannel") 
	end
	SetSpriteCapture(MessagePannel)
	--[[  载入  ]]--  
	local menu = CreateSprite("listitem")
 	LoadSprite(menu,sceneMessagePanel)
	AddChildSprite(MessagePannel, menu)
	local excelentSpriteName = FindChildSprite(menu,"excelent")
	SetSpriteFocus(excelentSpriteName)
end

--@function shareOnButtonClick
--@tag-name button-recommand
--@tag-action button:OnSelect
--@brief 推荐按钮，用户可以把视频分享给好友的功能点
function shareOnButtonClick(sprite)
	ReleaseSpriteCapture(sprite)
	SaveDefaultFocus(sprite)
	--[[	这里的全局量是互动模板的读取路径，在messagepannel中用到	]]--
	local messagepannel = registerCreate("messagepannel")
	registerSetString(messagepannel, "loadpath","MODULE:\\share.xml")
	registerSetString(messagepannel, "returnpath",scenePrograminfo_volume)
	registerSetString(messagepannel, "returnpathname","menuprograminfo_volume")
	registerSetString(messagepannel, "title","推荐好友")
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_volume") 
	local root = registerGetInteger(reg, "root") 
	local myshadow = FindChildSprite(root,"myshadow")
	SetSpriteVisible(myshadow,1)
	local MessagePannel = FindChildSprite(root, "MessagePannel") 
	if MessagePannel == 0 or MessagePannel == nil then 
		MessagePannel = CreateSprite("node", root) 
		SetSpriteProperty(MessagePannel,"name","MessagePannel")
	end
	--[[  载入  ]]--  
	local menu = CreateSprite("listitem")
 	LoadSprite(menu, sceneMessagePanel)
	AddChildSprite(MessagePannel, menu)
	SetSpriteCapture(MessagePannel)
	local sendSpriteName = FindChildSprite(menu,"testEdit")
	SetSpriteFocus(sendSpriteName)
end

--@function playOnButtonClick
--@tag-name button-play
--@tag-action button:OnSelect
--@brief 播放按钮，用户发起播放请求，成功则播放 失败则跳转订购
function playOnButtonClick(sprite)
	ReleaseSpriteCapture(sprite)
	SaveDefaultFocus(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_volume")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	--[[  这里应该动态获取点击按钮的具体url  ]]--
	--从全局读haveRequest 如果是1， 则用NB播放
	--if haveRequest == 0 then
	--	require("module.dialog.useDialog")
	--	exitLoading()
	--	setDialogParam("提示", "正在获取数据，请稍后", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume)
	--	Go2Scene(sceneDialog)
	--else
	--	RequestPlay_NB(scenePrograminfo_volume)
	--end
	require "module.protocol.protocol_videoloading"
	require("module.menuprograminfo")
	RequestVideo(103, json.playUrl, GetProgramInfoUrlPath(), json.contentName ,"demand")
	return 1
end

--@function downloadButtonOnSelect
--@tag-name button-download
--@tag-action button:OnSelect
--@brief 下载按钮，转到正在下载
function downloadButtonOnSelect(sprite)
	ReleaseSpriteCapture(sprite)
	SaveDefaultFocus(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("menuprograminfo_volume")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	
	if nil ~= json then
		--[[  这里应该动态获取点击按钮的具体url  ]]--
		local downUrl = json.downUrl
		if downUrl == "" then
			setDialogParam("提示", "获取下载地址失败", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume)
			Go2Scene(sceneDialog)
		else
			--[[  显示loading场景  ]]--
			enterLoading(loadarea)
			require "module.protocol.protocol_videoloading"
			RequestDownloadVideo(107, downUrl)
		end
	end
	return 1
end

--@function	loadJsonData
--@brief	从缓存中读取数据，完成数据回填，在bodyBuildChildrenFinished中调用
function loadJsonData()
	--[[  获取根节点 ]]--
	local reg = registerCreate("menuprograminfo_volume")   
	local root = registerGetInteger(reg, "root")
	if json then
		--[[  数据回填 ]]--
		if json.path then
			local sprite = FindChildSprite(root , "info-content-caption")
			SetSpriteProperty(sprite,"text",json.path)
		end
		if json.desc then
			local sprite = FindChildSprite(root , "distinct-introduce")
			SetSpriteProperty(sprite,"text",json.desc)
		end
		if json.starLevel then
			local starlevel = FindChildSprite(root , "starlevel")
			local width1 = math.floor(json.starLevel)*16
			local width2 = (json.starLevel - math.floor(json.starLevel))*6
			SetSpriteRect(starlevel,0,0,width1+width2,12)
		end
		if json.contentName then
			local contentName1 = FindChildSprite(root , "item-video-caption1")
			SetSpriteProperty(contentName1,"text",json.contentName)
			local contentName2 = FindChildSprite(root , "item-video-caption2")
			SetSpriteProperty(contentName2,"text",json.contentName)
		end
		if json.time then
			local content = FindChildSprite(root , "item-video-caption3")
			local time = tonumber(json.time)
			if time then
				SetSpriteProperty(content,"text","时长："..math.floor(json.time/60)..":"..((json.time%60<10) and ("0"..json.time%60) or (json.time%60) ))
			else
				SetSpriteProperty(content,"text","时长："..json.time)
			end
		end
		if json.img then
			--[[  设置海报图片内容，这里应该拿网络数据  ]]-- 
			local postpic = FindChildSprite(root, "item-video-caption-postpic")
			SetSpriteProperty(postpic, "src", json.img)
		end
	end
end

function OnSpriteEvent2(message, params)
	if message == 1001 then
		if overwriteflag == 1 then
			require("module.setting")
			local reg = registerCreate("Download")
			local DownloadOverWrite = registerGetString(reg,"DownloadOverWrite")
			if DownloadOverWrite then
				os.remove(DownloadOverWrite)
			end
			registerSetString(reg,"DownloadOverWrite", "")
			local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name,1)
			if result == -1 then
				SetTimer(2, 1000, "OnTimer")
			else
				SetTimer(1, 1000, "OnTimer")
			end
		elseif overwriteflag == 2 then
			require "module.common.DownloadUpload"
			PauseOneDownloadTask(videoData.urls[0].name, "true")
			local result = AppendDownloadQueue(videoData.urls[0].url,videoData.urls[0].name,1)
			SetTimer(1, 1000, "OnTimer")
		end
	end	
end

function OnTimer(idEvent)
	if idEvent == 1 then
		setDialogParam("提示", "已经添加到下载队列", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume, GetCurScene())
		Go2Scene(sceneDialog)
	end
	if idEvent == 3 then
		SetSpriteEnable(PlaySprite, 1)
	end
end

--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	if message == 107 then
		videoData = OnDownloadVideoDecode()
		exitLoading()
		require "module.common.DownloadUpload"
		DownloadProc(videoData,scenePrograminfo_volume)
	elseif message == 103 then
		RequestPlay(scenePrograminfo_volume)
	elseif message == 108 then
		WriteLogs("1088888888888888888888888888888888")
		haveRequest = 1
		--RequestPlay(scenePrograminfo_volume)
		local json = OnVideoDecode()
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		if MediapalyPlugin == 0 then
			MediapalyPlugin = pluginCreate("MediaPlayer")
			pluginInvoke(MediapalyPlugin, "Create", 0, 30, 240, 162)
			pluginInvoke(MediapalyPlugin, "Show",0)
			WriteLogs("2222222222222222222222222222")
		end
		if MediapalyPlugin ==0 then
			registerSetString(reg, "OpenStatus", "创建播放器失败，请重新安装程序")
		else
			if json.url and json.url ~= "" then
				pluginInvoke(MediapalyPlugin, "Stop")
				open = pluginInvoke(MediapalyPlugin, "Open", json.url)
				if open == 1 then
					require "module.common.DownloadUpload"
--					PauseDownloadTask()
					--PauseUploadTask()
					registerSetInteger(reg, "MediapalyPlugin", MediapalyPlugin)
					--pluginInvoke(MediapalyPlugin, "Pause")
					pluginInvoke(MediapalyPlugin, "Show",0)
						WriteLogs("333333333333333333333")
				else
					registerSetString(reg, "OpenStatus", "连接服务器失败")
				end
			else
				registerSetString(reg, "OpenStatus", "连接服务器失败")
			end
		end
		
	elseif message == 109 then
		local volumeData = OnVolumeDecode()
		FreeVolumeFuncs()
		if volumeData then
			exitLoading()
			local volumeSprite = GetCurScene()
			FreeScene(volumeSprite)
			Go2Scene(scenePrograminfo_volume)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeVolumeFuncs()
	elseif message == 110 then
		require("module.dialog.useDialog")		
		reslut, desc = OnPipeAddMyFav()
		exitLoading()
		setDialogParam("提示", desc, "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume, GetCurScene())
		Go2Scene(sceneDialog)
	elseif message == 111 then
		local labelData = OnLabelDecode() 
		if labelData then
			exitLoading()
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			Go2Scene(scenePrograminfo_label)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeLabelFuncs()
	elseif message == 112 then
		local listData = OnListDecode() 
		if listData then
			exitLoading()
			local listSprite = GetCurScene()
			FreeScene(listSprite)
			Go2Scene(scenePrograminfo_list)
		else
			exitLoading()
			require("module.dialog.useDialog")
			setDialogParam("提示", "获取网络数据错误", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume, GetCurScene())
			Go2Scene(sceneDialog)
		end
		FreeListFuncs()
	elseif message > 32768 and message ~= 108+32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume, GetCurScene())
		Go2Scene(sceneDialog)
	elseif message == 32768 then
		require("module.dialog.useDialog")
		setDialogParam("提示", "拨号失败", "BT_OK", scenePrograminfo_volume, scenePrograminfo_volume, GetCurScene())
		dailFail = 1
		Go2Scene(sceneDialog)
	elseif MSG_SMS_ID == message then
		DealMsgContent(scenePrograminfo_volume, scenePrograminfo_volume)
	end
	return 1
end

function SetFourButtonsEnable(isEnable)  -- isEnable 为 整数 0 或 1
	local reg = registerCreate("menuprograminfo_volume")   
	local root = registerGetInteger(reg, "root")
	
	local buttonplay = FindChildSprite(root, "button-play")
	local buttondownload = FindChildSprite(root, "button-download")
	local buttonrecommand = FindChildSprite(root, "button-recommand")
	local buttonvote = FindChildSprite(root, "button-vote")
	
	SetSpriteEnable(buttonplay,isEnable)
	SetSpriteEnable(buttondownload,isEnable)
	SetSpriteEnable(buttonrecommand,isEnable)
	SetSpriteEnable(buttonvote,isEnable)
end


function rootKeyUp(sprite, keyCode)
	WriteLogs("rootKeyUp")
	return 0
end

--[[---------------------------------修改人：yaoxiangyin 修改日期：2010.08.13------------------------------------------]]--
--四个功能按钮：播放，下载，推荐，投票
function menuVolumeButtonItemKeyUp(sprite, keyCode)
	--KeySaveFocus(sprite)
	local reg = registerCreate("menuprograminfo_volume")
	local regflag = registerCreate("buttonclickflag")
	local preflag = registerGetInteger(regflag,"preflag")
	local ItemList={"button-play","button-download","button-recommand","button-vote"}  --存放列表项中的Button名
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	local spriteName=GetSpriteName(sprite)
	
	local ItemName = GetSpriteName(sprite)
	local ItemFocusNum
	
	for i=1,#ItemList do  --寻找当前Button节点名
	  if ItemList[i]==ItemName then
	    ItemFocusNum=i
	  end
	end
	local defaultFocusButton
	local menuprograminfoSprite=GetParentSprite(GetParentSprite(sprite))
	
	local menuvolumeFocusReg=registerCreate("menuvolumeLastFocus")
	registerSetString(menuvolumeFocusReg,"menuvolumeFocus",GetSpriteName(sprite))
	registerSetInteger(menuvolumeFocusReg,"menuvolumeFocusSprite",sprite)
	registerSetNumber(menuvolumeFocusReg,"lastFocusFlag",1)
	--------------------ksw----------------------------------
	local ToMesReg = registerCreate("ToMesReg")
	registerSetInteger(ToMesReg,"ToMesFocus",sprite)
	---------------------------------------------------------
	--------------------------------------------ksw------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	--------------------------------------------ksw-----------------------------------------------
	if GetSpriteName(sprite) and GetSpriteName(sprite)=="button-recommand" then
		local mesCnlRtnReg =registerCreate("mesCnlRtn")
		registerSetInteger(mesCnlRtnReg,"mesCnlRtnFocus",sprite)
	end
	--------------------------------------------------------------------------------------------------
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode== ApKeyCode_Right and ItemList[ItemFocusNum+1]~=nil  then
		defaultFocusButton=FindChildSprite(GetParentSprite(sprite),ItemList[ItemFocusNum+1])
		WriteLogs("@@@@@@@@@@@"..GetSpriteName(defaultFocusButton))
		SetSpriteFocus(defaultFocusButton)
		saveTouchFocus(defaultFocusButton)
		registerSetInteger(reg, "lastFocus", defaultFocusButton)
	elseif keyCode== ApKeyCode_Left and ItemList[ItemFocusNum-1]~=nil  then
		defaultFocusButton=FindChildSprite(GetParentSprite(sprite),ItemList[ItemFocusNum-1])
		SetSpriteFocus(defaultFocusButton)
		saveTouchFocus(defaultFocusButton)
		registerSetInteger(reg, "lastFocus", defaultFocusButton)
	elseif keyCode== ApKeyCode_Up  then
		if 	IsSpriteVisible(FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,1),"button-backprogram"))~=0 then
			defaultFocusButton=FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,1),"button-backprogram")
			SetSpriteFocus(defaultFocusButton)
			saveTouchFocus(defaultFocusButton)
			registerSetInteger(reg, "lastFocus", defaultFocusButton)
		else
			if IsSpriteVisible(FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,1),"button-nextprogram"))~=0 then
			defaultFocusButton=FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,1),"button-nextprogram")
			SetSpriteFocus(defaultFocusButton)
			saveTouchFocus(defaultFocusButton)
			registerSetInteger(reg, "lastFocus", defaultFocusButton)
			end
		end
	elseif keyCode== ApKeyCode_CharB and LoadingFlag() then
			registerSetInteger(reg, "lastFocus", sprite)
			local videoBottomButton=FindChildSprite(GetParentSprite(menuprograminfoSprite),"video-bottom")
			--SetSpriteFocus(videoBottomButton)
			showDetailButtonOnSelect(videoBottomButton)
			--registerSetInteger(reg, "nextFocus",videoBottomButton)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_Enter  then
		if spriteName=="button-play" then
			playOnButtonClick(sprite)
		elseif spriteName=="button-download" then
			downloadButtonOnSelect(sprite)
		elseif spriteName=="button-recommand" then
			shareOnButtonClick(sprite)
		elseif spriteName=="button-vote" then
			voteOnButtonClick(sprite)
		end
	end
end

--节目翻页的两个按钮
function menuVolumeButtonProgramKeyUp(sprite, keyCode)
	--KeySaveFocus(sprite)
	local reg = registerCreate("menuprograminfo_volume")
	
	local regflag = registerCreate("buttonclickflag")
	local preflag = registerGetInteger(regflag,"preflag")
	
	local ItemName = GetSpriteName(sprite)
	local defaultFocusButton
	local menuprograminfoSprite=GetParentSprite(GetParentSprite(sprite))
	
	local menuvolumeFocusReg=registerCreate("menuvolumeLastFocus")
	registerSetString(menuvolumeFocusReg,"menuvolumeFocus",GetSpriteName(sprite))
	--registerSetInteger(menuvolumeFocusReg,"menuvolumeFocusSprite",sprite)
	--registerSetNumber(menuvolumeFocusReg,"lastFocusFlag",1)
	
	--------------------------------------------ksw------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	if keyCode== ApKeyCode_Right and ItemName=="button-backprogram" and IsSpriteVisible(FindChildSprite(GetParentSprite(sprite),"button-nextprogram"))~=0  then
		defaultFocusButton=FindChildSprite(GetParentSprite(sprite),"button-nextprogram")
		SetSpriteFocus(defaultFocusButton)
		saveTouchFocus(defaultFocusButton)
		registerSetInteger(reg, "lastFocus", defaultFocusButton)
	elseif keyCode== ApKeyCode_Left and ItemName=="button-nextprogram" and IsSpriteVisible(FindChildSprite(GetParentSprite(sprite),"button-backprogram"))~=0  then
		defaultFocusButton=FindChildSprite(GetParentSprite(sprite),"button-backprogram")
		SetSpriteFocus(defaultFocusButton)
		saveTouchFocus(defaultFocusButton)
		registerSetInteger(reg, "lastFocus", defaultFocusButton)
	elseif keyCode== ApKeyCode_Down then
		defaultFocusButton=FindChildSprite(SpriteList_GetListItem(menuprograminfoSprite,3),"button-play")
		SetSpriteFocus(defaultFocusButton)
		saveTouchFocus(defaultFocusButton)
		registerSetInteger(reg, "lastFocus", defaultFocusButton)
	elseif keyCode== ApKeyCode_CharB and LoadingFlag() then
		registerSetInteger(reg, "lastFocus", sprite)
		local videoBottomButton=FindChildSprite(GetParentSprite(menuprograminfoSprite),"video-bottom")
		--SetSpriteFocus(videoBottomButton)
		showDetailButtonOnSelect(videoBottomButton)
		--registerSetInteger(reg, "nextFocus",videoBottomButton)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_F2  then
		--KillSpriteFocus(sprite)
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	end
	return 0
end

function downloadButtonOnMouseDown(sprite)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"KeyFlag",0)
	saveTouchFocus(sprite)
	downloadButtonOnSelect(sprite)
end

function shareOnMouseDown(sprite)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"KeyFlag",0)
	saveTouchFocus(sprite)
	shareOnButtonClick(sprite)
end

function voteOnMouseDown(sprite)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"KeyFlag",0)
	saveTouchFocus(sprite)
	voteOnButtonClick(sprite)
end

function showDetailButtonKeyUp(sprite,keyCode)
	--------------------------------------------ksw------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	if keyCode==ApKeyCode_CharB and LoadingFlag() then
		showDetailButtonOnSelect(sprite)
	elseif keyCode==ApKeyCode_F1 then
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetNumber(homeLastFoucsReg,"lastFocusSprite",sprite)
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode==ApKeyCode_F2 then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
----------------------------------------------------------------------------------------------------------------------------





