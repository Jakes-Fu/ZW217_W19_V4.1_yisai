﻿--@module commonScroll
--@note 滚动条滑动统一控制
--@author shenyi,modified by cuiyizhou
--@date 2010/08/06
flag = 0
g_totalheight = 0
g_percentlimit = 0
g_heightlimit = 0
local g_ScrollSprite=nil
function CreateScrollBar(root,listname,totalheight,percentlimit)
	local listsprite = FindChildSprite(root,listname)
	local reg = registerCreate("commonScroll")
	registerSetInteger(reg, "listroot",listsprite)
	local parentframe = GetSpriteParent(listsprite)
	local l,t,w,spriteheight = GetSpriteRect(parentframe)
	local ListScrollSprite = FindChildSprite(root,"List-Scroll")
	if ListScrollSprite ~= 0 then
		SetSpriteEnable(ListScrollSprite,1)
		SetSpriteVisible(ListScrollSprite,1)
		local scroll = FindChildSprite(ListScrollSprite,"scroll")
		SetSpriteProperty(scroll,"pos",0)
		SpriteScrollBar_Adjust(scroll)
		g_totalheight = totalheight
		return
	end
	local ScrollSprite = CreateSprite("node", parentframe)
	SetSpriteName(ScrollSprite,"List-Scroll")
	LoadSprite(ScrollSprite,"MODULE:\\common\\scrollBar.xml")
	local scrollbody = FindChildSprite(ScrollSprite,"scrollbar-body")
	local upArrow = FindChildSprite(ScrollSprite,"scrollbar-upArrow")
	local downArrow = FindChildSprite(ScrollSprite,"scrollbar-downArrow")
	SetSpriteRect(scrollbody,w-13,0,13,spriteheight)
	SetSpriteRect(upArrow,w-13,0,13,13)
	SetSpriteRect(downArrow,w-13,spriteheight-13,13,13)
	scroll = FindChildSprite(ScrollSprite,"scroll")
	SetSpriteRect(scroll,w-13,13,13,spriteheight-26)
	local upArrowbutton = FindChildSprite(ScrollSprite,"upArrowbutton")
	local downArrowbutton = FindChildSprite(ScrollSprite,"downArrowbutton")
	SetSpriteRect(upArrowbutton,w-13,0,13,13)
	SetSpriteRect(downArrowbutton,w-13,spriteheight-13,13,13)
	g_totalheight = totalheight
	g_percentlimit = percentlimit
	g_heightlimit = spriteheight
	g_listname = listname
	g_ScrollSprite=ScrollSprite
	if spriteheight > totalheight then
		local bar = FindChildSprite(ScrollSprite,"splider-image")
		SetSpriteVisible(bar,0)
		return
	end
end

--@function upArrowbuttonOnSelect
--@tag-name scrollbar
--@tag-action button:OnSelect
--@brief 滑动条的向上箭头
function upArrowbuttonOnSelect(sprite)
	local TuchReg=registerCreate("PopMenuHide")
	local ToDigFocus = registerGetInteger(TuchReg,"sencePreFocus")
	WriteLogs("up the name of sencePreFocus=="..GetSpriteName(ToDigFocus))
	SetSpriteFocus(ToDigFocus)
	if g_heightlimit > g_totalheight then
		return
	end
	local pos = SpriteScrollBar_GetPos(scroll)
	SetSpriteProperty(scroll,"pos",(pos-10<=0) and 0 or (pos-10))
	SpriteScrollBar_Adjust(scroll)
	local RootSprite = GetRootSprite(sprite)
	spriteList = FindChildSprite(RootSprite,g_listname)
	local l,t,w,h = GetSpriteRect(spriteList)
	local totalheight = g_totalheight
	if pos-10 >= 0 then
		SetSpriteRect(spriteList,l,4-(pos-10)*(totalheight-g_heightlimit)/g_percentlimit,w,h)
	else
		SetSpriteRect(spriteList,l,4-0*(totalheight-g_heightlimit)/g_percentlimit,w,h)
	end
	ResetFocusPosition(spriteList)
end

function downArrowOnSelect(sprite)
	local TuchReg=registerCreate("PopMenuHide")
	local ToDigFocus = registerGetInteger(TuchReg,"sencePreFocus")
	local preSpriteName=GetSpriteName(ToDigFocus)
	WriteLogs("down the name of sencePreFocus=="..GetSpriteName(ToDigFocus))
	--[[判断列表高是否超出显示区域，没有超出则直接返回，超出则做一定步长的焦点跟进]]--
	if g_heightlimit > g_totalheight then  --没有超出，则返回
		SetSpriteFocus(ToDigFocus)
		WriteLogs("@@@@@@@@@@@do return")
		return
	end
	--超出，则做相应调整
	local pos = SpriteScrollBar_GetPos(scroll)
	SetSpriteProperty(scroll,"pos",(pos+10>=g_percentlimit) and g_percentlimit or (pos+10))
	SpriteScrollBar_Adjust(scroll)
	local RootSprite = GetRootSprite(sprite)
	spriteList = FindChildSprite(RootSprite,g_listname)
	local l,t,w,h = GetSpriteRect(spriteList)
	local totalheight = g_totalheight
	if pos+10 < g_percentlimit then
		SetSpriteRect(spriteList,l,4-(pos+10)*(totalheight-g_heightlimit)/g_percentlimit,w,h)
	else
		SetSpriteRect(spriteList,l,4-g_percentlimit*(totalheight-g_heightlimit)/g_percentlimit,w,h)
	end
	ResetFocusPosition(spriteList)
end

--@function ScrollBarHitTest
--@tag-name scrollbar
--@tag-action button:OnSelect
--@brief 滑动条的向下箭头
function ScrollBarHitTest(sprite,x,y,force)
	if force == nil and flag == 0 then
		return 1
	end
	--[[  鼠标移动过滑块后，按键需要调整屏幕区域 modified by cuiyizhou @10.26  ]]--
	ScrollAdjustFlag = 1
	local pos = y*100/(g_heightlimit-26)
	if pos >= g_percentlimit then
		pos = g_percentlimit
	end
	SetSpriteProperty(sprite,"pos",pos)
	SpriteScrollBar_Adjust(sprite)
	local RootSprite = GetRootSprite(sprite)
	spriteList = FindChildSprite(RootSprite,g_listname)
	local l,t,w,h = GetSpriteRect(spriteList)
	local totalheight = g_totalheight
	if g_totalheight > g_heightlimit then
		SetSpriteRect(spriteList,l,4-pos*(totalheight-g_heightlimit)/g_percentlimit,w,h)
	end
	SpriteScrollBar_Adjust(sprite)
end

--@function	ScrollbarOnMouseUp
--@tag-name	scroll
--@tag-action	scroll:OnMouseUp
--@brief	用于响应滚动条鼠标点击事件
function ScrollbarOnMouseUp(sprite,x,y)
	flag = 0
end

--@function	ScrollbarOnMouseDown
--@tag-name	scroll
--@tag-action	scroll:OnMouseDown
--@brief	用于响应滚动条鼠标点击事件
function ScrollbarOnMouseDown(sprite,x,y)
	flag = 1
end

function SetScrollTotalHeight(totalheight)
	local reg = registerCreate("commonScroll")
	local RootSprite = registerGetInteger(reg, "root")
	spriteList = FindChildSprite(RootSprite,g_listname)
	g_totalheight = totalheight
	SetSpriteProperty(scroll,"pos",0)
	SpriteScrollBar_Adjust(scroll)
	local l,t,w,h = GetSpriteRect(spriteList)
	SetSpriteRect(spriteList,l,4,w,h)
	local parentframe = GetSpriteParent(spriteList)
	local l,t,w,spriteheight = GetSpriteRect(parentframe) 
	local ScrollSprite=g_ScrollSprite
	if spriteheight > totalheight then
		local bar = FindChildSprite(ScrollSprite,"splider-image")
		SetSpriteVisible(bar,0)
	else
		local bar = FindChildSprite(ScrollSprite,"splider-image")
		SetSpriteVisible(bar,1)
	end
end

--@function	HideScrollArea
--@brief	在高级搜索中使用，隐藏指定表 并且重置参数
function HideScrollArea()
	local listsprite = FindChildSprite(GetCurScene(),"List-Scroll")
	if listsprite ~= 0 then
		SetSpriteEnable(listsprite,0)
		SetSpriteVisible(listsprite,0)
	end
end

function KeyAdjust(offset,UpDown)
	local reg = registerCreate("commonScroll")
	local RootSprite = registerGetInteger(reg, "root")	
	if UpDown == "down" then
		local pos = SpriteScrollBar_GetPos(scroll)
		SetSpriteProperty(scroll,"pos",(pos +(g_percentlimit*offset/((g_totalheight-g_heightlimit))) >= g_percentlimit) and g_percentlimit or (pos +(g_percentlimit*offset/((g_totalheight-g_heightlimit)))) )
	elseif UpDown == "up" then
		local pos = SpriteScrollBar_GetPos(scroll)
		SetSpriteProperty(scroll,"pos",(pos -(g_percentlimit*offset/((g_totalheight-g_heightlimit))) <= 0) and 0 or (pos -(g_percentlimit*offset/((g_totalheight-g_heightlimit)))))
	end
	SpriteScrollBar_Adjust(scroll)
end

function ScrollBarAdjust(CurIndex,LineLimit,mode)
	local reg = registerCreate("commonScroll")
	local RootSprite = registerGetInteger(reg, "listroot")
	local itemcount = SpriteList_GetListItemCount(RootSprite)
	if itemcount > LineLimit then
		local scrollpositon = 0
		if mode == 1 then
			scrollpositon = g_percentlimit*(CurIndex - LineLimit)/(itemcount - LineLimit-1)
		else
			scrollpositon = g_percentlimit*(CurIndex)/(itemcount - LineLimit-1)
		end
		if scrollpositon < 0 then
			SetSpriteProperty(scroll,"pos",0)
		elseif scrollpositon > g_percentlimit then
			SetSpriteProperty(scroll,"pos",g_percentlimit)
		else
			SetSpriteProperty(scroll,"pos",scrollpositon)
		end
		SpriteScrollBar_Adjust(scroll)
	end
end

function ResetFocusPosition(spriteList)
	local list_x,list_y,list_w,list_h=GetSpriteRect(spriteList)
	local listName=GetSpriteName(spriteList)
	local listCount=SpriteList_GetListItemCount(spriteList)
	
	--遍历列表，找到离列表上方最近的那个列表项后退出循环
	local nextItem=SpriteList_GetListItem(spriteList,0)
	for i=0,listCount-1 do
		local testItem=SpriteList_GetListItem(spriteList,i)
		local item_x,item_y,item_w,item_h=GetSpriteRect(testItem)
		if list_y+item_y>=0 then
			nextItem=testItem
			break
		end
	end
	local curIndex=SpriteListItem_GetIndex(nextItem)
	WriteLogs("@@@@@@@@@@@curIndex=="..curIndex)
	--根据不同页面做相应调整
	if listName=="favorite-list" then
		require "module.favorite"
		local nextOnSelectButton=FindChildSprite(nextItem,"item-button")
		itemButtonOnSelect(nextOnSelectButton)
	elseif listName=="history-list" then
		require "module.history"
		local nextOnSelectButton=FindChildSprite(nextItem,"item-button")
		itemButtonOnSelect(nextOnSelectButton)
	end
end