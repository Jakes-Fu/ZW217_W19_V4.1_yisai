﻿require "module.loading.useLoading"
function bodyBuildChildrenFinished(sprite)
	local reg_f = registerCreate("friendsrecommended_detail")
	registerSetInteger(reg_f,"root",sprite)
	CreatePage()
	SetSpriteFocus(FindChildSprite(sprite,"button-ok") )	--add by yaoxiangyin
end

--@function FindValue
--@brief 视屏快车数据获取方法
function FindValue(reg,itemNo,categoryName)
	local data = registerGetString(reg,itemNo)
	local i,j = string.find(data,"{"..categoryName.."}")
	if j then 
		i = string.find(data,"{",j+1)
		j = string.find(data,"}",j+1)
		if j == i+1 then 
			return 0
		else
			return string.sub(data,i+1,j-1)
		end
	else
		return 0
	end
end

--@function setIntroduceText(sprite, controlName, text)
--@tag-name controlName:要赋值的控件name; text:文本
--@brief 用于给推荐节目描述
function setIntroduceText(sprite, controlName, text)
	txtArea = FindChildSprite(sprite, controlName)
	--WriteLogs("SetIntroduceText:"..txtArea) --->该处将txtArea替换为text时蓝屏
	SetSpriteProperty(txtArea, "text", text)
	return 1
end

--@function SetIntroduceText(sprite, controlName, text)
--@tag-name controlName:要赋值的控件密码; text:文本
--@brief 用于给推荐节目描述
function btnOnSelect(sprite)
	require "module.common.SceneUtils"
	require "module.common.registerScene"
	require "module.Loading.useLoading"
	local name = GetSpriteName(sprite)
	local reg_f = registerCreate("friendsrecommended_detail")
	local root = registerGetInteger(reg_f,"root")
	local loadarea = FindChildSprite(root,"loadarea")
	if name == "button-ok" then
		if CategoryID and (CategoryID == "6" or CategoryID == "2") then
			require "module.protocol.protocol_infovolume"
			WriteLogs("friendsRecommend---------urlPath----"..urlpath)
			if urlpath then	
				require "module.Loading.useLoading"
				enterLoading(loadarea)
				RequestVolume(101, urlpath)
			end
		elseif CategoryID and CategoryID == "1" then			--营销信息					
			if nodeDisplayType == "1" then		--1：平铺式
				require("module.protocol.protocol_channelGroup")
				if urlpath and urlpath ~= "" then
					enterLoading(loadarea)	
					RequestChannelGroup(225, urlpath)
				end				
			elseif nodeDisplayType == "0" then   	--0：列表式
				require("module.protocol.protocol_channel")
				if urlpath and urlpath ~= "" then
					enterLoading(loadarea)	
					RequestChannel(226, urlpath)
				end
			elseif nodeDisplayType == "2" then	--2：评书
				require("module.protocol.protocol_navigation")
				if urlpath and urlpath ~= "" then
					enterLoading(loadarea)	
					RequestNavigation(227, urlpath)
				end
			elseif nodeDisplayType == "3" then	--3: 排行榜
				require("module.protocol.protocol_topten")
				if urlpath and urlpath ~= "" then
					enterLoading(loadarea)	
					RequestTopTen(228, urlpath)
				end
			else					--3: 内容
				require "module.protocol.protocol_infovolume"
				if urlpath then	
					require "module.Loading.useLoading"
					enterLoading(loadarea)
					RequestVolume(101, urlpath)
				end
			end
		elseif CategoryID and CategoryID == "3" then			--直播节目单
			require("module.protocol.protocol_channel")
			if urlpath and urlpath ~= "" then
				enterLoading(loadarea)
				RequestChannel(102, urlpath)
			end
		--以下2种情况不可能，因为专题消息、视频杂志 是不会跳到这个页面的
--		elseif CategoryID and CategoryID == "4" then			--专题消息
--			--这个可能需要请求网络数据，待确认
--			GoAndFreeScene(sceneReceiveThird)
--		elseif CategoryID and CategoryID == "5" then			--视频杂志
--		
		end
	end
end

function bodyOnPluginEvent(message, param)
	require("module.common.registerScene")
	require "module.videoexpress-common"
	if message == 101 then			
		require "module.Loading.useLoading"
		exitLoading()
		SetReturn(sceneReceiveSecondary,scenePrograminfo_volume)
		FreeScene(GetCurScene())
		GoAndFreeScene(scenePrograminfo_volume)
	elseif message == 225 then
		exitLoading()
		SetReturn(sceneReceiveSecondary,sceneGuide)
		pathName = "MODULE:\\guide.xml"
		if pathName then
			local scene = FindScene(pathName)
		end
		if scene and scene ~= 0 then
			FreeScene(scene)
		end
		Go2Scene(pathName, nil)
	elseif message == 226 then
		exitLoading()
		local jason = ChannelNetworkData()
		if jason.imgListNavi and jason.programList then
			SetReturn(sceneReceiveSecondary,sceneProduct)
			FreeScene(GetCurScene())
			WriteLogs("ChangeToProduct")
			GoAndFreeScene("MODULE:\\product.xml")
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneFriendsRecommended, sceneFriendsRecommended, GetCurScene())
			Go2Scene(sceneDialog)
		end
	elseif message == 227 then
		exitLoading()		
		local navigationData = LoadNavigationData()
		if navigationData then
			WriteLogs("ChangeToNavigationData")
			SetReturn(sceneReceiveSecondary,sceneNavigation)
			FreeScene(GetCurScene())
			GoAndFreeScene("MODULE:\\navigation.xml")
		end		
	elseif message == 228 then
		exitLoading()		
		local topTenData = LoadJsonTopTenNetworkData()
		if topTenData then
			WriteLogs("ChangeToguide")
			SetReturn(sceneReceiveSecondary,scenePaihang)
			FreeScene(GetCurScene())
			GoAndFreeScene("MODULE:\\paihang.xml")
		end		
	elseif message == 102 then
		exitLoading()		
		local jason = ChannelNetworkData()
		if jason and jason.imgListNavi and jason.programList then
			WriteLogs("ChangeToProduct")
			SetReturn(sceneReceiveSecondary,sceneProduct)
			FreeScene(GetCurScene())
			GoAndFreeScene("MODULE:\\product.xml")
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneFriendsRecommended, sceneFriendsRecommended, GetCurScene())
			Go2Scene(sceneDialog)
		end		
	elseif message > 32768 and message ~= MSG_SMS_ID + 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneFriendsRecommended, sceneFriendsRecommended, nil)
		Go2Scene(sceneDialog)
	elseif MSG_SMS_ID == message then			
		DealMsgContent(sceneFriendsRecommended, sceneFriendsRecommended)
	end
	WriteLogs("bodyOnPluginEvent-end")
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	require("module.common.commonMsg")
	if message == MSG_SMS then
		WriteLogs("bodyOnSpriteEvent-----------------------1")
		requestMsgContent()
	end
	--[[  返回事件  ]]--
	if message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
end

function CreatePage()
	local reg_f = registerCreate("friendsrecommended_detail")
	local sprite = registerGetInteger(reg_f,"root")
	local itemNo = registerGetString(reg_f,"ItemNo")
	local listNo = registerGetString(reg_f,"ListNo")	
	local reg = registerCreate("temp")	
	WriteLogs("friendsRecommend---------itemNo----"..itemNo)
	WriteLogs("friendsRecommend---------listNo----"..listNo)	
	local reg_f = registerCreate("friendsrecommended_detail")
	local type = registerGetString(reg_f, "type")
	if type == "SMS" then 		
		local CategoryID = registerGetString(reg_f, "recommendMsgCategoryID")
		registerLoad(reg, "MODULE:\\videoexpress\\categoryID"..CategoryID..".xml")
		registerSetString(reg_f, "type", "")
	else
		registerLoad(reg, "MODULE:\\videoexpress\\categoryID"..listNo..".xml")
		local name = FindValue(reg,"item"..itemNo,"MsgTitle")
	end
	CategoryID 	   = FindValue(reg,"item"..itemNo,"categoryID")	
	nodeDisplayType    = FindValue(reg,"item"..itemNo,"NodeDisplayType")
	urlpath 	   = FindValue(reg,"item"..itemNo,"UrlPath")
	local name	   = FindValue(reg,"item"..itemNo,"MsgTitle")	
	local PhoneNum 	   = FindValue(reg,"item"..itemNo,"sendPhoneNum")	
	local Content 	   = FindValue(reg,"item"..itemNo,"msgContent")		
	local categoryName = registerGetString(reg, "categoryName")
	local title_txt    = FindChildSprite(sprite, "title_txt")	
	SetSpriteProperty(title_txt, "text", categoryName)
	
	if name ~= 0 then
		setIntroduceText(sprite, "content_title", name)
	else
		setIntroduceText(sprite, "content_title", "")	
	end
	
	if CategoryID == "6" then
		if PhoneNum ~= 0 then
			setIntroduceText(sprite, "content_phone", PhoneNum)
		else
			setIntroduceText(sprite, "content_phone", "手机视频")	
		end
	else
		setIntroduceText(sprite, "content_phone", "手机视频")
	end

	if Content ~= 0 then
		setIntroduceText(sprite, "distinct-introduce", Content)
	else
		setIntroduceText(sprite, "distinct-introduce", "")
	end
	
	if urlpath == "" then
		urlpath = "http:////c2.cmvideo.cn//sup//data//clt//v2//content.jsp?contentId=1055557&channelId=10259&parentChannelId=10010156&isLog=0&msgId=10010407"
	end
	return 1
end

function GoAndFreeScene(pathName)
	local scene = FindScene(pathName)
	if scene and scene ~= 0 then
		FreeScene(scene)
	end
	FreeScene(GetCurScene())
	SetReturn("MODULE:\\myorder.xml", pathName)
	Go2Scene(pathName, nil)
end

function ButtonKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require "module.keyCode.keyCode"
	local name = GetSpriteName(sprite)
	WriteLogs("Key event begin !")
	WriteLogs("Key event is "..keyCode)
	WriteLogs("Current button Sprite is "..name)
	local root = GetRootSprite(sprite)
	if keyCode == ApKeyCode_Up then
	elseif keyCode == ApKeyCode_Down then
	elseif keyCode == ApKeyCode_Enter then
	elseif keyCode == ApKeyCode_Cancel or keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F1 and LoadingFlag() then
			require("module.sysmenu")
			require("module.menuopen")
			SysGetSeceSprite(sprite)
			menuButtonOnSelect(sprite)
	else
		WriteLogs("Other Key event !")
	end
	return 0
end