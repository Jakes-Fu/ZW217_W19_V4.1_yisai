﻿--@module video
--@note 播放界面
--@author cuiyizhou
--@date 2010/05/25
require "module.protocol.protocol_video"
require "module.video_com"
require "module.common.SceneUtils"
  ApKeyCode_Null	=	0
ApKeyCode_F1	=	1
ApKeyCode_F2	=	2
ApKeyCode_Enter	=	3
ApKeyCode_Cancel	=	4

ApKeyCode_Dial	=	5
ApKeyCode_Hangup	=	6

ApKeyCode_Left	=	7
ApKeyCode_Right	=	8
ApKeyCode_Up	=	9
ApKeyCode_Down	=	10

ApKeyCode_Char0	=	11
ApKeyCode_Char1	=	12
ApKeyCode_Char2	=	13
ApKeyCode_Char3	=	14
ApKeyCode_Char4	=	15
ApKeyCode_Char5	=	16
ApKeyCode_Char6	=	17
ApKeyCode_Char7	=	18
ApKeyCode_Char8	=	19
ApKeyCode_Char9	=	20

ApKeyCode_CharA	=	21
ApKeyCode_CharB	=	22

ApKeyCode_VolumeUp	=	23
ApKeyCode_VolumeDown	=	24
ApKeyExitApp	=	25
function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	reg = registerCreate("video")   
	registerSetInteger(reg, "root", sprite)
	--[[  以下为组点播时的面板创建  ]]--   
	local regflag = registerCreate("buttonclickflag_g")
	--[[	flag值为0时playerinterfaceOnTick函数会直接返回，即不移动播放器面板	]]--
	registerSetInteger(regflag, "flag", 0)
	--[[	preflag值置1，默认第一次播放器面板的运动为向上	]]--
	registerSetInteger(regflag, "preflag", 1)
	local reg_g = registerCreate("group")
	local scenename = registerGetString(reg_g, "scenename")
	local reg_l = registerCreate(scenename)
	local fileName = registerGetString(reg_l, "labelUrlFileName")
	
	jsonCreateData()
	InitScene()
	
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if MediapalyPlugin == 0 then
		MediapalyPlugin = pluginCreate("MediaPlayer")
		pluginInvoke(MediapalyPlugin, "Create", 0, 27, 240, 180)
	end
	
	if MediapalyPlugin ==0 then
		SetStatusText("创建播放器失败，请重新安装程序")
	else
		local open = pluginInvoke(MediapalyPlugin, "Open", urlpath)
		pluginInvoke(MediapalyPlugin, "Play");
		local Volume = pluginInvoke(MediapalyPlugin, "GetVolume");
		curVolume = Volume
		registerSetInteger(reg, "MediapalyPlugin", MediapalyPlugin)
		SetTimer(1, 500, "OnGetStatus")
	end
	initData_G()
	setPreNetButtonBgImage() --初始化节目按钮图片
	return 1
end

function bodyOnSpriteEvent(message, params)
	require("module.common.commonMsg")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	if message == MSG_EXCEPTIVEKEY then
		WriteLogs("MSG_EXCEPTIVEKEY: "..params)
		if params == 23 then
			VolumeUpOnButtonClick(nil)
		elseif params == 24 then
			VolumeDownOnButtonClick(nil)
		end
	elseif message == MSG_ACTIVATE then
	  SetSpriteFocus(spritefull)  
		require "module.common.DownloadUpload"
		PauseDownloadTask()
		PauseUploadTask()
		curPageIsVideo = true
		SetStatusText("")
		WriteLogs("MSG_ACTIVATE ")
		jsonCreateData()
		setPreNetButtonBgImage() --初始化节目按钮图片
		if MediapalyPlugin == 0 and urlpath then
			MediapalyPlugin = pluginCreate("MediaPlayer")
			local open = pluginInvoke(MediapalyPlugin, "Open", urlpath)
			if open ==1 then
				registerSetInteger(reg, "MediapalyPlugin", MediapalyPlugin)
			else
				SetStatusText("连接服务器失败")
				local reg=registerCreate("fullBt")
				local focus=registerGetInteger(reg,"FullBt")
				SetSpriteFocus(focus)
			end
		else
			pluginInvoke(MediapalyPlugin, "Open", urlpath)
		end
		pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 27, 240, 180)
		local playerinterface = FindChildSprite(GetCurScene(), "item-playerinterface")
		SetSpriteRect(playerinterface,0,211,240,100)
		local regflag = registerCreate("buttonclickflag_g")
		registerSetInteger(regflag, "preflag", 1)
		SetTimer(1, 500, "OnGetStatus")
	elseif message == MSG_DEACTIVATE then
		WriteLogs("MSG_DEACTIVATE")
		curPageIsVideo = false
		if MediapalyPlugin == 0 then
			MediapalyPlugin = pluginCreate("MediaPlayer")
		end
		pluginInvoke(MediapalyPlugin, "Stop")
		pluginInvoke(MediapalyPlugin, "Show" , 0)
		SetStatusText("")
		local left2, top2, width2, height2 = GetSpriteRect(huaKuaiSprite)
		SetSpriteRect(huaKuaiSprite, huaKuai_left,top2, width2, height2)
		local left2, top2, width2, height2 = GetSpriteRect(spritehighlight)
		SetSpriteRect(spritehighlight, left2, top2, 0, height2)
		SetSpriteRect(spritehighred, left2, top2, 0, height2)
	elseif message == MSG_MINIMIZED then
		reg = registerCreate("video")
		WriteLogs("MSG_MINIMIZED")
		if MediapalyPlugin then
			if iffull == 1 then
				iffull =0
				pluginInvoke(MediapalyPlugin, "FullScreen", 0)
				ReleaseSpriteCapture(FullSec)
				SetSpriteProperty(FullSec,"enable","false")
			end
			pluginInvoke(MediapalyPlugin, "Show" , 0)
			pluginInvoke(MediapalyPlugin, "Pause")
		end
	elseif message == MSG_MAXIMIZED then
		reg = registerCreate("video")
		WriteLogs("MSG_MAXIMIZED")
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "Show" , 1)
		end		
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	elseif message == MSG_SMS then
		hintSMS()
	end
end

function OnPluginEvent(message, param)
	if message == 101 then
		exitLoading()
		SetReturn(sceneProduct, scenePrograminfo_volume)
		GoAndFreeScene(scenePrograminfo_volume)
	elseif message == 102 then
		exitLoading()
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")	
		jsonCreateData()
		videoCurnum = videoCurnum-1;
		pluginInvoke(MediapalyPlugin, "Stop");
		pluginInvoke(MediapalyPlugin, "Open", urlpath)
	elseif message == 103 then
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneVideolocal, sceneVideolocal)
		videoDealSMS()
	end
end

--start 设置状态
function SetStatusText(text)
	SetSpriteProperty(statuslabel, "text", text)
	SetSpriteProperty(statuslabe2, "text", text)
	return 1
end

--start 解析数据
function jsonCreateData()
	-- add by xf_pan
	require("module.video_groupinfo")
	fileName = GetGroupFileName(fileName)
	json_l = jsonLoadFile(fileName)
	
	local reg = registerCreate("video")
	json =OnVideoDecode()
	commendUrlList={"item-playerinterface-recommand1","item-playerinterface-recommand2"}
	commendNameList={"item-playerinterface-recommand1","item-playerinterface-recommand2"}
	commendUrlList["item-playerinterface-recommand1"]=""
	commendUrlList["item-playerinterface-recommand2"]=""
	commendNameList["item-playerinterface-recommand1"]=""
	commendNameList["item-playerinterface-recommand2"]=""	
	localUrlList ={}
	urlpath =""
	videoCount =0
	videoCurnum =0
	--[[播放器页面推荐只用取最后一条记录]]--
	if json.commend1 ~= nil then 
		for i=0, table.maxn(json.commend1) do	
			if json.commend1[i].urlPath ~= nil then
				commendUrlList["item-playerinterface-recommand1"] = json.commend1[i].urlPath
				commendNameList["item-playerinterface-recommand1"] = json.commend1[i].contentName
			end
		end
	end
	if json.commend2 ~= nil then
		for i=0, table.maxn(json.commend2) do	
			if json.commend2[i].urlPath ~=nil then
				commendUrlList["item-playerinterface-recommand2"] = json.commend2[i].urlPath
				commendNameList["item-playerinterface-recommand2"] = json.commend2[i].contentName
			end
		end
	end
	urlpath = json.url
	jiNum = 10
	row = 2
	col = 4
	if page == nil then
		page = 0
	end
	videoCurnum = registerGetInteger(reg, "groupCurItem")+1
	videoCount = table.maxn(json_l.subIds)+1
	pageMaxNum = math.floor(jiNum / (row * col))
	videoList = {itemButton1="rul1",itemButton2="rul2",itemButton3="rul3",itemButton4="rul4",itemButton5="rul5",itemButton6="rul6",itemButton7="rul7",itemButton8="rul8",itemButton9="rul9",itemButton10="rul10"}
	SaveHistoryVideoList()
	return 1
end

function InitScene()
	createGroupVideo()	--[[  组点播面板创建  ]]--	
	createGlobalValue()
end

function initData_G()
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	setSecTime(labelStartTimeSprite, pluginInvoke(MediapalyPlugin, "GetCurTime"))
	gTotalTime = pluginInvoke(MediapalyPlugin, "GetTotalTime")
	setSecTime(labelEndTimeSprite, gTotalTime)
	
	local normalLable = FindChildSprite(recommand1Button, "normal")
	local focusLable = FindChildSprite(recommand1Button, "focus")
	SetSpriteProperty(normalLable, "text" ,commendNameList["item-playerinterface-recommand1"] )
	SetSpriteProperty(focusLable, "text" ,commendNameList["item-playerinterface-recommand1"] )
	normalLable = FindChildSprite(recommand2Button, "normal")
	focusLable = FindChildSprite(recommand2Button, "focus")
	SetSpriteProperty(normalLable, "text" ,commendNameList["item-playerinterface-recommand2"] )
	SetSpriteProperty(focusLable, "text" ,commendNameList["item-playerinterface-recommand2"] )
end

--@function showDetailOnSelect
--@tag-name item-playercontrols-showdetail PS:在player_groupvideomodule.xml中
--@tag-action button:OnSelect 
--@brief 组播页面时点击屏幕下方按钮 改变全局值从而在function playerinterfaceOnTick中改变面板大小
function showDetailOnSelect(sprite)
	local reg = registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	local regflag = registerCreate("buttonclickflag_g")
	local preflag = registerGetInteger(regflag,"preflag")
	local rootsprite = GetCurScene()
	--[[	preflag中存放上一次移动的状态，因为flag在不移动时会置0，所以需要另一个变量来保存上一次移动的信息	]]--
	if preflag == 1 then
		--[[	flag置-1后会往上移动，具体在playerinterfaceOnTick中实现	]]--		
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 27, 240, 135);
		end
		registerSetInteger(regflag, "flag" ,-1)
		--[[	改变按钮的图片 normal和focus状态	]]--
		local btnsprite = FindChildSprite(rootsprite,"item-playercontrols-showdetail")
		local btnnormal = FindChildSprite(btnsprite,"normal")
		SetSpriteProperty(btnnormal,"src","file:///image/player/gd_xia.png")
		local btnfocus = FindChildSprite(btnsprite,"focus")
		SetSpriteProperty(btnfocus,"src","file:///image/player/gd_xia.png")
	else
		--[[	flag置1后会往下移动，具体在playerinterfaceOnTick中实现	
		if MediapalyPlugin then
			pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 30, 240, 162)
		end]]--
		registerSetInteger(regflag, "flag" ,1)
		--[[	改变按钮的图片 normal和focus状态	]]--
		local btnsprite = FindChildSprite(rootsprite,"item-playercontrols-showdetail")
		local btnnormal = FindChildSprite(btnsprite,"normal")
		SetSpriteProperty(btnnormal,"src","file:///image/player/gd_shang.png")
		local btnfocus = FindChildSprite(btnsprite,"focus")
		SetSpriteProperty(btnfocus,"src","file:///image/player/gd_shang.png")
	end
	return 1
end

--@function playerinterfaceOnTick
--@tag-name item-playerinterface
--@tag-action list-item:OnTick 
--@brief 组播页面时点击屏幕下方按钮 播放器面板改动大小逻辑
function playerinterfaceOnTick(sprite)
	local reg = registerCreate("video")
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	local regflag = registerCreate("buttonclickflag_g")
	local flag = registerGetInteger(regflag, "flag")
	if flag == 0 then
		return 1
	end
	local root = registerGetInteger(reg, "root")
	if flag == 1 then
		local l,t,w,h = GetSpriteRect(sprite)
			t = t + 5
			h = h - 5
			if t >= 207 then
				registerSetInteger(regflag, "preflag", flag)
				registerSetInteger(regflag, "flag", "0")
				if MediapalyPlugin then
					pluginInvoke(MediapalyPlugin, "MoveWindow", 0, 30, 240, 180)
				end
			end
			SetSpriteRect(sprite, l, t, w, h)
		return	1
	else
		local l,t,w,h = GetSpriteRect(sprite)
			t = t - 5
			h = h + 5
			if t <= 163 then
				registerSetInteger(regflag, "preflag", flag)
				registerSetInteger(regflag, "flag", "0")
			end
			SetSpriteRect(sprite, l, t, w, h)
		return 1
	end
end

function groupbuttonOnSelect(sprite)
	require "module.Loading.useLoading"
	if json_l ~= nil then
		local reg = registerCreate("video")
		local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		pluginInvoke(MediapalyPlugin, "Stop")
		--[[  获得根节点  ]]--  
		local root = GetCurScene()
		local loadarea = FindChildSprite(root ,"loadarea")
		--[[  显示loading场景  ]]--
		enterLoading(loadarea)
		local listitem = GetSpriteParent(sprite)
		local index = SpriteListItem_GetIndex(listitem)
		videoCurnum = index + 1
		setPreNetButtonBgImage(1)
		require("module.menuprograminfo")
		require "module.protocol.protocol_videoloading"
		if json_l.contentName then
			videoName = json_l.contentName.." "..json_l.subIds[index].subName
		else
			videoName = json_l.subIds[index].subName
		end
		RequestVideo(102, json_l.subIds[index].playUrl, GetProgramInfoUrlPath(), json_l.contentName ,"group")
		initData_G()
	end
end

function RecommandOnSelect(sprite)
	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
	local tuijianName=GetSpriteName(sprite)
	if commendUrlList[tuijianName] ~="" then
  	if MediapalyPlugin then
    	pluginInvoke(MediapalyPlugin, "Show" , 0)
    	pluginInvoke(MediapalyPlugin, "Stop")
    end
    SetStatusText("")
    RequestGuide(commendUrlList[tuijianName], nil)
  end
end
--@function	createGroupVideo
--@brief	当场景为视屏组点播时，创建相应的界面，在bodyBuildChildrenFinished中调用
function createGroupVideo()
	--[[	获取根节点	]]--
--	local reg = registerCreate("player")
	local root = registerGetInteger(reg, "root")
	--[[	创建listitem类的节点	]]--
	local playercontrolsitemSprite = CreateSprite("listitem")
	local playercontrolsSprite = FindChildSprite(root, "list-playercontrols")
	--[[	用已有模板中数据填充该节点	]]--
	LoadSprite(playercontrolsitemSprite, "WONDER:\\module\\video_groupvideomodule.xml")
	SetSpriteRect(playercontrolsitemSprite, 0, 0, 240, 100)
	--[[	把该节点插入到场景中	]]--
	AddChildSprite(playercontrolsSprite, playercontrolsitemSprite)          
	SpriteList_AddListItem(playercontrolsSprite, playercontrolsitemSprite)
	
	--[[	重新调节场景中播放面板位置参数	]]--
	local playerinterfacesprite = FindChildSprite(root, "item-playerinterface")
	SetSpriteRect(playerinterfacesprite,0,190,240,102)
	
	--[[	接下来是创建组播界面特有的显示和隐藏视屏组的按钮	]]--
	--[[	类似地创建listitem类的节点，并插入到名为player的list中	]]--
	local playerSprite = FindChildSprite(root,"player")
	local playerinterfacebtnSprite = CreateSprite("listitem")
	LoadSprite(playerinterfacebtnSprite, "WONDER:\\module\\video_groupvideomodule_btn.xml")
	--[[	设置下名字和范围	]]--
	SetSpriteProperty(playerinterfacebtnSprite,"name","item-playerinterface-btn")
	SetSpriteRect(playerinterfacebtnSprite,0,190,240,100)
	--[[	把该节点插入到场景中的player标签	]]--
	AddChildSprite(playerSprite, playerinterfacebtnSprite)          
	SpriteList_AddListItem(playerSprite, playerinterfacebtnSprite)
	
	CreateListTable()
  local spritefull=FindChildSprite(playercontrolsitemSprite, "item-playercontrols-fullscreen") 
	SetSpriteFocus(spritefull) 
	local reg=registerCreate("fullBt")
	registerSetInteger(reg,"FullBt",spritefull)
	return 1
end
function CreateListTable()
	local reg = registerCreate("video")
	--[[	动态创建同组中链接到不同视频的按钮，应该从网络数据源中取数据	]]--
	local root = registerGetInteger(reg, "root")
	local groupbtnsSprite = FindChildSprite(root,"list-playercontrols-groupbtns")
	spritegroupitem=groupbtnsSprite
	SpriteList_ClearListItem(groupbtnsSprite, 1, 1)
	--[[	循环插入数据	]]--
	if( json_l ~= nil ) then
		for i=1 , table.maxn(json_l.subIds)+1 do
			local groupvideoitem = CreateSprite("listitem")
			SetSpriteProperty(groupvideoitem, "name","groupvideoitem" ..i)
			--[[	读取模板	]]--
			LoadSprite(groupvideoitem, "WONDER:\\module\\video_groupvideomodule_item.xml")
			--[[	对每个用模板创建的节点，给normal状态和focus状态下的label标签的text属性赋值	]]--
			local itemButton = FindChildSprite(groupvideoitem, "groupbutton")
			SetSpriteProperty(itemButton, "name", "itemButton" ..i)
			--[[	nomal状态	]]--
			local textNormal = FindChildSprite(groupvideoitem, "NormalButtontext")
			--[[	focus状态	]]--
			local textForcus = FindChildSprite(groupvideoitem, "FocusButtontext")           
			SetSpriteProperty(textNormal, "text", json_l.subIds[i-1].subName)
			SetSpriteProperty(textForcus, "text", json_l.subIds[i-1].subName)
			--[[	把该节点插入到场景中的list-playercontrols-groupbtns标签	]]--
			AddChildSprite(groupbtnsSprite, groupvideoitem)
			SpriteList_AddListItem(groupbtnsSprite, groupvideoitem)
		end
	end
	--[[	重新计算这些被插入的按钮控件之间的距离	]]--
	SpriteList_Adjust(groupbtnsSprite)
end

function refurbishListVideo()
	local root = registerGetInteger(reg, "root")
	local groupbtnsSprite = FindChildSprite(root,"list-playercontrols-groupbtns")

	local i = page * row * col
	SpriteList_SetStartItem(groupbtnsSprite, i)
	if page == 0 then 
		
	end
end



function FullChangeKeyUp(sprite,keyCode)
	WriteLogs("keyCode:"..keyCode)
	local reg=registerCreate("Fullselect")
	registerGetInteger(reg,"FullFocus",sprite)
	if keyCode then
	FulleSecOnButtonClick(sprite)
	end
	return 0
end

function listKeyUp(sprite, keyCode)
  local Jiaodian = {"item-playercontrols-fullscreen","item-playercontrols-volumedown","item-playercontrols-volumeup","pre","play","next","item-playercontrols-recommend"}
	local JiaodianUD= {"bar","item-playerinterface-recommand1","item-playerinterface-recommand2","item-playercontrols-fullscreen"}
	WriteLogs("KeyUp")
	WriteLogs("@@@@@@@@@@@"..keyCode)
	local name = GetSpriteName(sprite)
  if name=="splider-bar" and (keyCode == ApKeyCode_Left or keyCode == ApKeyCode_Right) then
	  local reg = registerCreate("video")
	  local seekTime
	  local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
    local spriteR=registerGetInteger(reg, "root")
  	labelStartTimeSprite = FindChildSprite(spriteR, "item-playerinterface-curtime")
    local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
    local totalTime=pluginInvoke(MediapalyPlugin, "GetTotalTime")
    WriteLogs("%%%%%%%%%%%%%%%%%%%%%%%%"..curTime)
    if keyCode == ApKeyCode_Left and curTime>=30 then
      seekTime=curTime-30
      WriteLogs("@@@@@@@@@@@@@@@@@seekTime"..seekTime)
      WriteLogs("@@@@@@@@@@@@@@@@@totalTime"..totalTime)
	    spriteS=GetSpriteParent(GetSpriteParent(sprite))
	    changeL=seekTime/totalTime*132
	    WriteLogs("@@@@@@@@@@@@@@@@@totalTime"..totalTime)
	    spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighred")
	    X,Y,X1,Y1=GetSpriteRect(spriteR)
	    SetSpriteRect(spriteR,X,Y,changeL,Y1)
	    spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighlight")
	    X,Y,X1,Y1=GetSpriteRect(spriteR)
	    SetSpriteRect(spriteR,X,Y,changeL,Y1)
	    spriteR=FindChildSprite(spriteS,"item-playerinterface-progressblock")
	    X,Y,X1,Y1=GetSpriteRect(spriteR)
	    SetSpriteRect(spriteR,changeL+48,Y,X1,Y1)
    end
    if keyCode == ApKeyCode_Right then
      seekTime=curTime+30
      WriteLogs("@@@@@@@@@@@@@@@@@seekTime"..seekTime)
      WriteLogs("@@@@@@@@@@@@@@@@@totalTime"..totalTime)
      spriteS=GetSpriteParent(GetSpriteParent(sprite))
	    changeL=seekTime/totalTime*132
	    spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighred")
	    X,Y,X1,Y1=GetSpriteRect(spriteR)
	    SetSpriteRect(spriteR,X,Y,changeL,Y1)
	    spriteR=FindChildSprite(spriteS,"item-playerinterface-progressbarhighlight")
	    X,Y,X1,Y1=GetSpriteRect(spriteR)
	    SetSpriteRect(spriteR,X,Y,changeL,Y1)
	    spriteR=FindChildSprite(spriteS,"item-playerinterface-progressblock")
	    X,Y,X1,Y1=GetSpriteRect(spriteR)
	    SetSpriteRect(spriteR,changeL+48,Y,X1,Y1)     
    end  
    setSecTime(labelStartTimeSprite, seekTime)	
	  pluginInvoke(MediapalyPlugin, "Seek", seekTime)
	  return 0
	end
	if name=="splider-bar" then 
   sprite=GetSpriteParent(sprite)
   name="bar"
  end
	if name=="item-playercontrols-play" or name=="item-playercontrols-pause" then 
	  name="play"
	  sprite=GetSpriteParent(sprite)
	end
	if name=="item-playercontrols-pre"  then
	   name="pre"
	   sprite=GetSpriteParent(sprite)
	end
	if name=="item-playercontrols-next"  then
	   name="next"
	   sprite=GetSpriteParent(sprite)
	end
	local jidodianNum
  local i 
  flagK=0
	for i=1,7 do
  if Jiaodian[i]==name then
	    jiaodianNum=i
	    flagK=1
	  end   
	end     
 if keyCode == ApKeyCode_Right and jiaodianNum<=6 and flagK==1 then   
   sprite1 = FindChildSprite(GetSpriteParent(sprite), Jiaodian[jiaodianNum+1])
   if GetSpriteName(sprite1)=="pre" then 
     sprite1=FindChildSprite(sprite1,"item-playercontrols-pre")
   end
   if GetSpriteName(sprite1)=="next" then 
     sprite1=FindChildSprite(sprite1,"item-playercontrols-next")
   end
   a,result1,c,d = GetSpriteRect(sprite1)
   WriteLogs("@@@@@@@@@@@@@@@@@@@@@result"..GetSpriteName(sprite1))
   WriteLogs("@@@@@@@@@@@@@@@@@@@@@result"..result1)    
  if result1 == 20 and jiaodianNum<=5 then
      WriteLogs("@@@@@@@@@@@@@@@@@@@@@@@@@1111111")
      sprite1=FindChildSprite(GetSpriteParent(sprite), Jiaodian[jiaodianNum+2])
  end   
    WriteLogs("@@@@@@@@"..GetSpriteName(sprite1))
    if GetSpriteName(sprite1)=="play" then
      local reg= registerCreate("video")
	    local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		  local status = pluginInvoke(MediapalyPlugin, "GetStatus")                   
       if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering then
        sprite1=FindChildSprite(sprite1,"item-playercontrols-play") 
      else sprite1=FindChildSprite(sprite1,"item-playercontrols-pause")
      end
    end
    SetSpriteFocus(sprite1)
  end     
 if keyCode == ApKeyCode_Left and jiaodianNum>=2 and flagK==1 then 
   sprite1 = FindChildSprite(GetSpriteParent(sprite), Jiaodian[jiaodianNum-1])
    if GetSpriteName(sprite1)=="pre" then 
     sprite1=FindChildSprite(sprite1,"item-playercontrols-pre")
   end
   if GetSpriteName(sprite1)=="next" then 
     sprite1=FindChildSprite(sprite1,"item-playercontrols-next")
   end
   a,result1,c,d = GetSpriteRect(sprite1)
   WriteLogs("@@@@@@@@@@@@@@@@@@@@@result"..GetSpriteName(sprite1))
   WriteLogs("@@@@@@@@@@@@@@@@@@@@@result"..result1)    
   if result1 == 20 and jiaodianNum>=3 then 
     sprite1=FindChildSprite(GetSpriteParent(sprite), Jiaodian[jiaodianNum-2])
     WriteLogs("##############")
   end      
   if GetSpriteName(sprite1)=="play" then
     local reg= registerCreate("video")
	   local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
		 local status = pluginInvoke(MediapalyPlugin, "GetStatus")                   
       if status==EPlayerStatus_Playing  or status==EPlayerStatus_Buffering then
       sprite1=FindChildSprite(sprite1,"item-playercontrols-play") 
     else sprite1=FindChildSprite(sprite1,"item-playercontrols-pause")
     end
   end   
   SetSpriteFocus(sprite1)
  end     
  
  if keyCode==ApKeyCode_Enter and name == "item-playercontrols-fullscreen" then
		SetSpriteFocus(FindChildSprite(GetRootSprite(sprite),"FullSec"))
		WriteLogs("进入全屏并焦点设置成功:"..HasSpriteFocus(FindChildSprite(GetRootSprite(sprite),"FullSec")))
		local reg=registerCreate("Fullselect")		--将全屏按钮键写入数据仓库
		registerSetInteger(reg,"FullFocus",sprite)

  
  end	
  
 if keyCode== ApKeyCode_CharB then 
   WriteLogs("@@@@@@@@@@@zhankai")
   showDetailOnSelect(sprite)   
  end
  if flagK==1 then 
   name="item-playercontrols-fullscreen"
 end
 flagK=0
 for i=1,4 do
   if JiaodianUD[i]==name then
	   jiaodianNum=i
	   flagK=1
	 end   
 end 
 if name=="item-playerinterface-recommand1" then
   sprite=GetSpriteParent(sprite)
 end
 	WriteLogs("@@@@@@@@@jiaodianNum"..jiaodianNum)
	WriteLogs("@@@@@@@@@jiaodianNum"..name)
 if keyCode == ApKeyCode_Up and flagK==1 and jiaodianNum>=2 then
    if jiaodianNum==2 then
      sprite=GetSpriteParent(sprite)
    end
    sprite1=FindChildSprite(GetSpriteParent(sprite), JiaodianUD[jiaodianNum-1])
    WriteLogs("@@@jiaodianNum"..jiaodianNum)
    WriteLogs("@@@sprite1"..GetSpriteName(sprite1))
    if jiaodianNum==2 then
      sprite1=FindChildSprite(sprite1,"splider-bar")
    end
    WriteLogs(GetSpriteName(sprite1))
    SetSpriteFocus(sprite1)
 end
 WriteLogs("#############"..name)
 if keyCode == ApKeyCode_Down and flagK==1 and jiaodianNum<=3 then
   sprite1=FindChildSprite(GetSpriteParent(sprite), JiaodianUD[jiaodianNum+1])
   WriteLogs(GetSpriteName(sprite1))
   SetSpriteFocus(sprite1)
 end
 	local regflag = registerCreate("buttonclickflag_g")
	local preflag = registerGetInteger(regflag,"preflag")
	WriteLogs("@@@@@@@@@@@@@@preflag"..preflag)
	WriteLogs("@@@@@@@@@@@@@@flagK"..flagK)
 if keyCode == ApKeyCode_Down and flagK==1 and jiaodianNum==4 and preflag==-1 then
  WriteLogs("@@@@@@@@@@@@@@bian") 
  WriteLogs("@@@@@@@@@@@@@@bian"..GetSpriteName(spritegroupitem))
  sprite1=FindChildSprite(spritegroupitem,"itemButton1" )
  WriteLogs("@@@@@@@@@@@@@@bian"..GetSpriteName(sprite1)) 
  SetSpriteFocus(sprite1)
 end 
 if keyCode == ApKeyCode_F1 then		
	  require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)

 end
 if keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)

 end	
  return 0
end
function listKeyUp1(sprite, keyCode)
  WriteLogs("@@@@@@@@@@@@@@sprite"..GetSpriteName(sprite))
  WriteLogs("@@@@@@@@@@@@@@keyCode"..keyCode)
  index = SpriteListItem_GetIndex(GetSpriteParent(sprite))
  indexy= index%4 
  indexz= math.floor(index/4)
  WriteLogs("@@@@@@@@@@@@@@index"..index)
  WriteLogs("@@@@@@@@@@@@@@indexy"..indexy)
  if keyCode == ApKeyCode_Left and indexy~=0 then
    index=index-1
  end
  if keyCode == ApKeyCode_Right and indexy~=3 then
    index=index+1
  end
  if keyCode == ApKeyCode_Right and indexy==3 then
   WriteLogs("@@@@@jinqula@@@")
   KillSpriteFocus(sprite)
   WriteLogs("@@@@@page@@@"..page)
		if page <= pageMaxNum then
			page =page + 1
			refurbishListVideo()
		end
  end 
  if keyCode == ApKeyCode_Left and indexy==0 then
    KillSpriteFocus(sprite)
		if page >0 then
			page =page - 1
			refurbishListVideo()
		end
  end
  if keyCode == ApKeyCode_Up and indexz%2==1 then
    index=index-4
  end 
  if keyCode == ApKeyCode_Down and indexz%2==0 then
    index=index+4
  end
  sprite1=SpriteList_GetListItem(GetSpriteParent(GetSpriteParent(sprite)), index)
  WriteLogs("@@@@@@@@@@"..GetSpriteName(sprite1)) 
  sprite1 = FindChildSpriteByClass(sprite1,"button")
  SetSpriteFocus(sprite1)
  if keyCode== ApKeyCode_CharB then 
   WriteLogs("@@@@@@@@@@@zhankai")
   showDetailOnSelect(sprite)   
   sprite1=GetRootSprite(sprite)
   sprite1=FindChildSprite(sprite1,"list-playercontrols")
   sprite1=FindChildSprite(sprite1,"item-playercontrols-fullscreen")
   SetSpriteFocus(sprite1)
  end
  if keyCode == ApKeyCode_Up and indexz%2==0 then
    sprite1=GetRootSprite(sprite)
    sprite1=FindChildSprite(sprite1,"list-playercontrols")
    sprite1=FindChildSprite(sprite1,"item-playercontrols-fullscreen")
    SetSpriteFocus(sprite1)
  end
  if keyCode == ApKeyCode_F1 then		
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)

	end
  if keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)

  end	  
  --WriteLogs("@@@@@@@@@@"..GetSpriteName(GetSpriteParent(sprite))) 
  return 0
end
function FullChangeKeyUp(sprite,keyCode)
	WriteLogs("keyCode:"..keyCode)
	local reg=registerCreate("Fullselect")
	registerGetInteger(reg,"FullFocus",sprite)
	if keyCode then
	FulleSecOnButtonClick(sprite)
	end
	return 0
end

--function listKeyUp2(sprite, keyCode)
--	local reg = registerCreate("video")
--	local  seekTime
--	local MediapalyPlugin = registerGetInteger(reg, "MediapalyPlugin")
--  local sprite=registerGetInteger(reg, "root")
--	labelStartTimeSprite = FindChildSprite(sprite, "item-playerinterface-curtime")
--  local curTime = pluginInvoke(MediapalyPlugin, "GetCurTime")
--  WriteLogs("%%%%%%%%%%%%%%%%%%%%%%%%"..curTime)
--  if keyCode == ApKeyCode_Left and curTime>=30 then
--    seekTime=curTime-30
--  end
--  if keyCode == ApKeyCode_Right then
--    seekTime=curTime+30
--  end  
--  setSecTime(labelStartTimeSprite, seekTime)	
--	pluginInvoke(MediapalyPlugin, "Seek", seekTime)
--	return 0
--end