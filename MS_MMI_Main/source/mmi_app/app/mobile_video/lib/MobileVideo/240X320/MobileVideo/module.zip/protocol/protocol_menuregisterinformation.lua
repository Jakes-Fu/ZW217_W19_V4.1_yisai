--author ljc
--date	2010/06/01
-- request menuregisterinformation
--UGC�û�ע��
function RequestUGCCheckReg(protocolNumber, searchUrl, nickName)
WriteLogs("RequestUGCCheckReg-start")
	local regSystem = registerCreate("System")
	local http = pluginCreate("HttpPipe")
	local observer = pluginGetObserver()
	local fileName = GetLocalFilename(searchUrl)
	local reg = registerCreate("menuregisterinformation")
	local postdata = string.format("A_NAME=%s&T_TYPE=001", nickName)

	registerSetString(reg, "UGCCheckRegFileName", fileName)
	--pluginInvoke(http, "AppendCommand", 0, searchUrl, "", fileName, observer, protocolNumber, 0)
	pluginInvoke(http, "AppendCommand", 1, searchUrl, postdata, fileName, observer, protocolNumber, 0, 0)
	WriteLogs("RequestUGCCheckReg-end")
end

function GetUGCCheckRegFileName()
	local reg = registerCreate("menuregisterinformation")
	local fileName = registerGetString(reg, "UGCCheckRegFileName")
	WriteLogs("GetUGCCheckRegFileName="..fileName)
	if fileName ~= nil and fileName ~= "" then
		return fileName
	end

	return nil
end


--�������û���֤
function RequestWhiteListUserVerify(protocolNumber, searchUrl)
	local regSystem = registerCreate("System")
	local http = pluginCreate("HttpPipe")
	local observer = pluginGetObserver()
	local fileName = GetLocalFilename(searchUrl)
	local reg = registerCreate("menuregisterinformation")
	registerSetString(reg, "WhiteListUserVerifyFileName", fileName)
	pluginInvoke(http, "AppendCommand", 0, searchUrl, "", fileName, observer, protocolNumber, 0,1)
end

function OnWhiteListUserVerifyDecode()
	local reg = registerCreate("menuregisterinformation")
	local fileName = registerGetString(reg, "WhiteListUserVerifyFileName")
	if fileName ~= nil and fileName ~= "" then
		return fileName
	end

	return nil
end
