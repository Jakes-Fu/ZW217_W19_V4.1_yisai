﻿--@module 	SystemMenu
--@note 		底部菜单
--@author 	chengzhongjie
--@date 		2010/05/25
--@brief 		用于显示弹出菜单

require "module.sysmenu"
require "module.menuopen"
function hidePopupSprites()
	local	reg = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(reg, "rootSprite");
	WriteLogs("rootSprite名字："..rootSprite)
	if hideMenuSprite(rootSprite) == 1 then	return	1;	end
	if hideBottomSprite(rootSprite) == 1 then	return	1;end
	return	0;
end
function addFavOnSelect(button)
	local reg = registerCreate("sysSprite")			--创建数据仓库，获取F1前的焦点
	local lastFocus=registerGetInteger(reg,"sprite_name")
	WriteLogs("addFavOnSelect");
	WriteLogs("_________________")
	require("module.common.commonMsg")
	hidePopupSprites()
	require "module.protocol.protocol_video"
	OnReturnButton()
	local root = GetCurScene()
	SendSpriteEvent(root, MSG_ADD_FAV)
	SetSpriteFocus(lastFocus)
end

function settingOnSelect(sprite)
	local	reg = registerCreate(keyQuickLauncherBar)
	local	rootSprite = registerGetInteger(reg, "rootSprite")
	hideMenuSprite(rootSprite)
	--hidePopupSprites()
	require "module.common.SceneUtils"
	SetReturn1("MODULE:\\menuSetting.xml")	
	FreeCurScene()
	Go2Scene("MODULE:\\menuSetting.xml")	
	--SetReturn(sceneHome,sceneSearch)
end
function FreeCurScene()
	require "module.common.registerScene"
	require "module.common.SceneUtils"
	require "module.common.commonMsg"
	local	regQuick = registerCreate(keyQuickLauncherBar);
	local	rootSprite = registerGetInteger(regQuick, "rootSprite")
	local	rootScene = GetRootSprite(rootSprite)
	--发给当前场景
	SendSpriteEvent(rootScene, MSG_RETURN)	--	MSG_RETURN	= USER_MSG + 99  
	return 1
end

function systools(sprite,keyCode)
	WriteLogs("-------------------++++++++++++++++++++++++++++:"..keyCode)
	item=GetParentSprite(sprite)
	local menuList=GetParentSprite(GetParentSprite(sprite))
	itemCount = SpriteList_GetListItemCount(menuList)
	WriteLogs("______name:"..GetSpriteName(menuList))
	index = SpriteListItem_GetIndex(item)
	
	 toolreg=registerCreate("toolButtonSprite")
	registerSetInteger(toolreg,"toolButton",FindChildSprite(GetParentSprite(GetParentSprite(sprite)),"menu-sc"))
	 
	 
	 local reg=registerCreate("PassLeft")
	 registerSetInteger(reg,"spritePassLeft",sprite)
	
	WriteLogs(".....index:"..index)
	local list1={"menuitem_open","menuitem_tool","menuitem_file","menuitem_service","menuitem_help","menuitemexit"}
	local list={"menu-sc","menu-zt","menu-sz"}
	local homeLastFoucsReg= registerCreate("homeLastFoucs")
		local lastFocus=registerGetInteger(homeLastFoucsReg,"lastFocusSprite")
	if keyCode==10 and index <=itemCount-1 then
		if index==(itemCount-1) then 
		
		return 0
		else
		listitem=SpriteList_GetListItem(menuList, index+1)
		WriteLogs("---------"..SpriteListItem_GetIndex(listitem))
		cursprite=FindChildSprite(listitem,list[index+2])
		SetSpriteFocus(cursprite)
		result=HasSpriteFocus(cursprite)
		WriteLogs("result:"..result)
		
		end
		
	elseif keyCode == 3 or keyCode== 8 then
		menuItemOnStatusChanged(GetParentSprite(sprite))
		if   index==1	then		
			local  reg = registerCreate("passSprite")
			registerSetInteger(reg, "SettingSprite", sprite)
			local flags=registerCreate("flags")
			local flag=registerGetInteger(flags, "flagtool")
			if flag==1 then
				WriteLogs("flag="..flag)
				local  reg1 = registerCreate("passSprite1")
				local tool=registerGetInteger(reg1, "SettingSprite1")
				WriteLogs("tool..."..GetSpriteName(tool))
				WriteLogs("sprite。 "..GetSpriteName(sprite))
				popMenuOnSelect(sprite)
				SetSpriteFocus(tool)
				WriteLogs("success"..HasSpriteFocus(tool))
				SetSpriteVisible(GetParentSprite(GetParentSprite(tool)),1)
				SetSpriteEnable(GetParentSprite(GetParentSprite(tool)),1)
			else 	
				popMenuOnSelect(sprite)			
			end
		else
			if name=="menu-sc" then addFavOnSelect(sprite)
			elseif name=="menuitem_setting" then settingOnSelect(sprite)
			end
		end
	
	
	elseif keyCode==7 then
			flag=1
			local flagReg=registerCreate("flagnum")
			registerSetInteger(flagReg,"flagnum",flag)
			local regInfor=registerCreate("passSprite")
			local senceSprite=registerGetInteger(regInfor,"CurSprite")
			WriteLogs("=-=-=-=-2013=-012=3012=30"..GetSpriteName(senceSprite))
			SetSpriteFocus(senceSprite)
			
			local regLeft=registerCreate("popL")
			Leftsize=registerGetInteger(regLeft,"pop",popSprite)
			
			ShowPopupMenu(Leftsize,0)

		elseif  keyCode== 8  and index==1 then
		popMenuOnSelect(FindChildSprite(menuList,list[index+1]))	
	
		elseif keyCode == 1 then
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			require("module.menuopen")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
			
		elseif keyCode == 2  then
			require("module.menuopen")
			 reg = registerCreate("sysSprite")
			SenceSprite=registerGetInteger(reg,"sprite_name")
			SetSpriteFocus(SenceSprite)
			returnButtonOnSelect(sprite)
			
	
	elseif keyCode==9 and index>=1 then
		WriteLogs("IsSpriteEnable:"..isEnable)
		if index==1 and 0 == isEnable then 
		WriteLogs("isEnable")
		return
		else
		listitem=SpriteList_GetListItem(menuList, index-1)
		WriteLogs("---------"..SpriteListItem_GetIndex(listitem))
		cursprite=FindChildSprite(listitem,list[index])
		SetSpriteFocus(cursprite)
		
		end
	end
		return 0
end


function ShowPopupMenu(popSprite, show)
	if show == 0 then
		SetSpriteVisible(popSprite, 0);
		SetSpriteEnable(popSprite, 0);
		childPopSprite = FindChildSpriteByClass(popSprite, "list");
		if childPopSprite ~= 0 then
			SpriteList_SetCurItem(childPopSprite, -1);
		end
	else
		SetSpriteVisible(popSprite, 1);
		SetSpriteEnable(popSprite, 1);
	end
end

