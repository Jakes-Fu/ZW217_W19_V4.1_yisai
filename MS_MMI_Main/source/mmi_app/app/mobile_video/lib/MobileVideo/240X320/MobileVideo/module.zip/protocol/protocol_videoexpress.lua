--author ljc
--date	2010/06/01
-- request videoexpress
function RequestMessageContent(protocolNumber, recommendContentUrl)

	local regSystem = registerCreate("System")
	local http = pluginCreate("HttpPipe")
	local observer = pluginGetObserver()
	local fileName = GetLocalFilename(recommendContentUrl)
	local reg = registerCreate("videoexpress")
	registerSetString(reg, "videoExpressFileName", fileName)
	pluginInvoke(http, "AppendCommand", 0, recommendContentUrl, "", fileName, observer, protocolNumber, 0,1)
WriteLogs("RequestMessageContent-end")
end

function OnMessageContentDecode()
	WriteLogs("OnMessageContentDecode-start")
	local reg = registerCreate("videoexpress")
	local fileName = registerGetString(reg, "videoExpressFileName")

	--test data
	--fileName = "CACHE:\\88d174b75e8f4cc628f4bc003b981111.txt"

	WriteLogs("fileName=="..fileName)
	if fileName ~= nil and fileName ~= "" then
		return jsonLoadFile(fileName)
	end
	WriteLogs("OnMessageContentDecode-end")
	return nil
end