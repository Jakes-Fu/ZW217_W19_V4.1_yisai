﻿--author czj
--date	2010/06/09
-- 加入下载队列
require "module.setting"
function AppendDownloadQueue(videoUrl,name,isMyVideo)
	if isMyVideo == nil then
		local FlashCardName = GetFlashCardName()
		if FlashCardName and FlashCardName ~= "" then
			return ExcuteDownload(Cfg.GetDownloadPath(),videoUrl,name)
		else
			if Cfg.GetDownloadPathCfg() == "card" then
				WriteLogs("没有存储卡却设置在存储卡上")
				return -2
			end
			return ExcuteDownload(Cfg.GetDownloadPath(),videoUrl,name)
		end
	elseif isMyVideo == 1 then
		local folder = GetDefaultFolder(WDFIDL_MYVIDIO)
		return ExcuteDownload(folder,videoUrl,name)
	end
end

function AppendDownloadQueueForMagazine(videoUrl,name,protocolnumber,newName)
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	local observer = pluginGetObserver()
	local path = GetModuleFolder().."module\\videoexpress\\"..name..".zip"
	WriteLogs("Magazine filepath : ".. path)
	download = pluginCreate("Download")
	local result = pluginInvoke(download, "Append", videoUrl , path, newName)
	return result
	--pluginInvoke(http, "AppendCommand", 0, videoUrl, 0, path, observer, protocolnumber, 0,1)
end

function AppendDownloadQueueForMagazine_ForExpress(videoUrl,name,protocolnumber,newName)
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	local observer = pluginGetObserver()
	local path = GetModuleFolder().."module\\videoexpress\\"..name..".zip"
	WriteLogs("Magazine filepath : ".. path)
	pluginInvoke(http, "AppendCommand", 0, videoUrl, 0, path, observer, protocolnumber, 0,1)
end

function GetLocalSpace()
	--从配置文件读下载路径
	--local reg = registerCreate("setting")
	--registerLoad(reg, "MODULE:\\config.xml")
	--local downloadPath = registerGetString(reg, "path")
	local downloadPath = Cfg.GetDownloadPath();

	local spaceh, spacel = GetDiskFreeSpaceEx(downloadPath)
	return spaceh,spacel
end

function ExcuteDownload(path, videoUrl, name)
	download = pluginCreate("Download")
	local result = pluginInvoke(download, "Append", videoUrl , path.."temp_"..name..Cfg.GetVideoType(), "temp_"..name)
	local regSys = registerCreate("System")
	registerSetInteger(regSys,"Download",download)
	return result
end
