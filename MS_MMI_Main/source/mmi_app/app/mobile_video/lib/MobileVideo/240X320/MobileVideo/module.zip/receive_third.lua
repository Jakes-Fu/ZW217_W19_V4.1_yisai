﻿--@module receive_third
--@note 收件箱三级菜单
--@author cuiyizhou
--@date 2010/05/30
require "module.Loading.useLoading"
require "module.common.SceneUtils"
require "module.common.registerScene"
function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("receive_third")   
	registerSetInteger(reg, "root", sprite)
	createSubjectList(sprite)
	return 1
end

--@function createSubjectList
--@brief 创建列表元素
function createSubjectList(sprite)
	local reg_f = registerCreate("friendsrecommended_detail")
	local itemNo = registerGetString(reg_f,"ItemNo")
	local listNo = registerGetString(reg_f,"ListNo")
	local reg_t = registerCreate("receive_third")
	registerSetInteger(reg_t,"root",sprite)
	local reg = registerCreate("temp")

	registerLoad(reg, "MODULE:\\videoexpress\\categoryID"..listNo..".xml")
	local itemIndex = "item"..itemNo
	
	--设置三级的标题
	local name = FindValue(reg, itemIndex, "MsgTitle")
	local titleSprite1 = FindChildSprite(sprite, "info-caption1")
	SetSpriteProperty(titleSprite1, "text", name)
	local titleSprite2 = FindChildSprite(sprite, "info-caption2")
	SetSpriteProperty(titleSprite2, "text", name)
	--设置三级的列表
	subjectArray = {}
	local MsgCount = FindValue(reg, itemIndex, "MsgCount")
	if MsgCount ~= nil and MsgCount ~= "" then
		nMax = tonumber(MsgCount)
	end
	
		
	for i = 1, nMax do
		subjectArray[i] = {
					ContentId 	= FindValue(reg, itemIndex, "ContentId"..i),
					ContentName	= FindValue(reg, itemIndex, "ContentName"..i),
					StarLevel	= FindValue(reg, itemIndex, "StarLevel"..i),
					UrlPath		= FindValue(reg, itemIndex, "UrlPath"..i),
					PlayUrl		= FindValue(reg, itemIndex, "PlayUrl"..i),
					Category	= FindValue(reg, itemIndex, "Category"..i),
					Type		= FindValue(reg, itemIndex, "Type"..i),
					FormType	= FindValue(reg, itemIndex, "FormType"..i),
					DisplayType	= FindValue(reg, itemIndex, "DisplayType"..i)
		  	          }
	end






	local spriteList = FindChildSprite(sprite, "listboard-item")
	--[[  创建列表元素，此处应该使用网络数据  ]]--

	if (subjectArray ~= nil ) then
		count = table.maxn(subjectArray)
		local xmlNode=xmlLoadFile("MODULE:\\receive_third_listItem.xml")
		for i=1, count do
			local menuprograminfoSprite = CreateSprite("listitem")
			LoadSpriteFromNode(menuprograminfoSprite, xmlNode)
			--[[  设置item区域大小  ]]--
			SetSpriteRect(menuprograminfoSprite, 0, 0, 205, 25)
			--[[  设置列表设置列表上的文字内容  ]]--
			if subjectArray[i].ContentName then
				local spritetextN = FindChildSprite(menuprograminfoSprite, "subjectButtontextN")
				SetSpriteProperty(spritetextN, "text", subjectArray[i].ContentName)
				local spritetextF = FindChildSprite(menuprograminfoSprite, "subjectButtontextF")
				SetSpriteProperty(spritetextF, "text", subjectArray[i].ContentName)
			end
			--[[  插入到list中  ]]--
			AddChildSprite(spriteList, menuprograminfoSprite)
			SpriteList_AddListItem(spriteList, menuprograminfoSprite)
		end
		xmlRelease(xmlNode)
	end
	--[[  自动调整item之间间隔  ]]--
	SpriteList_Adjust(spriteList)
	--[[  统一滚动条创建  ]]--
	require "module.common.commonScroll"
	CreateScrollBar(sprite,"receive-third-list",count*25+25,76)
	--SpriteList_SetStartItem(spriteList,4)
end

--@function ItemOnSelect
--@tag-name rowitem receive_third_listItem.xml中
--@tag-action button:OnSelect
--@brief 选择内容完成跳转
function ItemOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local reg = registerCreate("receive_third")   
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root ,"loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	
	local num = SpriteListItem_GetIndex(sprite)
	local volumeurl = subjectArray[num + 1].UrlPath
	if volumeurl then
		require "module.protocol.protocol_infovolume"
		RequestVolume(106, volumeurl)
	else
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据错误", "BT_OK", sceneReceiveThird, sceneReceiveThird)
		Go2Scene(sceneDialog)
	end	
end

--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	if message == 106 then
		local volumeData = OnVolumeDecode() 
		if volumeData then
			exitLoading()
			local thirdSprite = GetCurScene()
			FreeScene(thirdSprite)
			Go2Scene(scenePrograminfo_volume)
		else
			--[[  出错提示  ]]--
		end
	elseif message > 32768 and message ~= MSG_SMS_ID + 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneReceiveThird, sceneReceiveThird, nil)
		Go2Scene(sceneDialog)
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneReceiveThird, sceneReceiveThird)
	end
	return 1
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
end

function FindValue(reg,itemNo,categoryName)
	local data = registerGetString(reg,itemNo)
	local i,j = string.find(data,"{"..categoryName.."}")
	if j then 
		i = string.find(data,"{",j+1)
		j = string.find(data,"}",j+1)
		if j == i+1 then
			return ""
		else
			return string.sub(data,i+1,j-1)
		end
	else
		return ""
	end
end