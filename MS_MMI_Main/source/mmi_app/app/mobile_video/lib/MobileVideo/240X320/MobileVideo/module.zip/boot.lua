﻿
sprite = CreateSprite("node");
LoadSprite(sprite, "MODULE:\\welcome.xml");
SetCurScene(sprite);
