﻿
--
require "module.dialog.useDialog"
require "module.protocol.protocol_videoexpress"
require "module.common.registerScene"
require("module.common.SceneUtils")
require "module.setting"


local FRIENDSRECOMMENDED_DETAIL = "friendsrecommended_detail"
local MSG_CONTENT_REQUEST = Cfg.GetServer()..Cfg.GetPortal().."/msp/qryMsg.msp?msgId="
--local smsRecommendFileName = "\\Windows\\smsrecommend.txt"
local folder = GetDefaultFolder(WDFIDL_MMS)

local smsRecommendFileName = folder.."smsrecommend.txt"   		--"MODULE:\\smsrecommend.txt"
MSG_SMS_ID = 2001 --通过msgID向服务器请求数据的参数message的值
recommendMsgSuc = "true"

--收到推荐短信切换到提示对话框界面
--@content为内容，backScene返回的场景，background为背景，dialogsprite为按钮事件的节点title为标题
function changeDialog(title, content, backScene, background)
	if "true" == GetMessageContentResult() then
		setDialogParam(title, content, "BT_OK_CANCEL", backScene, nil)
	else
		setDialogParam(title, content, "BT_OK", backScene, nil)
	end
	if backScene == sceneWelcome then
		GoAndFreeScene(sceneRecommendMsgDialog,1)
	else
		GoAndFreeScene(sceneRecommendMsgDialog)
	end
end

--处理服务器返回的结果,
--@backScene返回的场景，background为背景
function DealMsgContent(backScene, background)
	removeSmsRecommend()					--读到就删
	g_backScene = backScene				--检测磁盘剩余空间的时候要用到
	WriteLogs("DealMsgContent()-start")
	json = OnMessageContentDecode()
	
	local reg_vc = registerCreate("videoexpress-common")
	g_isMagazine = registerGetString(reg_vc, "isMagazine")	--是否已经下载视频杂志
	if g_isMagazine == "true" then				--这里处理下载视频杂志后的处理，解压等操作
		WriteLogs("Finish Download Magazine,Start Unzip:")
		magazineItemName = json.msg[0].channelName
		if magazineItemName and magazineItemName ~= "" then
			Makefolder("MODULE:\\videoexpress\\"..magazineItemName)
			local src = "MODULE:\\videoexpress\\"..magazineItemName..".zip"
			local target = "MODULE:\\videoexpress\\"..magazineItemName.."\\"
			local unzip = BeginUnzip(src, target)
			if not unzip then
				WriteLogs("bad ZPKG file")
			else
				while GoToUnzipNextFile(unzip) do
					ProcessUnzip(unzip)
				end
				EndUnzip(unzip)
			end
		end
		os.remove("MODULE:\\videoexpress\\"..magazineItemName..".zip")
		registerSetString(reg_vc, "isMagazine", "")
		g_isMagazine = ""
	elseif json.categoryID == "5" and g_isMagazine ~= "true" then				--如果是视频杂志，且还没有下载，走这里
		WriteLogs("isMagazine,set isMagazineRequest [true]:如果是视频杂志，且还没有下载，走这里")
		local reg_vc = registerCreate("videoexpress-common")
		registerSetString(reg_vc, "isMagazineRequest", "true")				--是否请求下载
		g_isMagazine = "true"
		requestMsgContent()
	end
	

	if nil == json then
		--提示失败
		WriteLogs("json是空")
		return
	end
	local categoryName
	if nil == json.categoryName then
		categoryName = ""
	else
		categoryName = json.categoryName
		WriteLogs("DealMsgContent()-categoryName="..categoryName)
	end



	if "true" == json.success  then
		SetMessageContentResult(json.success)
		--好友号码,需要服务器提供
		--推荐内容,json.msgContent
		local promptContent = ""
		--插入电话号码提示
		if nil ~= json.sendPhoneNum and "" ~= json.sendPhoneNum then
			promptContent =promptContent..json.sendPhoneNum.."推荐："
			WriteLogs("DealMsgContent()-promptContent="..promptContent)
		end
		if nil ~= json.categoryID and "" ~= json.categoryID then
			if json.categoryID == "6" then
				--好友推荐是用contentName，其他消息用msgTitle
				if nil ~= json.msg[0].contentName and "" ~= json.msg[0].contentName then
					local reg_video = registerCreate("video") 
					registerSetString(reg_video, "smsAtPlayer", json.msg[0].contentName)
					promptContent =promptContent..json.msg[0].contentName.."是否查看"
					WriteLogs("DealMsgContent()-promptContent="..promptContent)
				end
			else
				if nil ~= json.msgTitle and "" ~= json.msgTitle then
					local reg_video = registerCreate("video") 
					registerSetString(reg_video, "smsAtPlayer", json.msgTitle)
					promptContent =promptContent..json.msgTitle.."是否查看"
					WriteLogs("DealMsgContent()-promptContent="..promptContent)
				end
			end
		end

		if "true" == GetMessageContentResult() then			--请求杂志下载，不写xml
			if g_isMagazine ~= "true" then
				WriteLogs("writeMsgContent2XML")
				writeMsgContent2XML(false)
			end
		end

		--需要考虑播放器状态，播放器存在，请求杂志下载，不弹出推荐短信提示对话框
		if backScene ~= sceneVideoLiveDemand and backScene ~= sceneVideoGroup and backScene ~= sceneVideolocal and 
		   backScene ~= sceneVideoLiveDemand_NB and backScene ~= sceneDialog and backScene ~= sceneRecommendMsgDialog and 
		   g_isMagazine ~= "true" then
			local reg_vc = registerCreate("videoexpress-common")
			local requestIndex = registerGetInteger(reg_vc, "requestIndex")
			if MsgTotalCount == requestIndex then
				changeDialog(categoryName, promptContent, backScene, background)
			end
		else

		end
	elseif "false" == json.success  then--失败
		SetMessageContentResult(json.success)
		local desc = json.desc
		if nil == desc then
			desc = "false"
		end
		--提示失败
		--changeDialog(categoryName, desc, backScene, background)
		WriteLogs("*************************视频快车***********************")
		WriteLogs("失败----》》》》》》》"..desc)

		--判断是否是客户端未启动状态
		local reg_System = registerCreate("System")
		local isToExit = registerGetString(reg_System, "isToExit", "true")
		if isToExit == "true" then
			Exit()
		end
	end

	WriteLogs("DealMsgContent()-end")
end

--把获得的短信内容存到XML中
--@isOk为true是用户选择确定按钮保存到具体信息类别文件中，false是取消按钮保存到未读信息文件中
function writeMsgContent2XML(isOk)
WriteLogs("writeXML()-start")
	local json = OnMessageContentDecode() --这里需要修改，现在只考虑用户在按OK前，当前只会有一条推荐短信
	if nil == json then
		return
	end
	if nil ~= json.success and "true" == json.success  then
		local year, month, day, hour, minute, second = GetTime()
		local receiveData = year.."-"..(month).."-"..(day).." "..(hour)..":"..(minute)..":"..(second)
		WriteLogs("receiveData -->"..receiveData)


		local regCategory = registerCreate("Category")
		local messageContent = "" --把接收的json解析成字符窜保存到XML的value里

		messageContent = messageContent.."{receiveData}:{"..receiveData.."},"

		if nil ~= json.sendPhoneNum and "" ~= json.sendPhoneNum then
			if messageContent then
				messageContent = messageContent.."{sendPhoneNum}:{"..json.sendPhoneNum.."},"
				WriteLogs("writeMsgContent2XML()-json.sendPhoneNum="..json.sendPhoneNum)
			else
				messageContent = "{sendPhoneNum}:{"..json.sendPhoneNum.."},"
				WriteLogs("writeMsgContent2XML()-json.sendPhoneNum="..json.sendPhoneNum)
			end
		end

		if nil ~= json.categoryID and "" ~= json.categoryID then
			if json.categoryID == "6" then
				--好友推荐是用contentName，其他消息用msgTitle
				if nil ~= json.msg[0].contentName and "" ~= json.msg[0].contentName then
					if messageContent then
						messageContent = messageContent.."{MsgTitle}:{"..json.msg[0].contentName.."},"		--服务器改成数组后还需加上【1】
					else
						messageContent = "{MsgTitle}:{"..json.msg[0].contentName.."},"
					end
				end
			else
				if nil ~= json.msgTitle and "" ~= json.msgTitle then
					if messageContent then
						messageContent = messageContent.."{MsgTitle}:{"..json.msgTitle.."},"
						WriteLogs("writeMsgContent2XML()-json.msgTitle="..json.msgTitle)
					else
						messageContent = "{MsgTitle}:{"..json.msgTitle.."},"
					end
				end
			end
		end

		if nil ~= json.msgContent and "" ~= json.msgContent then
			if messageContent then
				messageContent = messageContent.."{msgContent}:{"..json.msgContent.."},"
				WriteLogs("writeMsgContent2XML()-json.msgContent="..json.msgContent)
			else
				messageContent = "{msgContent}:{"..json.msgContent.."},"
			end
		end
		if nil ~= json.categoryID and "" ~= json.categoryID then
			if messageContent then
				messageContent = messageContent.."{categoryID}:{"..json.categoryID.."},"
				WriteLogs("writeMsgContent2XML()-json.categoryID="..json.categoryID)
			else
				messageContent = "{categoryID}:{"..json.categoryID.."},"
			end
			--以下是帮服务器容错
			if json.categoryID == "1" and "" == json.categoryName then
				messageContent = messageContent.."{categoryName}:{".."营销信息".."},"
			elseif json.categoryID == "2" and "" == json.categoryName then
				messageContent = messageContent.."{categoryName}:{".."视频内容".."},"
			elseif json.categoryID == "3" and "" == json.categoryName then
				messageContent = messageContent.."{categoryName}:{".."直播节目单".."},"
			elseif json.categoryID == "4" and "" == json.categoryName then
				messageContent = messageContent.."{categoryName}:{".."专题消息".."},"
			elseif json.categoryID == "5" and "" == json.categoryName then
				messageContent = messageContent.."{categoryName}:{".."视频杂志".."},"
			elseif json.categoryID == "6" and "" == json.categoryName then
				messageContent = messageContent.."{categoryName}:{".."好友推荐".."},"
			end
		end
		if nil ~= json.categoryName and "" ~= json.categoryName then
			if messageContent then
				messageContent = messageContent.."{categoryName}:{"..json.categoryName.."},"
				WriteLogs("writeMsgContent2XML()-json.categoryName="..json.categoryName)
			else
				messageContent = "{categoryName}:{"..json.categoryName.."},"
			end
		end

		--msg字段分为专题消息和非专题消息
		if json.categoryID ~= "4" then
			if nil ~= json.msg and "" ~= json.msg then
				local nMax = table.maxn(json.msg)
				WriteLogs("nMax="..nMax)
				for i=0, nMax  do
					--if "1" == json.msgType then
						if messageContent then
							messageContent = messageContent.."{MsgType}:{"..json.msgType.."},"
							WriteLogs("writeMsgContent2XML()-json.msgType="..json.msgType)
						else
							messageContent = "{MsgType}:{"..json.msgType.."},"
						end
						if nil ~= json.msg[i].contentId and "" ~= json.msg[i].contentId then
							if messageContent then
								messageContent = messageContent.."{ContentId}:{"..json.msg[i].contentId.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].contentId="..json.msg[i].contentId)
							else
								messageContent = "{ContentId}:{"..json.msg[i].contentId.."},"
							end
						end
						if nil ~= json.msg[i].contentName and "" ~= json.msg[i].contentName then
							if messageContent then
								messageContent = messageContent.."{ContentName}:{"..json.msg[i].contentName.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].contentName="..json.msg[i].contentName)
							else
								messageContent = "{ContentName}:{"..json.msg[i].contentName.."},"
							end
						end
						if nil ~= json.msg[i].starLevel and "" ~= json.msg[i].starLevel then
							if messageContent then
								messageContent = messageContent.."{StarLevel}:{"..json.msg[i].starLevel.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].starLevel="..json.msg[i].starLevel)
							else
								messageContent = "{StarLevel}:{"..json.msg[i].starLevel.."},"
							end
						end
						if nil ~= json.msg[i].urlPath and "" ~= json.msg[i].urlPath then
							if json.categoryID ~= "5" then
								if messageContent then
									--local strXmlUrl = string.gsub(json.msg.urlPath, "&", "&amp;")
									messageContent = messageContent.."{UrlPath}:{"..json.msg[i].urlPath.."},"
									WriteLogs("writeMsgContent2XML()-json.msg[i].urlPath="..json.msg[i].urlPath)
								else
									messageContent = "{UrlPath}:{"..json.msg[i].urlPath.."},"
								end
							else
								if messageContent and json and json.msg[i] and json.msg[i].channelName then
									messageContent = messageContent.."{UrlPath}:{MODULE:\\videoexpress\\"..json.msg[i].channelName.."\\cover.js},"
								else
									messageContent = "{UrlPath}:{MODULE:\\videoexpress\\"..json.msg[i].channelName.."\\cover.js},"
								end
							end
						end
						if nil ~= json.msg[i].playUrl and "" ~= json.msg[i].playUrl then
							if messageContent then
								--local strXmlUrl = string.gsub(json.msg[i].playUrl, "&", "&amp;")
								messageContent = messageContent.."{PlayUrl}:{"..json.msg[i].playUrl.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].playUrl="..json.msg[i].playUrl)
							else
								messageContent = "{PlayUrl}:{"..json.msg[i].playUrl.."},"
							end
						end
						if nil ~= json.msg[i].category and "" ~= json.msg[i].category then
							if messageContent then
								messageContent = messageContent.."{Category}:{"..json.msg[i].category.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].category="..json.msg[i].category)
							else
								messageContent = "{Category}:{"..json.msg[i].category.."},"
							end
						end
						if nil ~= json.msg[i].type and "" ~= json.msg[i].type then
							if messageContent then
								messageContent = messageContent.."{Type}:{"..json.msg[i].type.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].type="..json.msg[i].type)
							else
								messageContent = "{Type}:{"..json.msg[i].type.."},"
							end
						end
						if nil ~= json.msg[i].formType and "" ~= json.msg[i].formType then
							if messageContent then
								messageContent = messageContent.."{FormType}:{"..json.msg[i].formType.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].formType="..json.msg[i].formType)
							else
								messageContent = "{FormType}:{"..json.msg[i].formType.."},"
							end
						end
						if nil ~= json.msg[i].displayType and "" ~= json.msg[i].displayType then
							if messageContent then
								messageContent = messageContent.."{DisplayType}:{"..json.msg[i].displayType.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].displayType="..json.msg[i].displayType)
							else
								messageContent = "{DisplayType}:{"..json.msg[i].displayType.."},"
							end
						end
				--	elseif "" == json.msgType then
						if messageContent then
							messageContent = messageContent.."{MsgType}:{"..json.msgType.."},"
							WriteLogs("writeMsgContent2XML()-json.msgType="..json.msgType)
						else
							messageContent = "{MsgType}:{"..json.msgType.."},"
						end
						if nil ~= json.msg[i].channelId and "" ~= json.msg[i].channelId then
							if messageContent then
								messageContent = messageContent.."{ChannelId}:{"..json.msg[i].channelId.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].channelId="..json.msg[i].channelId)
							else
								messageContent = "{ChannelId}:{"..json.msg[i].channelId.."},"
							end
						end
						if nil ~= json.msg[i].channelName and "" ~= json.msg[i].channelName then
							if messageContent then
								messageContent = messageContent.."{ChannelName}:{"..json.msg[i].channelName.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].channelName="..json.msg[i].channelName)
							else
								messageContent = "{ChannelName}:{"..json.msg[i].channelName.."},"
							end
						end
						if nil ~= json.msg[i].urlPath and "" ~= json.msg[i].urlPath then
							if json.categoryID ~= "5" then
								if messageContent then
									--local strXmlUrl = string.gsub(json.msg.urlPath, "&", "&amp;")
									messageContent = messageContent.."{UrlPath}:{"..json.msg[i].urlPath.."},"
									WriteLogs("writeMsgContent2XML()-json.msg[i].urlPath="..json.msg[i].urlPath)
								else
									messageContent = "{UrlPath}:{"..json.msg[i].urlPath.."},"
								end
							else
								if messageContent and json and json.msg[i] and json.msg[i].channelName then
									messageContent = messageContent.."{UrlPath}:{MODULE:\\videoexpress\\"..json.msg[i].channelName.."\\cover.js},"
								else
									messageContent = "{UrlPath}:{MODULE:\\videoexpress\\"..json.msg[i].channelName.."\\cover.js},"
								end
							end
						end
						if nil ~= json.msg[i].img and "" ~= json.msg[i].img then
							if messageContent then
								messageContent = messageContent.."{Img}:{"..json.msg[i].img.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].img="..json.msg[i].img)
							else
								messageContent = "{Img}:{"..json.msg[i].img.."},"
							end
						end
						if nil ~= json.msg[i].hlImg and "" ~= json.msg[i].hlImg then
							if messageContent then
								messageContent = messageContent.."{HlImg}:{"..json.msg[i].hlImg.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].hlImg="..json.msg[i].hlImg)
							else
								messageContent = "{HlImg}:{"..json.msg[i].hlImg.."},"
							end
						end
						if nil ~= json.msg[i].channelType and "" ~= json.msg[i].channelType then
							if messageContent then
								messageContent = messageContent.."{ChannelType}:{"..json.msg[i].channelType.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].channelType="..json.msg[i].channelType)
							else
								messageContent = "{ChannelType}:{"..json.msg[i].channelType.."},"
							end
						end
						if nil ~= json.msg[i].nodeDisplayType and "" ~= json.msg[i].nodeDisplayType then
							if messageContent then
								messageContent = messageContent.."{NodeDisplayType}:{"..json.msg[i].nodeDisplayType.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].nodeDisplayType="..json.msg[i].nodeDisplayType)
							else
								messageContent = "{NodeDisplayType}:{"..json.msg[i].nodeDisplayType.."},"
							end
						end
						if nil ~= json.msg[i].contentName and "" ~= json.msg[i].contentName then
							if messageContent then
								messageContent = messageContent.."{ContentName}:{"..json.msg[i].contentName.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].contentName="..json.msg[i].contentName)
							else
								messageContent = "{ContentName}:{"..json.msg[i].contentName.."},"
							end
						end
					--end
				end
			end

		elseif json.categoryID == "4" then	--if json.categoryID ~= 4
				local nMax = table.maxn(json.msg)
				WriteLogs("nMax----"..nMax)
				local MsgCount = nMax+1
				if messageContent then
					messageContent = messageContent.."{MsgCount}:{"..MsgCount.."},"
					WriteLogs("writeMsgContent2XML()-MsgCount"..MsgCount)
				else
					messageContent = "{MsgCount}:{"..MsgCount.."},"
				end
				for i=0, nMax  do
					--if "1" == json.msgType then
						if messageContent then
							messageContent = messageContent.."{MsgType" .. i+1 .. "}:{"..json.msgType.."},"
							WriteLogs("writeMsgContent2XML()-json.msgType="..json.msgType)
						else
							messageContent = "{MsgType" .. i+1 .. "}:{"..json.msgType.."},"
						end
						if nil ~= json.msg[i].contentId and "" ~= json.msg[i].contentId then
							if messageContent then
								messageContent = messageContent.."{ContentId" .. i+1 .. "}:{"..json.msg[i].contentId.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].contentId="..json.msg[i].contentId)
							else
								messageContent = "{ContentId" .. i+1 .. "}:{"..json.msg[i].contentId.."},"
							end
						end
						if nil ~= json.msg[i].contentName and "" ~= json.msg[i].contentName then
							if messageContent then
								messageContent = messageContent.."{ContentName" .. i+1 .. "}:{"..json.msg[i].contentName.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].contentName="..json.msg[i].contentName)
							else
								messageContent = "{ContentName" .. i+1 .. "}:{"..json.msg[i].contentName.."},"
							end
						end
						if nil ~= json.msg[i].starLevel and "" ~= json.msg[i].starLevel then
							if messageContent then
								messageContent = messageContent.."{StarLevel" .. i+1 .. "}:{"..json.msg[i].starLevel.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].starLevel="..json.msg[i].starLevel)
							else
								messageContent = "{StarLevel" .. i+1 .. "}:{"..json.msg[i].starLevel.."},"
							end
						end
						if nil ~= json.msg[i].urlPath and "" ~= json.msg[i].urlPath then
							if messageContent then
								--local strXmlUrl = string.gsub(json.msg.urlPath, "&", "&amp;")
								messageContent = messageContent.."{UrlPath" .. i+1 .. "}:{"..json.msg[i].urlPath.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].urlPath="..json.msg[i].urlPath)
							else
								messageContent = "{UrlPath" .. i+1 .. "}:{"..json.msg[i].urlPath.."},"
							end
						end
						if nil ~= json.msg[i].playUrl and "" ~= json.msg[i].playUrl then
							if messageContent then
								--local strXmlUrl = string.gsub(json.msg[i].playUrl, "&", "&amp;")
								messageContent = messageContent.."{PlayUrl" .. i+1 .. "}:{"..json.msg[i].playUrl.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].playUrl="..json.msg[i].playUrl)
							else
								messageContent = "{PlayUrl" .. i+1 .. "}:{"..json.msg[i].playUrl.."},"
							end
						end
						if nil ~= json.msg[i].category and "" ~= json.msg[i].category then
							if messageContent then
								messageContent = messageContent.."{Category" .. i+1 .. "}:{"..json.msg[i].category.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].category="..json.msg[i].category)
							else
								messageContent = "{Category" .. i+1 .. "}:{"..json.msg[i].category.."},"
							end
						end
						if nil ~= json.msg[i].type and "" ~= json.msg[i].type then
							if messageContent then
								messageContent = messageContent.."{Type" .. i+1 .. "}:{"..json.msg[i].type.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].type="..json.msg[i].type)
							else
								messageContent = "{Type" .. i+1 .. "}:{"..json.msg[i].type.."},"
							end
						end
						if nil ~= json.msg[i].formType and "" ~= json.msg[i].formType then
							if messageContent then
								messageContent = messageContent.."{FormType" .. i+1 .. "}:{"..json.msg[i].formType.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].formType="..json.msg[i].formType)
							else
								messageContent = "{FormType" .. i+1 .. "}:{"..json.msg[i].formType.."},"
							end
						end
						if nil ~= json.msg[i].displayType and "" ~= json.msg[i].displayType then
							if messageContent then
								messageContent = messageContent.."{DisplayType" .. i+1 .. "}:{"..json.msg[i].displayType.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].displayType="..json.msg[i].displayType)
							else
								messageContent = "{DisplayType" .. i+1 .. "}:{"..json.msg[i].displayType.."},"
							end
						end
					--elseif "2" == json.msgType then
						if messageContent then
							messageContent = messageContent.."{MsgType" .. i+1 .. "}:{"..json.msgType.."},"
							WriteLogs("writeMsgContent2XML()-json.msgType="..json.msgType)
						else
							messageContent = "{MsgType" .. i+1 .. "}:{"..json.msgType.."},"
						end
						if nil ~= json.msg[i].channelId and "" ~= json.msg[i].channelId then
							if messageContent then
								messageContent = messageContent.."{ChannelId" .. i+1 .. "}:{"..json.msg[i].channelId.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].channelId="..json.msg[i].channelId)
							else
								messageContent = "{ChannelId" .. i+1 .. "}:{"..json.msg[i].channelId.."},"
							end
						end
						if nil ~= json.msg[i].channelName and "" ~= json.msg[i].channelName then
							if messageContent then
								messageContent = messageContent.."{ChannelName" .. i+1 .. "}:{"..json.msg[i].channelName.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].channelName="..json.msg[i].channelName)
							else
								messageContent = "{ChannelName" .. i+1 .. "}:{"..json.msg[i].channelName.."},"
							end
						end
						if nil ~= json.msg[i].urlPath and "" ~= json.msg[i].urlPath then
							if messageContent then
								--local strXmlUrl = string.gsub(json.msg.urlPath, "&", "&amp;")
								messageContent = messageContent.."{UrlPath" .. i+1 .. "}:{"..json.msg[i].urlPath.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].urlPath="..json.msg[i].urlPath)
							else
								messageContent = "{UrlPath" .. i+1 .. "}:{"..json.msg[i].urlPath.."},"
							end
						end
						if nil ~= json.msg[i].img and "" ~= json.msg[i].img then
							if messageContent then
								messageContent = messageContent.."{Img" .. i+1 .. "}:{"..json.msg[i].img.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].img="..json.msg[i].img)
							else
								messageContent = "{Img" .. i+1 .. "}:{"..json.msg[i].img.."},"
							end
						end
						if nil ~= json.msg[i].hlImg and "" ~= json.msg[i].hlImg then
							if messageContent then
								messageContent = messageContent.."{HlImg" .. i+1 .. "}:{"..json.msg[i].hlImg.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].hlImg="..json.msg[i].hlImg)
							else
								messageContent = "{HlImg" .. i+1 .. "}:{"..json.msg[i].hlImg.."},"
							end
						end
						if nil ~= json.msg[i].channelType and "" ~= json.msg[i].channelType then
							if messageContent then
								messageContent = messageContent.."{ChannelType" .. i+1 .. "}:{"..json.msg[i].channelType.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].channelType="..json.msg[i].channelType)
							else
								messageContent = "{ChannelType" .. i+1 .. "}:{"..json.msg[i].channelType.."},"
							end
						end
						if nil ~= json.msg[i].nodeDisplayType and "" ~= json.msg[i].nodeDisplayType then
							if messageContent then
								messageContent = messageContent.."{NodeDisplayType" .. i+1 .. "}:{"..json.msg[i].nodeDisplayType.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].nodeDisplayType="..json.msg[i].nodeDisplayType)
							else
								messageContent = "{NodeDisplayType" .. i+1 .. "}:{"..json.msg[i].nodeDisplayType.."},"
							end
						end
						if nil ~= json.msg[i].contentName and "" ~= json.msg[i].contentName then
							if messageContent then
								messageContent = messageContent.."{ContentName" .. i+1 .. "}:{"..json.msg[i].contentName.."},"
								WriteLogs("writeMsgContent2XML()-json.msg[i].contentName="..json.msg[i].contentName)
							else
								messageContent = "{ContentName" .. i+1 .. "}:{"..json.msg[i].contentName.."},"
							end
						end
					--end
				end
		end

		if nil ~= json.categoryID and "" ~= json.categoryID then
			--保存categoryID到下一个场景
			local regCreate = registerCreate(FRIENDSRECOMMENDED_DETAIL)
			registerSetString(regCreate, "recommendMsgCategoryID", json.categoryID)






			registerSetString(regCreate, "type", "SMS")
			local filename ="MODULE:\\videoexpress\\categoryID" --x.xml,
			if (true == isOk) then
				filename = filename..json.categoryID..".xml"
			else
				filename = filename.."0.xml" --如果选中cancel就保存在未读短信中,当用户浏览过，应从未读栏中移到分类栏中
			end
			--需判断文件是否存在，不存在则创建新文件
			require "module.common.io"
			local fileExist = fileExist(filename)
			if nil == fileExist then
				registerSetString(regCategory, "count", "0")
				if json.categoryID == "6" and "" == json.categoryName then
					registerSetString(regCategory, "categoryName", "好友推荐")
				else
					registerSetString(regCategory, "categoryName", json.categoryName)
				end
				registerSave(regCategory, filename)
				WriteLogs("createNewFile 成功")
				local regCategory0 = registerCreate("Category0")
				registerLoad(regCategory0, "MODULE:\\videoexpress\\categoryID0.xml")
				local totalcount = registerGetInteger(regCategory0, "totalcount")
				if tonumber(json.categoryID) > totalcount then
					registerSetString(regCategory0, "totalcount", json.categoryID)
					registerSave(regCategory0, "MODULE:\\videoexpress\\categoryID0.xml")
				end
			end
			WriteLogs("registerSave------------------------------======================filename="..filename)
			--保存到XML中
			registerLoad(regCategory, filename)
			local count = registerGetInteger(regCategory, "count")
			count = count + 1
			WriteLogs("count="..count)
			registerSetString(regCategory, "count", tostring(count)) --用于遍历计算item个数

			--跳转之后读取数据需要的参数
			local reg_f = registerCreate("friendsrecommended_detail")
			registerSetString(reg_f,"ItemNo",count)
			registerSetString(reg_f,"ListNo",json.categoryID)

			if nil ~= messageContent and "" ~= messageContent then
				local itemIndex = "item"..count
				WriteLogs("itemIndex="..itemIndex)
				registerSetString(regCategory, itemIndex, messageContent)
				WriteLogs("messageContent="..messageContent)
			end

			registerSave(regCategory, filename)
			WriteLogs("registerSave------------------------------======================2")
		end
		registerRelease("Category")
		return true
	elseif nil ~= json.success and "false" == json.success then--失败
		local desc = json.desc
		return false
	end
	--registerSetString(regCategory, "item1", "{categoryName}:{未读信息},{MsgType}:{1},{MsgTitle}:{10},{ChannelId}:{11},{ChannelName}:{12},{UrlPath}:{13},{Img}:{14},{HlImg}:{15},{ChannelType}:{16}")
WriteLogs("writeXML()-end")
end

--寻找节点的值
function FindNodeValue(reg,itemNo,nodeName)
	local data = registerGetString(reg,itemNo)
	local i,j = string.find(data,"{"..nodeName.."}")
	if j then
		i = string.find(data,"{",j+1)
		j = string.find(data,"}",j+1)
		return string.sub(data,i+1,j-1)
	else
		return nil
	end
end

--根据msgID请求内容
function requestMsgContent()				
	local reg_vc = registerCreate("videoexpress-common")
	local isMagazineRequest = registerGetString(reg_vc, "isMagazineRequest")
	if isMagazineRequest ~= "true" then							--不是请求杂志下载
		WriteLogs("Not Magazine Download:")
		require "module.protocol.protocol_downloadinfor"
		local spaceh, spacel = GetLocalSpace()
		space = spaceh*4294967296 + spacel
		if space < 100 then
			isDelete = 0
			require "module.dialog.useDialog"
			local reg_vc = registerCreate("videoexpress-common")
			registerSetString(reg_vc, "EnoughSpace","false")
			local curScene = GetCurScene()		
			local menu = FindChildSprite(curScene, "MenuBar")
			local tips = FindChildSprite(menu,"event")	
			local regHandle = registerCreate("SCMngr_handle");
			local SceneName = registerGetString(regHandle, string.format("%d", GetCurScene()))
			if SceneName and SceneName ~= sceneWelcome then
				setDialogParam("收件箱", "存储容量不足，无法接收短信", "BT_OK_CANCEL", SceneName, SceneName,tips)
				Go2Scene(sceneDialog)
			end
			return 0
		end
		local reg_vc = registerCreate("videoexpress-common")
		registerSetString(reg_vc, "EnoughSpace","true")
		if isRecommendMsg() then
			for i = 1, MsgTotalCount do
				local reg_vc = registerCreate("videoexpress-common")
				registerSetInteger(reg_vc, "requestIndex", i)
				WriteLogs("recommendMsgID222[i]--"..recommendMsgID[i])
				local msgContentRequest = MSG_CONTENT_REQUEST..recommendMsgID[i]
				RequestMessageContent(MSG_SMS_ID, msgContentRequest)
			end
		end
	else										--是否请求杂志下载
		require("module.protocol.protocol_downloadinfor")
		WriteLogs("Request Download Magazine:请求杂志下载")
		isMagazineRequest = ""
		local reg_vc = registerCreate("videoexpress-common")
		registerSetString(reg_vc, "isMagazineRequest", "")
		registerSetString(reg_vc, "isMagazine", "true")				--是否已经下载视频杂志
		if json and json.msg and json.msg[0].playUrl and json.msg[0].channelName then
			AppendDownloadQueueForMagazine(json.msg[0].playUrl,json.msg[0].channelName,MSG_SMS_ID)
		end
	end
end


--判断是否是推荐短信启动,返回值为msgID
function isRecommendMsg()
	require "module.common.io"
	recommendMsgContent = {}
	local dir = OpenDirectory(smsRecommendFileName)
	if dir then
		WriteLogs("if dir then--->>>>>>>>>>>>>>>>>>>>>>>>>>>>>"..smsRecommendFileName)
		recommendMsgContent = fileReadToTable(smsRecommendFileName)
		MsgTotalCount = #recommendMsgContent
		require "module.SMS"
		recommendMsgID = {}
		for i=1, MsgTotalCount do
			recommendMsgID[i] = SMS_ParseMessageID(recommendMsgContent[i])
			WriteLogs("recommendMsgID["..i.."]--"..recommendMsgID[i])
		end
	else
		WriteLogs("未找到短信文件")
	end
	if nil == recommendMsgID or "" == recommendMsgID then
		return false
	else
		return true
	end
end

--删除推荐短信文件
function removeSmsRecommend()
	require "module.common.io"
	fileRemove(smsRecommendFileName)
end

function GetMessageContentResult()
	local reg = registerCreate("videoexpress-common")
	WriteLogs("GetMessageContentResult")
	local messageContentResult = registerGetString(reg, "requestMessageContentResult")
	return messageContentResult
end

function SetMessageContentResult(messageContentResult)
	local reg = registerCreate("videoexpress-common")
	WriteLogs("SetMessageContentResult"..messageContentResult)
	registerSetString(reg, "requestMessageContentResult", messageContentResult)
end

-- release this file
function FreeFunction()

end

function formatData(Data)
	if tonumber(Data)< 10 then
		return "0"..Data
	end
end

function GetTime()
	require ("module.protocol.protocol_systime")
	local jsonfile = OnSysDataDecode()
	if jsonfile and jsonfile.sysDate then
		local year, month, day, hour, minute, second = ParseDate(jsonfile.sysDate)
		return ParseDate(jsonfile.sysDate)
	else
		local m_date=os.date("*t", os.time())
		return m_date.year, m_date.month, m_date.day, m_date.hour, m_date.min, m_date.sec
	end
end

--时间格式20100621125251
function ParseDate(time)
	if time ~= "" then
		local year = string.sub(time,1,4)
		local month = string.sub(time,5,6)
		local day = string.sub(time,7,8)
		local hour = string.sub(time,9,10)
		local minute = string.sub(time,11,12)
		local second = string.sub(time,13,14)
		return year, month, day, hour, minute, second
	else
		return 0
	end
end
