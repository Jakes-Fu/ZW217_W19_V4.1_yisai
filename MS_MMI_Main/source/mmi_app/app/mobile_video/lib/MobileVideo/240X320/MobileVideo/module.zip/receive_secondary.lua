﻿--@module receive_secondary
--@note 收件箱二级菜单
--@author cuiyizhou
--@date 2010/05/30
--Modified by Chen Zhonglong
--Date 2010/08/26

require "module.common.registerScene"
require "module.common.SceneUtils"
require "module.Loading.useLoading"

lastSprite = nil
receiveSecondary_MenuprograminfoRect = {0, 0, 205, 25}
lineDistance=25

function PrePropertySetting(sprite)
	local reg = registerCreate("receive_secondary")   
	local istodelete = registerGetString(reg, "istodelete")
	if istodelete == "1" then
		SetSpriteVisible(sprite, 0)
		SetSpriteEnable(sprite, 0)
	else
		SetSpriteVisible(sprite, 1)
		SetSpriteEnable(sprite, 1)
	end
end

function bodyBuildChildrenFinished(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("receive_secondary")   
	registerSetInteger(reg, "root", sprite)
	ListDataName = {}
	ListDataKey = {}
	ListDataTime = {}
	local filepath = registerGetString(reg, "loadpath")
	--[[  从文件获取列表数据  ]]-- 
	createDataFromFile(filepath,sprite)
	if table.maxn(ListDataName) == 0 then
		local tip = FindChildSprite(sprite,"tip")
		SetSpriteVisible(tip,1)
		local clearBtn = FindChildSprite(sprite,"clearAll")
		SetSpriteEnable(clearBtn,0)
	else
		local tip = FindChildSprite(sprite,"tip")
		SetSpriteVisible(tip,0)
	end
	--[[  创建列表元素  ]]-- 
	createSubjectList(sprite)
	local listboard = FindChildSprite(sprite, "listboard-item")
	local spriteItem = SpriteList_GetListItem(listboard, 0)
	if spriteItem ~= 0 then
		--//start
		---SetSpriteFocus(FindChildSprite(spriteItem, "browse"))
		SetSpriteFocus(FindChildSprite(spriteItem, "item-button"))
		saveTouchFocus(FindChildSprite(spriteItem, "item-button"))
		lastSprite=FindChildSprite(spriteItem, "item-button")
		--//end
	else 
		SetSpriteFocus(FindChildSprite(sprite, "listboardCacheFocus"))
		saveTouchFocus(FindChildSprite(sprite, "listboardCacheFocus"))
		lastSprite=FindChildSprite(sprite, "listboardCacheFocus")
	end
	--SetSpriteFocus(FindChildSprite(sprite, "columnbtn"))
	return 1
end

--@function createDataFromFile
--@brief 从文件获取列表数据
function createDataFromFile(filepath,sprite)
	local reg = registerCreate("temp")
	registerLoad(reg, filepath)
	local count = registerGetInteger(reg,"count")
	local caption = FindChildSprite(sprite,"info-content-caption")
	local regSec = registerCreate("receive_secondary")   
	local istodelete = registerGetString(regSec, "istodelete")
	if istodelete == "1" then
		SetSpriteProperty(caption,"text","未读消息")
	else
		SetSpriteProperty(caption,"text",registerGetString(reg,"categoryName"))
	end	
  	for i=1,count do
	  	local name = FindValue(reg,"item"..i,"MsgTitle")
	  	local time = FindValue(reg,"item"..i,"receiveData")
	  	if name then
			table.insert(ListDataName, name)
			table.insert(ListDataKey, "item"..i)
			table.insert(ListDataTime, time)
		end
  	end
  registerRelease("temp")
end

function FindValue(reg,itemNo,categoryName)
	local data = registerGetString(reg,itemNo)
	local i,j = string.find(data,"{"..categoryName.."}")
	if j then 
		i = string.find(data,"{",j+1)
		j = string.find(data,"}",j+1)
		return string.sub(data,i+1,j-1)
	else
		return nil
	end
end

--@function createSubjectList
--@brief 创建列表元素
function createSubjectList(sprite)
    if ListDataName and ListDataTime then
		local spriteList = FindChildSprite(sprite, "listboard-item")
		--[[  创建列表元素，此处应该使用网络数据  ]]--
		count = table.maxn(ListDataName)
		local xmlNode=xmlLoadFile("MODULE:\\receive_secondary_listItem.xml")
		for i=1, count do
			local menuprograminfoSprite = CreateSprite("listitem")
			LoadSpriteFromNode(menuprograminfoSprite, xmlNode)
			--[[  设置item区域大小  ]]--
			SetSpriteRect(menuprograminfoSprite, receiveSecondary_MenuprograminfoRect[1], receiveSecondary_MenuprograminfoRect[2],receiveSecondary_MenuprograminfoRect[3], receiveSecondary_MenuprograminfoRect[4])
			--[[  设置列表设置列表上的文字内容  ]]--
			if ListDataName[i] then
				local spritetextN = FindChildSprite(menuprograminfoSprite, "subjectButtontextN")
				SetSpriteProperty(spritetextN, "text", ListDataName[i])
				local spritetextF = FindChildSprite(menuprograminfoSprite, "subjectButtontextF")
				SetSpriteProperty(spritetextF, "text", ListDataName[i])
			end
			--[[  接收时间  ]]--	
			if ListDataTime[i] then
				local receiveTime = FindChildSprite(menuprograminfoSprite, "receiveTime")
				SetSpriteProperty(receiveTime, "text", ListDataTime[i])
			end
			--[[  插入到list中  ]]--
			AddChildSprite(spriteList, menuprograminfoSprite)
			SpriteList_AddListItem(spriteList, menuprograminfoSprite)
		end
		xmlRelease(xmlNode)
		--[[  自动调整item之间间隔  ]]--
		SetSpriteProperty(spriteList,"line",count)
		SpriteList_Adjust(spriteList)
		--SpriteList_SetStartItem(spriteList,4)
	end
	--[[  统一滚动条创建  ]]--
	require "module.common.commonScroll"
	CreateScrollBar(sprite,"listboard-item",count*25+0,77)
end

--@function BrowseOnSelect
--@tag-name browse receive_secondary_listItem.xml中
--@tag-action button:OnSelect
--@brief 浏览按钮点击跳转
function BrowseOnSelect(sprite)
	--[[  获得根节点并保存在全局量中  ]]--  
	local reg = registerCreate("receive_secondary")   
	local istodelete = registerGetString(reg, "istodelete")
	local categoryID = registerGetString(reg, "categoryID")
	if istodelete == "1" then
		require "module.common.reveiveMsgCtrl"
--		receiveMsgBrowse(sprite)
		--local reg = registerCreate("receive_secondary")
		local root = registerGetInteger(reg, "root")
		local loadarea = FindChildSprite(root ,"loadarea")
		enterLoading(loadarea)
		local returnValue = receiveMsgBrowse(sprite)
		if returnValue == "5" then 			--视频杂志
			if urlpath then	
				WriteLogs("Not yet")
			end
		elseif returnValue == "4" then 			--专题消息		
			FreeScene(GetCurScene())			
			Go2Scene(sceneReceiveThird)
			SetReturn(sceneReceiveSecondary,sceneReceiveThird)
		else						--其余跳到消息详情界面
			FreeScene(GetCurScene())			
			Go2Scene(sceneFriendsRecommended)
			SetReturn(sceneReceiveSecondary,sceneFriendsRecommended)
		end
	else
		local reg_f = registerCreate("receive_secondary")
		local root = registerGetInteger(reg_f,"root")
		local loadarea = FindChildSprite(root,"loadarea")
		
		require "module.protocol.protocol_infovolume"
		local node = GetSpriteParent(sprite)
		local button = GetSpriteParent(node)
		local listitem = GetSpriteParent(button)
		local count = SpriteListItem_GetIndex(listitem)+1
		registerLoad(reg, "MODULE:\\videoexpress\\categoryID"..categoryID..".xml")
		local urlpath = FindValue(reg,"item"..count,"UrlPath")
		
		local reg_f = registerCreate("friendsrecommended_detail")
		registerSetString(reg_f,"ItemNo", count)
		registerSetString(reg_f,"ListNo", categoryID)
		
		if categoryID == "5" then 			--视频杂志
			if urlpath then	
				local path = string.gsub(urlpath,"MODULE:\\",GetModuleFolder())
				local dir = OpenDirectory(path)	
				if dir then
					local name = FindValue(reg,"item"..count,"msgContent")
					require("module.protocol.protocol_magazine")
					local reg_maga = registerCreate("magazine")
					registerSetString(reg_maga, "magazinename", name)
					SetReturn(sceneReceiveSecondary,sceneMagazine)
					FreeScene(GetCurScene())
					RequestMagazine(108, urlpath)
				else
					require("module.dialog.useDialog")
					setDialogParam("收件箱", "文件已损坏，请删除后重新下载", "BT_OK", sceneReceiveSecondary, sceneReceiveSecondary)
					Go2Scene(sceneDialog)
				end
			end
		elseif categoryID == "4" then 			--专题消息		
			FreeScene(GetCurScene())			
			GoAndFreeScene(sceneReceiveThird)
			SetReturn(sceneReceiveSecondary,sceneReceiveThird)
		else						--其余跳到消息详情界面
			FreeScene(GetCurScene())			
			GoAndFreeScene(sceneFriendsRecommended)
			SetReturn(sceneReceiveSecondary,sceneFriendsRecommended)
		end
	end
end

--@function	bodyOnSpriteEvent
--@brief	返回free事件
function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_USER + 99 then
		FreeScene(GetCurScene())
	elseif message == MSG_SMS then
		requestMsgContent()
	end
end

--@function	OnSpriteEvent
--@brief	删除确认
function OnSpriteEvent_receive(message, params)
	if message == 1001 then
		if deleteButton == 1 then		--点删除
			delProc()
		else					--点清空
			local reg = registerCreate("receive_secondary")  
			local categoryID = registerGetString(reg, "categoryID")
			fileName = "MODULE:\\videoexpress\\categoryID"..categoryID..".xml"
			local regCategory = registerCreate("Category")
			registerLoad(regCategory, fileName)
			local count = tonumber(registerGetInteger(regCategory, "count")) 
			for n=1,count do						
				--视频杂志的话需要删除杂志文件夹		
				if categoryID == "5" then
					local name = FindValue(regCategory,"item"..n,"MsgTitle")
					local folder = "MODULE:\\videoexpress\\"..name.."\\"
					require "module.common.io"
					deleteDir(folder)
				end
				registerRemove(regCategory,"item"..n)
			end
			registerSetString(regCategory, "count","0")
			registerSave(regCategory, fileName)
			registerRelease("Category")
			
			local curSprite = GetCurScene()
			FreeScene(curSprite)
			Go2Scene(sceneReceiveSecondary)
		end
	elseif message == 1002 then
	end
end

--@function	deleteOnSelect
--@brief	删除短信记录逻辑
function deleteOnSelect(sprite)
	local reg = registerCreate("receive_secondary")
	registerSetInteger(reg, "deleteSprite", sprite)
	registerSetString(reg,"lastFocus",lastSprite)
	local spriteRoot = registerGetInteger(reg,"root")
	local spriteEvent = FindChildSprite(spriteRoot, "event")
	deleteButton = 1
		
	require("module.dialog.useDialog")
	setDialogParam("收件箱", "是否需要删除这条信息？", "BT_OK_CANCEL", sceneReceiveSecondary, sceneReceiveSecondary, spriteEvent)
	Go2Scene(sceneDialog)
end

function clearAllOnSelect(sprite)
	local reg = registerCreate("receive_secondary")   
	local istodelete = registerGetString(reg, "istodelete")
	if istodelete == "1" then
		require("module.dialog.useDialog")
		setDialogParam("收件箱", "未读消息无法清空", "BT_OK", sceneReceiveSecondary, sceneReceiveSecondary)
		Go2Scene(sceneDialog)
	else	
		local spriteRoot = registerGetInteger(reg,"root")
		local spriteEvent = FindChildSprite(spriteRoot, "event")
		registerSetString(reg,"lastFocus",lastSprite)
	
		require("module.dialog.useDialog")
		setDialogParam("收件箱", "是否要清空该文件夹的所有内容？", "BT_OK_CANCEL", sceneReceiveSecondary, sceneReceiveSecondary, spriteEvent)
		Go2Scene(sceneDialog)
	end
end

function bodyOnPluginEvent(message, param)
	require "module.videoexpress-common"
	if MSG_SMS_ID == message then
		DealMsgContent(sceneReceiveSecondary, sceneReceiveSecondary)
	elseif message == 101 then
		exitLoading()		
		SetReturn(sceneReceiveSecondary,sceneReceiveThird)
		local curSprite = GetCurScene()
		FreeScene(curSprite)
		Go2Scene(sceneReceiveThird)
	elseif message == 225 then
		exitLoading()
		pathName = "MODULE:\\monthguidelist.xml"
		if pathName then
			local scene = FindScene(pathName)
		end
		if scene and scene ~= 0 then
			FreeScene(scene)
		end
		Go2Scene(pathName, nil)
		SetReturn(sceneMyOrder,sceneMonthGuideList)
	elseif message == 226 then
		exitLoading()
		FreeScene(GetCurScene())
		local jason = ChannelNetworkData()
		if jason.imgListNavi and jason.programList then
			WriteLogs("ChangeToProduct")
			GoAndFreeScene("MODULE:\\product.xml")
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneReceiveSecondary, sceneReceiveSecondary)
			Go2Scene(sceneDialog)
		end
	elseif message == 227 then
		exitLoading()
		FreeScene(GetCurScene())
		local navigationData = LoadNavigationData()
		if navigationData then
			WriteLogs("ChangeToNavigationData")
			GoAndFreeScene("MODULE:\\navigation.xml")
		end
	elseif message == 228 then
		exitLoading()
		FreeScene(GetCurScene())
		local topTenData = LoadJsonTopTenNetworkData()
		if topTenData then
			WriteLogs("ChangeToguide")
			GoAndFreeScene("MODULE:\\paihang.xml")
		end
	elseif message == 102 then
		exitLoading()
		FreeScene(GetCurScene())
		local jason = ChannelNetworkData()
		if jason.imgListNavi and jason.programList then
			WriteLogs("ChangeToProduct")
			GoAndFreeScene("MODULE:\\product.xml")
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneReceiveSecondary, sceneReceiveSecondary)
			Go2Scene(sceneDialog)
		end
	elseif message == 108 then	
		require("module.protocol.protocol_magazine")
		local json = MagazineNetworkData()
		exitLoading()
		FreeScene(GetCurScene())
		if json ~= nil and json ~= "" then
			SetReturn(sceneReceiveSecondary,sceneMagazine)
			Go2Scene(sceneMagazine)
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "服务器返回数据错误", "BT_OK", sceneReceiveSecondary, sceneReceiveSecondary, nil)
			Go2Scene(sceneDialog)
		end
	elseif message > 32768 and message ~= MSG_SMS_ID + 32768 then
		exitLoading()
		require("module.dialog.useDialog")
		setDialogParam("提示", "获取网络数据失败", "BT_OK", sceneReceiveSecondary, sceneReceiveSecondary, nil)
		Go2Scene(sceneDialog)
	end
end

function delProc()
	local reg = registerCreate("receive_secondary")   
	local categoryID = registerGetString(reg, "categoryID")
	local sprite = registerGetInteger(reg, "deleteSprite")
	local node = GetSpriteParent(sprite)
	local button = GetSpriteParent(node)
	local listitem = GetSpriteParent(button)
	local count = SpriteListItem_GetIndex(listitem)+1

	local reg = registerCreate("receive_secondary")   
	local filepath = registerGetString(reg, "loadpath")
	local category = registerCreate("category")
	registerLoad(category, filepath)
	local name = FindValue(category,"item"..count,"MsgTitle")
	registerRemove(category, ListDataKey[count])
	
	local listcount = registerGetInteger(category,"count")
	for i=count,listcount-1 do
		registerSetString(category,"item"..i,registerGetString(category,"item"..(i+1)))
	end
	registerRemove(category, "item"..listcount)
	registerSetInteger(category,"count",listcount-1)
	
	registerSave(category,filepath)
	registerRelease("category")
	--视频杂志的话需要删除杂志文件夹
	if categoryID == "5" then
		local folder = "MODULE:\\videoexpress\\"..name.."\\"
		require "module.common.io"
		deleteDir(folder)
	end
	
	local curSprite = GetCurScene()
	FreeScene(curSprite)
	Go2Scene(sceneReceiveSecondary)
end

function readUrl()
	local reg = registerCreate("receive_secondary")  
	local sprite = registerGetInteger(reg, "sprite")
	local returnValue = registerGetInteger(reg, "returnValue")
	require "module.protocol.protocol_3rdmsgbox"
	local node = GetSpriteParent(sprite)
	local button = GetSpriteParent(node)
	
	local listitem = GetSpriteParent(button)
	local count = SpriteListItem_GetIndex(listitem)+1
	local reg_c = registerCreate("categoryID")
	registerLoad(reg_c, "MODULE:\\videoexpress\\categoryID"..returnValue..".xml")			
	local urlpath = FindValue(reg_c,"item"..count,"UrlPath")
	if urlpath then	
		Request3rdMsg(101, urlpath)
	end
	--registerRelease(reg_c)
	registerRelease("CategoryID")
end
function ButtonKeyUp(sprite, keyCode)
	require "module.keyCode.keyCode"
	local name = GetSpriteName(sprite)
	WriteLogs("Key event begin !")
	WriteLogs("Key event is "..keyCode)
	WriteLogs("Current button Sprite is "..name)
	local ToDigReg = registerCreate("ToDigReg")  --add by yaoxiangyin
	registerSetInteger(ToDigReg,"ToDigFocus",sprite) --add by yaoxiangyin
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local root = GetRootSprite(sprite)
	
	--added by chenzhonglong
	local MsgList = FindChildSprite(root, "listboard-item")
	local list_x, list_y2, list_w, list_h = GetSpriteRect(MsgList)
	--ended
	
	if keyCode == ApKeyCode_Up then
--------------------------add by yaoxiangyin-----------------------------------------------		
		if name~="clearAll" and IsSpriteEnable(FindChildSprite(root,"clearAll"))==1 then
			local curItem = GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite)))
			local curIndex=SpriteListItem_GetIndex(curItem)
			if curIndex==0 and IsSpriteVisible(FindChildSprite(root,"clearAll"))==1 then
				local clearBtn=FindChildSprite(root,"clearAll")
				SetSpriteFocus(clearBtn)
				saveTouchFocus(clearBtn)
			end
		end
-----------------------------------------------------------------------------------------		
		if name == "browse" or name == "delete" then
			local listboard = FindChildSprite(root, "listboard-item")
			local curItem = GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite)))
			local select = SpriteListItem_GetIndex(curItem) - 1
			local nextItem = SpriteList_GetListItem(listboard,select)
			
			--added by chenzhonglong
			local _, list_y1 = GetSpriteRect(curItem)
			local list_y = list_y1+list_y2
			--ended
			
			if nextItem ~= 0 then
				--//start
				---SetSpriteFocus(FindChildSprite(nextItem,"browse"))
				SetSpriteFocus(FindChildSprite(nextItem,"item-button"))
				saveTouchFocus(FindChildSprite(nextItem,"item-button"))
				lastSprite=FindChildSprite(nextItem,"item-button")
				
				--added by chenzhonglong
				if list_y <= 10 then
					SpriteScrollBar_Adjust(MsgList)
					SetSpriteRect(MsgList,list_x, list_y2+lineDistance,list_w, list_h)
					ChangeScrollPositon(SpriteListItem_GetIndex(curItem),"up")
				end
				KeyAfterScroll(MsgList,select)
				--//end
			end
		--//start
		elseif name=="item-button" then
			local listboard = FindChildSprite(root, "listboard-item")
			local curItem = GetSpriteParent(GetSpriteParent(sprite))
			local select = SpriteListItem_GetIndex(curItem) -1
			local nextItem = SpriteList_GetListItem(listboard,select)
			
			--added by chenzhonglong
			local _, list_y1 = GetSpriteRect(curItem)
			local list_y = list_y1+list_y2
			--ended
			
			if nextItem ~= 0 then
				--SetSpriteFocus(FindChildSprite(nextItem,"browse"))
				SetSpriteFocus(FindChildSprite(nextItem,"item-button"))
				saveTouchFocus(FindChildSprite(nextItem,"item-button"))
				lastSprite=FindChildSprite(nextItem,"item-button")
				
				--added by chenzhonglong
				if list_y <= 10 then
					SpriteScrollBar_Adjust(MsgList)
					SetSpriteRect(MsgList,list_x, list_y2+lineDistance,list_w, list_h)
					ChangeScrollPositon(SpriteListItem_GetIndex(curItem),"up")
				end
				KeyAfterScroll(MsgList,select)
				--ended
			end
		--//end
		end

	elseif keyCode == ApKeyCode_Down then
		if name == "browse" or name == "delete" then
			local listboard = FindChildSprite(root, "listboard-item")
			local curItem = GetSpriteParent(GetSpriteParent(GetSpriteParent(sprite)))
			local select = SpriteListItem_GetIndex(curItem) + 1
			local nextItem = SpriteList_GetListItem(listboard,select)
			
			--added by chenzhonglong
			local _, list_y1 = GetSpriteRect(curItem)
			local list_y = list_y1+list_y2
			--ended
			
			if nextItem ~= 0 then
				--//start
				---SetSpriteFocus(FindChildSprite(nextItem,"browse"))
				SetSpriteFocus(FindChildSprite(nextItem,"item-button"))
				saveTouchFocus(FindChildSprite(nextItem,"item-button"))
				lastSprite=FindChildSprite(nextItem,"item-button")
				
				--added by chenzhonglong
				if list_y >=200 then
					SpriteScrollBar_Adjust(MsgList)
					SetSpriteRect(MsgList,list_x, list_y2-lineDistance,list_w, list_h)
					ChangeScrollPositon(SpriteListItem_GetIndex(curItem),"down")
				end
				KeyAfterScroll(MsgList,select)
				--//end
			end
		--//start
		elseif name=="item-button" then
			local listboard = FindChildSprite(root, "listboard-item")
			local curItem = GetSpriteParent(GetSpriteParent(sprite))
			local select = SpriteListItem_GetIndex(curItem) + 1
			local nextItem = SpriteList_GetListItem(listboard,select)
			
			--added by chenzhonglong
			local _, list_y1 = GetSpriteRect(curItem)
			local list_y = list_y1+list_y2
			--ended
			
			if nextItem ~= 0 then
				--SetSpriteFocus(FindChildSprite(nextItem,"browse"))
				SetSpriteFocus(FindChildSprite(nextItem,"item-button"))
				saveTouchFocus(FindChildSprite(nextItem,"item-button"))
				lastSprite=FindChildSprite(nextItem,"item-button")
				
				--added by chenzhonglong
				if list_y >=200 then
					SpriteScrollBar_Adjust(MsgList)
					SetSpriteRect(MsgList,list_x, list_y2-lineDistance,list_w, list_h)
					ChangeScrollPositon(SpriteListItem_GetIndex(curItem),"down")
				end
				KeyAfterScroll(MsgList,select)
				--ended
			end
		--//end
---------------------------------add by yaoxiangyin-----------------------------------		
		elseif name=="clearAll" then
			local spriteList=FindChildSprite(root,"listboard-item")
			local itemCount=SpriteList_GetListItemCount(spriteList)
			if itemCount>0 then
				local firstItem=SpriteList_GetListItem(spriteList,0)
				local firstBtn=FindChildSprite(firstItem,"item-button")
				SetSpriteFocus(firstBtn)
				saveTouchFocus(firstBtn)
			end
-------------------------------------------------------------------------------------			
		end

	elseif keyCode == ApKeyCode_Left then
		if name == "delete" then
			parentSprite = GetSpriteParent(sprite)
			SetSpriteFocus(FindChildSprite(parentSprite,"browse"))
			saveTouchFocus(FindChildSprite(parentSprite,"browse"))
			lastSprite=FindChildSprite(parentSprite,"browse")
		end
	elseif keyCode == ApKeyCode_Right then
		if name == "browse" then
			parentSprite = GetSpriteParent(sprite)
			SetSpriteFocus(FindChildSprite(parentSprite,"delete"))
			saveTouchFocus(FindChildSprite(parentSprite,"delete"))
			lastSprite=FindChildSprite(parentSprite,"delete")
		end
	elseif keyCode == ApKeyCode_Enter then
		if name == "browse" then
			BrowseOnSelect(sprite)
		elseif name == "delete" then
		--[[
			local reg = registerCreate("receive_secondary")   
			registerSetInteger(reg, "deleteItem", sprite)
			local spriteEvent = FindChildSprite(root,"event")				
			setDialogParam("删除消息", "您确认要删除此条消息吗？", "BT_OK_CANCEL",sceneReceiveSecondary ,sceneReceiveSecondary,spriteEvent,nil)
			Go2Scene(sceneDialog) 				
			]]--
			deleteOnSelect(sprite)
		--//start
		elseif name=="item-button" then
			local curItem = GetSpriteParent(GetSpriteParent(sprite))
			SetSpriteFocus(FindChildSprite(curItem,"browse"))
			saveTouchFocus(FindChildSprite(curItem,"browse"))
			lastSprite=FindChildSprite(curItem,"browse")
		--//end
-------------------------------------add by yaoxiangyin---------------------------------------------------------------
		elseif name=="clearAll" then
			local listboard = FindChildSprite(root, "listboard-item")
			local itemCount=SpriteList_GetListItemCount(listboard)
			if itemCount ~= 0 then
				local clearButton = FindChildSprite(root, "clearAll")
				clearAllOnSelect(clearButton)
			end
----------------------------------------------------------------------------------------------------------------------
		end
	elseif keyCode == ApKeyCode_Cancel or keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_CharA then	--上一页
		--listUpButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_CharB then	--下一页
		--listDownButtonOnSelect(sprite)
		local listboard = FindChildSprite(root, "listboard-item")
		local itemCount=SpriteList_GetListItemCount(listboard)
		if itemCount ~= 0 then
			local clearButton = FindChildSprite(root, "clearAll")
			clearAllOnSelect(clearButton)
		end
	else
		WriteLogs("Other Key event !")
	end
	return 1
end

--//start3
--[[function btnItemSelect(sprite)
	local curItem = GetSpriteParent(GetSpriteParent(sprite))
	SetSpriteFocus(FindChildSprite(curItem,"browse"))
end--]]
--//end

function ChangeScrollPositon(CurIndex,direction)
	--local spriteitem = GetSpriteParent(sprite)
	--local CurIndex = SpriteListItem_GetIndex(spriteitem)
	require "module.common.commonScroll"
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,8,0)
	else
		ScrollBarAdjust(CurIndex + 1,8,1)
	end
end

function KeyAfterScroll(spriteList,curIndex)
	local sprite_x,sprite_y,sprite_w,sprite_h=GetSpriteRect(spriteList)
	local item=SpriteList_GetStartItem(spriteList)
	local firstIndex=SpriteListItem_GetIndex(item)

	if curIndex-firstIndex>=0 and curIndex-firstIndex<=8 then
		WriteLogs("")
	else
		local totalcount = SpriteList_GetListItemCount(spriteList)
		if totalcount - curIndex <= 8  then
			firstIndex = totalcount - 8 - 1
		else
			firstIndex = curIndex
		end	
	end
	--[[  这里是鼠标移动过滑块后的第一次按键的处理  ]]--
	
	WriteLogs("after setfocus")
	if ScrollAdjustFlag and ScrollAdjustFlag == 1 then				
		SetSpriteRect(spriteList,sprite_x,0-(firstIndex)*25,sprite_w,sprite_h)
		ScrollBarAdjust(curIndex,8,0)
		ScrollAdjustFlag = 0
	end
end