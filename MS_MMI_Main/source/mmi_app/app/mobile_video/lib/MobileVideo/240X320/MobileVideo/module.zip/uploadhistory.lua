﻿--@module 	Upload
--@note 	uploadhistory
--@author 	shenyi
--@date 	2010/06/05
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.Loading.useLoading"

uploadHistory_SelectHeight = 48
uploadHistory_NormalHeight = 25
uploadHistory_ItemWidth = 222

--全局变量
nIsChange = 0
CurForcus = 0
nIndex2 = 1 --记录上一次点击的行数
nIndex = 1 --记录这一次点击的行数
filter={"*.3gp","*.dat"}	--需要过滤的文件类型，可以直接添加
uploadurl={}
uploadname={}
count = nil


--@function 		bodyBuildChildrenFinished
--@tag-name 		body
--@tag-action 	BuildChildrenFinished
--@brief 				xml创建完成后默认选择第一条数据
function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("uploadhist")
	registerSetInteger(reg, "root",sprite)	
	--创建文件列表
	LoadUploadHistoryList()
	if count > 0 then
		createVideoList()
	
	elseif count==0 then
		local reg = registerCreate("uploadhist")
		itemfocus=FindChildSprite(registerGetInteger(reg, "root"),"empty")
		SetSpriteFocus(itemfocus)
		saveTouchFocus(itemfocus)
	end
	return 1
end

--@function	CreatefavoriteList
--@brief	创建收藏列表
function createVideoList()
	local reg = registerCreate("uploadhist")
	local sprite = registerGetInteger(reg, "root")	
	local spriteList = FindChildSprite(sprite, "uploadFileList")
	SpriteList_ClearListItem(spriteList, 1, 1)
	SpriteList_LoadListItem(spriteList, "MODULE:\\uploadhistory_ListItem.xml", count)	
	for i=1,count do
		local uploadSprite	 = SpriteList_GetListItem(spriteList, i-1)		
	
		local spriteSel = FindChildSprite(uploadSprite,"select")
		local spriteUnSel = FindChildSprite(uploadSprite,"unselect")
		
		local spriteText = FindChildSprite(uploadSprite,"item-text")
		local spriteText1 = FindChildSprite(uploadSprite,"item-text1")
		SetSpriteProperty(spriteText,"text",uploadname[i])
		SetSpriteProperty(spriteText1,"text",uploadname[i])
					
		if i == 1 then
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)			
			SetSpriteRect(uploadSprite, 0, 0, uploadHistory_ItemWidth,uploadHistory_NormalHeight)
			prevSelectSprite = uploadSprite
			WriteLogs("CreateUploadList "..uploadSprite)
			SetSpriteFocus(FindChildSprite(spriteUnSel,"item-button"))
			saveTouchFocus(FindChildSprite(spriteUnSel,"item-button"))
		else
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)
			SetSpriteRect(uploadSprite, 0, 0, uploadHistory_ItemWidth, uploadHistory_NormalHeight)
		end
		
	end
	SpriteList_Adjust(spriteList)
	uploadlist=spriteList
	--[[  统一滚动条创建  ]]--
	require "module.common.commonScroll"
	CreateScrollBar(sprite,"uploadFileList",(count-1)*uploadHistory_NormalHeight + uploadHistory_SelectHeight,76)
	ScrollBarAdjust(0,3,0)
	select = 1
end

--@function	itemButtonOnSelect
--@tag-name	item-button
--@tag-action	button:OnSelect
--@brief	用于响应各列表项按钮
function itemButtonOnSelect(sprite)	
	--WriteLogs("1111111111")
	WriteLogs("prevSelectSprite  "..prevSelectSprite)
	if prevSelectSprite ~= nil then
		WriteLogs("itemButtonOnSelect "..prevSelectSprite)
		local spriteSel1 = FindChildSprite(prevSelectSprite,"select")
		local spriteUnSel1 = FindChildSprite(prevSelectSprite,"unselect")
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(prevSelectSprite, 0, 0, uploadHistory_ItemWidth, uploadHistory_NormalHeight)
	end
	--WriteLogs("aaaaaaaaaa")
	local spriteParent = GetSpriteParent(sprite)
	local uploadSprite = GetSpriteParent(spriteParent)
	local spriteSel2 = FindChildSprite(uploadSprite,"select")
	local spriteUnSel2 = FindChildSprite(uploadSprite,"unselect")
	SetSpriteVisible(spriteUnSel2, 0)
	SetSpriteEnable(spriteUnSel2, 0)
	SetSpriteVisible(spriteSel2, 1)			
	SetSpriteEnable(spriteSel2, 1)
	SetSpriteRect(uploadSprite, 0, 0, uploadHistory_ItemWidth, uploadHistory_SelectHeight)
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "uploadFileList")--dw
	SpriteList_Adjust(spriteList)
	prevSelectSprite = uploadSprite
	select = SpriteListItem_GetIndex(uploadSprite) + 1
	WriteLogs(select)
	SetSpriteFocus(FindChildSprite(spriteSel2, "playbutton"))
	saveTouchFocus(FindChildSprite(spriteSel2, "playbutton"))
end

function iuploadButtonOnSelect(sprite)
 	SetReturn( sceneUploadHistory, sceneUpload)
	FreeScene(GetCurScene())	
	Go2Scene(sceneUpload )
end

function buttonUploadingSelect(sprite)
	SetReturn(sceneUploadHistory,sceneUploadingInfo)	
	FreeScene(GetCurScene())
    Go2Scene(sceneUploadingInfo)
end

--@function playOnSelect
--@tag-name play
--@tag-action button:OnSelect
--@brief 播放按钮，用户发起播放请求，成功则播放
function playOnSelect(sprite)
	SetReturn(sceneUploadHistory,sceneVideolocal)
	--[[  获得根节点  ]]--  
	--local reg = registerCreate("menuprograminfo_volume")
	local root = GetRootSprite(sprite)
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	--[[  这里应该动态获取点击按钮的具体url  ]]--
	local spriteButton = GetSpriteParent(GetSpriteParent(sprite))
	local num = SpriteListItem_GetIndex(spriteButton)
	local nIndex = num + 1
	local PlayTable = {url = uploadurl, urlItem = nIndex}
	WriteLogs("current request "..uploadurl[nIndex])
	require "module.protocol.protocol_video"
	RequestVideo(109, PlayTable,"","","local")
	exitLoading()
	local listSprite = GetCurScene()
	FreeScene(listSprite)
	Go2Scene(sceneVideolocal)
	return 1
end

function deleteOnSelect(sprite)
	local index =  SpriteListItem_GetIndex(GetParentSprite(GetParentSprite(sprite)))+1
	local reg = registerCreate("uploadhist")	
	local spriteRoot = registerGetInteger(reg, "root")	
	local spriteEvent = FindChildSprite(spriteRoot,"event")
	
	registerSetInteger(reg,"cur",index)	
	require "module.dialog.useDialog"
	setDialogParam("已经上传", "您确认要删除该文件吗？", "BT_OK_CANCEL",sceneUploadHistory ,sceneUploadHistory,spriteEvent)
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位
	 curScene=registerSetString(SceneReg,"SceneName","uploadHistoryFile")
	Go2Scene(sceneDialog)		

end


--@function	OnPluginEvent
--@brief	响应插件消息
function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if MSG_SMS_ID == message then			
		DealMsgContent(sceneUploadHistory, sceneUploadHistory)
	end
	return 1
end

function OnSpriteEvent(message, params)
	WriteLogs("bodyOnSpriteEvent message"..message)
	if message == 1001 then
		local reg = registerCreate("uploadhist")
		local index = registerGetInteger(reg, "cur")
		DeleteUploadHistory(index)
	elseif message == 1002 then
		
	end
end

--从文件载入上传历史记录
function LoadUploadHistoryList()
    require ("module.setting");

	local regUploadList = registerCreate("uploadHistoryList")
	local filename = Cfg.GetTempPath( "uploadhist.xml" );

	registerLoad(regUploadList, filename)
	count = registerGetInteger(regUploadList, "count")
	WriteLogs("LoadUploadHistoryList count "..count)
	
	--将所有载入的历史记录的url和name放到全局的uploadurl,uploadname中
	if count ~= nil then
		for i=1, count do
			uploadurl[i] = registerGetString(regUploadList, "playurl" ..i)
			uploadname[i] = registerGetString(regUploadList, "name" ..i)
			WriteLogs("index-----"..i)
			WriteLogs("uploadurl "..uploadurl[i])
			WriteLogs("uploadname "..uploadname[i])
		end
	end
	registerRelease("uploadHistoryList")
--	local regVideoList = registerCreate("historyVideoList")
--	registerLoad(regVideoList, "")
end

--删除上传历史记录
function DeleteUploadHistory(num)
    require ("module.setting");
	local regUploadList = registerCreate("uploadHistoryList")
	local filename = Cfg.GetTempPath( "uploadhist.xml" );

	registerLoad(regUploadList, filename)
	
	--将要删除的记录和最后一条记录交换，并删除该记录
	historyplayurl1 = registerGetString(regUploadList, "playurl" ..count)
	historyname1 = registerGetString(regUploadList, "name" ..count)
		
	--WriteLogs("delete playurl  "..registerGetString(regUploadList, "playurl" ..num))
	--WriteLogs("delete name  "..registerGetString(regUploadList, "name" ..num))
	
	registerSetString(regUploadList, "playurl" ..num, historyplayurl1)
	registerSetString(regUploadList, "name" ..num, historyname1)	
		
	registerRemove(regUploadList,"name"..count)
	registerRemove(regUploadList,"playurl"..count)

	--记录个数减少一个
	registerSetInteger(regUploadList, "count", count-1)
	registerSave(regUploadList, filename)
	registerRelease("uploadHistoryList")	

	
	local labelSprite = GetCurScene()
	FreeScene(labelSprite)
	Go2Scene(sceneUploadHistory)
end

function OnSpriteEvent2(message, params)
	require("module.common.commonMsg")
	require "module.videoexpress-common"
	--WriteLogs("message-----------message-----message-------message----message="..MSG_SMS)
	if message == MSG_SMS then
		WriteLogs("bodyOnSpriteEvent-----------------------1")
		requestMsgContent()
	WriteLogs("bodyOnSpriteEvent-----------------------3")
	--[[  返回事件  ]]--
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
	return 1
end
--@brief 上传列表按钮键盘事件
--@auther  dw

function emptyKeyUp(sprite,keyCode)
	 local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	WriteLogs("empty:"..keyCode)
	local name = GetSpriteName(sprite)
	require("module.keyCode.keyCode")
	local name = GetSpriteName(sprite)
	if	keyCode==ApKeyCode_Enter or keyCode==ApKeyCode_Down  or keyCode==ApKeyCode_Up    then return 0
	elseif  keyCode==ApKeyCode_Left then 
		if name=="iupload" then 
		SetSpriteFocus(FindChildSprite(GetRootSprite(sprite),"empty"))
		saveTouchFocus(FindChildSprite(GetRootSprite(sprite),"empty"))
		else buttonUploadingSelect(sprite)
		end
	elseif  keyCode==ApKeyCode_Right then 
	SetSpriteFocus(FindChildSprite(GetRootSprite(sprite),"iupload"))
	saveTouchFocus(FindChildSprite(GetRootSprite(sprite),"iupload"))
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

function buttonOnKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	if count==0 then
	emptyKeyUp(sprite,keyCode)
	return 0
	end
	local itemCount=SpriteList_GetListItemCount(uploadlist)
	local item=GetSpriteParent(GetSpriteParent(sprite))
	local index=SpriteListItem_GetIndex(item)
	local spriteSel = FindChildSprite(item,"select")
	local spriteUnSel = FindChildSprite(item,"unselect")
	local name = GetSpriteName(sprite)
	require("module.keyCode.keyCode")
	WriteLogs("~~~~~~~~~~~buttonOnKeyUp："..keyCode)
	local list_x, list_y2, list_w, list_h = GetSpriteRect(uploadlist)
	local _, list_y1 = GetSpriteRect(item)
	local list_y = list_y1+list_y2
	
	if	keyCode==ApKeyCode_Enter then
			if GetSpriteName(sprite)=="iupload" then
				iuploadButtonOnSelect(sprite)
			elseif GetSpriteName(GetSpriteParent(sprite))=="unselect" then				
					local i=1
					SetSpriteVisible(spriteSel, 1)
					SetSpriteEnable(spriteSel, 1)
					SetSpriteVisible(spriteUnSel, 0)			
					SetSpriteEnable(spriteUnSel, 0)	
					local x, y, w, h = GetSpriteRect(item)
					SetSpriteRect(item, x, y, uploadHistory_ItemWidth, uploadHistory_SelectHeight)
					SetSpriteFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton"))
					saveTouchFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton"))
					WriteLogs("焦点成功:"..HasSpriteFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton")))
					for j=index,itemCount-1 do												
						spriteItem = SpriteList_GetListItem(uploadlist, index+i)
						i=i+1
						local x, y, w, h = GetSpriteRect(spriteItem)			
						SetSpriteRect(spriteItem,x,y+uploadHistory_NormalHeight,w,h)						
					end
					if list_y >= 195 then
						SetSpriteRect(uploadlist,list_x, list_y2-uploadHistory_NormalHeight,list_w, list_h)
						---------------------------modified 10.27-----------------
						ChangeScrollPositon(sprite,"down")
						----------------------------------------------------------
					end
			elseif GetSpriteName(GetSpriteParent(sprite))=="select" then
				if GetSpriteName(sprite)=="playbutton" then playOnSelect(sprite)
				elseif GetSpriteName(sprite)=="deletebutton" then deleteOnSelect(sprite)
				end
			end
			SpriteList_Adjust(uploadlist)
	elseif (keyCode==ApKeyCode_Down  and index<=itemCount-1) or name=="iupload" then
		if name=="iupload" and count~=0 then
			SetSpriteFocus(FindChildSprite(spriteUnSel,"item-button"))
			saveTouchFocus(FindChildSprite(spriteUnSel,"item-button"))
		end
		if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
			if index==itemCount-1 then return 0 end
			local nextListItem = SpriteList_GetListItem(uploadlist, index+1)			
			SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
			saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
		elseif	GetSpriteName(GetSpriteParent(sprite))=="select" then
			if index==itemCount-1 and  name=="deletebutton" then return 0 end
			local i=1
			if name=="playbutton" then	
				SetSpriteFocus(FindChildSprite(spriteSel,"deletebutton"))
				saveTouchFocus(FindChildSprite(spriteSel,"deletebutton"))
			elseif name=="deletebutton" then	
				local nextListItem = SpriteList_GetListItem(uploadlist, index+1)					
				WriteLogs("下焦点："..SpriteListItem_GetIndex(nextListItem))
				SetSpriteVisible(spriteSel, 0)
				SetSpriteEnable(spriteSel, 0)
				SetSpriteVisible(spriteUnSel, 1)			
				SetSpriteEnable(spriteUnSel, 1)		
				local x, y, w, h = GetSpriteRect(item)							
				SetSpriteRect(item, x, y, uploadHistory_ItemWidth, uploadHistory_NormalHeight)
				local spriteSelNext = FindChildSprite(nextListItem,"select")
				local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
				SetSpriteVisible(spriteSelNext, 0)
				SetSpriteEnable(spriteSelNext, 0)
				SetSpriteVisible(spriteUnSelNext, 1)			
				SetSpriteEnable(spriteUnSelNext, 1)		
				SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
				saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
				for j=index,itemCount-1 do
					
					spriteItem = SpriteList_GetListItem(uploadlist, index+i)
					i=i+1
					local x, y, w, h = GetSpriteRect(spriteItem)			
					SetSpriteRect(spriteItem,x,y-uploadHistory_NormalHeight,w,h)
				end
			end	
		end		
		if list_y >= 195 then
			SpriteScrollBar_Adjust(uploadlist)
			SetSpriteRect(uploadlist,list_x, list_y2-uploadHistory_NormalHeight,list_w, list_h)
			---------------------------modified 10.27-----------------
			ChangeScrollPositon(sprite,"down")
			----------------------------------------------------------
		end
	elseif 	keyCode==ApKeyCode_Up  then
			WriteLogs("上移动 ")
				if index==0 and name=="deletebutton" then 
				SetSpriteFocus(FindChildSprite(spriteSel,"playbutton")) 
				saveTouchFocus(FindChildSprite(spriteSel,"playbutton"))
				return 0
				elseif index==0 and name=="playbutton" then return 0 
				elseif index==0 then return 0 end
					local i=1					
					local nextListItem = SpriteList_GetListItem(uploadlist, index-1)					
				if 		GetSpriteName(GetSpriteParent(sprite))=="unselect" then
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))	
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
				elseif	GetSpriteName(GetSpriteParent(sprite))=="select" then
					WriteLogs("上焦点："..SpriteListItem_GetIndex(nextListItem))
					if name=="deletebutton" then
						SetSpriteFocus(FindChildSprite(spriteSel,"playbutton"))
						saveTouchFocus(FindChildSprite(spriteSel,"playbutton"))
					elseif  name=="playbutton" then
						SetSpriteVisible(spriteSel, 0)
						SetSpriteEnable(spriteSel, 0)
						SetSpriteVisible(spriteUnSel, 1)			
						SetSpriteEnable(spriteUnSel, 1)		
						local x, y, w, h = GetSpriteRect(item)							
						SetSpriteRect(item, x, y, uploadHistory_ItemWidth, uploadHistory_NormalHeight)
						local spriteSelNext = FindChildSprite(nextListItem,"select")
						local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
						SetSpriteVisible(spriteSelNext, 0)
						SetSpriteEnable(spriteSelNext, 0)
						SetSpriteVisible(spriteUnSelNext, 1)			
						SetSpriteEnable(spriteUnSelNext, 1)		
						SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
						saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
						for j=index,itemCount-1 do
							spriteItem = SpriteList_GetListItem(uploadlist, index+i)
							i=i+1
							local x, y, w, h = GetSpriteRect(spriteItem)			
							SetSpriteRect(spriteItem,x,y-uploadHistory_NormalHeight,w,h)
						end
					end
			end
				if list_y <= 10 then
				SpriteScrollBar_Adjust(uploadlist)
				SetSpriteRect(uploadlist,list_x, list_y2+uploadHistory_NormalHeight,list_w, list_h)
				---------------------------modified 10.27-----------------
				ChangeScrollPositon(sprite,"up")
				----------------------------------------------------------
				end
	elseif keyCode == ApKeyCode_Left then
		buttonUploadingSelect(sprite)
	elseif keyCode == ApKeyCode_Right  then
		local reg = registerCreate("uploadhist")
		local upload=registerGetInteger(reg, "root")
		if GetSpriteName(sprite)=="iupload" then
		SetSpriteFocus(FindChildSprite(spriteUnSel,"item-button"))
		saveTouchFocus(FindChildSprite(spriteUnSel,"item-button"))
		elseif   GetSpriteName(sprite)=="deletebutton" or GetSpriteName(sprite)=="playbutton" then 
			local i=1	
			local nextListItem = SpriteList_GetListItem(uploadlist, index)
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)			
			SetSpriteEnable(spriteUnSel, 1)		
			local x, y, w, h = GetSpriteRect(item)							
			SetSpriteRect(item, x, y, uploadHistory_ItemWidth, uploadHistory_NormalHeight)			
			--SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
			--saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
			for j=index,itemCount-1 do
			spriteItem = SpriteList_GetListItem(uploadlist, index+i)
			i=i+1
			local x, y, w, h = GetSpriteRect(spriteItem)			
			SetSpriteRect(spriteItem,x,y-uploadHistory_NormalHeight,w,h)
			end
			SetSpriteFocus(FindChildSprite(upload,"iupload"))
			saveTouchFocus(FindChildSprite(upload,"iupload"))
		elseif GetSpriteName(sprite)=="item-button" then
			SetSpriteFocus(FindChildSprite(upload,"iupload"))
			saveTouchFocus(FindChildSprite(upload,"iupload"))
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end

--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	WriteLogs("liuchaobing test spriteitem name is "..GetSpriteName(spriteitem))
	WriteLogs("liuchaobing test spriteitem index is "..CurIndex)
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,4,0)
	else
		ScrollBarAdjust(CurIndex + 1,4,1)
	end
end
