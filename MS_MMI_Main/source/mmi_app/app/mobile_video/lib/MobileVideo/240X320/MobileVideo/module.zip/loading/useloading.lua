﻿--author xf_pan
--date	2010/05/31

require "module.common.registerScene"
--param sprite loading嵌入的节点
function enterLoading(sprite)
	WriteLogs("sprite" .. sprite)
	local rootsprite = GetCurScene()
	returnsprite = FindChildSprite(rootsprite,"Return")
	if returnsprite then
		SetSpriteCapture(returnsprite)
	end
	spriteLoadingName = GetSpriteName(sprite)
	if sprite ~= nil then
		globalNode = sprite
		local loadingNode = FindChildSprite(globalNode, "loading")
		if loadingNode ~= 0 then
			SetSpriteVisible(loadingNode, 1)
			SetSpriteEnable(loadingNode, 1)
			SetSpriteActive(loadingNode, 1)
		else
			LoadSprite(globalNode, "MODULE:\\Loading_.xml")
		end
	end
end

function exitLoading()
	local rootsprite = GetCurScene()
	if returnsprite then
		ReleaseSpriteCapture(returnsprite)
	end
	if rootsprite and rootsprite ~= 0 then
		local loadingNode = FindChildSprite(rootsprite, "loading")
		SetSpriteVisible(loadingNode, 0)
		SetSpriteEnable(loadingNode, 0)
		SetSpriteActive(loadingNode, 0)
	end
end

function FreeFunction()
	enterLoading = nil
	enterLoading = nil
endfunction LoadingFlag()
	local rootsprite = GetCurScene()
	local loadingNode = FindChildSprite(rootsprite, "loading")
	if loadingNode==0 then
		return true
	else
		if IsSpriteVisible(loadingNode)==1 then
			return false
		else
			return true
		end
	end
end  
 