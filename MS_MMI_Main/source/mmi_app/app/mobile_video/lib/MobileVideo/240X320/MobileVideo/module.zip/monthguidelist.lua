﻿require "module.keyCode.keyCode"
require "module.common.SceneUtils"
--@@ auther zuoran
--@@ time:7/6/2010 8:42 PM
--@@ name:monthguidelist.lua

function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("monthguidelist")
	registerSetInteger(reg, "root", sprite)
	SetSpriteFocus(FindChildSprite(sprite,"emptybutton"))
	saveTouchFocus(FindChildSprite(sprite,"emptybutton"))
	WriteLogs("bodyBuildChildrenFinished")
	SetTimer(1, 1, "OnTimerCreateContent")
	return 1
end

function OnTimerCreateContent()
	local reg = registerCreate("monthguidelist")
	local fileName = registerGetString(reg, "monthguideUrlFileName")
	--jsonData = jsonLoadFile("CACHE:\\qryOrderNodes1.txt")
	jsonData = jsonLoadFile(fileName)
	createContentList(jsonData)
	SetTimer(1, 1, "OnCreateLoadingSprite")
end

function OnCreateLoadingSprite()
	local reg = registerCreate("monthguidelist")
	local sprite = registerGetInteger(reg, "root")
	
	local nodeLoad =  FindChildSprite(sprite, "loadarea")
	if nodeLoad == nil or nodeLoad == 0 then
		nodeLoad = CreateSprite("node", sprite)
		SetSpriteProperty(nodeLoad, "name", "loadarea")
		SetSpriteRect(nodeLoad, 0, 0, 240, 320)
	end
end

function GoAndFreeScene(pathName)
	local scene = FindScene(pathName)
	if scene and scene ~= 0 then
		FreeScene(scene)
	end
	FreeScene(GetCurScene())
	SetReturn("MODULE:\\monthguidelist.xml", pathName)
	Go2Scene(pathName, nil)
end

function OnPluginEvent(message, Param)
	require("module.loading.useLoading")
	require("module.common.SceneUtils")
	require "module.videoexpress-common"
	if message == 101 then 	--主业务界面
		exitLoading()
		local channelData = LoadChannelGroupData()
		if channelData then
			WriteLogs("ChangeToGuide")
			SetReturn(sceneMonthGuideList,sceneGuide)
			GoAndFreeScene( sceneGuide )
		end
	elseif message == 102 then --列表式导航
		exitLoading()
		local jason = ChannelNetworkData()
		if jason.imgListNavi and jason.programList then
			WriteLogs("ChangeToProduct")
			SetReturn(sceneMonthGuideList,sceneProduct)
			GoAndFreeScene("MODULE:\\product.xml")
		else
			setDialogParam("提示", "服务器返回数据错误", "BT_OK", sceneMonthGuideList, sceneMonthGuideList, nil)
			Go2Scene(sceneDialog)
		end
	elseif message == 103 then --标签式导航
		exitLoading()
		local navigationData = LoadNavigationData()
		if navigationData then
			SetReturn(sceneMonthGuideList,sceneNavigation)
			GoAndFreeScene("MODULE:\\navigation.xml")
		end
	elseif message == 104 then --排行榜
		exitLoading()
		local topTenData = LoadJsonTopTenNetworkData()
		if topTenData then
			SetReturn(sceneMonthGuideList,scenePaihang)
			GoAndFreeScene("MODULE:\\paihang.xml")
		end
	elseif message == 2000 then
		exitLoading()
		require("module.common.SceneUtils")
		GoAndFreeScene(sceneBulletin)
	elseif message == 2002 then
		exitLoading()
		GoAndFreeScene( scenePrograminfo_volume )
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneGuide, sceneGuide)
	end
end

function  createContentList(jsonChannelGroupData)
--[[----------------------------------------------------------------]]--
	pageIndexReg= registerCreate("pageIndex")
	registerSetNumber(pageIndexReg,"contentPageIndex",0)
	
------------------------------------------------------------------------	
	local reg = registerCreate("monthguidelist")
	local sprite = registerGetInteger(reg, "root")
	local spriteList = FindChildSprite(sprite, "guide-content-list")
	local caption = FindChildSprite(sprite,"guide-caption")
	SetSpriteProperty(caption,"text",jsonChannelGroupData.namePath)
	local imgListArray = jsonChannelGroupData.imgList
	if  imgListArray then
		local n = table.maxn(imgListArray)
		for i=0, n do
			local guideContentSprite = CreateSprite("listitem")
			LoadSprite(guideContentSprite, "MODULE:\\guideContentItem.xml")
			SetSpriteProperty(guideContentSprite, "name", string.format("content-listItem-%d", i))
			SetSpriteRect(guideContentSprite, 5, 0, 70, 60)
			
			---------------------设置每个listItem的默认选中选中------------------
			--SetSpriteProperty(guideContentSprite, "defaultFocusName", "buttonChangeName")
			---------------------------------------------------------------------
			
			---------------设置listItem的键盘点击事件----------------
			--SetSpriteProperty(guideContentSprite, "OnKeyUp", "monthGuideListItemButtonSubjectKeyUp")
			---------------------------------------------------------
			
			local spriteButton = FindChildSprite(guideContentSprite, "buttonChangeName")
			SetSpriteProperty(spriteButton, "name", string.format("content-button-%d", i))
			
			SetSpriteProperty(spriteButton,"OnKeyUp","monthGuideListItemButtonSubjectKeyUp")
			
			--[[  小图标  ]]--
			local spriteSmallImg = FindChildSprite(guideContentSprite, "smallImg")
			if jsonChannelGroupData.imgList[i].img then
				SetSpriteProperty(spriteSmallImg, "src", jsonChannelGroupData.imgList[i].img)
			end					
			--[[  文字  ]]--
			local spriteText = FindChildSprite(guideContentSprite, "subjectname")
			if jsonChannelGroupData.imgList[i].channelName then
				SetSpriteProperty(spriteText, "text", jsonChannelGroupData.imgList[i].channelName)

				--[[  文字太短了，不需要滚动，这个时候需要重新调整 坐标  ]]--
				local widthMax = 49;
				local offX = adjustOffx( jsonChannelGroupData.imgList[i].channelName , 11, widthMax );
				SetSpriteRect(spriteText, offX ,40, widthMax, 16);				
			end
			
			AddChildSprite(spriteList, guideContentSprite)
			SpriteList_AddListItem(spriteList, guideContentSprite)
			
			-------------设置第一个节点为焦点、设置一个数据仓库，将initMonthListItemButton放入其中----------------
			if i == 0 then
				--------------找button节点-----------------------------------------------------
				local initMothGuideListItemFocus = FindChildSprite(guideContentSprite, "content-button-0")
				--------------------------------------------------------------------------------
				
				SetSpriteFocus(initMothGuideListItemFocus)
				saveTouchFocus(initMothGuideListItemFocus)
			end
			-------------------------------------------------------
		end
	
		SpriteList_Adjust(spriteList)
		if n > 4 then
			SpriteList_SetCurItem(spriteList, 2)
		end
		
		local start = SpriteList_GetStartItem(spriteList)
		local listItemCount = SpriteList_GetListItemCount(spriteList)
		local itemPerPage = SpriteList_GetItemPerPage(spriteList)
		
		local spriteLeftImage = FindChildSprite(sprite, "guid-content-left-arrow-image")
		local spriteRightImage = FindChildSprite(sprite, "guid-content-right-arrow-image")
		DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
	end
end

function monthGuideListItemButtonSubjectKeyUp(sprite,keyCode)
	local contentList={}  --存放列表项中的Button名
	--guide-content-list区域内操作
	local spriteList =GetSpriteParent(GetSpriteParent(sprite))  --guide-content-list节点
	local spriteRightArrow=FindChildSprite(GetSpriteParent(spriteList),"guid-content-right-arrow-button")   --与guide-content-list节点平级的向右翻页按钮
	local spriteLeftArrow=FindChildSprite(GetSpriteParent(spriteList), "guid-content-left-arrow-button")    --与guide-content-list节点平级的向左翻页按钮
	
	local contentName = GetSpriteName(sprite)
	local contentFocusNum
	local itemCount=SpriteList_GetListItemCount(spriteList)
	local ListLine = SpriteList_GetLineCount(spriteList)		--行数2
	local ListCol = SpriteList_GetColCount(spriteList)		--列数4
	local ListCount = SpriteList_GetItemPerPage(spriteList)		--总数8
	--为表contentList赋值
	for j=0,itemCount-1 do
		contentList[j]="content-button-"..j
	end
	
	local pageNum --总页数
	if itemCount%ListCount==0 then
		pageNum=itemCount/ListCount
	else
		pageNum=math.ceil(itemCount/ListCount)
	end
	
	for i=0,itemCount-1 do  --寻找当前Button节点名
	  if contentList[i]==contentName then
	    contentFocusNum=i
	  end
	end
	
	local lineNum --总行数
	if itemCount%ListLine==0 then
		lineNum=itemCount/ListLine
	else
		lineNum=math.ceil(itemCount/ListLine) 
	end
	local rightEdgeFalg=0 --当前位置是否在右边缘标志0表示否，1表示是
	local leftEdgeFalg=0  --当前位置是否在左边缘标志0表示否，1表示是
	for i=0,lineNum-1 do
		if contentFocusNum==i*ListCol+ListCol-1 then
			rightEdgeFalg=1
			break
		elseif contentFocusNum==i*ListCol then
			leftEdgeFalg=1
			break
		end
	end
	
	-------------------------------------------------------------------------------------------
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	-------------------------------------------------------------------------------------------
	local homeLastFoucsReg= registerCreate("homeLastFoucs")--dw
	registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)--dw
	--end

	if keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
		return 1	
		--SetSpriteFocus(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
		return 1
	elseif keyCode == ApKeyCode_Right  then
		if rightEdgeFalg==0 then --content区域内向右移动
			if contentList[contentFocusNum+1]~=nil then
				local sprite1=FindChildSprite(spriteList,contentList[contentFocusNum+1])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		elseif rightEdgeFalg==1 then --content右边界操作
			if registerGetInteger(pageIndexReg,"contentPageIndex")<pageNum-1 then
			registerSetNumber(pageIndexReg,"contentPageIndex",(registerGetInteger(pageIndexReg, "contentPageIndex")+1))
			contentListButtonOnSelect(spriteRightArrow)
			end
		end
		return 1
	elseif keyCode == ApKeyCode_Left  then
		if leftEdgeFalg==0 then --content区域内向左移动
			if contentList[contentFocusNum-1]~=nil then
				local sprite1=FindChildSprite(spriteList,contentList[contentFocusNum-1])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		elseif leftEdgeFalg==1 then --content左边界操作
			if registerGetInteger(pageIndexReg,"contentPageIndex")>0 then
			registerSetNumber(pageIndexReg,"contentPageIndex",(registerGetInteger(pageIndexReg, "contentPageIndex")-1))
			contentListButtonOnSelect(spriteLeftArrow)
			end
		end
		return 1
	elseif keyCode == ApKeyCode_Up  then
		if contentFocusNum%ListCount >= 0 and contentFocusNum%ListCount <= ListCol-1 then
		
		else
			if contentList[contentFocusNum-ListCol]~=nil and contentFocusNum-ListCol >= 0 then 
				local sprite1=FindChildSprite(spriteList,contentList[contentFocusNum-ListCol])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		end
	elseif keyCode == ApKeyCode_Down  then
		if contentFocusNum%ListCount >= ListCount-ListCol and contentFocusNum%ListCount <= ListCol-1 then
		
		else
			if contentList[contentFocusNum+ListCol]~=nil and contentFocusNum+ListCol <= ListCount-1 then
				local sprite1=FindChildSprite(spriteList,contentList[contentFocusNum+ListCol])
				SetSpriteFocus(sprite1)
				saveTouchFocus(sprite1)
			end
		end
	else
		return 0
	end
end

function deleteContentList(sprite)
	local spriteList = FindChildSprite(sprite, "guide-content-list")
	SpriteList_ClearListItem(spriteList, 1, 1)
end


--[[  文字太短了，不需要滚动，这个时候需要重新调整 坐标  ]]--
function adjustOffx( text, startX , maxLineX )
	local offX = startX;
	local textLineSize = GetTextSize( text )
	textLineSize = math.floor( ( maxLineX - textLineSize  )/2)
	if ( textLineSize >0 )then 
		offX = startX + textLineSize;
	end
	return offX;
end

function DisplayButton(spriteLeftImage, spriteRightImage, start, step, total, isRing)
	if isRing then --环状
		if spriteLeftImage and spriteLeftImage ~= 0 then
			if step < total then
				SetSpriteVisible(spriteLeftImage, 1)
			else
				SetSpriteVisible(spriteLeftImage, 0)
			end
		end
		if spriteRightImage and spriteRightImage ~= 0 then
			if step < total then
				SetSpriteVisible(spriteRightImage, 1)
			else
				SetSpriteVisible(spriteRightImage, 0)
			end
		end
	else
		if spriteLeftImage and spriteLeftImage ~= 0 then
			if start >= step then
				SetSpriteVisible(spriteLeftImage, 1)
			else
				SetSpriteVisible(spriteLeftImage, 0)
			end
		end
		if spriteRightImage and spriteRightImage ~= 0 then
			if start + step < total then
				SetSpriteVisible(spriteRightImage, 1)
			else
				SetSpriteVisible(spriteRightImage, 0)
			end
		end
	end
end

function contentListButtonOnSelect(spriteButton)
	local contentSpriteRoot = GetSpriteParent(spriteButton)
	if contentSpriteRoot and contentSpriteRoot ~= 0 then
		local contentList = FindChildSprite(contentSpriteRoot, "guide-content-list")
		local spriteLeftButton = FindChildSprite(contentSpriteRoot, "guid-content-left-arrow-button")
		local spriteRightButton = FindChildSprite(contentSpriteRoot, "guid-content-right-arrow-button")
		
		if contentList and contentList ~= 0 then
			local listItemCount = SpriteList_GetListItemCount(contentList)
			local itemPerPage = SpriteList_GetItemPerPage(contentList)
			
			--可以进行翻页操作
			if itemPerPage < listItemCount then
				local start = SpriteList_GetStartItem(contentList)
--[[------------------------------------------------------------------------------------------------]]--
				local startItem
				local startButton
--------------------------------------------------------------------------------------------------------				
				local spriteLeftImage = FindChildSprite(spriteLeftButton, "guid-content-left-arrow-image")
				local spriteRightImage = FindChildSprite(spriteRightButton, "guid-content-right-arrow-image")
						
				if spriteButton == spriteLeftButton then
					start = start - itemPerPage
					if start >= 0 then
-------------------------------------------------------------------------------------------------------------
						startItem=SpriteList_GetListItem(contentList,start)
						startButton=FindChildSprite(startItem,"content-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
--------------------------------------------------------------------------------------------------------------					
						SpriteList_SetStartItem(contentList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end
				elseif spriteButton == spriteRightButton then
					start = start + itemPerPage
					if start < listItemCount then
-----------------------------------------------------------------------------------------------------------						
						startItem=SpriteList_GetListItem(contentList,start)
						startButton=FindChildSprite(startItem,"content-button-"..start)
						SetSpriteFocus(startButton)
						saveTouchFocus(startButton)
--------------------------------------------------------------------------------------------------------------					
						SpriteList_SetStartItem(contentList, start)
						DisplayButton(spriteLeftImage, spriteRightImage, start, itemPerPage, listItemCount)
					end	
				end
			end
		end
		SpriteList_Adjust(contentList)
	end
end

function listItemOnMouseDown(sprite)
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	local spriteListItem = GetSpriteParent(sprite)
	local spriteList = GetSpriteParent(spriteListItem)
	local index = SpriteListItem_GetIndex(spriteListItem)	
	if GetSpriteName(spriteList) == "guide-content-list" then	
		RequestObject(jsonData.imgList[index])
	end
	loadAnimation()
end
function listItemOnSelect(sprite)
	local spriteListItem = GetSpriteParent(sprite)
	local spriteList = GetSpriteParent(spriteListItem)
	local index = SpriteListItem_GetIndex(spriteListItem)	
	if GetSpriteName(spriteList) == "guide-content-list" then	
		RequestObject(jsonData.imgList[index])
	end
	loadAnimation()
end

function RequestObject(channelObject)
	local typeID = channelObject.nodeDisplayType
	WriteLogs(string.format("typeID [%s]", typeID))
	if typeID == "0" then 			--列表式
		WriteLogs(string.format("2.typeID [%s]", typeID))
		require("module.protocol.protocol_channel")
		RequestChannel(102, channelObject.urlPath)
	elseif typeID == "1" then		--业务式
		require("module.protocol.protocol_channelGroup")
		WriteLogs(string.format("1.typeID [%s]", typeID))
		RequestChannelGroup(101, channelObject.urlPath)
		WriteLogs(string.format("================="))
	elseif typeID == "2" then		--标签式
		require("module.protocol.protocol_navigation")
		RequestNavigation(103, channelObject.urlPath)
	elseif typeID == "3" then		--排列榜
		require("module.protocol.protocol_topten")
		RequestTopTen(104, channelObject.urlPath)
	end
	loadAnimation()
end

function loadAnimation()
	local reg = registerCreate("monthguidelist")
	local root = registerGetInteger(reg, "root")
	local loadarea = FindChildSprite(root, "loadarea")
	require("module.loading.useLoading")
	enterLoading(loadarea)
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	require("module.common.commonMsg")
	WriteLogs("MSG_SMS::"..MSG_SMS)
	if message == MSG_SMS then
		WriteLogs("bodyOnSpriteEvent-----------------------1")
		requestMsgContent()
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	end
end

-------------------设置list的键盘点击事件-------------------
function guideMonthlistOnKeyUp(sprite,keyCode)
	return 0
end
------------------------------------------------------------

function emptyKeyUp(sprite,keyCode)
	require("module.keyCode.keyCode")
	WriteLogs("keyCode:"..keyCode)
	if keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	return 0
end
