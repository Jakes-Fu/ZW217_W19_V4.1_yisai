--author ljc
--date	2010/06/01
-- request menusearch
function RequestMenuSearch(protocolNumber, searchUrl, isFromMenu)
	WriteLogs("request")
	local regSystem = registerCreate("System")
	local http = registerGetInteger(regSystem, "comHttpPipe")
	if http == nil or http == 0 then
		http = pluginCreate("HttpPipe")
		registerSetInteger(regSystem, "comHttpPipe", http)
	end
	local observer = nil
	if isFromMenu then
		local regObserver = registerCreate("saveObserver")
		observer = registerGetInteger(regObserver, "observer")
	else
		observer = pluginGetObserver()
	end
	WriteLogs("searchUrl=1="..searchUrl)
	local fileName = GetLocalFilename(searchUrl)
	local reg = registerCreate("menusearch")
	registerSetString(reg, "menuSearchFileName", fileName)
	WriteLogs("menuSearchFileName="..fileName)
	pluginInvoke(http, "AppendCommand", 0, searchUrl, "", fileName, observer, protocolNumber, 0, 1)
--	pluginRelease(http)
	WriteLogs("protocolNumber="..protocolNumber)
	WriteLogs("searchUrl=2="..searchUrl)
	WriteLogs("searchUrl=2="..fileName)
end

function OnMenuSearchDecode()
	local reg = registerCreate("menusearch")
	local fileName = registerGetString(reg, "menuSearchFileName")
	WriteLogs("OnMenuSearchDecode="..fileName)
	if fileName ~= nil and fileName ~= "" then
		return jsonLoadFile(fileName)
	end
	
	return nil
end
