
--@module orderdetail
--@note 订购详情
--@author Abigale
--@date 2010/05/30

require "module.Loading.useLoading"
require "module.common.registerScene"
require "module.common.SceneUtils"
--require "module.common.ascertainTargetScene"
require "module.myorder"

function bodyBuildChildrenFinished(sprite)
	--  获得根节点，保存在全局量中  
	local reg = registerCreate("orderdetail")   
	registerSetInteger(reg, "root", sprite)
	CreateOrderDetailData(sprite)
	return 1
end
function CreateOrderDetailData(sprite)
--	WriteLogs("望天地之悠悠")
	local OrderDetailArray = {}
	OrderDetailArray = OnMyOrderDecode()	
--		WriteLogs("望天地之悠悠2222")
	local spriteproductname = FindChildSprite(sprite, "productname")
	local spriteName = FindChildSprite(sprite, "product-name")
	local spriteIntroduce = FindChildSprite(sprite, "product-detail")
	local spriteFeed = FindChildSprite(sprite, "product-feed")
	if OrderDetailArray.orderList ~= nil then
--		WriteLogs("独怆然而涕下")
		local regSystem = registerCreate("system")
		index = registerGetInteger(regSystem, "IndexData")
		if  OrderDetailArray and OrderDetailArray.orderList[index] then
			SetSpriteProperty(spriteproductname, "text",  OrderDetailArray.orderList[index].productName)
			SetSpriteProperty(spriteName, "text", OrderDetailArray.orderList[index].productName)
			SetSpriteProperty(spriteIntroduce, "text", OrderDetailArray.orderList[index].productFullName)
			SetSpriteProperty(spriteFeed, "text", OrderDetailArray.orderList[index].fee)
		end
	end -- if
end

function buttonOnSelect(sprite)
	SetSpriteFocus(sprite)
	local reg = registerCreate("orderdetail")   
	local root = registerGetInteger(reg, "root")
	
	ReleaseSpriteCapture(sprite)
	local cancelOrder = FindChildSprite(root, "cancelOrder")
	if cancelOrder == 0 or cancelOrder == nil then
		cancelOrder = CreateSprite("node", root)
		SetSpriteProperty(cancelOrder,"name","cancelOrder")
	end
	SetSpriteCapture(cancelOrder)
	--[[  载入  ]]--
	local menu = CreateSprite("listitem")
 	LoadSprite(menu,sceneCancelOrder)
	AddChildSprite(cancelOrder, menu)
	local cancelOrderButton = FindChildSprite(root,"option-box1")
	SetSpriteFocus(cancelOrderButton)
end

function bodyOnPluginEvent(message, param)
	require "module.videoexpress-common"
	if MSG_SMS_ID == message then
		DealMsgContent(sceneCancelOrderDetail, sceneCancelOrderDetail)
	end
end

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	if message == MSG_SMS then
		requestMsgContent()
	end
end

function returnOnSpriteEvent(message, params)
	GoAndFreeScene(sceneMyOrder)
end

function orderDetailCancel(sprite,keyCode)
	if keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		WriteLogs("history_sprite_name:----------------------:"..GetSpriteName(sprite))
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	
		--SetSpriteFocus(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_Enter then
		buttonOnSelect(sprite)
	end
end