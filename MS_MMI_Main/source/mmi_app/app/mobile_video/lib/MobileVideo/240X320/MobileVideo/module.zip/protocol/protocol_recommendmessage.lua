--author ljc
--date	2010/06/01
-- request recommendmessage
function RequestRecommendMessage(protocolNumber, searchUrl)
	--WriteLogs("request")
	local regSystem = registerCreate("System")
	local http = pluginCreate("HttpPipe")
	local observer = pluginGetObserver()
	local fileName = GetLocalFilename(searchUrl)
	pluginInvoke(http, "AppendCommand", 0, searchUrl, "", fileName, observer, protocolNumber, 0,1)
	--WriteLogs("protocolNumber="..protocolNumber)
	--WriteLogs("searchUrl="..searchUrl)
end

function OnRecommendMessageDecode()
	local reg = registerCreate("recommendmessage")
	local fileName = registerGetString(reg, "recommendMessageFileName")
	if fileName ~= nil and fileName ~= "" then
		return jsonLoadFile(fileName)
	end
	
	return nil
end