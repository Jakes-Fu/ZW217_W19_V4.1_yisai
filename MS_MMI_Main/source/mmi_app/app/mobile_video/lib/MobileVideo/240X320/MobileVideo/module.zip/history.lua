﻿--@module	history
--@note	用于历史记录界面的UI显示
--@author	shenyi
--@date	2010/05/28
require "module.common.SceneUtils"
require "module.common.registerScene"
require "module.protocol.protocol_videoloading"
require "module.dialog.useDialog"
require "module.Loading.useLoading"
require "module.common.commonScroll"

history_SelectHeight = 48
history_NormalHeight = 25
history_ItemWidth = 222

prevSelectSprite = nil
historyplayurl = {}
historypathurl = {}
historydate = {}
historyname = {}
historyvideoType ={}
historyIsReview = {}
count = 0
flag = 0
arrowPercent = 10
curPercent = 0
global_percent = nil

--@tag-action	body:BuildChildrenFinished
--@brief	创建历史记录列表
function bodyBuildChildrenFinished(sprite)
	local reg = registerCreate("history")
	registerSetInteger(reg,"root",sprite)
	http = pluginCreate("HttpPipe")
	count = 0
	return 1
end

function loadData(sprite)
	LoadHistoryVideoList()
	if count ~= nil and count > 0 then
		CreateHistoryList()
	elseif count==0 then       ---dw
		
		local spriteImage = FindChildSprite(sprite,"scrollbar-image")
		local spriteScroll = FindChildSprite(sprite,"scroll")
		local spriteSplider = FindChildSprite(sprite,"splider-bar")
		SetSpriteVisible(spriteImage,0)
		SetSpriteVisible(spriteSplider,0)
		SetSpriteEnable(spriteScroll,0)
		SetSpriteEnable(spriteSplider,0)
		local root = GetRootSprite(sprite)
		local empty = FindChildSprite(root, "emptybutton")
		SetSpriteFocus(empty)		--dw
		saveTouchFocus(empty)
	end
end

imagelist = {"file:///image/history/bt_qk.png", "file:///image/history/bt_qk3.png"}

function bodyOnSpriteEvent(message, params)
	require "module.videoexpress-common"
	require "module.common.commonMsg"
	if message == MSG_ACTIVATE then
		exitLoading()
		WriteLogs("MSG_ACTIVATE")
		LoadHistoryVideoList()
		local reg = registerCreate("history")
		local sprite = registerGetInteger(reg, "root")
		local spriteImage1 = FindChildSprite(sprite,"normal-image")
		local spriteLabel1 = FindChildSprite(sprite,"disable-text")
		local spriteButton1 = FindChildSprite(sprite,"clearButton")
		if count ~= nil and count > 0 then
			SetSpriteProperty(spriteImage1,"src",imagelist[1])
			SetSpriteVisible(spriteLabel1,0)
			SetSpriteEnable(spriteButton1,1)
			CreateHistoryList()
		else	
			SetSpriteProperty(spriteImage1,"src",imagelist[2])
			SetSpriteVisible(spriteLabel1,1)
			SetSpriteEnable(spriteButton1,0)
			local spriteImage = FindChildSprite(sprite,"scrollbar-image")
			local spriteScroll = FindChildSprite(sprite,"scroll")
			local spriteSplider = FindChildSprite(sprite,"splider-bar")
			SetSpriteVisible(spriteImage,1)
			SetSpriteVisible(spriteSplider,0)
			SetSpriteEnable(spriteScroll,0)
			SetSpriteEnable(spriteSplider,0)
			local empty = FindChildSprite(sprite, "emptybutton")
			WriteLogs("~~~~~~~bodyOnSpriteEvent~~~~~~empty, count:"..count)
			SetSpriteFocus(empty)
			saveTouchFocus(empty)
		end
	elseif message == MSG_DEACTIVATE then
		WriteLogs("MSG_DEACTIVATE")
	elseif message == MSG_RETURN then
		FreeScene(GetCurScene())
	elseif message == MSG_SMS then
		requestMsgContent()
	end
end

--@function	CreatefavoriteList
--@brief	创建历史记录列表
function CreateHistoryList()
	local reg = registerCreate("history")
	local sprite = registerGetInteger(reg, "root")
	local historyList = FindChildSprite(sprite, "history-list")
	SpriteList_ClearListItem(historyList, 1, 1)
	SpriteList_LoadListItem(historyList, "MODULE:\\historyItemList.xml", count)
	for i=1,count do
		WriteLogs("CreateHistoryList name"..i.."---"..historyname[i])
		local historySprite	 = SpriteList_GetListItem(historyList,count-i)
		local spriteSel = FindChildSprite(historySprite,"select")
		local spriteUnSel = FindChildSprite(historySprite,"unselect")
		local spriteText = FindChildSprite(historySprite,"item-text")
		local spriteText1 = FindChildSprite(historySprite,"item-text1")
		local spriteTime = FindChildSprite(historySprite,"item-time")
		SetSpriteProperty(spriteText,"text",historyname[i])
		SetSpriteProperty(spriteText1,"text",historyname[i])
		SetSpriteProperty(spriteTime,"text",historydate[i])
		
		--[[if i == count then			
			SetSpriteVisible(spriteSel, 1)
			SetSpriteEnable(spriteSel, 1)
			SetSpriteVisible(spriteUnSel, 0)
			SetSpriteEnable(spriteUnSel, 0)
			SetSpriteRect(historySprite, 0, 0, history_ItemWidth, history_SelectHeight)
			prevSelectSprite = historySprite
		]]--
		--else
			SetSpriteVisible(spriteSel, 0)
			SetSpriteEnable(spriteSel, 0)
			SetSpriteVisible(spriteUnSel, 1)
			SetSpriteEnable(spriteUnSel, 1)
			SetSpriteRect(historySprite, 0, 0, history_ItemWidth, history_NormalHeight)
	--	end
		
		if historyvideoType[i] == "local" or historypathurl[i] == "" then
			local spriteDetail = FindChildSprite(historySprite,"detailbutton")
			local spriteImg = FindChildSprite(spriteDetail,"imagexq2")
			local spriteText2 = FindChildSprite(spriteDetail,"detaildis")
			SetSpriteProperty(spriteImg,"src","file:///image/upload/disable.png")
			SetSpriteProperty(spriteText2,"text","详情")
			SetSpriteEnable(spriteDetail, 0)
			if historyvideoType[i] == "local" then
				local directory = historyplayurl[i]
				local t={}
				local k=0
				while true do
					k=string.find(directory,"\\",k+1)
					if k==nil then break end
					table.insert(t,k)
					WriteLogs("k"..k.."")
				end
				if #t > 0 then
					local position = t[#t]+1
					WriteLogs("position "..position)
					local filename = string.sub(directory,position)
					WriteLogs("filename: "..filename)
							
					SetSpriteProperty(spriteText,"text",filename)
					SetSpriteProperty(spriteText1,"text",filename)
				else
					SetSpriteProperty(spriteText,"text",directory)
					SetSpriteProperty(spriteText1,"text",directory)
				end
			end
		end

		if historyvideoType[i] == "live" then
			local spriteDetail = FindChildSprite(historySprite,"detailbutton")
			local spriteImg = FindChildSprite(spriteDetail,"imagexq2")
			local spriteText2 = FindChildSprite(spriteDetail,"detaildis")
			SetSpriteProperty(spriteImg,"src","file:///image/upload/disable.png")
			SetSpriteProperty(spriteText2,"text","详情")
			SetSpriteEnable(spriteDetail, 0)
		elseif historyvideoType[i] == "demand" then
			local pos = string.find(historyplayurl[i],"ifLive")
			if pos ~= nil then
				local spriteDetail = FindChildSprite(historySprite,"detailbutton")
				local spriteImg = FindChildSprite(spriteDetail,"imagexq2")
				local spriteText2 = FindChildSprite(spriteDetail,"detaildis")
				SetSpriteProperty(spriteImg,"src","file:///image/upload/disable.png")
				SetSpriteProperty(spriteText2,"text","详情")
				SetSpriteEnable(spriteDetail, 0)
			end
		end
	end
	SpriteList_Adjust(historyList)
	history_list=historyList
	CreateScrollBar(sprite,"history-list",(count-1)*history_NormalHeight + history_SelectHeight,76)	
	ScrollBarAdjust(0,4,0)
	
	local button = FindChildSprite(FindChildSprite(historyList,"unselect"),"item-button")
	WriteLogs("button:__________________________"..GetSpriteName(button))
	SetSpriteFocus(button)
	saveTouchFocus(button)
end

function clearButtonOnSelect(sprite)
	local reg = registerCreate("history")
	registerSetInteger(reg,"dialognum",2)
	registerSetInteger(reg,"flag_history_#",1)
	local root = GetRootSprite(sprite)
	local spriteEvent = FindChildSprite(root, "event")
	WriteLogs("爆破3")
	setDialogParam("清空历史记录", "您确认要清空全部浏览历史记录吗？", "BT_OK_CANCEL", sceneHistory, sceneHistory, spriteEvent)
----------------------------------------------------------------
	local SceneReg=registerCreate("SceneNameReg")
	registerSetString(SceneReg,"SceneName","history")
	local empty = FindChildSprite(root, "emptybutton")
	local his_Reg=registerCreate("sc_Reg")
	registerSetInteger(his_Reg,"sprite_flag",empty)
---------------------------------------------------------------------
	Go2Scene(sceneDialog)	
end

--@function	itemButtonOnSelect
--@tag-name	item-button
--@tag-action	button:OnSelect
--@brief	用于响应各列表项按钮
function itemButtonOnSelect(sprite)
	local spriteRoot = GetRootSprite(sprite)
	local spriteList = FindChildSprite(spriteRoot, "history-list")
	--[[
	if prevSelectSprite ~= nil then
		local spriteSel1 = FindChildSprite(prevSelectSprite,"select")
		local spriteUnSel1 = FindChildSprite(prevSelectSprite,"unselect")
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteUnSel1, 1)
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(prevSelectSprite, 0, 0, history_ItemWidth, history_NormalHeight)
	end
	]]--
	for i=0,(SpriteList_GetListItemCount(spriteList)-1) do
		local initSpriteItem = SpriteList_GetListItem(spriteList,i)
		local spriteSel1 = FindChildSprite(initSpriteItem,"select")
		local spriteUnSel1 = FindChildSprite(initSpriteItem,"unselect")
		SetSpriteVisible(spriteSel1, 0)
		SetSpriteEnable(spriteSel1, 0)
		SetSpriteVisible(spriteUnSel1, 1)			
		SetSpriteEnable(spriteUnSel1, 1)
		SetSpriteRect(initSpriteItem, 0, 0, favorite_ItemWidth, favorite_NormalHeight)
	end
	local spriteParent = GetSpriteParent(sprite)
	local spriteHistory = GetSpriteParent(spriteParent)
	local spriteSel2 = FindChildSprite(spriteHistory,"select")
	local spriteUnSel2 = FindChildSprite(spriteHistory,"unselect")
	SetSpriteVisible(spriteUnSel2, 0)
	SetSpriteEnable(spriteUnSel2, 0)
	SetSpriteVisible(spriteSel2, 1)
	SetSpriteEnable(spriteSel2, 1)
	SetSpriteRect(spriteHistory, 0, 0, history_ItemWidth, history_SelectHeight)
	SpriteList_Adjust(spriteList)
	prevSelectSprite = spriteHistory
	local playButton = FindChildSprite(spriteHistory,"playbutton")--dw
	SetSpriteFocus(playButton)
	saveTouchFocus(playButton)
end

function deleteButtonOnSelect(sprite)
	local root = GetRootSprite(sprite)
	local spriteEvent = FindChildSprite(root, "event")
	local SceneReg=registerCreate("SceneNameReg")
	registerSetString(SceneReg,"SceneName","history")
	WriteLogs("spriteEvent "..spriteEvent)

	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	--显示倒序排列
	local num = count-SpriteListItem_GetIndex(spriteItem)
	local reg = registerCreate("history")
	registerSetInteger(reg,"deletenum",num)
	registerSetInteger(reg,"dialognum",1)
	historyCurrentFocus = sprite  --dw
	setDialogParam("删除历史记录", "您确认要删除这条历史记录吗？", "BT_OK_CANCEL", sceneHistory, sceneHistory, spriteEvent)
	Go2Scene(sceneDialog)
end

function detailButtonOnSelect(sprite)
	local spriteListItem = GetSpriteParent(GetSpriteParent(sprite))
	--显示倒序排列
	local index = count - SpriteListItem_GetIndex(spriteListItem)
	--[[  获得根节点  ]]--  
	local root = GetRootSprite(sprite)
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	enterLoading(loadarea)
	local urlpath = historypathurl[index]
	local videotype = historyvideoType[index]
	if videotype == "live" then
		require("module.protocol.protocol_channel")
		RequestChannel(108,urlpath)
	elseif videotype == "group" then
		require("module.protocol.protocol_infolabel")
		Requestlabel(109, urlpath)
	else
		require "module.protocol.protocol_infovolume"
		RequestVolume(103, urlpath)
	end
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
end

--@function playButtonOnSelect
--@tag-name playButton
--@tag-action button:OnSelect
--@brief 播放按钮，用户发起播放请求，成功则播放
function playButtonOnSelect(sprite)
	--[[  获得根节点  ]]--  
	local root = GetRootSprite(sprite)
	local loadarea = FindChildSprite(root, "loadarea")
	--[[  显示loading场景  ]]--
	--enterLoading(loadarea)
	--[[  这里应该动态获取点击按钮的具体url  ]]--
	local spriteItem = GetSpriteParent(GetSpriteParent(sprite))
	--显示倒序排列	
	local num = count - SpriteListItem_GetIndex(spriteItem)
	local playurl = historyplayurl[num]
	local urlpath = historypathurl[num]
	local videotype = historyvideoType[num]
	local videoname = historyname[num]
	local isReview = historyIsReview[num]
	local isTemp = string.find(playurl,"vfile")
	if isTemp then
		regVideo = registerCreate("video")
		registerSetString(regVideo, "isDownloading", "Downloading")
	end
	if videotype ~= "local" then	
		local start = string.find(playurl,"contentId")
		if start then
			local str = string.sub(playurl,start+9)
			if str then
				local strend = nil
				local contentId = nil
				strend = string.find(str,"&")
				if strend then
					contentId = string.sub(str,0,strend-1)
				else
					contentId = str
				end
				local reg_p = registerCreate("product")
				registerSetString(reg_p,"playurl",playurl)
				registerSetString(reg_p,"contentid", contentId)
			end
		end
	end
	enterLoading(loadarea)
	if videotype == "group" then
		local reg = registerCreate("history")
		registerSetInteger(reg,"index",num)
		require "module.protocol.protocol_infolabel"
		Requestlabel(104,urlpath)
	elseif videotype == "live" then
		local reg = registerCreate("history")
		registerSetInteger(reg,"index",num)
		require ("module.protocol.protocol_systime")
		RequestSysTime(113)
		require("module.protocol.protocol_channel")
		RequestChannel(105,urlpath)
	else
		RequestHistoryVideo(102, playurl, urlpath, videoname, videotype)
		if videotype == "demand" then
			WriteLogs("demand RequestVolume")
			require "module.protocol.protocol_infovolume"
			require("module.setting")
			local reg_video = registerCreate("video")
			if Cfg.GetVideoType() == ".cmtv" then
				registerSetString(reg_video, "IsReview", isReview)
			end
			if isReview == "true" then
				registerSetString(reg_video, "historyReview", "true")
			end
			RequestVolume(999, urlpath)
		end
	end
	if videotype=="local" then
		exitLoading()
		SetReturn(sceneHistory,sceneVideolocal)
		Go2Scene(sceneVideolocal)
	end
	SetSpriteFocus(sprite)
	saveTouchFocus(sprite)
	return 1
end

function DeleteHistory()
	require "module.setting"
	local reg = registerCreate("history")
	local num = registerGetInteger(reg,"deletenum")
	local regVideoList = registerCreate("historyVideoList")
	local filename = Cfg.GetTempPath("history.xml")
	registerLoad(regVideoList, filename)
	local strData = registerGetString(regVideoList, "history"..count)
	local strRepalceData = registerGetString(regVideoList, "history"..num)
	registerSetString(regVideoList, "history" ..num, strData)
	registerRemove(regVideoList,"history"..count)
	registerSetInteger(regVideoList, "historyItemCount", count-1)
	local i = string.find(strRepalceData,"{")
	local j = string.find(strRepalceData,"}")
	local contentId = string.sub(strRepalceData,i+1,j-1)
	if contentId and contentId ~="" then
		local historyContent = registerGetString(regVideoList, "historyContent")
		local replaceStr = string.gsub(historyContent, contentId..",", "")
		WriteLogs("replaceStr:"..replaceStr)
		registerSetString(regVideoList, "historyContent",replaceStr)
	end
	registerSave(regVideoList, filename)
	registerRelease("historyVideoList")
end

function ClearHistory()
    require "module.setting"
	local regVideoList = registerCreate("historyVideoList")
	registerSave(regVideoList, "MODULE:\\..\\temp\\history.xml")
	local filename = Cfg.GetTempPath("history.xml");
	
	registerLoad(regVideoList, filename)
	
	for n=1,count do
		registerRemove(regVideoList,"name"..n)
		registerRemove(regVideoList,"playurl"..n)
		registerRemove(regVideoList,"pathurl"..n)
		registerRemove(regVideoList,"date"..n)
		registerRemove(regVideoList,"videoType"..n)
	end
	registerSetInteger(regVideoList, "count",0)
	registerSave(regVideoList, filename)
	registerRelease("historyVideoList")	
end

--filter={"*.3gp","*.dat"}
function SelectExistVideoList()
	WriteLogs("SelectExistVideoList count "..count)
	--local folder = GetModuleFolder()
	require "module.setting"
	local filter = Cfg.GetFilter();
	local dlfolder = Cfg.GetPhoneDownloadPath();
	local localcount = 0
	local localname = {}
	for n = 1 ,table.maxn(filter) do
		dir = OpenDirectory( dlfolder..filter[n])	
		if dir~=nil then	
			for i = 0, table.maxn(dir) do
				localname[localcount+1] = dir[i].filename
				WriteLogs(localname[localcount+1])
				localcount = localcount + 1			
			end
		end		
	end	

	delindex = {}
	extindex = {}
	delcount = 0
	extcount = 0
	for n=1,count do
		if historyvideoType[n] == "local" then
			local name = historyname[n]
			local exist = 0
			for i = 1,localcount do
				if name == localname[i] then
					exist = 1
					break
				end
			end
			if  exist == 0 then
				delcount = delcount+1
				delindex[delcount] = n 
			elseif exist == 1 then
				extcount = extcount+1
				extindex[extcount] = n 
			end
		else
		 	extcount = extcount+1
			extindex[extcount] = n 
		end		
	end
	
	require "module.setting"
	local regVideoList = registerCreate("historyVideoList")
	local filename = Cfg.GetTempPath("history.xml");
	
	registerLoad(regVideoList, filename)
	
	if extcount > 0 and delcount > 0 then
		begin1 = 1
		begin2 = extcount
		while extindex[begin2] > delindex[begin1] do
			local index1 = extindex[begin2]
			local index2 = delindex[begin1]
			begin1 = begin1+1
			begin2 = begin2-1
			historyplayurl1 = registerGetString(regVideoList, "playurl" ..index1)
			historypathurl1 = registerGetString(regVideoList, "pathurl" ..index1)
			historydate1 = registerGetString(regVideoList, "date" ..index1)
			historyname1 = registerGetString(regVideoList, "name" ..index1)
			historyvideoType1 = registerGetString(regVideoList, "videoType" ..index1)	
			registerSetString(regVideoList, "playurl" ..index2, historyplayurl1)
			registerSetString(regVideoList, "pathurl" ..index2, historypathurl1)
			registerSetString(regVideoList, "date" ..index2, historydate1)
			registerSetString(regVideoList, "name" ..index2, historyname1)
			registerSetString(regVideoList, "videoType"..index2, historyvideoType1)	
		end
	end
	
	for n=count-delcount+1,count do	
		registerRemove(regVideoList,"name"..n)
		registerRemove(regVideoList,"playurl"..n)
		registerRemove(regVideoList,"pathurl"..n)
		registerRemove(regVideoList,"date"..n)
		registerRemove(regVideoList,"videoType"..n)
	end
	registerSetInteger(regVideoList, "count", count-delcount)
	registerSave(regVideoList, filename)
	registerRelease("historyVideoList")
end

function OnSpriteEvent(message, params)
	if message == 1001 then
		local reg = registerCreate("history")
		local dlgnum = registerGetInteger(reg,"dialognum")
		WriteLogs("dlgnum "..dlgnum)
		if dlgnum == 1 then
			DeleteHistory()
			WriteLogs("SetTimer")
			SetTimer(1, 1000, "OnTimer")
			enterLoading(FindChildSprite(GetCurScene(), "loadarea"))
		elseif dlgnum == 2 then
			ClearHistory()
			WriteLogs("SetTimer2")
			SetTimer(1, 100, "OnTimer2")
			enterLoading(FindChildSprite(GetCurScene(), "loadarea"))
		elseif dlgnum == 3 then
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			Go2Scene(sceneHistory)
		elseif dlgnum == 4 then
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			Go2Scene(sceneHistory)
		end
	elseif message == 1002 then
	end
end

function OnTimer()
	exitLoading()
	WriteLogs("Ontimer ")
	local reg = registerCreate("history")
	local spriteRoot = registerGetInteger(reg,"root")
	local spriteEvent = FindChildSprite(spriteRoot, "event")
	WriteLogs("spriteEvent---"..spriteEvent)
	registerSetInteger(reg,"dialognum",3)
	setDialogParam("删除历史记录", "删除历史记录完成!", "BT_OK", sceneHistory, sceneHistory, spriteEvent)
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位 add by yao
	local curScene=registerSetString(SceneReg,"SceneName","history") --add by yao
	Go2Scene(sceneDialog)
end

function OnTimer2()
	exitLoading()
	WriteLogs("Ontimer2 ")
	local reg = registerCreate("history")
	local spriteRoot = registerGetInteger(reg,"root")
	local spriteEvent = FindChildSprite(spriteRoot, "event")
	registerSetInteger(reg,"dialognum",4)
	setDialogParam("清空历史记录", "清空历史记录完成!", "BT_OK", sceneHistory, sceneHistory, spriteEvent)
	local SceneReg=registerCreate("SceneNameReg")			---判断当前String页面标志位 add by yao
	local curScene=registerSetString(SceneReg,"SceneName","history") --add by yao
	Go2Scene(sceneDialog)
end

function OnPluginEvent(message, param)
	require "module.videoexpress-common"
	require("module.common.registerScene")
	if message == 101 then
		exitLoading()
		RequestPlay(sceneHistory)
	elseif	message == 102 then
		exitLoading()
		local labelSprite = GetCurScene()
		FreeScene(labelSprite)
		RequestPlay(sceneHistory)
	elseif message == 103 then
		local volumeData = OnVolumeDecode()
		WriteLogs("volume decode end")
		if volumeData then
			exitLoading()		
			SetReturn(sceneHistory,scenePrograminfo_volume)
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			GoAndFreeScene(scenePrograminfo_volume)
		else
		--[[  出错提示  ]]--
		end		
	elseif message == 104 then
		local labelData = OnLabelDecode()
		WriteLogs("label decode end")
		if labelData then
			local reg = registerCreate("history")
			local num = registerGetInteger(reg,"index")
			local reg_d = registerCreate("download_select")
			registerSetString(reg_d,"filepath",historypathurl[num])
			require "module.protocol.protocol_videoloading"
			WriteLogs("RequestVideo group")
			local labelSprite = GetCurScene()
			FreeScene(labelSprite)
			RequestVideo(101,historyplayurl[num], historypathurl[num], historyname[num] ,"group")
		end
	elseif message == 105 then
		local reg = registerCreate("history")
		local num = registerGetInteger(reg,"index")
		RequestVideo(106, historyplayurl[num], historypathurl[num], historyname[num] ,"live")
	elseif message == 106 then
		exitLoading()
		RequestPlay(sceneHistory)
	elseif message == 108 then
		exitLoading()
		require("module.protocol.protocol_channel")
		local jason = ChannelNetworkData()
		if jason.imgListNavi and jason.programList then
			WriteLogs("ChangeToProduct")
			GoAndFreeScene("MODULE:\\product.xml")
		else
			require("module.dialog.useDialog")
			setDialogParam("提示", "该栏目尚在建设中", "BT_OK", sceneHistory, sceneHistory, GetCurScene())
			Go2Scene(sceneDialog)
		end
	elseif message == 109 then
		require("module.protocol.protocol_infolabel")
		local json = OnLabelDecode()
		exitLoading()
		if json ~= nil and json ~= "" then
			SetReturn(sceneProduct,scenePrograminfo_label)
			GoAndFreeScene(scenePrograminfo_label)
		end
	elseif MSG_SMS_ID == message then
		DealMsgContent(sceneHistory, sceneHistory)
	end
end
--@brief 响应列表播放按钮键盘事件
--@auther  dw

function emptyKeyUp(sprite,keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	require("module.keyCode.keyCode")
	WriteLogs("keyCode:"..keyCode)
	if keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
	return 0
end


function buttonOnKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local root = GetRootSprite(sprite)
	local itemCount=SpriteList_GetListItemCount(history_list)
	WriteLogs("itemCount="..itemCount)
	local item=GetSpriteParent(GetSpriteParent(sprite))
	local index=SpriteListItem_GetIndex(item)
	WriteLogs("当前index"..index)
	local spriteSel = FindChildSprite(item,"select")
	local spriteUnSel = FindChildSprite(item,"unselect")
	local playSpriteButton = FindChildSprite(FindChildSprite(item,"select"), "playbutton")
	local detailSpriteButton = FindChildSprite(FindChildSprite(item,"select"),"detailbutton")
	local deleteSpriteButton = FindChildSprite(FindChildSprite(item,"select"),"delete")
	local result = IsSpriteEnable(detailSpriteButton)
	local name = GetSpriteName(sprite)
	require("module.keyCode.keyCode")
	WriteLogs("~~~~~~~~~~~buttonOnKeyUp："..keyCode)
	local list_x, list_y2, list_w, list_h = GetSpriteRect(history_list)
	local _, list_y1 = GetSpriteRect(item)
	local list_y = list_y1+list_y2
	
	if	keyCode==ApKeyCode_Enter then
		WriteLogs("Enter 当前index"..index)
		if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
			local i=1
			SetSpriteVisible(spriteSel, 1)
			SetSpriteEnable(spriteSel, 1)
			SetSpriteVisible(spriteUnSel, 0)			
			SetSpriteEnable(spriteUnSel, 0)	
			local x, y, w, h = GetSpriteRect(item)
			SetSpriteRect(item, x, y, history_ItemWidth, history_SelectHeight)
			SetSpriteFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton"))
			saveTouchFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton"))
			WriteLogs("焦点成功:"..HasSpriteFocus(FindChildSprite(FindChildSprite(item,"select"),"playbutton")))
			for j=index,itemCount-1 do
				
				spriteItem = SpriteList_GetListItem(history_list, index+i)
				i=i+1
				local x, y, w, h = GetSpriteRect(spriteItem)			
				SetSpriteRect(spriteItem,x,y+history_NormalHeight,w,h)
			end
		elseif GetSpriteName(GetSpriteParent(sprite))=="select" then
			if GetSpriteName(sprite)=="playbutton" then playButtonOnSelect(sprite)
			elseif GetSpriteName(sprite)=="detailbutton" then detailButtonOnSelect(sprite)
			elseif GetSpriteName(sprite)=="delete" then deleteButtonOnSelect(sprite)
			end										
		end		
		if list_y >= 195 then
			SetSpriteRect(history_list,list_x, list_y2-history_NormalHeight,list_w, list_h)
			ChangeScrollPositon(sprite,"down")
		end
		SpriteList_Adjust(history_list)		
	elseif keyCode == ApKeyCode_Left then
		if name == "delete" then
				if result == 0 then
						SetSpriteFocus(playSpriteButton)
						saveTouchFocus(playSpriteButton)
					else
						SetSpriteFocus(detailSpriteButton)
						saveTouchFocus(detailSpriteButton)
				end
		elseif name == "detailbutton" then
				SetSpriteFocus(playSpriteButton)
				saveTouchFocus(playSpriteButton)
		end	
	elseif keyCode==ApKeyCode_Right then
			WriteLogs("右移动")
			if name == "playbutton" then
				if result == 0 then
					SetSpriteFocus(deleteSpriteButton)
					saveTouchFocus(deleteSpriteButton)
				else
					SetSpriteFocus(detailSpriteButton)
					saveTouchFocus(detailSpriteButton)
				end
			elseif name == "detailbutton" then
				SetSpriteFocus(deleteSpriteButton)
				saveTouchFocus(deleteSpriteButton)
			end
	
	elseif keyCode==ApKeyCode_Down  and index<=itemCount-1 then
			WriteLogs("下移动")
			if index==itemCount-1 then return 0 end
				if GetSpriteName(GetSpriteParent(sprite))=="unselect" then
					local nextListItem = SpriteList_GetListItem(history_list, index+1)			
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
				elseif	GetSpriteName(GetSpriteParent(sprite))=="select" then
					local i=1
					local nextListItem = SpriteList_GetListItem(history_list, index+1)
					
					WriteLogs("下焦点："..SpriteListItem_GetIndex(nextListItem))
					SetSpriteVisible(spriteSel, 0)
					SetSpriteEnable(spriteSel, 0)
					SetSpriteVisible(spriteUnSel, 1)			
					SetSpriteEnable(spriteUnSel, 1)		
					local x, y, w, h = GetSpriteRect(item)							
					SetSpriteRect(item, x, y, 222,25)
					local spriteSelNext = FindChildSprite(nextListItem,"select")
					local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
					SetSpriteVisible(spriteSelNext, 0)
					SetSpriteEnable(spriteSelNext, 0)
					SetSpriteVisible(spriteUnSelNext, 1)			
					SetSpriteEnable(spriteUnSelNext, 1)		
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					for j=index,itemCount-1 do
						
						spriteItem = SpriteList_GetListItem(history_list, index+i)
						i=i+1
						local x, y, w, h = GetSpriteRect(spriteItem)			
						SetSpriteRect(spriteItem,x,y-history_NormalHeight,w,h)
					end
				end
			if list_y >= 195 then
			SpriteScrollBar_Adjust(history_list)
			SetSpriteRect(history_list,list_x, list_y2-history_NormalHeight,list_w, list_h)
			ChangeScrollPositon(sprite,"down")
			end	
	elseif 	keyCode==ApKeyCode_Up and index>=1 then
			WriteLogs("上移动 ")
					if index==0 then return 0 end
					local i=1
					local nextListItem = SpriteList_GetListItem(history_list, index-1)
			if 		GetSpriteName(GetSpriteParent(sprite))=="unselect" then
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
			elseif	GetSpriteName(GetSpriteParent(sprite))=="select" then
					WriteLogs("上焦点："..SpriteListItem_GetIndex(nextListItem))
					SetSpriteVisible(spriteSel, 0)
					SetSpriteEnable(spriteSel, 0)
					SetSpriteVisible(spriteUnSel, 1)			
					SetSpriteEnable(spriteUnSel, 1)		
					local x, y, w, h = GetSpriteRect(item)							
					SetSpriteRect(item, x, y, 222,25)
					local spriteSelNext = FindChildSprite(nextListItem,"select")
					local spriteUnSelNext = FindChildSprite(nextListItem,"unselect")
					SetSpriteVisible(spriteSelNext, 0)
					SetSpriteEnable(spriteSelNext, 0)
					SetSpriteVisible(spriteUnSelNext, 1)			
					SetSpriteEnable(spriteUnSelNext, 1)		
					SetSpriteFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					saveTouchFocus(FindChildSprite(FindChildSprite(nextListItem,"unselect"),"item-button"))
					for j=index,itemCount-1 do
						spriteItem = SpriteList_GetListItem(history_list, index+i)
						i=i+1
						local x, y, w, h = GetSpriteRect(spriteItem)			
						SetSpriteRect(spriteItem,x,y-history_NormalHeight,w,h)
					end
				
			end
			if list_y <= 10 then
				SpriteScrollBar_Adjust(history_list)
				SetSpriteRect(history_list,list_x, list_y2+history_NormalHeight,list_w, list_h)
				ChangeScrollPositon(sprite,"up")
			end
	----------------------------add by yaoxiangyin  2010.10.15-----------------------------------------------------
	elseif 	keyCode==ApKeyCode_Up and index==0 then
		WriteLogs("@@@@@@@@@@@@@@@@@@@@@@do edge operation")
		local clearBtn=FindChildSprite(root,"clearButton")
		SetSpriteFocus(clearBtn)
		saveTouchFocus(clearBtn)
		local x, y, w, h = GetSpriteRect(item)							
		SetSpriteRect(item, x, y, 222,25)
		SetSpriteVisible(spriteSel, 0)
		SetSpriteEnable(spriteSel, 0)
		SetSpriteVisible(spriteUnSel, 1)			
		SetSpriteEnable(spriteUnSel, 1)
		if 	GetSpriteName(GetSpriteParent(sprite))=="select" then
			local i=1
			for j=index,itemCount-2 do
				local spriteItem = SpriteList_GetListItem(history_list, index+i)
				i=i+1
				local x, y, w, h = GetSpriteRect(spriteItem)
				SetSpriteRect(spriteItem,x,y-history_NormalHeight,w,h)
			end
		end
	---------------------------------------------------------------------------------------------------------------
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2  then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	
	elseif keyCode == ApKeyCode_CharB then
		if itemCount ~= 0 then
			WriteLogs("#号键激活")
			local clearButton = FindChildSprite(root, "clearButton")
			clearButtonOnSelect(clearButton)
			WriteLogs("爆破end")
		end
	end
end

-------------------add by yaoxiangyin  2010.10.15-------------------------------------------------
function clearButtonKeyUp(sprite, keyCode)
	local ToDigReg = registerCreate("ToDigReg")
	registerSetInteger(ToDigReg,"ToDigFocus",sprite)
	registerSetInteger(ToDigReg,"KeyFlag",1)
	local root = GetRootSprite(sprite)
	local spriteList=FindChildSprite(root,"history-list")
	local itemCount=SpriteList_GetListItemCount(spriteList)
	if keyCode==ApKeyCode_Down then
		if itemCount>0 then
			local firstItem=SpriteList_GetListItem(spriteList,0)
			local firstBtn=FindChildSprite(firstItem,"item-button")
			SetSpriteFocus(firstBtn)
			saveTouchFocus(firstBtn)
		end
	elseif keyCode==ApKeyCode_Enter or keyCode==ApKeyCode_CharB then
		if itemCount ~= 0 then
			clearButtonOnSelect(sprite)
		end
	elseif keyCode == ApKeyCode_F1 then
		require("module.sysmenu")
		require("module.menuopen")
		local homeLastFoucsReg= registerCreate("homeLastFoucs")
		registerSetInteger(homeLastFoucsReg,"lastFocusSprite",sprite)
		SysGetSeceSprite(sprite)
		menuButtonOnSelect(sprite)
	elseif keyCode == ApKeyCode_F2 then
		require("module.menuopen")
		returnButtonOnSelect(sprite)
	end
end
-----------------------------------------------------------------------------------------------
--@function ChangeScrollPositon
--@brief 移动滑块的私有方法，区分向上向下按键动作，并使滑块随之移动
function ChangeScrollPositon(sprite,direction)
	local spriteitem = GetSpriteParent(GetSpriteParent(sprite))
	local CurIndex = SpriteListItem_GetIndex(spriteitem)
	WriteLogs("liuchaobing test spriteitem name is "..GetSpriteName(spriteitem))
	WriteLogs("liuchaobing test spriteitem index is "..CurIndex)
	if direction == "up" then
		ScrollBarAdjust(CurIndex - 1,4,0)
	else
		ScrollBarAdjust(CurIndex + 1,4,1)
	end
end