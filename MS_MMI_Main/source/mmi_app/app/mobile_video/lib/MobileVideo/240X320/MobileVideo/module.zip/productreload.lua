-- @author shy
-- @date 2010/07/22
-- @brief reload product data
function ReloadProductData()
	require("module.common.commonMsg")
	local reg = registerCreate("product")
	local product = registerGetInteger(reg, "root")
	
	if product and product ~= 0 then
		WriteLogs("ReloadProductData SendSpriteEvent")
		SendSpriteEvent(product, MSG_RELOAD)
	end
end